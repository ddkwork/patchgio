package gvcode

import (
	"image"
	stdColor "image/color"
	"strings"

	"gioui.org/f32"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/op/clip"
	"gioui.org/op/paint"
	"gioui.org/text"
	"gioui.org/unit"
	gvcolor "github.com/oligo/gvcode/color"
	"github.com/oligo/gvcode/lsp"
	"github.com/oligo/gvcode/textstyle/decoration"
)

const (
	diagnosticsSource = "_diagnostics"
	todoSource        = "_todo"
)

// withLanguageService attaches the analysis results to the editor.
type languageService struct {
	server  lsp.Server
	rev     uint64
	version int

	diagnostics []lsp.Diagnostic
	symbols     []lsp.DocumentSymbol
	inlay       []lsp.InlayHint
	semantic    []lsp.SemanticToken
	lenses      []lsp.CodeLens

	// usagePos / usageReady / usageSelection cache the caret the usage highlight
	// was computed for, and usage holds the ranges it marked; see navigation.go.
	usagePos       lsp.Position
	usageReady     bool
	usageSelection bool
	usage          []lsp.Location

	// intentions holds the code actions the last Alt+Enter produced, so
	// ApplyCodeAction can run one after the host showed its menu.
	intentions []lsp.CodeAction

	// quickDoc and parameterInfo are the two IDEA popups this layer renders.
	quickDoc      *textPopup
	parameterInfo *textPopup
}

// textPopup is a small bounded text box painted near the caret.
type textPopup struct {
	title string
	lines []string
}

// WithLanguageServer connects a language server. The editor runs its analyses
// once per document change and turns the results into squiggles, TODO
// highlighting, inlay hints and the quick-documentation / parameter-info popups.
// MockServer is the drop-in stand-in until a real LSP client exists.
func WithLanguageServer(server lsp.Server) EditorOption {
	return func(e *Editor) {
		e.language = &languageService{server: server}
	}
}

// IntentionEvent carries the code actions available at the caret. The host shows
// them (a menu, usually) and calls ApplyCodeAction with the chosen index, which
// is how IntelliJ's Alt+Enter popup works.
type IntentionEvent struct {
	Actions []lsp.CodeAction
	Pos     lsp.Position
}

func (IntentionEvent) isEditorEvent() {}

// document builds the LSP snapshot of the current text.
func (e *Editor) document() lsp.Document {
	svc := e.language
	svc.version++
	return lsp.Document{
		URI:        "inmemory://editor",
		LanguageID: "go",
		Version:    svc.version,
		Text:       e.Text(),
	}
}

// syncLanguage refreshes the analysis when the text changed since the last run.
// It is called once per frame from Layout, so a language server that is slow
// would have to debounce internally; the mock is pure syntax and cheap.
func (e *Editor) syncLanguage() {
	svc := e.language
	if svc == nil || svc.server == nil {
		return
	}
	rev := e.buffer.Revision()
	if svc.rev != rev || svc.rev == 0 {
		svc.rev = rev

		doc := e.document()
		svc.diagnostics = svc.server.Diagnostics(doc)
		svc.symbols = svc.server.DocumentSymbols(doc)
		svc.inlay = svc.server.InlayHints(doc, lsp.Range{
			Start: lsp.Position{},
			End:   e.positionAt(e.Len()),
		})
		svc.lenses = svc.server.CodeLenses(doc)
		if tokens := svc.server.SemanticTokens(doc); tokens != nil {
			svc.semantic = tokens.Data
		} else {
			svc.semantic = nil
		}

		e.applyLanguageDecorations()
	}

	// The caret moves far more often than the text does, so the usage scan is
	// keyed on the caret rather than folded into the analysis above.
	e.syncUsageHighlighting()
}

// applyLanguageDecorations paints the diagnostics as squiggles and the TODO
// comments as a highlighted run, the way IntelliJ marks them.
func (e *Editor) applyLanguageDecorations() {
	svc := e.language
	e.ClearDecorations(diagnosticsSource)
	e.ClearDecorations(todoSource)

	var diags, todos []decoration.Decoration
	for _, d := range svc.diagnostics {
		start, end := e.offsetAt(d.Range.Start), e.offsetAt(d.Range.End)
		if start == end {
			end = start + 1
		}
		if end > e.Len() {
			end = e.Len()
		}
		if start >= end {
			continue
		}
		switch d.Severity {
		case lsp.SeverityError:
			diags = append(diags, decoration.Decoration{
				Source: diagnosticsSource, Start: start, End: end,
				Squiggle: &decoration.Squiggle{Color: gvcolor.MakeColor(errorSquiggleColor)},
			})
		case lsp.SeverityWarning:
			diags = append(diags, decoration.Decoration{
				Source: diagnosticsSource, Start: start, End: end,
				Squiggle: &decoration.Squiggle{Color: gvcolor.MakeColor(warningSquiggleColor)},
			})
		case lsp.SeverityInformation:
			if d.Code == "todo" {
				todos = append(todos, decoration.Decoration{
					Source: todoSource, Start: start, End: end,
					Background: &decoration.Background{Color: gvcolor.MakeColor(todoBackground)},
					Bold:       true,
				})
			}
		}
	}
	if len(diags) > 0 {
		_ = e.AddDecorations(diags...)
	}
	if len(todos) > 0 {
		_ = e.AddDecorations(todos...)
	}
}

var (
	errorSquiggleColor   = stdColor.NRGBA{R: 0xDB, G: 0x5C, B: 0x5C, A: 0xFF}
	warningSquiggleColor = stdColor.NRGBA{R: 0xE8, G: 0xA4, B: 0x4A, A: 0xFF}
	todoBackground       = stdColor.NRGBA{R: 0xFF, G: 0xD7, B: 0x00, A: 0x40}
)

// --------------------------------------------------------------- public API

// Diagnostics returns the problems of the current text.
func (e *Editor) Diagnostics() []lsp.Diagnostic {
	if e.language == nil {
		return nil
	}
	return e.language.diagnostics
}

// LanguageSymbols returns the document outline.
func (e *Editor) LanguageSymbols() []lsp.DocumentSymbol {
	if e.language == nil {
		return nil
	}
	return e.language.symbols
}

// SemanticTokens returns the semantic classification of the document. It is not
// applied automatically: the application owns syntax highlighting and merges
// these tokens itself.
func (e *Editor) SemanticTokens() []lsp.SemanticToken {
	if e.language == nil {
		return nil
	}
	return e.language.semantic
}

// InlayHints returns the hints currently painted.
func (e *Editor) InlayHints() []lsp.InlayHint {
	if e.language == nil {
		return nil
	}
	return e.language.inlay
}

// SymbolPath returns the outline entries containing pos, outermost first. It is
// what a breadcrumb trail renders.
func (e *Editor) SymbolPath() []lsp.DocumentSymbol {
	svc := e.language
	if svc == nil {
		return nil
	}
	pos := e.positionAt(e.caretOffset())
	var path []lsp.DocumentSymbol
	for _, s := range svc.symbols {
		if containsPosition(s.Range, pos) {
			path = append(path, s)
		}
	}
	return path
}

func containsPosition(r lsp.Range, p lsp.Position) bool {
	if p.Line < r.Start.Line || p.Line > r.End.Line {
		return false
	}
	if p.Line == r.Start.Line && p.Character < r.Start.Character {
		return false
	}
	if p.Line == r.End.Line && p.Character > r.End.Character {
		return false
	}
	return true
}

// CodeActionsAt returns the quick fixes and intentions available at the caret.
func (e *Editor) CodeActionsAt() []lsp.CodeAction {
	svc := e.language
	if svc == nil || svc.server == nil {
		return nil
	}
	pos := e.positionAt(e.caretOffset())
	rng := lsp.Range{Start: pos, End: pos}
	var local []lsp.Diagnostic
	for _, d := range svc.diagnostics {
		if containsPosition(d.Range, pos) {
			local = append(local, d)
		}
	}
	return svc.server.CodeActions(e.document(), rng, local)
}

// RequestIntentions is Alt+Enter: it collects the actions at the caret and, when
// there is more than one, hands them to the host through an IntentionEvent so it
// can show IntelliJ's intention popup. A single action is applied directly.
func (e *Editor) RequestIntentions() (EditorEvent, bool) {
	svc := e.language
	if svc == nil {
		return nil, false
	}
	actions := e.CodeActionsAt()
	if len(actions) == 0 {
		return nil, false
	}
	svc.intentions = actions
	if len(actions) == 1 {
		e.ApplyCodeAction(0)
		return ChangeEvent{}, true
	}
	return IntentionEvent{Actions: actions, Pos: e.positionAt(e.caretOffset())}, true
}

// ApplyCodeAction runs one of the actions RequestIntentions collected. The edits
// are LSP ranges, so they go through the shared edit path (see
// applyTextEdits), which applies them from the end of the document backwards.
func (e *Editor) ApplyCodeAction(idx int) bool {
	svc := e.language
	if svc == nil || idx < 0 || idx >= len(svc.intentions) {
		return false
	}
	if !e.applyTextEdits(svc.intentions[idx].Edits) {
		return false
	}
	svc.intentions = nil
	svc.rev = 0 // force a re-analysis on the next frame
	return true
}

// ShowQuickDocumentation is IntelliJ's Ctrl+Q: it shows the hover contents of the
// symbol at the caret in a popup. Calling it again hides the popup.
func (e *Editor) ShowQuickDocumentation() bool {
	svc := e.language
	if svc == nil || svc.server == nil {
		return false
	}
	if svc.quickDoc != nil {
		svc.quickDoc = nil
		return true
	}
	pos := e.positionAt(e.caretOffset())
	hover := svc.server.Hover(e.document(), pos)
	if hover == nil {
		return false
	}
	svc.quickDoc = &textPopup{title: "Documentation", lines: plainDocLines(hover.Contents)}
	return true
}

// ShowParameterInfo is IntelliJ's Ctrl+P: it shows the signature of the call the
// caret sits in and marks the active parameter.
func (e *Editor) ShowParameterInfo() bool {
	svc := e.language
	if svc == nil || svc.server == nil {
		return false
	}
	if svc.parameterInfo != nil {
		svc.parameterInfo = nil
		return true
	}
	pos := e.positionAt(e.caretOffset())
	help := svc.server.SignatureHelp(e.document(), pos)
	if help == nil || len(help.Signatures) == 0 {
		return false
	}
	sig := help.Signatures[help.ActiveSignature]
	popup := &textPopup{title: "Parameter Info", lines: []string{sig.Label}}
	if help.ActiveParameter >= 0 && help.ActiveParameter < len(sig.Parameters) {
		popup.lines = append(popup.lines, "", "current: "+sig.Parameters[help.ActiveParameter].Label)
	}
	if sig.Documentation != "" {
		popup.lines = append(popup.lines, "", sig.Documentation)
	}
	svc.parameterInfo = popup
	return true
}

// HidePopups closes the quick documentation and parameter info popups.
func (e *Editor) HidePopups() {
	if e.language == nil {
		return
	}
	e.language.quickDoc = nil
	e.language.parameterInfo = nil
}

// plainDocLines strips the markdown code fences a hover may use.
func plainDocLines(contents string) []string {
	var lines []string
	for _, line := range strings.Split(contents, "\n") {
		trimmed := strings.TrimSpace(line)
		if strings.HasPrefix(trimmed, "```") {
			continue
		}
		lines = append(lines, line)
	}
	return lines
}

// ------------------------------------------------------------- positions

func (e *Editor) caretOffset() int {
	start, end := e.Selection()
	if start > end {
		return end
	}
	return start
}

// positionAt converts a rune offset into a line/character position.
func (e *Editor) positionAt(off int) lsp.Position {
	runes := e.runes()
	if off > len(runes) {
		off = len(runes)
	}
	if off < 0 {
		off = 0
	}
	line, col := 0, 0
	for i := 0; i < off; i++ {
		if runes[i] == '\n' {
			line++
			col = 0
		} else {
			col++
		}
	}
	return lsp.Position{Line: line, Character: col}
}

// OffsetAt converts a line/character position into a rune offset, clamped to the
// document. It is the converter a host needs to merge semantic tokens (see
// MergeSemanticTokens) or to map its own navigation data onto the text.
func (e *Editor) OffsetAt(p lsp.Position) int { return e.offsetAt(p) }

// Revision returns a counter that changes whenever the text does, so a host can
// skip work that depends only on the document.
func (e *Editor) Revision() uint64 {
	e.initBuffer()
	return e.buffer.Revision()
}

// SemanticRevision returns the document revision the current semantic analysis
// was computed from, or 0 before the first analysis. A host that merges
// SemanticTokens re-merges when this changes.
func (e *Editor) SemanticRevision() uint64 {
	if e.language == nil {
		return 0
	}
	return e.language.rev
}

// offsetAt converts a line/character position into a rune offset.
func (e *Editor) offsetAt(p lsp.Position) int {
	runes := e.runes()
	off, line := 0, 0
	for off < len(runes) && line < p.Line {
		if runes[off] == '\n' {
			line++
		}
		off++
	}
	off += p.Character
	if off > len(runes) {
		off = len(runes)
	}
	if off < 0 {
		off = 0
	}
	return off
}

// --------------------------------------------------------------- painting

// paintLanguageOverlays draws the inlay hints and the two language popups.
func (e *Editor) paintLanguageOverlays(gtx layout.Context, shaper *text.Shaper) {
	svc := e.language
	if svc == nil || shaper == nil {
		return
	}
	e.paintInlayHints(gtx, shaper)
	e.paintCodeLenses(gtx, shaper)
	if svc.parameterInfo != nil {
		e.paintPopup(gtx, shaper, svc.parameterInfo, int(e.text.GetLineHeight().Ceil()))
	}
	if svc.quickDoc != nil {
		e.paintPopup(gtx, shaper, svc.quickDoc, int(e.text.GetLineHeight().Ceil()))
	}
}

// paintInlayHints draws a dimmed label in front of every hinted position. The
// hint is an overlay, not part of the text, so it never shifts the glyphs.
func (e *Editor) paintInlayHints(gtx layout.Context, shaper *text.Shaper) {
	svc := e.language
	if len(svc.inlay) == 0 {
		return
	}
	viewport := e.text.Viewport()
	params := e.text.Params()
	params.MinWidth = 0
	params.MaxLines = 1
	lineHeight := int(e.text.GetLineHeight().Ceil())

	for _, hint := range svc.inlay {
		if hint.Position.Line*lineHeight > viewport.Max.Y ||
			(hint.Position.Line+1)*lineHeight < viewport.Min.Y {
			continue
		}
		off := e.offsetAt(hint.Position)
		coords := e.text.RuneCoords(off)
		// RuneCoords' Y is the line's BASELINE, which is exactly what the glyph
		// painting wants.
		e.paintTextAtBaseline(gtx, shaper, params, hint.Label,
			float32(coords.X), float32(coords.Y), inlayHintColor)
	}
}

// paintPopup paints a bordered box near the caret.
func (e *Editor) paintPopup(gtx layout.Context, shaper *text.Shaper, popup *textPopup, lineHeight int) {
	coords := e.text.CaretCoords()
	position := image.Pt(int(coords.X)+16, int(coords.Y)+lineHeight)
	e.PaintOverlay(gtx, position, func(gtx layout.Context) layout.Dimensions {
		return e.layoutPopupBox(gtx, shaper, popup)
	})
}

// layoutPopupBox measures and paints the popup content; PaintOverlay draws the
// drop shadow behind it.
func (e *Editor) layoutPopupBox(gtx layout.Context, shaper *text.Shaper, popup *textPopup) layout.Dimensions {
	params := e.text.Params()
	params.MinWidth = 0
	params.MaxLines = 1
	lineHeight := int(e.text.GetLineHeight().Ceil())

	lines := popup.lines
	if popup.title != "" {
		lines = append([]string{popup.title}, lines...)
	}
	pad := gtx.Dp(unit.Dp(8))
	width := 0
	for _, line := range lines {
		if w := measureString(shaper, params, line); w > width {
			width = w
		}
	}
	if maxWidth := max(gtx.Constraints.Max.X, 1); width+2*pad > maxWidth {
		width = max(maxWidth-2*pad, 0)
	}
	size := image.Pt(width+2*pad, len(lines)*lineHeight+2*pad)

	// The overlay itself paints no background, so the popup owns its frame.
	rr := clip.UniformRRect(image.Rectangle{Max: size}, gtx.Dp(unit.Dp(4)))
	paint.FillShape(gtx.Ops, popupBackground, rr.Op(gtx.Ops))
	stroke := clip.Stroke{Path: rr.Path(gtx.Ops), Width: float32(gtx.Dp(unit.Dp(1)))}.Op().Push(gtx.Ops)
	paint.ColorOp{Color: popupBorder}.Add(gtx.Ops)
	paint.PaintOp{}.Add(gtx.Ops)
	stroke.Pop()

	for i, line := range lines {
		col := popupTextColor
		if i == 0 && popup.title != "" {
			col = popupTitleColor
		}
		e.paintTextRun(gtx, shaper, params, line, float32(pad), float32(pad+i*lineHeight), col)
	}
	return layout.Dimensions{Size: size}
}

var (
	inlayHintColor  = stdColor.NRGBA{R: 0x7A, G: 0x7E, B: 0x85, A: 0xFF}
	popupTextColor  = stdColor.NRGBA{R: 0xD4, G: 0xD4, B: 0xD4, A: 0xFF}
	popupTitleColor = stdColor.NRGBA{R: 0x9A, G: 0x9A, B: 0x9A, A: 0xFF}
	popupBackground = stdColor.NRGBA{R: 0x2B, G: 0x2B, B: 0x2B, A: 0xF2}
	popupBorder     = stdColor.NRGBA{R: 0x4A, G: 0x4A, B: 0x4A, A: 0xFF}
)

// paintTextRun shapes one line and paints it at (x, y), where y is the text box
// top. It is the glyph-painting path the sticky band also uses.
func (e *Editor) paintTextRun(gtx layout.Context, shaper *text.Shaper, params text.Parameters, s string, x, y float32, col stdColor.NRGBA) {
	glyphs := shapeString(shaper, params, s)
	if len(glyphs) == 0 {
		return
	}
	baseline := y + float32(glyphs[0].Ascent.Ceil())
	e.paintGlyphs(gtx, shaper, glyphs, x, baseline, col)
}

// paintTextAtBaseline paints a single line whose y coordinate is the glyph
// baseline, which is the coordinate system a text layout works in.
func (e *Editor) paintTextAtBaseline(gtx layout.Context, shaper *text.Shaper, params text.Parameters, s string, x, baseline float32, col stdColor.NRGBA) {
	e.paintGlyphs(gtx, shaper, shapeString(shaper, params, s), x, baseline, col)
}

// shapeString shapes one line with the given parameters.
func shapeString(shaper *text.Shaper, params text.Parameters, s string) []text.Glyph {
	if shaper == nil || s == "" {
		return nil
	}
	params.MaxLines = 1
	params.MinWidth = 0
	shaper.LayoutString(params, s)
	glyphs := make([]text.Glyph, 0, 16)
	for {
		g, ok := shaper.NextGlyph()
		if !ok {
			break
		}
		glyphs = append(glyphs, g)
	}
	return glyphs
}

func (e *Editor) paintGlyphs(gtx layout.Context, shaper *text.Shaper, glyphs []text.Glyph, x, baseline float32, col stdColor.NRGBA) {
	if len(glyphs) == 0 {
		return
	}
	trans := op.Affine(f32.Affine2D{}.Offset(f32.Pt(x, baseline))).Push(gtx.Ops)
	path := shaper.Shape(glyphs)
	outline := clip.Outline{Path: path}.Op().Push(gtx.Ops)
	paint.ColorOp{Color: col}.Add(gtx.Ops)
	paint.PaintOp{}.Add(gtx.Ops)
	outline.Pop()
	trans.Pop()
}

// measureString returns the width of s in pixels: the last glyph's pen position
// plus its advance.
func measureString(shaper *text.Shaper, params text.Parameters, s string) int {
	if shaper == nil || s == "" {
		return 0
	}
	shaper.LayoutString(params, s)
	width := 0
	for {
		g, ok := shaper.NextGlyph()
		if !ok {
			break
		}
		width = g.X.Ceil() + g.Advance.Ceil()
	}
	return width
}
