package gutter

import (
	"image"

	"gioui.org/layout"
	"gioui.org/text"
	"gioui.org/unit"
	"gioui.org/widget/material"
	gvcolor "github.com/oligo/gvcode/color"
	lt "github.com/oligo/gvcode/internal/layout"
	"golang.org/x/image/math/fixed"
)

const (
	// LineNumberProviderID is the unique identifier for the line number provider.
	LineNumberProviderID = "linenumber"
)

// GutterProvider defines the interface for components that render content
// in the gutter area of the editor. Providers are rendered left-to-right
// sorted by their priority (lower priority = closer to text).
type GutterProvider interface {
	// ID returns a unique identifier for this provider.
	ID() string

	// Priority determines the rendering order. Lower values are rendered
	// closer to the text area (rightmost in the gutter).
	Priority() int

	// Width returns the width needed by this provider for the given context.
	// The lineCount parameter indicates the total number of lines in the document,
	// which can be used to calculate width (e.g., for line numbers).
	Width(gtx layout.Context, shaper *text.Shaper, params text.Parameters, lineCount int) unit.Dp

	// Layout renders the gutter content for the visible lines.
	Layout(gtx layout.Context, ctx GutterContext) layout.Dimensions
}

// LineContentProvider is an optional interface that GutterProviders can implement
// to receive the contents of visible lines for analysis.
type LineContentProvider interface {
	GutterProvider
	// SetLineContents sets the contents of all visible lines for analysis.
	// The startLine parameter indicates the absolute line number of the first line in the slice.
	SetLineContents(lines []string, startLine int)
}

// GutterContext provides the context needed for gutter providers to render
// their content. It includes information about the visible area, line metadata,
// and colors.
type GutterContext struct {
	// Shaper is the text shaper used for rendering text.
	Shaper *text.Shaper

	// TextParams contains the text parameters for shaping.
	TextParams text.Parameters

	// Viewport is the visible area in document coordinates.
	Viewport image.Rectangle

	// Paragraphs contains metadata for visible lines.
	Paragraphs []Paragraph

	// CurrentLine is the line number where the caret is located.
	// It is -1 if the selection spans multiple lines.
	CurrentLine int

	// LineHeight is the calculated line height in fixed-point format.
	LineHeight fixed.Int26_6

	// Colors provides the color scheme for gutter rendering.
	Colors *GutterColors

	// LineNumberWidth is the width of the line number column in pixels.
	// This is set by the gutter manager when a line number provider is present.
	LineNumberWidth int

	// LayoutLines contains the layout lines from the text layouter.
	// This is used by color indicators to get accurate glyph positions.
	LayoutLines []lt.Line
}

// Paragraph contains metadata about a paragraph (logical line) in the document.
type Paragraph struct {
	// StartY is the baseline Y coordinate of the first screen line in the paragraph.
	StartY int

	// EndY is the baseline Y coordinate of the last screen line in the paragraph.
	EndY int

	// Ascent is the distance from baseline to the top of glyphs.
	Ascent fixed.Int26_6

	// Descent is the distance from baseline to the bottom of glyphs.
	Descent fixed.Int26_6

	// Runes is the number of runes in this paragraph.
	Runes int
	// RuneOff is the rune offset of the first rune in this paragraph.
	RuneOff int

	// Index is the 0-based line number of this paragraph among the VISIBLE ones.
	Index int

	// LogicalIndex is the 0-based line number counting every paragraph, hidden by
	// folding included. The line number gutter prints it, so collapsing a fold
	// never renumbers the lines below, and Index keeps selecting the paragraph the
	// caret is on.
	LogicalIndex int
}

// GutterColors defines the color scheme for gutter rendering.
type GutterColors struct {
	// Text is the default text color for gutter content.
	Text gvcolor.Color

	// TextHighlight is the text color for highlighted content (e.g., current line number).
	TextHighlight gvcolor.Color

	// Background is the background color for the gutter area.
	Background gvcolor.Color

	// LineHighlight is the color used to highlight the current line background.
	LineHighlight gvcolor.Color

	// Custom contains provider-specific colors, keyed by provider ID or custom name.
	Custom map[string]gvcolor.Color
}

// LineHighlighter is an optional interface that GutterProviders can implement
// to specify lines that should be highlighted with a background color.
// The Editor will paint these highlights spanning the full editor width.
type LineHighlighter interface {
	// HighlightedLines returns the lines that should be highlighted.
	// This is called after Layout to collect highlights from all providers.
	HighlightedLines() []LineHighlight
}

// LineHighlight specifies a line to be highlighted with a background color.
type LineHighlight struct {
	// Line is the 0-based line index to highlight.
	Line int

	// Color is the background color for the highlight.
	Color gvcolor.Color
}

// RunButtonEvent represents a click event on a run button in the gutter.
type RunButtonEvent struct {
	// ButtonType is the type of button that was clicked.
	ButtonType int

	// Line is the 0-based line number where the button was clicked.
	Line int

	// ButtonText is the text content of the line containing the button.
	ButtonText string
}

// RunButtonType constants
const (
	RunButtonNone = iota
	RunButtonMain
	RunButtonTest
)

// MethodIconKind is the kind of inheritance marker IntelliJ draws in the gutter
// next to a method: the method overrides or implements one, or is itself
// overridden or implemented further down the hierarchy.
type MethodIconKind int

const (
	MethodIconNone MethodIconKind = iota
	// MethodOverrides draws IntelliJ's "O" with an up arrow.
	MethodOverrides
	// MethodImplements draws IntelliJ's "I" with an up arrow.
	MethodImplements
	// MethodOverridden draws the "O" with a down arrow.
	MethodOverridden
	// MethodImplemented draws the "I" with a down arrow.
	MethodImplemented
)

// MethodIconEvent represents a click on an inheritance marker in the gutter, so
// the application can navigate to the overridden or implemented method.
type MethodIconEvent struct {
	// Line is the 0-based DOCUMENT line of the marker.
	Line int
	// Kind is the marker that was clicked.
	Kind MethodIconKind
}

// ColorPickerLayout is an interface for color picker layout.
type ColorPickerLayout interface {
	Update(gtx layout.Context)
	Layout(gtx layout.Context, th *material.Theme) layout.Dimensions
	// SetOnColorChange registers a callback invoked when the user picks a new color.
	SetOnColorChange(callback func(oldText, newText string, start, end int))
}

// ColorPickerProvider is an interface for providers that can show a color picker.
type ColorPickerProvider interface {
	GutterProvider
	// ShowColorPicker returns whether the color picker should be shown.
	ShowColorPicker() bool
	// GetEditorColorPicker returns the editor color picker instance.
	GetEditorColorPicker() ColorPickerLayout
	// RenderInTextArea renders color indicators in the text area (not gutter).
	RenderInTextArea(gtx layout.Context, ctx GutterContext, gutterWidth int)
	// GetColorOffsets returns the character offsets where color indicators should be inserted.
	// Returns a map from line number to a slice of character offsets.
	GetColorOffsets() map[int][]int
	// GetIndicatorWidth returns the width of the color indicator in pixels.
	GetIndicatorWidth(gtx layout.Context) int
}

// StickyLineInfo describes one sticky line: a structure declaration that stays
// visible at the top of the editor after it scrolls out of view.
type StickyLineInfo struct {
	// Line is the 0-based DOCUMENT line the declaration is on.
	Line int
	// Text is the declaration's source line.
	Text string
	// Indent is the indentation level.
	Indent int
	// Type is the kind of structure (function, type, const, ...).
	Type string
}

// StickyLinesProvider is implemented by the gutter provider that draws sticky
// lines. Sticky lines live over the text area rather than inside the gutter's own
// input area, so the editor asks the provider which declaration a click at a
// given Y navigates to.
type StickyLinesProvider interface {
	GutterProvider

	// StickyLines returns the sticky lines currently shown, and the height in
	// pixels of the band they occupy at the top of the text area.
	StickyLines() ([]StickyLineInfo, int)

	// StickyLineAt reports the sticky line drawn at y, in text-area coordinates.
	// It returns false when y is outside the band.
	StickyLineAt(y int) (StickyLineInfo, bool)
}
