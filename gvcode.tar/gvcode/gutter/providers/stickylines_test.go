package providers

import "testing"

// TestStickyLinesAnalysisIsSkippedWhenTheDocumentIsUnchanged pins the cost of the
// whole-document analysis: the editor feeds this provider on every frame, and
// re-analysing an unchanged document every frame is what made large files
// stutter. Equal content must be recognised even when it arrives in a fresh
// slice, and a real edit must re-analyse.
func TestStickyLinesAnalysisIsSkippedWhenTheDocumentIsUnchanged(t *testing.T) {
	p := NewStickyLinesProvider()
	doc := []string{"package main", "", "func a() {", "\tprintln(1)", "}", ""}

	p.SetLineContents(doc, 0)
	if p.analysisRuns != 1 {
		t.Fatalf("analysisRuns = %d after the first feed, want 1", p.analysisRuns)
	}

	equal := append([]string(nil), doc...)
	p.SetLineContents(equal, 0)
	p.SetLineContents(doc, 0)
	if p.analysisRuns != 1 {
		t.Fatalf("analysisRuns = %d after re-feeding equal content, want 1", p.analysisRuns)
	}

	changed := []string{"package main", "", "func b() {", "\tprintln(2)", "}", ""}
	p.SetLineContents(changed, 0)
	if p.analysisRuns != 2 {
		t.Fatalf("analysisRuns = %d after the document changed, want 2", p.analysisRuns)
	}
	if len(p.structureCache) != 1 || p.structureCache[0].Line != 2 {
		t.Fatalf("structureCache = %+v, want the function on line 2", p.structureCache)
	}
}

// TestStickyLineAtMapsRowsAndRejectsClicksOutsideTheBand: the band owns the clicks
// that land inside it and nothing else, so a click below it stays a text click.
func TestStickyLineAtMapsRowsAndRejectsClicksOutsideTheBand(t *testing.T) {
	p := NewStickyLinesProvider()
	p.lineHeight = 10
	p.stickyLines = []StickyLineInfo{
		{Line: 3, Text: "func a() {"},
		{Line: 8, Text: "func b() {"},
	}
	p.stickyAreaHeight = len(p.stickyLines) * p.lineHeight

	if _, ok := p.StickyLineAt(-1); ok {
		t.Fatal("a negative y matched a sticky line")
	}
	if got, ok := p.StickyLineAt(0); !ok || got.Line != 3 {
		t.Fatalf("StickyLineAt(0) = %+v, %v; want line 3", got, ok)
	}
	if got, ok := p.StickyLineAt(15); !ok || got.Line != 8 {
		t.Fatalf("StickyLineAt(15) = %+v, %v; want line 8", got, ok)
	}
	if _, ok := p.StickyLineAt(20); ok {
		t.Fatal("a y below the band matched a sticky line")
	}
}
