package providers

import (
	"image"
	"image/color"

	"gioui.org/f32"
	"gioui.org/io/key"
	"gioui.org/io/pointer"
	"gioui.org/layout"
	"gioui.org/op/clip"
	"gioui.org/op/paint"
	"gioui.org/text"
	"gioui.org/unit"
	"github.com/oligo/gvcode/gutter"
)

const (
	// BookmarkProviderID is the unique identifier for the bookmark provider.
	BookmarkProviderID = "bookmark"
	// BreakpointProviderID is the unique identifier for the breakpoint provider.
	BreakpointProviderID = "breakpoint"

	// markSize is the width of a mark column in dp. It matches the other icon
	// columns of the gutter (method icons and run buttons).
	markSize = 16
	// markIconSize is the icon box inside the column.
	markIconSize = 12
)

// IntelliJ's gutter mark colours, from expui: a breakpoint is a red dot and a
// bookmark a blue-grey ribbon.
var (
	breakpointColor = color.NRGBA{R: 0xE0, G: 0x55, B: 0x55, A: 0xFF}
	breakpointRing  = color.NRGBA{R: 0x7A, G: 0x2B, B: 0x2B, A: 0xFF}
	bookmarkColor   = color.NRGBA{R: 0x6E, G: 0x9A, B: 0xCF, A: 0xFF}
)

// markProvider draws one gutter column of line marks (bookmarks or breakpoints).
// The lines come from a callback so the editor stays the single owner of the
// mark state and the provider never has to be re-registered.
type markProvider struct {
	id string
	// priority places the column inside the gutter; see Priority.
	priority int
	// lines reports the marked 0-based DOCUMENT lines.
	lines func() map[int]bool
	// toggle, when set, is called with the clicked document line.
	toggle func(line int) bool
	// draw paints one mark whose centre is at (cx, cy).
	draw func(gtx layout.Context, cx, cy, size float32)

	paragraphs []gutter.Paragraph
}

func (p *markProvider) ID() string { return p.id }

// Priority places the column: providers render left to right in descending
// priority, so breakpoints (110) sit left of the line numbers (100) and
// bookmarks (99) right of them, the way IntelliJ orders its gutter.
func (p *markProvider) Priority() int { return p.priority }

func (p *markProvider) Width(gtx layout.Context, shaper *text.Shaper, params text.Parameters, lineCount int) unit.Dp {
	return unit.Dp(markSize)
}

func (p *markProvider) Layout(gtx layout.Context, ctx gutter.GutterContext) layout.Dimensions {
	p.paragraphs = ctx.Paragraphs
	if p.lines == nil {
		return layout.Dimensions{}
	}
	lines := p.lines()
	if len(lines) == 0 {
		return layout.Dimensions{Size: image.Pt(gtx.Dp(unit.Dp(markSize)), 0)}
	}
	sizePx := gtx.Dp(unit.Dp(markSize))
	iconPx := float32(gtx.Dp(unit.Dp(markIconSize)))

	for _, para := range ctx.Paragraphs {
		if para.EndY < ctx.Viewport.Min.Y {
			continue
		}
		if para.StartY > ctx.Viewport.Max.Y {
			break
		}
		if !lines[para.LogicalIndex] {
			continue
		}
		p.draw(gtx, float32(sizePx)/2, lineCenterY(para, ctx.Viewport), iconPx)
	}
	return layout.Dimensions{Size: image.Pt(sizePx, 0)}
}

// HandleClick implements the InteractiveGutter interface: clicking the column
// toggles the mark on that line.
func (p *markProvider) HandleClick(line int, source pointer.Source, numClicks int, modifiers key.Modifiers) bool {
	logical := p.logicalLine(line)
	if logical < 0 {
		return false
	}
	if p.toggle == nil {
		return false
	}
	p.toggle(logical)
	return true
}

// HandleHover implements the InteractiveGutter interface.
func (p *markProvider) HandleHover(line int) *gutter.HoverInfo {
	logical := p.logicalLine(line)
	if logical < 0 {
		return nil
	}
	if p.lines != nil && p.lines()[logical] {
		return &gutter.HoverInfo{Text: "Click to remove"}
	}
	return &gutter.HoverInfo{Text: "Click to add"}
}

// logicalLine translates a visible paragraph index into the document line.
func (p *markProvider) logicalLine(visible int) int {
	for _, para := range p.paragraphs {
		if para.Index == visible {
			return para.LogicalIndex
		}
	}
	return -1
}

// NewBookmarkProvider draws IntelliJ's bookmark ribbons for the lines the
// callback reports.
func NewBookmarkProvider(lines func() map[int]bool, toggle func(line int) bool) *markProvider {
	return &markProvider{
		id: BookmarkProviderID, priority: 99, lines: lines, toggle: toggle,
		draw: drawBookmarkRibbon,
	}
}

// NewBreakpointProvider draws IntelliJ's red breakpoint dots.
func NewBreakpointProvider(lines func() map[int]bool, toggle func(line int) bool) *markProvider {
	return &markProvider{
		id: BreakpointProviderID, priority: 110, lines: lines, toggle: toggle,
		draw: drawBreakpointDot,
	}
}

// drawBreakpointDot paints IntelliJ's line breakpoint: a filled red circle with
// a darker ring.
func drawBreakpointDot(gtx layout.Context, cx, cy, size float32) {
	r := size / 2
	var path clip.Path
	path.Begin(gtx.Ops)
	path.MoveTo(f32.Pt(cx+r, cy))
	path.ArcTo(f32.Pt(cx, cy), f32.Pt(cx-r, cy), 2*3.14159265)
	path.Close()
	paint.FillShape(gtx.Ops, breakpointColor, clip.Outline{Path: path.End()}.Op())

	ring := clip.Stroke{
		Path:  markCirclePath(gtx, cx, cy, r),
		Width: float32(gtx.Dp(unit.Dp(1))),
	}.Op().Push(gtx.Ops)
	paint.ColorOp{Color: breakpointRing}.Add(gtx.Ops)
	paint.PaintOp{}.Add(gtx.Ops)
	ring.Pop()
}

// drawBookmarkRibbon paints IntelliJ's bookmark: a ribbon whose bottom edge is
// notched.
func drawBookmarkRibbon(gtx layout.Context, cx, cy, size float32) {
	w := size * 0.6
	h := size
	left := cx - w/2
	top := cy - h/2
	bottom := cy + h/2
	notch := h * 0.28

	var path clip.Path
	path.Begin(gtx.Ops)
	path.MoveTo(f32.Pt(left, top))
	path.LineTo(f32.Pt(left+w, top))
	path.LineTo(f32.Pt(left+w, bottom))
	path.LineTo(f32.Pt(cx, bottom-notch))
	path.LineTo(f32.Pt(left, bottom))
	path.Close()
	paint.FillShape(gtx.Ops, bookmarkColor, clip.Outline{Path: path.End()}.Op())
}

// markCirclePath builds a circle outline for stroking.
func markCirclePath(gtx layout.Context, cx, cy, r float32) clip.PathSpec {
	var path clip.Path
	path.Begin(gtx.Ops)
	path.MoveTo(f32.Pt(cx+r, cy))
	path.ArcTo(f32.Pt(cx, cy), f32.Pt(cx-r, cy), 2*3.14159265)
	path.Close()
	return path.End()
}
