package providers

import (
	"image"
	"image/color"

	"gioui.org/f32"
	"gioui.org/io/key"
	"gioui.org/io/pointer"
	"gioui.org/layout"
	"gioui.org/op/clip"
	"gioui.org/op/paint"
	"gioui.org/text"
	"gioui.org/unit"
	gvcolor "github.com/oligo/gvcode/color"
	"github.com/oligo/gvcode/gutter"
	"github.com/oligo/gvcode/internal/folding"
	"github.com/oligo/gvcode/internal/stroke"
)

const (
	// FoldButtonProviderID is the unique identifier for the fold button provider.
	FoldButtonProviderID = "foldbutton"

	// foldButtonSize is the width of the fold button column in dp units.
	foldButtonSize = 16

	// foldChevronSize is the icon box IntelliJ's gutter chevrons live in:
	// platform/icons/src/expui/gutter/unfold.svg and fold.svg are 9x9 icons with a
	// hairline, round-capped chevron.
	foldChevronSize = 9
	// foldChevronStroke is the icon's stroke width, matching the SVG's default.
	foldChevronStroke = 1

	// foldGuideAlpha dims the outline drawn down the chevron column for an
	// expanded region, the way IntelliJ's folding outline is a faint tearline.
	foldGuideAlpha = 0x60
)

// lineCenterY returns the vertical centre of a paragraph's glyph box, in
// provider-local coordinates. Gutter icons are centred there — not on the
// baseline, which sits at the bottom of the glyph box — so an icon reads as
// belonging to its own line instead of hanging into the next one.
func lineCenterY(para gutter.Paragraph, viewport image.Rectangle) float32 {
	offset := (para.Ascent.Ceil() - para.Descent.Ceil()) / 2
	return float32(para.StartY - viewport.Min.Y - offset)
}

// FoldButtonType represents the type of fold button to display.
type FoldButtonType int

const (
	// FoldButtonNone indicates no fold button should be shown.
	FoldButtonNone FoldButtonType = iota
	// FoldButtonCollapsed indicates a collapsed fold (show expand icon).
	FoldButtonCollapsed
	// FoldButtonExpanded indicates an expanded fold (show collapse icon).
	FoldButtonExpanded
)

// FoldButtonProvider renders fold buttons in the gutter.
type FoldButtonProvider struct {
	// foldManager manages fold regions.
	foldManager *folding.Manager

	// pending holds fold events that haven't been consumed yet.
	pending []FoldButtonEvent

	// paragraphs caches the visible paragraphs from the last Layout call.
	paragraphs []gutter.Paragraph

	// buttons caches where each chevron was drawn, in provider-local
	// coordinates, so a click can be matched to the exact button it hit.
	buttons []foldButton

	// buttonStates caches the button state for each LOGICAL line.
	buttonStates map[int]FoldButtonType

	// enabled indicates whether fold buttons are enabled.
	enabled bool
}

// foldButton is one drawn chevron and the line it belongs to.
type foldButton struct {
	rect image.Rectangle
	line int // logical (document) line
}

// FoldButtonEvent represents a click event on a fold button.
type FoldButtonEvent struct {
	// Line is the 0-based line number of the fold.
	Line int
	// IsCollapsed indicates the new state after the click.
	IsCollapsed bool
}

// NewFoldButtonProvider creates a new fold button provider.
func NewFoldButtonProvider(foldManager *folding.Manager) *FoldButtonProvider {
	return &FoldButtonProvider{
		foldManager:  foldManager,
		buttonStates: make(map[int]FoldButtonType),
		pending:      make([]FoldButtonEvent, 0),
		enabled:      true,
	}
}

// SetEnabled sets whether fold buttons are enabled.
func (p *FoldButtonProvider) SetEnabled(enabled bool) {
	p.enabled = enabled
}

// Enabled returns whether fold buttons are enabled.
func (p *FoldButtonProvider) Enabled() bool {
	return p.enabled
}

// ID returns the unique identifier for this provider.
func (p *FoldButtonProvider) ID() string {
	return FoldButtonProviderID
}

// Priority returns the rendering priority. Providers render left to right in
// descending priority, and the fold buttons use the lowest value so the chevrons
// end up to the RIGHT of the run buttons (95) and the line numbers (100), hugging
// the code the way IntelliJ's gutter does.
func (p *FoldButtonProvider) Priority() int {
	return 90
}

// Width returns the fixed width needed for fold buttons.
func (p *FoldButtonProvider) Width(gtx layout.Context, shaper *text.Shaper, params text.Parameters, lineCount int) unit.Dp {
	if !p.enabled {
		return 0
	}
	return unit.Dp(foldButtonSize)
}

// SetLineContents is called to provide line contents for analysis.
// The fold manager will analyze the lines to detect foldable regions.
func (p *FoldButtonProvider) SetLineContents(lines []string, startLine int) {
	if p.foldManager != nil {
		p.foldManager.AnalyzeLines(lines)
	}
}

// Layout renders fold buttons for visible paragraphs.
func (p *FoldButtonProvider) Layout(gtx layout.Context, ctx gutter.GutterContext) layout.Dimensions {
	if !p.enabled {
		return layout.Dimensions{}
	}

	// Cache context info for event handling
	p.paragraphs = ctx.Paragraphs
	p.buttonStates = make(map[int]FoldButtonType)
	p.buttons = p.buttons[:0]

	foldRanges := p.foldManager.GetFoldRanges()
	// The chevron belongs to the region that STARTS on the line. Ranges are
	// sorted by (start line, level), so the first range for a line is the
	// outermost one and owns the arrow, the way IntelliJ nests its arrows.
	foldMap := make(map[int]folding.FoldRange, len(foldRanges))
	for _, r := range foldRanges {
		if _, seen := foldMap[r.StartLine]; !seen {
			foldMap[r.StartLine] = r
		}
	}

	buttonColor := gvcolor.MakeColor(color.NRGBA{R: 0x6F, G: 0x73, B: 0x7A, A: 0xFF})
	if ctx.Colors != nil && ctx.Colors.TextHighlight.IsSet() {
		buttonColor = ctx.Colors.TextHighlight
	} else if ctx.Colors != nil && ctx.Colors.Text.IsSet() {
		buttonColor = ctx.Colors.Text
	}

	buttonSizePx := gtx.Dp(unit.Dp(foldButtonSize))
	chevronSizePx := float32(gtx.Dp(unit.Dp(foldChevronSize)))
	chevronStrokePx := float32(gtx.Dp(unit.Dp(foldChevronStroke)))
	centerX := float32(gtx.Constraints.Max.X) / 2

	// A line's centre, so the outline below can run from the header line to the
	// closing line of a region.
	lineCenter := make(map[int]float32, len(ctx.Paragraphs))
	for _, para := range ctx.Paragraphs {
		lineCenter[para.LogicalIndex] = lineCenterY(para, ctx.Viewport)
	}

	// An expanded region is outlined with a hairline down the chevron column, the
	// way IntelliJ paints its folding outline (EditorGutterComponentImpl
	// .paintFoldingLines): from the region's first line to the line that closes it.
	// A region partly scrolled off screen still gets the visible part of its
	// outline, because IntelliJ clips it to the viewport rather than dropping it.
	guideColor := buttonColor.MulAlpha(foldGuideAlpha)
	guideX := int(centerX)
	firstLine, lastLine := 0, -1
	if n := len(ctx.Paragraphs); n > 0 {
		firstLine = ctx.Paragraphs[0].LogicalIndex
		lastLine = ctx.Paragraphs[n-1].LogicalIndex
	}
	viewportTop := float32(0)
	viewportBottom := float32(gtx.Constraints.Max.Y)
	for _, fold := range foldRanges {
		if fold.Collapsed {
			continue
		}
		start, okStart := lineCenter[fold.StartLine]
		if !okStart {
			if fold.StartLine >= firstLine {
				continue // the whole region sits below the viewport
			}
			start = viewportTop
		}
		end, okEnd := lineCenter[fold.EndLine+1]
		if !okEnd {
			if fold.EndLine+1 <= lastLine {
				continue // the whole region sits above the viewport
			}
			end = viewportBottom
		}
		if end <= start {
			continue
		}
		guide := clip.Rect(image.Rect(guideX, int(start), guideX+1, int(end)+1)).Push(gtx.Ops)
		guideColor.Op(gtx.Ops).Add(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
		guide.Pop()
	}

	for _, para := range ctx.Paragraphs {
		// Skip paragraphs outside the viewport
		if para.EndY < ctx.Viewport.Min.Y {
			continue
		}
		if para.StartY > ctx.Viewport.Max.Y {
			break
		}

		// Fold ranges are numbered by the DOCUMENT's lines, so the lookup has to
		// use the logical index: after a collapse the visible indices shift and
		// the chevrons would otherwise land on the wrong lines.
		fold, hasFold := foldMap[para.LogicalIndex]
		if !hasFold {
			continue
		}

		var btnType FoldButtonType
		if fold.Collapsed {
			btnType = FoldButtonCollapsed
		} else {
			btnType = FoldButtonExpanded
		}
		p.buttonStates[para.LogicalIndex] = btnType

		// Center the chevron on the line's glyph box, so the arrow sits on the
		// line it belongs to instead of drifting into the next one.
		centerY := lineCenterY(para, ctx.Viewport)
		rect := image.Rect(
			int(centerX)-buttonSizePx/2,
			int(centerY)-buttonSizePx/2,
			int(centerX)+buttonSizePx/2,
			int(centerY)+buttonSizePx/2,
		)
		p.buttons = append(p.buttons, foldButton{rect: rect, line: para.LogicalIndex})

		drawChevron(gtx, btnType, centerX, centerY, chevronSizePx, chevronStrokePx, buttonColor)
	}

	return layout.Dimensions{Size: image.Pt(buttonSizePx, 0)}
}

// drawChevron paints the fold arrow with the very geometry of IntelliJ's gutter
// icons: unfold.svg (a right chevron) marks a collapsed region, fold.svg (a down
// chevron) an expanded one. Both are drawn as a stroked polyline with round caps
// inside a 9x9 box, so the marker stays a hairline glyph instead of a blob.
func drawChevron(gtx layout.Context, btnType FoldButtonType, cx, cy, size, strokeWidth float32, col gvcolor.Color) {
	x0, y0 := cx-size/2, cy-size/2

	// The SVG paths, transcribed verbatim.
	var pts [3]f32.Point
	if btnType == FoldButtonCollapsed {
		pts = [3]f32.Point{ // M3 8 L6.5 4.5 L3 1
			f32.Pt(x0+3, y0+8),
			f32.Pt(x0+6.5, y0+4.5),
			f32.Pt(x0+3, y0+1),
		}
	} else {
		pts = [3]f32.Point{ // M8 2.75 L4.5 6.25 L1 2.75
			f32.Pt(x0+8, y0+2.75),
			f32.Pt(x0+4.5, y0+6.25),
			f32.Pt(x0+1, y0+2.75),
		}
	}

	path := stroke.Path{}
	path.Segments = append(path.Segments,
		stroke.MoveTo(pts[0]),
		stroke.LineTo(pts[1]),
		stroke.LineTo(pts[2]),
	)
	stack := stroke.Stroke{
		Path:  path,
		Width: strokeWidth,
		Cap:   stroke.RoundCap,
		Join:  stroke.RoundJoin,
	}.Op(gtx.Ops).Push(gtx.Ops)

	col.Op(gtx.Ops).Add(gtx.Ops)
	paint.PaintOp{}.Add(gtx.Ops)

	stack.Pop()
}

// HandleClick implements the InteractiveGutter interface. line is the VISIBLE
// paragraph index the gutter manager hit-tested; folds are keyed by the logical
// line, so the index is translated first.
func (p *FoldButtonProvider) HandleClick(line int, source pointer.Source, numClicks int, modifiers key.Modifiers) bool {
	logical := p.logicalLine(line)
	if logical < 0 {
		return false
	}
	if _, hasButton := p.buttonStates[logical]; !hasButton {
		return false
	}

	isCollapsed := p.foldManager.ToggleFold(logical)
	p.pending = append(p.pending, FoldButtonEvent{
		Line:        logical,
		IsCollapsed: isCollapsed,
	})

	return true
}

// HandleHover implements the InteractiveGutter interface.
func (p *FoldButtonProvider) HandleHover(line int) *gutter.HoverInfo {
	logical := p.logicalLine(line)
	if logical < 0 {
		return nil
	}
	if _, hasButton := p.buttonStates[logical]; !hasButton {
		return nil
	}

	fold := p.foldManager.GetFoldAtLine(logical)
	if fold == nil {
		return nil
	}

	var text string
	if fold.Collapsed {
		text = "Expand " + fold.Type.String()
	} else {
		text = "Collapse " + fold.Type.String()
	}
	if fold.Name != "" {
		text += " (" + fold.Name + ")"
	}

	return &gutter.HoverInfo{
		Text: text,
	}
}

// logicalLine translates a visible paragraph index into the document line it
// belongs to, or -1 when the paragraph is not on screen.
func (p *FoldButtonProvider) logicalLine(visible int) int {
	for _, para := range p.paragraphs {
		if para.Index == visible {
			return para.LogicalIndex
		}
	}
	return -1
}

// GetPendingEvents returns pending fold button events and clears the pending list.
func (p *FoldButtonProvider) GetPendingEvents() []FoldButtonEvent {
	events := p.pending
	p.pending = p.pending[:0]
	return events
}

// GetFoldManager returns the underlying fold manager.
func (p *FoldButtonProvider) GetFoldManager() *folding.Manager {
	return p.foldManager
}
