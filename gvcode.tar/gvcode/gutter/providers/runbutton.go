package providers

import (
	"image"
	"image/color"
	"regexp"

	"gioui.org/f32"
	"gioui.org/io/key"
	"gioui.org/io/pointer"
	"gioui.org/layout"
	"gioui.org/op/clip"
	"gioui.org/op/paint"
	"gioui.org/text"
	"gioui.org/unit"
	"github.com/oligo/gvcode/gutter"
	"github.com/oligo/gvcode/internal/stroke"
)

const (
	// RunButtonProviderID is the unique identifier for the run button provider.
	RunButtonProviderID = "runbutton"

	// buttonSize is the width of the run button column in dp units.
	buttonSize = 18

	// runIconSize is the icon box IntelliJ draws its run marker in:
	// platform/icons/src/expui/run/run.svg is a 16x16 icon, and
	// runIconStrokeWidth is the hairline outline it is drawn with.
	runIconSize        = 16
	runIconStrokeWidth = 1
)

// IntelliJ's run marker is a rounded play triangle filled with the editor
// background tinted by the state colour and outlined with the colour itself. The
// values below are the dark-theme pair from expui/run/run.svg (stroke #57965C,
// fill #253627); the test marker keeps a blue outline to stay distinguishable.
var (
	runMainStroke = color.NRGBA{R: 0x57, G: 0x96, B: 0x5C, A: 0xFF}
	runMainFill   = color.NRGBA{R: 0x25, G: 0x36, B: 0x27, A: 0xFF}
	runTestStroke = color.NRGBA{R: 0x21, G: 0x96, B: 0xF3, A: 0xFF}
	runTestFill   = color.NRGBA{R: 0x16, G: 0x2B, B: 0x3D, A: 0xFF}
)

// RunButtonType represents the type of run button.
type RunButtonType int

const (
	// RunButtonNone indicates no run button should be shown.
	RunButtonNone RunButtonType = iota
	// RunButtonMain indicates a main function run button.
	RunButtonMain
	// RunButtonTest indicates a test function run button.
	RunButtonTest
)

// RunButtonProvider renders run buttons for main and test functions in the gutter.
type RunButtonProvider struct {
	// paragraphs caches the visible paragraphs from the last Layout call.
	paragraphs []gutter.Paragraph

	// buttonTypes caches the button type for each LOGICAL line.
	buttonTypes map[int]RunButtonType

	// buttonTexts caches button labels for each LOGICAL line.
	buttonTexts map[int]string

	// lineHeight caches the line height from the last Layout call.
	lineHeight int

	// viewport caches the viewport from the last Layout call.
	viewport image.Rectangle

	// pending holds run button events that haven't been consumed yet.
	pending []RunButtonEvent
}

// NewRunButtonProvider creates a new run button provider with default settings.
func NewRunButtonProvider() *RunButtonProvider {
	return &RunButtonProvider{
		buttonTypes: make(map[int]RunButtonType),
		buttonTexts: make(map[int]string),
		paragraphs:  make([]gutter.Paragraph, 0),
		pending:     make([]RunButtonEvent, 0),
	}
}

// ID returns the unique identifier for this provider.
func (p *RunButtonProvider) ID() string {
	return RunButtonProviderID
}

// Priority returns the rendering priority. Providers render left to right in
// descending priority, so 95 places the run buttons between the line numbers
// (100) and the fold chevrons (90), the way IntelliJ orders its gutter columns.
func (p *RunButtonProvider) Priority() int {
	return 95
}

// Width returns the fixed width needed for run buttons.
func (p *RunButtonProvider) Width(gtx layout.Context, shaper *text.Shaper, params text.Parameters, lineCount int) unit.Dp {
	return unit.Dp(buttonSize)
}

// SetLineContents sets the contents of all visible lines for analysis.
// This should be called before Layout.
func (p *RunButtonProvider) SetLineContents(lines []string, startLine int) {
	p.analyzeLines(lines, startLine)
}

// Layout renders run buttons for visible paragraphs.
func (p *RunButtonProvider) Layout(gtx layout.Context, ctx gutter.GutterContext) layout.Dimensions {
	// Cache context info for event handling
	p.paragraphs = ctx.Paragraphs
	p.lineHeight = ctx.LineHeight.Ceil()
	p.viewport = ctx.Viewport

	// Define colors for different button types. The palette can override the
	// outline, in which case the fill follows it as a dark tint.
	mainStroke, mainFill := runMainStroke, runMainFill
	testStroke, testFill := runTestStroke, runTestFill

	if ctx.Colors != nil && ctx.Colors.Custom != nil {
		if c, ok := ctx.Colors.Custom["runbutton.main"]; ok {
			mainStroke = c.NRGBA()
			mainFill = shadeFill(mainStroke)
		}
		if c, ok := ctx.Colors.Custom["runbutton.test"]; ok {
			testStroke = c.NRGBA()
			testFill = shadeFill(testStroke)
		}
	}

	// Render buttons for each visible paragraph
	buttonSizePx := gtx.Dp(unit.Dp(buttonSize))
	iconSizePx := float32(gtx.Dp(unit.Dp(runIconSize)))

	for _, para := range ctx.Paragraphs {
		// Skip paragraphs outside the viewport
		if para.EndY < ctx.Viewport.Min.Y {
			continue
		}
		if para.StartY > ctx.Viewport.Max.Y {
			break
		}

		// The analysis numbers the document's lines, so the lookup uses the
		// logical index: collapsing a fold shifts the visible indices and a
		// visible-index lookup would move the button to the wrong function.
		btnType, hasButton := p.buttonTypes[para.LogicalIndex]
		if !hasButton || btnType == RunButtonNone {
			continue
		}

		// Center the icon on the line's glyph box. The provider is already
		// translated to its own column, so x is column-local.
		centerY := lineCenterY(para, ctx.Viewport)
		centerX := float32(buttonSizePx) / 2

		strokeColor, fillColor := mainStroke, mainFill
		if btnType == RunButtonTest {
			strokeColor, fillColor = testStroke, testFill
		}

		drawRunIcon(gtx, strokeColor, fillColor, centerX, centerY, iconSizePx)
	}

	return layout.Dimensions{Size: image.Pt(buttonSizePx, 0)}
}

// shadeFill derives the icon's fill from its outline colour: IntelliJ fills the
// run marker with the editor background tinted by the state colour, which on a
// dark theme is a very dark version of it.
func shadeFill(stroke color.NRGBA) color.NRGBA {
	return color.NRGBA{
		R: stroke.R / 4,
		G: stroke.G / 4,
		B: stroke.B / 4,
		A: 0xFF,
	}
}

// drawRunIcon paints IntelliJ's run marker: the rounded play triangle from
// platform/icons/src/expui/run/run.svg, filled with the dark tint and outlined
// with the state colour, exactly as the icon is authored.
func drawRunIcon(gtx layout.Context, strokeColor, fillColor color.NRGBA, cx, cy, size float32) {
	// The SVG's coordinates, mapped from the icon's 16x16 box onto the gutter.
	scale := size / 16
	pt := func(x, y float32) f32.Point {
		return f32.Pt(cx+(x-8)*scale, cy+(y-8)*scale)
	}

	var fill clip.Path
	fill.Begin(gtx.Ops)
	fill.MoveTo(pt(13.5, 7.134))
	fill.CubeTo(pt(14.1667, 7.51888), pt(14.1667, 8.48112), pt(13.5, 8.86602))
	fill.LineTo(pt(4.5, 14.0622))
	fill.CubeTo(pt(3.83333, 14.4471), pt(3, 13.966), pt(3, 13.1962))
	fill.LineTo(pt(3, 2.80385))
	fill.CubeTo(pt(3, 2.03405), pt(3.83333, 1.55292), pt(4.5, 1.93782))
	fill.Close()
	paint.FillShape(gtx.Ops, fillColor, clip.Outline{Path: fill.End()}.Op())

	outline := stroke.Path{}
	outline.Segments = append(outline.Segments,
		stroke.MoveTo(pt(13.5, 7.134)),
		stroke.CubeTo(pt(14.1667, 7.51888), pt(14.1667, 8.48112), pt(13.5, 8.86602)),
		stroke.LineTo(pt(4.5, 14.0622)),
		stroke.CubeTo(pt(3.83333, 14.4471), pt(3, 13.966), pt(3, 13.1962)),
		stroke.LineTo(pt(3, 2.80385)),
		stroke.CubeTo(pt(3, 2.03405), pt(3.83333, 1.55292), pt(4.5, 1.93782)),
		stroke.LineTo(pt(13.5, 7.134)),
	)
	stack := stroke.Stroke{
		Path:  outline,
		Width: float32(runIconStrokeWidth) * scale,
		Cap:   stroke.RoundCap,
		Join:  stroke.RoundJoin,
	}.Op(gtx.Ops).Push(gtx.Ops)

	paint.ColorOp{Color: strokeColor}.Add(gtx.Ops)
	paint.PaintOp{}.Add(gtx.Ops)

	stack.Pop()
}

// HandleClick implements the InteractiveGutter interface. The gutter manager
// hit-tests visible paragraphs; run buttons are keyed by logical line.
func (p *RunButtonProvider) HandleClick(line int, source pointer.Source, numClicks int, modifiers key.Modifiers) bool {
	logical := p.logicalLine(line)
	if logical < 0 {
		return false
	}

	btnType, hasButton := p.buttonTypes[logical]
	if !hasButton || btnType == RunButtonNone {
		return false
	}

	// Generate run button event
	p.pending = append(p.pending, RunButtonEvent{
		ButtonType: int(btnType),
		Line:       logical,
		ButtonText: p.buttonTexts[logical],
	})

	return true
}

// HandleHover implements the InteractiveGutter interface.
func (p *RunButtonProvider) HandleHover(line int) *gutter.HoverInfo {
	logical := p.logicalLine(line)
	if logical < 0 {
		return nil
	}

	btnType, hasButton := p.buttonTypes[logical]
	if !hasButton || btnType == RunButtonNone {
		return nil
	}

	var text string
	if btnType == RunButtonMain {
		text = "Run main function"
	} else if btnType == RunButtonTest {
		text = "Run test function"
	}

	return &gutter.HoverInfo{
		Text: text,
	}
}

// logicalLine translates a visible paragraph index into the document line it
// belongs to, or -1 when the paragraph is not on screen.
func (p *RunButtonProvider) logicalLine(visible int) int {
	for _, para := range p.paragraphs {
		if para.Index == visible {
			return para.LogicalIndex
		}
	}
	return -1
}

// GetPendingEvents returns pending run button events and clears the pending list.
func (p *RunButtonProvider) GetPendingEvents() []RunButtonEvent {
	events := p.pending
	p.pending = p.pending[:0]
	return events
}

// hitTestLine determines which logical line corresponds to a Y coordinate.
func (p *RunButtonProvider) hitTestLine(y int) int {
	if len(p.paragraphs) == 0 {
		return -1
	}

	for _, para := range p.paragraphs {
		if y >= para.StartY && y <= para.EndY {
			return para.Index
		}
	}

	return -1
}

// analyzeLines analyzes line contents to determine if they should have run buttons.
func (p *RunButtonProvider) analyzeLines(lines []string, startLine int) {
	// Patterns for detecting main and test functions
	mainPattern := regexp.MustCompile(`^func\s+main\s*\(`)
	testPattern := regexp.MustCompile(`^func\s+Test\w+\s*\(`)
	benchmarkPattern := regexp.MustCompile(`^func\s+Benchmark\w+\s*\(`)

	// Clear previous button types
	p.buttonTypes = make(map[int]RunButtonType)
	p.buttonTexts = make(map[int]string)

	for i, line := range lines {
		line = trimLine(line)
		absoluteLine := startLine + i

		// Check for main function
		if mainPattern.MatchString(line) {
			p.buttonTypes[absoluteLine] = RunButtonMain
			p.buttonTexts[absoluteLine] = line
			continue
		}

		// Check for test function
		if testPattern.MatchString(line) {
			p.buttonTypes[absoluteLine] = RunButtonTest
			p.buttonTexts[absoluteLine] = line
			continue
		}

		// Check for benchmark function
		if benchmarkPattern.MatchString(line) {
			p.buttonTypes[absoluteLine] = RunButtonTest
			p.buttonTexts[absoluteLine] = line
		}
	}
}

// trimLine removes leading/trailing whitespace and comments from a line.
func trimLine(line string) string {
	// Remove comments
	for i := 0; i < len(line); i++ {
		if line[i] == '/' && i+1 < len(line) && line[i+1] == '/' {
			line = line[:i]
			break
		}
	}
	return trimSpace(line)
}

// trimSpace trims whitespace from a string.
func trimSpace(s string) string {
	// Simple implementation, can be optimized
	start := 0
	for start < len(s) && (s[start] == ' ' || s[start] == '\t' || s[start] == '\n' || s[start] == '\r') {
		start++
	}
	end := len(s)
	for end > start && (s[end-1] == ' ' || s[end-1] == '\t' || s[end-1] == '\n' || s[end-1] == '\r') {
		end--
	}
	return s[start:end]
}

// RunButtonEvent is the gutter-facing click event type. The provider reports the
// gutter's own event so the editor's collector can pick it up: a type declared
// here would be a different type and the collector's type assertion would fail.
type RunButtonEvent = gutter.RunButtonEvent
