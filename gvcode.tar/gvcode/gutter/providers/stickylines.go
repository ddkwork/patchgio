package providers

import (
	"image"
	"regexp"
	"sort"
	"strings"

	"gioui.org/io/key"
	"gioui.org/io/pointer"
	"gioui.org/layout"
	"gioui.org/text"
	"gioui.org/unit"
	"github.com/oligo/gvcode/gutter"
)

const (
	// StickyLinesProviderID is the unique identifier for the sticky lines provider.
	StickyLinesProviderID = "stickylines"

	// DefaultMaxStickyLines is the default maximum number of sticky lines to display.
	DefaultMaxStickyLines = 5
)

// The structure patterns are compiled once: the analyser runs on every edit, and
// compiling six expressions per run was measurable on large files.
var (
	stickyFunctionPattern = regexp.MustCompile(`^\s*(func|func\s+\(\s*\w+\s*\*?\s*\w+\s*\))\s+(\w+)\s*\(`)
	stickyTypePattern     = regexp.MustCompile(`^\s*type\s+(\w+)\s+(struct|interface|map|chan|func)`)
	stickyBlockPattern    = regexp.MustCompile(`^\s*(const|var)\s*\(`)
	stickyImportPattern   = regexp.MustCompile(`^\s*import\s*\(`)
	stickyConstPattern    = regexp.MustCompile(`^\s*const\s+\w+`)
	stickyVarPattern      = regexp.MustCompile(`^\s*var\s+\w+`)
)

// StickyLineInfo aliases the gutter's structure description so the editor can
// consume the provider's output without a second, structurally identical type.
type StickyLineInfo = gutter.StickyLineInfo

// StickyLinesProvider renders sticky lines that remain visible while scrolling.
// This is similar to JetBrains GoLand's "Sticky Lines" feature.
type StickyLinesProvider struct {
	// enabled indicates whether sticky lines are enabled.
	enabled bool

	// maxStickyLines is the maximum number of sticky lines to display.
	maxStickyLines int

	// stickyLines contains the currently sticky lines.
	stickyLines []StickyLineInfo

	// allLines caches all lines from the document for structure analysis.
	allLines []string

	// structureCache caches the code structure analysis results.
	structureCache []StickyLineInfo

	// analysisRuns counts how many times the structure was re-analysed. The
	// analysis is the expensive part of this provider, so tests assert that an
	// unchanged document is not analysed again.
	analysisRuns int

	// lineHeight caches the line height from the last Layout call, which is what
	// turns a click's Y coordinate into a band row.
	lineHeight int

	// stickyAreaHeight is the height occupied by sticky lines.
	stickyAreaHeight int
}

// NewStickyLinesProvider creates a new sticky lines provider with default settings.
func NewStickyLinesProvider() *StickyLinesProvider {
	return &StickyLinesProvider{
		enabled:        true,
		maxStickyLines: DefaultMaxStickyLines,
		stickyLines:    make([]StickyLineInfo, 0),
		structureCache: make([]StickyLineInfo, 0),
	}
}

// SetEnabled sets whether sticky lines are enabled.
func (p *StickyLinesProvider) SetEnabled(enabled bool) {
	p.enabled = enabled
}

// Enabled returns whether sticky lines are enabled.
func (p *StickyLinesProvider) Enabled() bool {
	return p.enabled
}

// SetMaxStickyLines sets the maximum number of sticky lines to display.
func (p *StickyLinesProvider) SetMaxStickyLines(max int) {
	if max < 1 {
		max = 1
	}
	p.maxStickyLines = max
}

// MaxStickyLines returns the maximum number of sticky lines.
func (p *StickyLinesProvider) MaxStickyLines() int {
	return p.maxStickyLines
}

// ID returns the unique identifier for this provider.
func (p *StickyLinesProvider) ID() string {
	return StickyLinesProviderID
}

// Priority returns the rendering priority. Sticky lines have priority 0,
// meaning they are rendered on top of all other content in the editor area.
func (p *StickyLinesProvider) Priority() int {
	return 0
}

// Width returns the width needed for sticky lines.
// Since sticky lines span the entire editor width, this returns 0.
func (p *StickyLinesProvider) Width(gtx layout.Context, shaper *text.Shaper, params text.Parameters, lineCount int) unit.Dp {
	return unit.Dp(0)
}

// SetLineContents sets the contents of all lines for structure analysis.
// This implements the gutter.LineContentProvider interface.
// The analysis is skipped when the document is unchanged: the editor feeds this
// provider on every frame, and a full-document scan per frame is what made
// typing and scrolling stutter on large files.
func (p *StickyLinesProvider) SetLineContents(lines []string, startLine int) {
	if stickyLinesEqual(p.allLines, lines) {
		return
	}
	p.allLines = lines
	p.analyzeStructure()
}

// stickyLinesEqual reports whether two line slices hold the same text.
func stickyLinesEqual(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

// analyzeStructure analyzes the code structure to identify lines that can be sticky.
// This includes functions, types, constants, variables, etc.
func (p *StickyLinesProvider) analyzeStructure() {
	p.analysisRuns++
	if len(p.allLines) == 0 {
		p.structureCache = p.structureCache[:0]
		return
	}

	p.structureCache = p.structureCache[:0]

	for i, line := range p.allLines {
		trimmed := strings.TrimSpace(line)
		if trimmed == "" {
			continue
		}

		// Calculate indentation level
		indent := p.calculateIndent(line)

		var stickyType string
		var shouldStick bool

		// Check for function declarations
		if stickyFunctionPattern.MatchString(line) {
			stickyType = "function"
			shouldStick = true
		} else if stickyTypePattern.MatchString(line) {
			stickyType = "type"
			shouldStick = true
		} else if stickyBlockPattern.MatchString(line) || stickyImportPattern.MatchString(line) {
			stickyType = "block"
			shouldStick = true
		} else if stickyConstPattern.MatchString(line) {
			stickyType = "const"
			shouldStick = true
		} else if stickyVarPattern.MatchString(line) {
			// Only stick top-level variables (indentation 0 or 1)
			if indent <= 1 {
				stickyType = "var"
				shouldStick = true
			}
		}

		if shouldStick {
			p.structureCache = append(p.structureCache, StickyLineInfo{
				Line:   i,
				Text:   line,
				Indent: indent,
				Type:   stickyType,
			})
		}
	}
}

// calculateIndent calculates the indentation level of a line.
func (p *StickyLinesProvider) calculateIndent(line string) int {
	indent := 0
	for _, r := range line {
		if r == ' ' {
			// Assume 4 spaces per indentation level
			indent++
		} else if r == '\t' {
			indent += 4
		} else {
			break
		}
	}
	return indent / 4
}

// Layout determines which sticky lines are shown. Painting is done by the
// editor, which owns the text area these lines are drawn over.
func (p *StickyLinesProvider) Layout(gtx layout.Context, ctx gutter.GutterContext) layout.Dimensions {
	p.lineHeight = ctx.LineHeight.Ceil()
	p.calculateStickyLines(ctx)

	return layout.Dimensions{Size: image.Point{X: 0, Y: p.stickyAreaHeight}}
}

// calculateStickyLines determines which lines should be sticky based on scroll position.
func (p *StickyLinesProvider) calculateStickyLines(ctx gutter.GutterContext) {
	p.stickyLines = p.stickyLines[:0]
	p.stickyAreaHeight = 0
	if !p.enabled || len(p.structureCache) == 0 || len(ctx.Paragraphs) == 0 {
		return
	}

	// The band shows the declarations that scrolled off the top, so the line that
	// decides its content is the first paragraph of the viewport.
	//
	// The band's own height is deliberately NOT part of this: feeding it back made
	// the band depend on its own result — after a click the band changed size, the
	// reference line moved with it and the declaration that had just been clicked
	// flipped in and out of the band on successive frames. Keying the content to
	// the scroll position alone keeps it stable.
	top := ctx.Viewport.Min.Y
	paras := ctx.Paragraphs
	i := sort.Search(len(paras), func(i int) bool { return paras[i].EndY >= top })
	if i >= len(paras) {
		return
	}
	// Paragraphs are numbered by the document, not by what is on screen, so a fold
	// above the viewport cannot shift which line the band shows.
	firstVisibleLine := paras[i].LogicalIndex

	// structureCache is ordered by line, so the structures at or above the first
	// visible line are a prefix of it. Keep the innermost few.
	end := sort.Search(len(p.structureCache), func(i int) bool {
		return p.structureCache[i].Line > firstVisibleLine
	})
	start := max(0, end-p.maxStickyLines)
	p.stickyLines = append(p.stickyLines, p.structureCache[start:end]...)

	p.stickyAreaHeight = len(p.stickyLines) * p.lineHeight
}

// StickyLines returns the sticky lines currently shown and the height in pixels
// of the band they occupy at the top of the text area. It implements
// gutter.StickyLinesProvider.
func (p *StickyLinesProvider) StickyLines() ([]StickyLineInfo, int) {
	return p.stickyLines, p.stickyAreaHeight
}

// StickyLineAt reports the sticky line drawn at y, in text-area coordinates. It
// returns false when y is outside the band, so a click below the band keeps
// behaving like an ordinary click in the text.
func (p *StickyLinesProvider) StickyLineAt(y int) (StickyLineInfo, bool) {
	if p.lineHeight <= 0 || y < 0 || y >= p.stickyAreaHeight {
		return StickyLineInfo{}, false
	}
	idx := y / p.lineHeight
	if idx < 0 || idx >= len(p.stickyLines) {
		return StickyLineInfo{}, false
	}
	return p.stickyLines[idx], true
}

// StickyLinesHeight returns the height occupied by sticky lines.
func (p *StickyLinesProvider) StickyLinesHeight() int {
	return p.stickyAreaHeight
}

// HandleClick handles click events on sticky lines.
// Since sticky lines are rendered over the editor, not in the gutter, this
// method is not used: the editor routes a click in the band through StickyLineAt.
func (p *StickyLinesProvider) HandleClick(line int, source pointer.Source, numClicks int, modifiers key.Modifiers) bool {
	// Sticky lines are not in the gutter area, so this is not used
	return false
}

// HandleHover handles hover events on sticky lines.
// Since sticky lines are rendered over the editor, not in the gutter,
// this method is not used.
func (p *StickyLinesProvider) HandleHover(line int) *gutter.HoverInfo {
	// Sticky lines are not in the gutter area, so this is not used
	return nil
}
