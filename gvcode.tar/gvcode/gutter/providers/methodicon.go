package providers

import (
	"image"
	"image/color"
	"math"

	"gioui.org/f32"
	"gioui.org/io/key"
	"gioui.org/io/pointer"
	"gioui.org/layout"
	"gioui.org/op/clip"
	"gioui.org/op/paint"
	"gioui.org/text"
	"gioui.org/unit"
	"github.com/oligo/gvcode/gutter"
	"github.com/oligo/gvcode/internal/stroke"
)

// MethodIconProviderID is the unique identifier for the method icon provider.
const MethodIconProviderID = "methodicon"

// MethodIconKind is the kind of inheritance marker IntelliJ draws in the gutter.
// The four kinds are the icons platform/icons/src/expui/gutter carries:
// overridingMethod (this method overrides another), implementingMethod (it
// implements an interface method), overridenMethod and implementedMethod (it IS
// overridden or implemented further down the hierarchy).
//
// It is an alias of the gutter package's kind: the editor's event collector
// asserts on gutter.MethodIconEvent, and a locally declared type would be a
// different type.
type MethodIconKind = gutter.MethodIconKind

const (
	MethodIconNone    = gutter.MethodIconNone
	MethodOverrides   = gutter.MethodOverrides
	MethodImplements  = gutter.MethodImplements
	MethodOverridden  = gutter.MethodOverridden
	MethodImplemented = gutter.MethodImplemented
)

// The dark-theme colours of IntelliJ's icons: the "O" ring is blue, the "I" ring
// is green, and the arrow is the same red in every icon.
var (
	methodOverridesColor   = color.NRGBA{R: 0x54, G: 0x8A, B: 0xF7, A: 0xFF}
	methodOverridesFill    = color.NRGBA{R: 0x25, G: 0x32, B: 0x4D, A: 0xFF}
	methodImplementsColor  = color.NRGBA{R: 0x57, G: 0x96, B: 0x5C, A: 0xFF}
	methodImplementsFill   = color.NRGBA{R: 0x25, G: 0x36, B: 0x27, A: 0xFF}
	methodArrowColor       = color.NRGBA{R: 0xDB, G: 0x5C, B: 0x5C, A: 0xFF}
	methodIconSize         = 14 // the SVG's viewBox, in dp
	methodIconStroke       = float32(1)
	methodIconRingRadius   = float32(4.5)
	methodIconLetterRadius = float32(1.5)
)

// MethodIconEvent reports a click on a method icon, so the application can
// navigate to the overridden or implemented method the way IntelliJ does. It is
// an alias of the gutter package's event so the editor's collector can assert
// on it.
type MethodIconEvent = gutter.MethodIconEvent

// MethodIconProvider draws IntelliJ's inheritance markers in the gutter. Which
// methods override or implement something is language knowledge, so the provider
// is fed by the application, exactly like the run button provider.
type MethodIconProvider struct {
	// icons maps a DOCUMENT line to its marker.
	icons map[int]MethodIconKind
	// paragraphs caches the visible paragraphs from the last Layout call, so a
	// click's visible index can be translated back to a document line.
	paragraphs []gutter.Paragraph
	// hits records the markers actually drawn, for hit testing and tests.
	hits    []methodIconHit
	pending []MethodIconEvent
}

type methodIconHit struct {
	rect image.Rectangle
	line int
	kind MethodIconKind
}

// NewMethodIconProvider creates a method icon provider.
func NewMethodIconProvider() *MethodIconProvider {
	return &MethodIconProvider{icons: make(map[int]MethodIconKind)}
}

// ID implements gutter.GutterProvider.
func (p *MethodIconProvider) ID() string {
	return MethodIconProviderID
}

// Priority returns the rendering priority. The markers are gutter annotations,
// like the run buttons, so 97 places their column between the line numbers (100)
// and the run buttons (95), both of which sit left of the fold chevrons (90).
func (p *MethodIconProvider) Priority() int {
	return 97
}

// Width implements gutter.GutterProvider.
func (p *MethodIconProvider) Width(gtx layout.Context, shaper *text.Shaper, params text.Parameters, lineCount int) unit.Dp {
	return unit.Dp(methodIconSize)
}

// SetMethodIcons replaces the markers. The map is keyed by DOCUMENT line, so
// collapsing a fold never moves a marker onto another method.
func (p *MethodIconProvider) SetMethodIcons(icons map[int]MethodIconKind) {
	p.icons = icons
}

// MarkMethodIcon sets one marker; a zero kind clears the line.
func (p *MethodIconProvider) MarkMethodIcon(line int, kind MethodIconKind) {
	if p.icons == nil {
		p.icons = make(map[int]MethodIconKind)
	}
	if kind == MethodIconNone {
		delete(p.icons, line)
		return
	}
	p.icons[line] = kind
}

// Layout draws one marker per visible line that carries one.
func (p *MethodIconProvider) Layout(gtx layout.Context, ctx gutter.GutterContext) layout.Dimensions {
	p.hits = p.hits[:0]
	p.paragraphs = append(p.paragraphs[:0], ctx.Paragraphs...)

	sizePx := gtx.Dp(unit.Dp(methodIconSize))
	for _, para := range ctx.Paragraphs {
		if para.EndY < ctx.Viewport.Min.Y {
			continue
		}
		if para.StartY > ctx.Viewport.Max.Y {
			break
		}
		kind, ok := p.icons[para.LogicalIndex]
		if !ok || kind == MethodIconNone {
			continue
		}

		centerY := lineCenterY(para, ctx.Viewport)
		rect := image.Rect(
			gtx.Constraints.Max.X/2-sizePx/2,
			int(centerY)-sizePx/2,
			gtx.Constraints.Max.X/2+sizePx/2,
			int(centerY)+sizePx/2,
		)
		p.hits = append(p.hits, methodIconHit{rect: rect, line: para.LogicalIndex, kind: kind})

		drawMethodIcon(gtx, kind, float32(gtx.Constraints.Max.X)/2, centerY, float32(sizePx))
	}

	return layout.Dimensions{Size: image.Pt(sizePx, 0)}
}

// HandleClick implements gutter.InteractiveGutterProvider: the click is kept and
// handed to the application, which knows where the super method lives.
func (p *MethodIconProvider) HandleClick(line int, source pointer.Source, numClicks int, modifiers key.Modifiers) bool {
	logical := p.logicalLine(line)
	if logical < 0 {
		return false
	}
	for _, hit := range p.hits {
		if hit.line != logical {
			continue
		}
		p.pending = append(p.pending, MethodIconEvent{Line: logical, Kind: hit.kind})
		return true
	}
	return false
}

// HandleHover implements gutter.InteractiveGutterProvider.
func (p *MethodIconProvider) HandleHover(line int) *gutter.HoverInfo {
	logical := p.logicalLine(line)
	if logical < 0 {
		return nil
	}
	for _, hit := range p.hits {
		if hit.line != logical {
			continue
		}
		var text string
		switch hit.kind {
		case MethodOverrides:
			text = "Overrides method"
		case MethodImplements:
			text = "Implements method"
		case MethodOverridden:
			text = "Is overridden"
		case MethodImplemented:
			text = "Is implemented"
		}
		return &gutter.HoverInfo{Text: text}
	}
	return nil
}

// logicalLine translates a visible paragraph index into the document line it
// belongs to, or -1 when the paragraph is not on screen. The markers are keyed
// by document line, so collapsing a fold must not move them.
func (p *MethodIconProvider) logicalLine(visible int) int {
	for _, para := range p.paragraphs {
		if para.Index == visible {
			return para.LogicalIndex
		}
	}
	return -1
}

// GetPendingEvents returns the pending click events and clears them.
func (p *MethodIconProvider) GetPendingEvents() []MethodIconEvent {
	events := p.pending
	p.pending = p.pending[:0]
	return events
}

// MethodIconRects exposes the drawn markers' rectangles, which the render tests
// use to prove a marker landed on the right line.
func (p *MethodIconProvider) MethodIconRects() []image.Rectangle {
	rects := make([]image.Rectangle, 0, len(p.hits))
	for _, hit := range p.hits {
		rects = append(rects, hit.rect)
	}
	return rects
}

// drawMethodIcon paints one of IntelliJ's inheritance markers: a donut ring in the
// kind's colour, the letter inside it, and a red arrow above it pointing at the
// super type (up) or the subtype (down). The geometry is taken from the SVGs in
// platform/icons/src/expui/gutter, which are 14x14.
//
// The letters are drawn as their vectors rather than as text: IntelliJ ships them
// as paths, and text rendering would depend on the shaper.
func drawMethodIcon(gtx layout.Context, kind MethodIconKind, cx, cy, size float32) {
	scale := size / 14
	ringColor, fillColor := methodOverridesColor, methodOverridesFill
	letter := 'O'
	up := true
	switch kind {
	case MethodImplements:
		ringColor, fillColor, letter = methodImplementsColor, methodImplementsFill, 'I'
	case MethodOverridden:
		ringColor, fillColor, up = methodOverridesColor, methodOverridesFill, false
	case MethodImplemented:
		ringColor, fillColor, letter, up = methodImplementsColor, methodImplementsFill, 'I', false
	}

	// The icon's own origin: the SVG's (5.5, 7) is the ring's centre, and the box
	// is 14 wide, so the ring sits left of centre.
	ox, oy := cx-7*scale, cy-7*scale
	ringCenter := f32.Pt(ox+5.5*scale, oy+7*scale)

	// The dark disc the letter sits on, then the ring around it.
	disc := circlePath(gtx, ringCenter, methodIconRingRadius*scale)
	paint.FillShape(gtx.Ops, fillColor, clip.Outline{Path: disc}.Op())

	drawCircle(gtx, ringCenter, methodIconRingRadius*scale, methodIconStroke*scale, ringColor)

	if letter == 'O' {
		drawCircle(gtx, ringCenter, methodIconLetterRadius*scale, 0.55*scale, ringColor)
	} else {
		// IntelliJ's "I" has serifs: a top bar, a stem and a bottom bar.
		for _, r := range []image.Rectangle{
			image.Rect(int(ox+4*scale), int(oy+4*scale), int(ox+7*scale), int(oy+5*scale)),
			image.Rect(int(ox+5*scale), int(oy+5*scale), int(ox+6*scale), int(oy+9*scale)),
			image.Rect(int(ox+4*scale), int(oy+9*scale), int(ox+7*scale), int(oy+10*scale)),
		} {
			fillRect(gtx, r, ringColor)
		}
	}

	// The arrow: a stem at x = 11.5 and a head at y = 1.7 up, or mirrored down.
	arrowDY := float32(0)
	if !up {
		arrowDY = 7 * scale
	}
	tipY := oy + 1.7*scale + arrowDY
	headY := oy + 3.2*scale + arrowDY
	stemY := oy + 8*scale + arrowDY
	x := ox + 11.5*scale

	path := stroke.Path{}
	path.Segments = append(path.Segments,
		stroke.MoveTo(f32.Pt(x, stemY)),
		stroke.LineTo(f32.Pt(x, tipY)),
		stroke.MoveTo(f32.Pt(x-2.4*scale, headY)),
		stroke.LineTo(f32.Pt(x, tipY)),
		stroke.LineTo(f32.Pt(x+2.4*scale, headY)),
	)
	stack := stroke.Stroke{
		Path:  path,
		Width: methodIconStroke * scale,
		Cap:   stroke.RoundCap,
		Join:  stroke.RoundJoin,
	}.Op(gtx.Ops).Push(gtx.Ops)
	paint.ColorOp{Color: methodArrowColor}.Add(gtx.Ops)
	paint.PaintOp{}.Add(gtx.Ops)
	stack.Pop()
}

// drawCircle strokes a circle outline.
func drawCircle(gtx layout.Context, center f32.Point, radius, width float32, col color.NRGBA) {
	path := stroke.Path{}
	const segments = 24
	step := float32(2*math.Pi) / segments
	for i := 0; i <= segments; i++ {
		a := float64(i) * float64(step)
		p := f32.Pt(center.X+radius*float32(math.Cos(a)), center.Y+radius*float32(math.Sin(a)))
		if i == 0 {
			path.Segments = append(path.Segments, stroke.MoveTo(p))
			continue
		}
		path.Segments = append(path.Segments, stroke.LineTo(p))
	}
	stack := stroke.Stroke{
		Path:  path,
		Width: width,
		Cap:   stroke.RoundCap,
		Join:  stroke.RoundJoin,
	}.Op(gtx.Ops).Push(gtx.Ops)
	paint.ColorOp{Color: col}.Add(gtx.Ops)
	paint.PaintOp{}.Add(gtx.Ops)
	stack.Pop()
}

// circlePath builds a filled circle.
func circlePath(gtx layout.Context, center f32.Point, radius float32) clip.PathSpec {
	var path clip.Path
	path.Begin(gtx.Ops)
	const segments = 24
	step := float32(2*math.Pi) / segments
	path.MoveTo(f32.Pt(center.X+radius, center.Y))
	for i := 1; i <= segments; i++ {
		a := float64(i) * float64(step)
		path.LineTo(f32.Pt(center.X+radius*float32(math.Cos(a)), center.Y+radius*float32(math.Sin(a))))
	}
	path.Close()
	return path.End()
}

// fillRect fills an axis-aligned rectangle.
func fillRect(gtx layout.Context, r image.Rectangle, col color.NRGBA) {
	if r.Empty() {
		return
	}
	defer clip.Rect(r).Push(gtx.Ops).Pop()
	paint.ColorOp{Color: col}.Add(gtx.Ops)
	paint.PaintOp{}.Add(gtx.Ops)
}
