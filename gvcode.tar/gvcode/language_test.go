package gvcode

import (
	"image"
	"strings"
	"testing"

	"gioui.org/io/key"
	"gioui.org/unit"

	"github.com/oligo/gvcode/lsp"
)

// newLanguageHarness builds a focused editor wired to the mock language server.
func newLanguageHarness(t *testing.T, content string) *columnEditHarness {
	t.Helper()
	h := newColumnEditHarness(t, content, image.Pt(560, 220), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	h.ed.WithOptions(WithLanguageServer(lsp.NewMockServer()))
	for range 2 {
		h.frame(true)
	}
	return h
}

const languageSample = "package main\n" +
	"\n" +
	"// greet says hello.\n" +
	"func greet(name string, times int) {\n" +
	"\tprintln(name)\n" +
	"}\n" +
	"\n" +
	"func main() {\n" +
	"\tunused := 1\n" +
	"\tgreet(\"hi\", 3)\n" +
	"\t// TODO: handle errors\n" +
	"}\n"

// TestLanguageDiagnosticsBecomeSquiggles pins the diagnostics wiring: the mock
// server's unused-variable warning and TODO marker must reach the editor and be
// painted, the warning as a squiggle and the TODO as a highlighted run.
func TestLanguageDiagnosticsBecomeSquiggles(t *testing.T) {
	h := newLanguageHarness(t, languageSample)
	e := h.ed
	h.frame(true)

	diags := e.Diagnostics()
	var hasUnused, hasTodo bool
	for _, d := range diags {
		switch d.Code {
		case "unused-variable":
			hasUnused = true
		case "todo":
			hasTodo = true
		}
	}
	if !hasUnused || !hasTodo {
		t.Fatalf("diagnostics = %+v, want the unused variable and the TODO", diags)
	}

	img := image.NewRGBA(image.Rect(0, 0, 560, 220))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-language-diagnostics", img)

	lineHeight := e.text.GetLineHeight().Round()
	// The unused declaration is on document line 8.
	if n := countColorIn(img, e.gutterWidth, 560, 8*lineHeight, 9*lineHeight, warningSquiggleColor); n < 4 {
		t.Fatalf("no warning squiggle painted on the unused declaration (%d pixels)", n)
	}
	// The TODO comment is on document line 10. The highlight is a translucent
	// yellow wash, so it is counted as "yellowish" rather than by exact colour.
	if n := countYellowishIn(img, e.gutterWidth, 560, 10*lineHeight, 11*lineHeight); n < 20 {
		t.Fatalf("no TODO background painted (%d yellowish pixels)", n)
	}
}

// countYellowishIn counts pixels whose red and green clearly dominate the blue,
// which is what the translucent TODO wash produces over the dark background.
func countYellowishIn(img *image.RGBA, x0, x1, y0, y1 int) int {
	n := 0
	for y := y0; y < y1; y++ {
		for x := x0; x < x1; x++ {
			r, g, b, _ := img.At(x, y).RGBA()
			rr, gg, bb := int(r>>8), int(g>>8), int(b>>8)
			if rr >= 0x30 && gg >= 0x30 && bb+16 < rr && bb+16 < gg {
				n++
			}
		}
	}
	return n
}

// TestLanguageInlayHintsNameArguments pins the inlay hints: the arguments of a
// call to a function declared in the same file get parameter-name hints, painted
// without shifting the text.
func TestLanguageInlayHintsNameArguments(t *testing.T) {
	h := newLanguageHarness(t, languageSample)
	e := h.ed
	h.frame(true)

	labels := map[string]bool{}
	for _, hint := range e.InlayHints() {
		labels[hint.Label] = true
	}
	if !labels["name:"] || !labels["times:"] {
		t.Fatalf("inlay hints = %+v, want the two parameter names", e.InlayHints())
	}

	img := image.NewRGBA(image.Rect(0, 0, 560, 220))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-language-inlay-hints", img)

	lineHeight := e.text.GetLineHeight().Round()
	// The call sits on document line 9; the hints are grey labels there.
	if n := countColorIn(img, e.gutterWidth, 560, 9*lineHeight, 10*lineHeight, inlayHintColor); n < 6 {
		t.Fatalf("no inlay hint painted on the call (%d grey pixels)", n)
	}
}

// TestLanguageIntentionsOfferTheQuickFixAndTheIntention pins Alt+Enter's data
// path: with the caret on the unused declaration both the diagnostic fix and the
// "convert to var" intention are offered, and applying the first one deletes the
// declaration — IntelliJ's ShowIntentionActions contract.
func TestLanguageIntentionsOfferTheQuickFixAndTheIntention(t *testing.T) {
	h := newLanguageHarness(t, languageSample)
	e := h.ed

	// The caret inside the "unused" name on line 8.
	off := runeOffsetOfDocumentLine(languageSample, 8) + len("\tunus")
	e.SetCaret(off, off)
	h.frame(true)

	event, ok := e.RequestIntentions()
	if !ok {
		t.Fatal("Alt+Enter found no actions at the unused declaration")
	}
	intention, isIntention := event.(IntentionEvent)
	if !isIntention {
		t.Fatalf("a single action was applied instead of offering the popup: %T", event)
	}
	if len(intention.Actions) != 2 {
		t.Fatalf("actions = %+v, want the quick fix and the intention", intention.Actions)
	}
	if intention.Actions[0].Kind != lsp.QuickFixKind {
		t.Fatalf("the quick fix should be listed first: %+v", intention.Actions)
	}
	if intention.Actions[1].Kind != lsp.RefactorKind {
		t.Fatalf("the intention should be listed second: %+v", intention.Actions)
	}

	if !e.ApplyCodeAction(0) {
		t.Fatal("applying the quick fix failed")
	}
	h.frame(true)
	h.frame(true)

	want := "package main\n" +
		"\n" +
		"// greet says hello.\n" +
		"func greet(name string, times int) {\n" +
		"\tprintln(name)\n" +
		"}\n" +
		"\n" +
		"func main() {\n" +
		"\tgreet(\"hi\", 3)\n" +
		"\t// TODO: handle errors\n" +
		"}\n"
	if got := e.Text(); got != want {
		t.Fatalf("after the quick fix:\n%q\nwant\n%q", got, want)
	}
}

// TestLanguageAltEnterAppliesASingleAction drives the real Alt+Enter key where
// only one action exists: IntelliJ applies it without showing a popup. The
// document uses its short declaration, so the only action is "convert to var".
func TestLanguageAltEnterAppliesASingleAction(t *testing.T) {
	content := "package main\n" +
		"\n" +
		"func main() {\n" +
		"\tx := 1\n" +
		"\tprintln(x)\n" +
		"}\n"
	h := newLanguageHarness(t, content)
	e := h.ed

	caret := runeOffsetOfDocumentLine(content, 3) + len("\tx")
	e.SetCaret(caret, caret)
	h.frame(true)

	h.pressKey(key.NameEnter, key.ModAlt)
	h.frame(true)
	h.frame(true)

	want := "package main\n" +
		"\n" +
		"func main() {\n" +
		"\tvar x = 1\n" +
		"\tprintln(x)\n" +
		"}\n"
	if got := e.Text(); got != want {
		t.Fatalf("after Alt+Enter with a single action:\n%q\nwant\n%q", got, want)
	}
}

// TestLanguageSymbolPathFeedsBreadcrumbs pins the breadcrumb source: the outline
// entries containing the caret, outermost first.
func TestLanguageSymbolPathFeedsBreadcrumbs(t *testing.T) {
	h := newLanguageHarness(t, languageSample)
	e := h.ed

	// The caret inside greet's body (line 4).
	off := runeOffsetOfDocumentLine(languageSample, 4) + 2
	e.SetCaret(off, off)
	h.frame(true)

	path := e.SymbolPath()
	if len(path) != 1 || path[0].Name != "greet" {
		t.Fatalf("symbol path = %+v, want just greet", path)
	}

	// The caret outside every declaration has an empty trail.
	e.SetCaret(0, 0)
	h.frame(true)
	if p := e.SymbolPath(); len(p) != 0 {
		t.Fatalf("symbol path at the top = %+v, want empty", p)
	}
}

// TestLanguageQuickDocumentationAndParameterInfo pins the two popups: Ctrl+Q
// shows the hover contents, Ctrl+P the signature with the active parameter
// marked, and both are painted above the text.
func TestLanguageQuickDocumentationAndParameterInfo(t *testing.T) {
	h := newLanguageHarness(t, languageSample)
	e := h.ed

	// The caret inside the "greet" call arguments on line 9.
	off := runeOffsetOfDocumentLine(languageSample, 9) + len("\tgreet(\"hi\", ")
	e.SetCaret(off, off)
	h.frame(true)

	h.pressKey("P", key.ModShortcut)
	h.frame(true)
	if e.language.parameterInfo == nil {
		t.Fatal("Ctrl+P did not open the parameter info popup")
	}
	if got := e.language.parameterInfo.lines[0]; got != "func greet(name string, times int)" {
		t.Fatalf("parameter info signature = %q", got)
	}
	if !containsLine(e.language.parameterInfo.lines, "current: times") {
		t.Fatalf("parameter info lost the active parameter: %+v", e.language.parameterInfo.lines)
	}

	img := image.NewRGBA(image.Rect(0, 0, 560, 220))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-language-parameter-info", img)

	// Ctrl+P again closes it, Ctrl+Q opens the documentation instead.
	h.pressKey("P", key.ModShortcut)
	h.frame(true)
	if e.language.parameterInfo != nil {
		t.Fatal("Ctrl+P did not close the parameter info popup")
	}

	// Ctrl+Q on the declaration name opens the documentation popup.
	hoverOff := runeOffsetOfDocumentLine(languageSample, 3) + len("func gre")
	e.SetCaret(hoverOff, hoverOff)
	h.frame(true)
	h.pressKey("Q", key.ModShortcut)
	h.frame(true)
	if e.language.quickDoc == nil {
		t.Fatal("Ctrl+Q did not open the quick documentation popup")
	}
	joined := strings.Join(e.language.quickDoc.lines, "\n")
	if !strings.Contains(joined, "greet says hello.") {
		t.Fatalf("quick doc contents = %q", joined)
	}

	img = image.NewRGBA(image.Rect(0, 0, 560, 220))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-language-quick-doc", img)

	// Esc closes it, the way IntelliJ dismisses the documentation popup.
	h.pressKey(key.NameEscape, 0)
	h.frame(true)
	if e.language.quickDoc != nil {
		t.Fatal("Esc did not close the quick documentation popup")
	}
}

func containsLine(lines []string, want string) bool {
	for _, line := range lines {
		if line == want {
			return true
		}
	}
	return false
}
