package gvcode

import (
	"image"
	"sort"

	"gioui.org/layout"
	gvcolor "github.com/oligo/gvcode/color"
)

// caretRange is one caret's selection, in rune offsets.
type caretRange struct {
	start, end int
}

// multiCaretState mirrors IntelliJ's multi-caret editing
// (EditorMultiCaretModeTest / a CaretModel with several carets): every caret
// carries its own selection, so typing replaces all of them at once. The primary
// caret stays in the text view itself — index 0 of allCarets — which keeps normal
// editing, undo and painting untouched.
type multiCaretState struct {
	// carets holds the carets beyond the primary one.
	carets []caretRange
}

// multiCaretEdit is one edit of a multi-caret operation.
type multiCaretEdit struct {
	// from and to delimit the replaced range.
	from, to int
	// insert is the replacement text; empty means a plain removal.
	insert string
	// primary marks the edit of the primary caret.
	primary bool
}

// MultiCaretEnabled reports whether more than one caret is active.
func (e *Editor) MultiCaretEnabled() bool {
	return len(e.multiCaret.carets) > 0
}

// extraCarets returns the carets beyond the primary one.
func (e *Editor) extraCarets() []caretRange {
	return e.multiCaret.carets
}

// clearMultiCarets drops every extra caret, the way Esc collapses a multi-caret
// session in IntelliJ.
func (e *Editor) clearMultiCarets() {
	e.multiCaret.carets = e.multiCaret.carets[:0]
}

// allCarets returns the primary caret plus the extras; the primary is first so
// callers can tell which caret the text view mirrors.
func (e *Editor) allCarets() []caretRange {
	start, end := e.text.Selection()
	all := make([]caretRange, 0, len(e.multiCaret.carets)+1)
	all = append(all, caretRange{start: start, end: end})
	all = append(all, e.multiCaret.carets...)
	return all
}

// addCaretAt adds a caret at a rune offset (IntelliJ: Ctrl+Click in the editor).
// An offset that already carries a caret is ignored.
func (e *Editor) addCaretAt(runeOff int) {
	if runeOff < 0 || runeOff > e.text.Len() {
		return
	}
	for _, c := range e.allCarets() {
		if c.start == runeOff {
			return
		}
	}
	e.multiCaret.carets = append(e.multiCaret.carets, caretRange{start: runeOff, end: runeOff})
}

// occurrenceRange returns the rune range an occurrence action works on: the
// primary selection when there is one, otherwise the word at the primary caret,
// which the action promotes to a selection the way IntelliJ's
// SelectNextOccurrenceAction does.
func (e *Editor) occurrenceRange() (caretRange, bool) {
	start, end := e.text.Selection()
	if start != end {
		if start > end {
			start, end = end, start
		}
		return caretRange{start: start, end: end}, true
	}
	wordStart, wordEnd := e.text.WordBoundariesAt(start, false)
	if wordStart == wordEnd {
		return caretRange{}, false
	}
	return caretRange{start: wordStart, end: wordEnd}, true
}

// selectNextOccurrence is IntelliJ's SelectNextOccurrenceAction (Alt+J). The first
// press only selects the word under the caret; later presses add a caret at the
// next occurrence after every caret already there, so repeated presses walk the
// file without revisiting a caret.
func (e *Editor) selectNextOccurrence() {
	current, ok := e.occurrenceRange()
	if !ok {
		return
	}
	if start, end := e.text.Selection(); start == end {
		// No selection yet: IntelliJ selects the word under the caret and stops.
		e.text.SetCaret(current.start, current.end)
		return
	}

	last := current.end
	for _, c := range e.allCarets() {
		if c.end > last {
			last = c.end
		}
	}
	for _, occ := range e.text.FindAllTextOccurrences(current.start, current.end) {
		if occ[0] < last {
			continue
		}
		e.multiCaret.carets = append(e.multiCaret.carets, caretRange{start: occ[0], end: occ[1]})
		e.sortCarets()
		return
	}
}

// selectAllOccurrences is IntelliJ's SelectAllOccurrencesAction
// (Ctrl+Alt+Shift+J): a caret at every occurrence of the current word or
// selection.
func (e *Editor) selectAllOccurrences() {
	current, ok := e.occurrenceRange()
	if !ok {
		return
	}

	e.clearMultiCarets()
	e.text.SetCaret(current.start, current.end)
	for _, occ := range e.text.FindAllTextOccurrences(current.start, current.end) {
		if occ[0] == current.start && occ[1] == current.end {
			continue
		}
		e.multiCaret.carets = append(e.multiCaret.carets, caretRange{start: occ[0], end: occ[1]})
	}
	e.sortCarets()
}

// sortCarets keeps the extra carets ordered by offset, which keeps painting and
// reading them deterministic.
func (e *Editor) sortCarets() {
	carets := e.multiCaret.carets
	sort.SliceStable(carets, func(i, j int) bool { return carets[i].start < carets[j].start })
}

// multiCaretInsert types text at every caret, replacing each caret's selection.
func (e *Editor) multiCaretInsert(text string) {
	carets := e.allCarets()
	edits := make([]multiCaretEdit, 0, len(carets))
	for i, c := range carets {
		edits = append(edits, multiCaretEdit{from: c.start, to: c.end, insert: text, primary: i == 0})
	}
	e.applyMultiCaretEdits(edits)
	e.scrollCaret = true
}

// multiCaretDelete removes every caret's selection, or one rune before or after an
// empty caret, mirroring what a single Backspace/Delete does.
func (e *Editor) multiCaretDelete(backward bool) (deleted int) {
	length := e.text.Len()
	carets := e.allCarets()
	edits := make([]multiCaretEdit, 0, len(carets))
	for i, c := range carets {
		from, to := c.start, c.end
		if from == to {
			if backward {
				from--
			} else {
				to++
			}
		}
		// A caret that has nothing to delete still contributes a no-op edit, so its
		// position is remapped like the others.
		if from < 0 || to > length || from == to {
			edits = append(edits, multiCaretEdit{from: c.start, to: c.start, primary: i == 0})
			continue
		}
		edits = append(edits, multiCaretEdit{from: from, to: to, primary: i == 0})
		deleted++
	}
	if deleted > 0 {
		e.applyMultiCaretEdits(edits)
		e.scrollCaret = true
	}
	return deleted
}

// applyMultiCaretEdits performs one edit per caret and recomputes where every caret
// lands. The edits are applied from the highest offset down, so the offsets the
// remaining carets hold stay valid, and each caret ends up at the end of its own
// insertion (or where the removed text began).
func (e *Editor) applyMultiCaretEdits(edits []multiCaretEdit) {
	descending := append([]multiCaretEdit(nil), edits...)
	sort.SliceStable(descending, func(i, j int) bool { return descending[i].from > descending[j].from })
	for _, ed := range descending {
		if ed.from == ed.to && ed.insert == "" {
			continue
		}
		e.text.Replace(ed.from, ed.to, ed.insert)
	}

	ascending := append([]multiCaretEdit(nil), edits...)
	sort.SliceStable(ascending, func(i, j int) bool { return ascending[i].from < ascending[j].from })

	primary := -1
	extras := make([]caretRange, 0, len(ascending))
	seen := make(map[int]bool, len(ascending))
	delta := 0
	for _, ed := range ascending {
		pos := ed.from + len([]rune(ed.insert)) + delta
		delta += len([]rune(ed.insert)) - (ed.to - ed.from)

		if seen[pos] {
			// Two carets met after deleting the text between them: IntelliJ keeps
			// one.
			continue
		}
		seen[pos] = true
		if ed.primary {
			primary = pos
			continue
		}
		extras = append(extras, caretRange{start: pos, end: pos})
	}

	if primary >= 0 {
		e.text.SetCaret(primary, primary)
	}
	e.multiCaret.carets = append(e.multiCaret.carets[:0], extras...)
	e.sortCarets()
}

// paintMultiCaretSelections draws the selections of the carets beyond the primary
// one. They belong under the text, like the primary selection.
func (e *Editor) paintMultiCaretSelections(gtx layout.Context, selectionColor gvcolor.Color) {
	if !e.MultiCaretEnabled() {
		return
	}
	selOp := selectionColor.Op(gtx.Ops)
	for _, c := range e.extraCarets() {
		if c.start != c.end {
			e.text.PaintSelectionRange(gtx, c.start, c.end, selOp)
		}
	}
}

// paintMultiCaretCarets draws the caret bars of the carets beyond the primary one.
func (e *Editor) paintMultiCaretCarets(gtx layout.Context, caretColor gvcolor.Color) {
	if !e.MultiCaretEnabled() {
		return
	}
	caretOp := caretColor.Op(gtx.Ops)
	for _, c := range e.extraCarets() {
		e.text.PaintCaretAt(gtx, c.end, caretOp)
	}
}

// multiCaretCaretRects exposes the extra carets' rectangles, which the render tests
// use to prove the carets are drawn where they belong.
func (e *Editor) multiCaretCaretRects() []image.Rectangle {
	rects := make([]image.Rectangle, 0, len(e.multiCaret.carets))
	for _, c := range e.multiCaret.carets {
		pos, ascent, descent := e.text.CaretInfoAt(c.end)
		rects = append(rects, image.Rect(pos.X-1, pos.Y-ascent, pos.X+1, pos.Y+descent))
	}
	return rects
}
