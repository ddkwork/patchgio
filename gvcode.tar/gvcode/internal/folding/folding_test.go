package folding

import "testing"

// TestDetectFoldsKeepsTheClosingBraceVisible pins the convention that fold ranges
// cover the BODY of a braced block: the header line and the closing brace both stay
// on screen, the way IntelliJ folds a method, so a collapsed fold has somewhere to
// put its placeholder and neither brace disappears.
func TestDetectFoldsKeepsTheClosingBraceVisible(t *testing.T) {
	m := NewManager()
	m.AnalyzeLines([]string{
		"package main",  // 0
		"",              // 1
		"func main() {", // 2
		"\tprintln(1)",  // 3
		"\tprintln(2)",  // 4
		"}",             // 5
		"",              // 6
	})

	ranges := m.GetFoldRanges()
	if len(ranges) != 1 {
		t.Fatalf("fold ranges = %+v, want exactly one for the function body", ranges)
	}
	r := ranges[0]
	if r.StartLine != 2 || r.EndLine != 4 {
		t.Fatalf("fold range = %d..%d, want 2..4 (the body only, closing brace excluded)",
			r.StartLine, r.EndLine)
	}

	// Collapsing hides the body and nothing else.
	if !m.CollapseFold(2) {
		t.Fatal("CollapseFold reported no change")
	}
	for line, want := range map[int]bool{2: true, 3: false, 4: false, 5: true} {
		if got := m.IsLineVisible(line); got != want {
			t.Fatalf("IsLineVisible(%d) = %v, want %v", line, got, want)
		}
	}
}

// TestDetectFoldsKeepsTheClosingParenthesisVisible mirrors the brace rule for
// import/const/var blocks: the closing parenthesis is not part of the folded body.
func TestDetectFoldsKeepsTheClosingParenthesisVisible(t *testing.T) {
	m := NewManager()
	m.AnalyzeLines([]string{
		"package main", // 0
		"",             // 1
		"import (",     // 2
		"\t\"fmt\"",    // 3
		"\t\"os\"",     // 4
		")",            // 5
	})

	found := false
	for _, r := range m.GetFoldRanges() {
		if r.StartLine == 2 {
			found = true
			if r.EndLine != 4 {
				t.Fatalf("import fold = %d..%d, want 2..4 (closing parenthesis excluded)",
					r.StartLine, r.EndLine)
			}
		}
	}
	if !found {
		t.Fatalf("no fold range for the import block: %+v", m.GetFoldRanges())
	}
}

// TestDetectFoldsSkipsSingleLineBodies: a body that is only braces has nothing to
// hide, so it must not produce a fold the user could collapse into nothing.
func TestDetectFoldsSkipsSingleLineBodies(t *testing.T) {
	m := NewManager()
	m.AnalyzeLines([]string{
		"package main", // 0
		"",             // 1
		"func f() {}",  // 2
	})

	if ranges := m.GetFoldRanges(); len(ranges) != 0 {
		t.Fatalf("a one-line function produced fold ranges: %+v", ranges)
	}
}

// TestDetectFoldsFindsNestedBlocks pins that a block nested inside another one is
// foldable on its own. IntelliJ folds every code block, so an `if`/`for` body
// inside a function gets its own region; the earlier detector only looked at
// brace depth zero and therefore missed all of them.
func TestDetectFoldsFindsNestedBlocks(t *testing.T) {
	m := NewManager()
	m.AnalyzeLines([]string{
		"package main",         // 0
		"",                     // 1
		"func f() {",           // 2
		"\tif x {",             // 3
		"\t\ta()",              // 4
		"\t}",                  // 5
		"\tfor i := range y {", // 6
		"\t\tb()",              // 7
		"\t}",                  // 8
		"}",                    // 9
	})

	want := map[int]int{2: 8, 3: 4, 6: 7}
	got := map[int]int{}
	for _, r := range m.GetFoldRanges() {
		got[r.StartLine] = r.EndLine
	}
	if len(got) != len(want) {
		t.Fatalf("fold ranges = %+v, want one per block: %v", m.GetFoldRanges(), want)
	}
	for start, end := range want {
		if got[start] != end {
			t.Fatalf("fold at line %d ends at %d, want %d (ranges %+v)",
				start, got[start], end, m.GetFoldRanges())
		}
	}
}

// TestDetectFoldsIgnoresBracesInStringsAndComments: a `{` that is only text must
// not open a block, otherwise the fold stack desynchronises and every region
// after it is wrong.
func TestDetectFoldsIgnoresBracesInStringsAndComments(t *testing.T) {
	m := NewManager()
	m.AnalyzeLines([]string{
		"package main", // 0
		"",             // 1
		"func f() {",   // 2
		"\ts := \"{\"", // 3
		"\t// }",       // 4
		"\t/* { */",    // 5
		"}",            // 6
	})

	ranges := m.GetFoldRanges()
	if len(ranges) != 1 {
		t.Fatalf("fold ranges = %+v, want exactly the function body", ranges)
	}
	if ranges[0].StartLine != 2 || ranges[0].EndLine != 5 {
		t.Fatalf("fold = %d..%d, want 2..5", ranges[0].StartLine, ranges[0].EndLine)
	}
}

// TestDetectFoldsFoldsMultiLineComment mirrors IntelliJ's comment folding: a block
// comment spanning several lines collapses, with the closing line left visible.
func TestDetectFoldsFoldsMultiLineComment(t *testing.T) {
	m := NewManager()
	m.AnalyzeLines([]string{
		"package main", // 0
		"/*",           // 1
		"   hi",        // 2
		"*/",           // 3
		"func f() {",   // 4
		"}",            // 5
	})

	ranges := m.GetFoldRanges()
	if len(ranges) != 1 {
		t.Fatalf("fold ranges = %+v, want exactly the comment", ranges)
	}
	if ranges[0].StartLine != 1 || ranges[0].EndLine != 2 || ranges[0].Type != FoldTypeComment {
		t.Fatalf("comment fold = %+v, want comment 1..2", ranges[0])
	}
}

// TestDetectFoldsOnlyFoldsDeclarationGroups: a parenthesised declaration group
// folds, but a parenthesised argument list that merely follows the same keyword
// on the line does not — `const x = f(` is a call, not a block.
func TestDetectFoldsOnlyFoldsDeclarationGroups(t *testing.T) {
	m := NewManager()
	m.AnalyzeLines([]string{
		"package main", // 0
		"",             // 1
		"type (",       // 2
		"\tC = int",    // 3
		")",            // 4
		"",             // 5
		"const x = f(", // 6
		"\t1,",         // 7
		")",            // 8
	})

	byStart := map[int]FoldRange{}
	for _, r := range m.GetFoldRanges() {
		byStart[r.StartLine] = r
	}
	if r, ok := byStart[2]; !ok || r.Type != FoldTypeType || r.EndLine != 3 {
		t.Fatalf("type group = %+v, want a type fold 2..3", r)
	}
	if r, ok := byStart[6]; ok {
		t.Fatalf("an argument list produced a fold: %+v", r)
	}
}

// TestDetectFoldsClassifiesBlocks pins the fold metadata the gutter uses for its
// tooltip and icon: a function, a type body, an import group and a control-flow
// block each report their own kind.
func TestDetectFoldsClassifiesBlocks(t *testing.T) {
	m := NewManager()
	m.AnalyzeLines([]string{
		"package main",                     // 0
		"",                                 // 1
		"import (",                         // 2
		"\t\"fmt\"",                        // 3
		")",                                // 4
		"",                                 // 5
		"type Event struct {",              // 6
		"\tName string",                    // 7
		"}",                                // 8
		"",                                 // 9
		"func (e Event) String() string {", // 10
		"\tif e.Name == \"\" {",            // 11
		"\t\treturn \"\"",                  // 12
		"\t}",                              // 13
		"\treturn e.Name",                  // 14
		"}",                                // 15
	})

	byStart := map[int]FoldRange{}
	for _, r := range m.GetFoldRanges() {
		byStart[r.StartLine] = r
	}

	if r, ok := byStart[2]; !ok || r.Type != FoldTypeImport {
		t.Fatalf("import group = %+v, want an import fold at line 2", r)
	}
	if r, ok := byStart[6]; !ok || r.Type != FoldTypeType || r.Name != "Event" {
		t.Fatalf("type block = %+v, want a type fold named Event at line 6", r)
	}
	if r, ok := byStart[10]; !ok || r.Type != FoldTypeFunction || r.Name != "String" {
		t.Fatalf("method block = %+v, want a function fold named String at line 10", r)
	}
	if r, ok := byStart[11]; !ok || r.Type != FoldTypeBlock {
		t.Fatalf("if block = %+v, want a generic code block at line 11", r)
	}
}
