// Package folding implements code folding functionality for the editor.
// It provides code structure analysis and manages fold regions.
package folding

import (
	"regexp"
	"sort"
	"strings"
	"sync"
)

// FoldType represents the type of foldable region.
type FoldType int

const (
	// FoldTypeFunction represents a function/method fold.
	FoldTypeFunction FoldType = iota
	// FoldTypeType represents a type definition fold.
	FoldTypeType
	// FoldTypeComment represents a multi-line comment fold.
	FoldTypeComment
	// FoldTypeImport represents an import block fold.
	FoldTypeImport
	// FoldTypeConst represents a const block fold.
	FoldTypeConst
	// FoldTypeVar represents a var block fold.
	FoldTypeVar
	// FoldTypeRegion represents a user-defined region fold.
	FoldTypeRegion
	// FoldTypeBlock represents a generic code block: the body of an if, for,
	// switch, select or a bare braced block.
	FoldTypeBlock
)

// String returns the string representation of the fold type.
func (t FoldType) String() string {
	switch t {
	case FoldTypeFunction:
		return "function"
	case FoldTypeType:
		return "type"
	case FoldTypeComment:
		return "comment"
	case FoldTypeImport:
		return "import"
	case FoldTypeConst:
		return "const"
	case FoldTypeVar:
		return "var"
	case FoldTypeRegion:
		return "region"
	case FoldTypeBlock:
		return "block"
	default:
		return "unknown"
	}
}

// FoldRange represents a foldable region in the code.
type FoldRange struct {
	// StartLine is the 0-based starting line number.
	StartLine int
	// EndLine is the 0-based ending line number (inclusive).
	EndLine int
	// Type is the type of fold.
	Type FoldType
	// Name is a descriptive name for the fold (e.g., function name).
	Name string
	// Collapsed indicates whether the fold is currently collapsed.
	Collapsed bool
	// Level is the nesting level of the fold.
	Level int
}

// Manager manages code folding regions and their states.
type Manager struct {
	mu sync.RWMutex

	// foldRanges contains all detected fold ranges.
	foldRanges []FoldRange

	// collapsedLines tracks which lines are hidden due to folding.
	// A line is considered collapsed if it's within a collapsed fold range.
	collapsedLines map[int]bool

	// lineCache caches the last analyzed lines.
	lineCache []string

	// foldMarkers caches the positions of fold markers in the text.
	foldMarkers []FoldMarker

	// version counts fold-state changes, so caches that depend on which lines are
	// visible can detect staleness. See Version.
	version uint64
}

// FoldMarker represents a fold marker (opening or closing brace).
type FoldMarker struct {
	Line  int
	Type  MarkerType
	Level int
}

// MarkerType represents the type of fold marker.
type MarkerType int

const (
	// MarkerOpen represents an opening brace or start of fold.
	MarkerOpen MarkerType = iota
	// MarkerClose represents a closing brace or end of fold.
	MarkerClose
)

// NewManager creates a new folding manager.
func NewManager() *Manager {
	return &Manager{
		foldRanges:     make([]FoldRange, 0),
		collapsedLines: make(map[int]bool),
	}
}

// AnalyzeLines analyzes the given lines and detects foldable regions.
// This should be called whenever the document content changes.
func (m *Manager) AnalyzeLines(lines []string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	// Check if lines have changed
	if m.linesEqual(m.lineCache, lines) {
		return
	}

	m.lineCache = make([]string, len(lines))
	copy(m.lineCache, lines)

	// Clear previous analysis
	m.foldRanges = m.foldRanges[:0]
	m.foldMarkers = m.foldMarkers[:0]

	// Analyze the code structure
	m.detectFolds(lines)

	// Rebuild collapsed lines map
	m.rebuildCollapsedLines()

	// The set of foldable regions changed, so anything that cached which lines
	// are visible must be redone.
	m.version++
}

// Version returns a counter that changes whenever the fold state changes. Caches
// that depend on which lines are visible compare it to tell whether they are
// stale — collapsing a fold changes no text at all, so a text-only cache key
// would happily keep the folded lines on screen.
func (m *Manager) Version() uint64 {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.version
}

// linesEqual checks if two line slices are equal.
func (m *Manager) linesEqual(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

// blockDetector walks the source character by character so braces and
// parentheses that live inside strings, runes or comments never open a fold —
// a plain strings.Count over a line happily counts a `{` in "fmt.Println(\"{\")".
//
// Every braced block that spans more than one line becomes a fold, regardless of
// nesting, which is what IntelliJ's code-block folding does: a `func` body, an
// `if`, a `switch`, a composite literal and a closure are all code blocks. The
// header keyword only decides the fold's name and icon.
type blockDetector struct {
	lines   []string
	ranges  *[]FoldRange
	stack   []blockEntry
	line    int
	lineOff int // byte offset of the current line's first byte
}

type blockEntry struct {
	openLine int
	open     byte // '{' or '('
	kind     FoldType
	name     string
	level    int
	foldable bool
}

// scanner states for blockDetector.
const (
	stCode = iota
	stLineComment
	stBlockComment
	stString
	stRawString
	stRune
)

func (d *blockDetector) run() {
	src := strings.Join(d.lines, "\n")
	state := stCode
	blockCommentStart := -1

	for i := 0; i < len(src); i++ {
		c := src[i]
		switch state {
		case stCode:
			switch c {
			case '\n':
				d.line++
				d.lineOff = i + 1
			case '/':
				if i+1 < len(src) {
					switch src[i+1] {
					case '/':
						state = stLineComment
						i++
					case '*':
						state = stBlockComment
						blockCommentStart = d.line
						i++
					}
				}
			case '"':
				state = stString
			case '`':
				state = stRawString
			case '\'':
				state = stRune
			case '{':
				kind, name := d.classifyBlock(i - d.lineOff)
				d.stack = append(d.stack, blockEntry{
					openLine: d.line,
					open:     '{',
					kind:     kind,
					name:     name,
					level:    len(d.stack),
					foldable: true,
				})
			case '(':
				kind, name, foldable := d.classifyParen(i - d.lineOff)
				d.stack = append(d.stack, blockEntry{
					openLine: d.line,
					open:     '(',
					kind:     kind,
					name:     name,
					level:    len(d.stack),
					foldable: foldable,
				})
			case '}':
				d.closeBrace()
			case ')':
				d.closeParen()
			}
		case stLineComment:
			if c == '\n' {
				state = stCode
				d.line++
				d.lineOff = i + 1
			}
		case stBlockComment:
			if c == '\n' {
				d.line++
				d.lineOff = i + 1
			} else if c == '*' && i+1 < len(src) && src[i+1] == '/' {
				// A comment block of its own is foldable, the same way IntelliJ
				// folds a multi-line comment. The closing line stays visible.
				if end := d.line - 1; end > blockCommentStart {
					*d.ranges = append(*d.ranges, FoldRange{
						StartLine: blockCommentStart,
						EndLine:   end,
						Type:      FoldTypeComment,
						Name:      "comment",
					})
				}
				state = stCode
				i++
			}
		case stString:
			switch c {
			case '\\':
				i++
			case '"':
				state = stCode
			case '\n':
				// An unterminated literal is a syntax error; resynchronise at the
				// line break so one bad line cannot swallow the rest of the file.
				state = stCode
				d.line++
				d.lineOff = i + 1
			}
		case stRawString:
			if c == '`' {
				state = stCode
			} else if c == '\n' {
				d.line++
				d.lineOff = i + 1
			}
		case stRune:
			switch c {
			case '\\':
				i++
			case '\'':
				state = stCode
			}
		}
	}

	// Unterminated blocks (malformed code) still fold down to the last line.
	last := len(d.lines) - 1
	for _, e := range d.stack {
		if !e.foldable || last <= e.openLine {
			continue
		}
		*d.ranges = append(*d.ranges, FoldRange{
			StartLine: e.openLine,
			EndLine:   last,
			Type:      e.kind,
			Name:      e.name,
			Level:     e.level,
		})
	}
}

func (d *blockDetector) closeBrace() {
	for len(d.stack) > 0 {
		e := d.stack[len(d.stack)-1]
		d.stack = d.stack[:len(d.stack)-1]
		d.emit(e, d.line)
		if e.open == '{' {
			return
		}
	}
}

func (d *blockDetector) closeParen() {
	if len(d.stack) == 0 || d.stack[len(d.stack)-1].open != '(' {
		return
	}
	e := d.stack[len(d.stack)-1]
	d.stack = d.stack[:len(d.stack)-1]
	d.emit(e, d.line)
}

// emit records the fold for a block that closes on closeLine. The region covers
// the BODY only: the header line and the closing token both stay on screen,
// which is how IntelliJ folds a method and what leaves room for the placeholder.
func (d *blockDetector) emit(e blockEntry, closeLine int) {
	if !e.foldable {
		return
	}
	if end := closeLine - 1; end > e.openLine {
		*d.ranges = append(*d.ranges, FoldRange{
			StartLine: e.openLine,
			EndLine:   end,
			Type:      e.kind,
			Name:      e.name,
			Level:     e.level,
		})
	}
}

// classifyParen recognises the parenthesised declaration groups Go writes as
// `import (`, `const (`, `var (` and `type (`. The keyword must be the ONLY thing
// before the paren — `const x = f(` opens an argument list, not a declaration
// group — and every other parenthesis is tracked for matching without folding.
func (d *blockDetector) classifyParen(col int) (FoldType, string, bool) {
	switch strings.TrimSpace(d.linePrefix(col)) {
	case "import":
		return FoldTypeImport, "import", true
	case "const":
		return FoldTypeConst, "const", true
	case "var":
		return FoldTypeVar, "var", true
	case "type":
		return FoldTypeType, "type", true
	}
	return FoldTypeBlock, "", false
}

// classifyBlock names the block whose opening brace sits at col. A Go signature
// may be wrapped so that the brace lands on a line with no keyword at all, in
// which case the search walks back over the continuation lines.
func (d *blockDetector) classifyBlock(col int) (FoldType, string) {
	if kind, name, ok := classifySignature(d.linePrefix(col)); ok {
		return kind, name
	}
	for i := d.line - 1; i >= 0 && d.line-i <= 12; i-- {
		prev := strings.TrimRight(d.lines[i], " \t")
		if prev == "" {
			break
		}
		// A line that opens a block of its own is a container, not this block's
		// header, so the walk must not run past the enclosing block.
		if prev[len(prev)-1] == '{' {
			break
		}
		if kind, name, ok := classifySignature(prev); ok {
			return kind, name
		}
		// Only keep walking while the previous line reads as a continuation.
		switch prev[len(prev)-1] {
		case ',', '(':
		default:
			return FoldTypeBlock, ""
		}
	}
	return FoldTypeBlock, ""
}

// linePrefix returns the text of the current line up to col.
func (d *blockDetector) linePrefix(col int) string {
	text := d.lines[d.line]
	if col < 0 || col > len(text) {
		col = len(text)
	}
	return text[:col]
}

var (
	funcHeaderRe = regexp.MustCompile(`^func\s+(?:\([^)]*\)\s+)?(\w+)`)
	typeHeaderRe = regexp.MustCompile(`^type\s+(\w+)`)
)

// classifySignature derives the fold's type and name from the text before a
// block-opening brace.
func classifySignature(text string) (FoldType, string, bool) {
	t := strings.TrimSpace(text)
	switch {
	case hasKeyword(t, "func"):
		if matches := funcHeaderRe.FindStringSubmatch(t); matches != nil {
			return FoldTypeFunction, matches[1], true
		}
		return FoldTypeFunction, "", true
	case hasKeyword(t, "type"):
		if matches := typeHeaderRe.FindStringSubmatch(t); matches != nil {
			return FoldTypeType, matches[1], true
		}
		return FoldTypeType, "", true
	case hasKeyword(t, "struct") || hasKeyword(t, "interface"):
		// An anonymous struct/interface literal folds like a type body.
		return FoldTypeType, "", true
	}
	// Control-flow blocks all fold as generic code blocks, matching IntelliJ,
	// which does not distinguish an `if` block from a `for` block.
	if hasKeyword(t, "if") || hasKeyword(t, "for") || hasKeyword(t, "switch") ||
		hasKeyword(t, "select") || hasKeyword(t, "else") || hasKeyword(t, "range") ||
		hasKeyword(t, "go") || hasKeyword(t, "defer") || hasKeyword(t, "return") {
		return FoldTypeBlock, "", true
	}
	return FoldTypeBlock, "", false
}

// hasKeyword reports whether text contains word as a standalone identifier, so
// `if` matches `if x {` but not `iffy :=`.
func hasKeyword(text, word string) bool {
	for i := 0; i+len(word) <= len(text); {
		j := strings.Index(text[i:], word)
		if j < 0 {
			return false
		}
		j += i
		beforeOK := j == 0 || !isIdentByte(text[j-1])
		after := j + len(word)
		afterOK := after == len(text) || !isIdentByte(text[after])
		if beforeOK && afterOK {
			return true
		}
		i = j + 1
	}
	return false
}

func isIdentByte(b byte) bool {
	return b == '_' || (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9')
}

// detectFolds detects all foldable regions in the code.
func (m *Manager) detectFolds(lines []string) {
	d := &blockDetector{lines: lines, ranges: &m.foldRanges}
	d.run()

	// Folds are looked up by (StartLine, Level) so the gutter can pick the
	// outermost region that begins on a line.
	sort.Slice(m.foldRanges, func(i, j int) bool {
		if m.foldRanges[i].StartLine != m.foldRanges[j].StartLine {
			return m.foldRanges[i].StartLine < m.foldRanges[j].StartLine
		}
		return m.foldRanges[i].Level < m.foldRanges[j].Level
	})
}

// rebuildCollapsedLines rebuilds the map of collapsed lines.
func (m *Manager) rebuildCollapsedLines() {
	m.collapsedLines = make(map[int]bool)
	for _, fold := range m.foldRanges {
		if fold.Collapsed {
			for i := fold.StartLine + 1; i <= fold.EndLine; i++ {
				m.collapsedLines[i] = true
			}
		}
	}
}

// GetFoldRanges returns all fold ranges.
func (m *Manager) GetFoldRanges() []FoldRange {
	m.mu.RLock()
	defer m.mu.RUnlock()

	result := make([]FoldRange, len(m.foldRanges))
	copy(result, m.foldRanges)
	return result
}

// GetFoldAtLine returns the fold range at the given line (if any).
func (m *Manager) GetFoldAtLine(line int) *FoldRange {
	m.mu.RLock()
	defer m.mu.RUnlock()

	for i := range m.foldRanges {
		if m.foldRanges[i].StartLine == line {
			return &m.foldRanges[i]
		}
	}
	return nil
}

// GetDeepestFoldAtLine returns the deepest fold range containing the given line.
func (m *Manager) GetDeepestFoldAtLine(line int) *FoldRange {
	m.mu.RLock()
	defer m.mu.RUnlock()

	var deepest *FoldRange
	maxLevel := -1

	for i := range m.foldRanges {
		fold := &m.foldRanges[i]
		if line >= fold.StartLine && line <= fold.EndLine {
			if fold.Level > maxLevel {
				maxLevel = fold.Level
				deepest = fold
			}
		}
	}

	return deepest
}

// ToggleFold toggles the collapsed state of the fold at the given line.
func (m *Manager) ToggleFold(startLine int) bool {
	m.mu.Lock()
	defer m.mu.Unlock()

	for i := range m.foldRanges {
		if m.foldRanges[i].StartLine == startLine {
			m.foldRanges[i].Collapsed = !m.foldRanges[i].Collapsed
			m.rebuildCollapsedLines()
			m.version++
			return m.foldRanges[i].Collapsed
		}
	}
	return false
}

// CollapseFold collapses the fold at the given line.
func (m *Manager) CollapseFold(startLine int) bool {
	m.mu.Lock()
	defer m.mu.Unlock()

	for i := range m.foldRanges {
		if m.foldRanges[i].StartLine == startLine {
			changed := !m.foldRanges[i].Collapsed
			m.foldRanges[i].Collapsed = true
			if changed {
				m.rebuildCollapsedLines()
				m.version++
			}
			return changed
		}
	}
	return false
}

// ExpandFold expands the fold at the given line.
func (m *Manager) ExpandFold(startLine int) bool {
	m.mu.Lock()
	defer m.mu.Unlock()

	for i := range m.foldRanges {
		if m.foldRanges[i].StartLine == startLine {
			changed := m.foldRanges[i].Collapsed
			m.foldRanges[i].Collapsed = false
			if changed {
				m.rebuildCollapsedLines()
				m.version++
			}
			return changed
		}
	}
	return false
}

// CollapseAll collapses all foldable regions.
func (m *Manager) CollapseAll() {
	m.mu.Lock()
	defer m.mu.Unlock()

	changed := false
	for i := range m.foldRanges {
		if !m.foldRanges[i].Collapsed {
			m.foldRanges[i].Collapsed = true
			changed = true
		}
	}
	if changed {
		m.rebuildCollapsedLines()
		m.version++
	}
}

// ExpandAll expands all foldable regions.
func (m *Manager) ExpandAll() {
	m.mu.Lock()
	defer m.mu.Unlock()

	changed := false
	for i := range m.foldRanges {
		if m.foldRanges[i].Collapsed {
			m.foldRanges[i].Collapsed = false
			changed = true
		}
	}
	if changed {
		m.rebuildCollapsedLines()
		m.version++
	}
}

// IsLineVisible returns true if the given line is visible (not collapsed).
func (m *Manager) IsLineVisible(line int) bool {
	m.mu.RLock()
	defer m.mu.RUnlock()

	return !m.collapsedLines[line]
}

// GetVisibleLineCount returns the number of visible lines in the given range.
func (m *Manager) GetVisibleLineCount(start, end int) int {
	m.mu.RLock()
	defer m.mu.RUnlock()

	count := 0
	for i := start; i <= end; i++ {
		if !m.collapsedLines[i] {
			count++
		}
	}
	return count
}

// MapLineToVisible maps an actual line number to its visible position.
// Returns -1 if the line is collapsed.
func (m *Manager) MapLineToVisible(line int) int {
	m.mu.RLock()
	defer m.mu.RUnlock()

	if m.collapsedLines[line] {
		return -1
	}

	visiblePos := 0
	for i := range line {
		if !m.collapsedLines[i] {
			visiblePos++
		}
	}
	return visiblePos
}

// MapVisibleToLine maps a visible position to an actual line number.
func (m *Manager) MapVisibleToLine(visiblePos int) int {
	m.mu.RLock()
	defer m.mu.RUnlock()

	visibleCount := 0
	for i := 0; i < len(m.lineCache); i++ {
		if !m.collapsedLines[i] {
			if visibleCount == visiblePos {
				return i
			}
			visibleCount++
		}
	}
	return -1
}
