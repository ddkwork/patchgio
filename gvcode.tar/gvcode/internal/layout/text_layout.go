package layout

import (
	"bufio"
	"fmt"
	"image"
	"io"
	"math"
	"slices"
	"sort"

	"gioui.org/layout"
	"gioui.org/text"
	"github.com/go-text/typesetting/segmenter"
	"github.com/oligo/gvcode/internal/buffer"
	"github.com/oligo/gvcode/internal/folding"
	"golang.org/x/image/math/fixed"
)

type paragraphLayout struct {
	text      string
	last      bool
	runes     int
	graphemes []int
	lines     []Line
}

// hiddenSpan is a rune range [start, end) that a collapsed fold keeps off screen.
type hiddenSpan struct {
	start, end int
}

type TextLayout struct {
	src          buffer.TextSource
	reader       *bufio.Reader
	params       text.Parameters
	spaceGlyph   text.Glyph
	wrapper      lineWrapper
	seg          segmenter.Segmenter
	shaper       *text.Shaper
	glyphCache   map[string][]text.Glyph
	nextCache    map[string][]text.Glyph
	paragraphs   []paragraphLayout
	nextParas    []paragraphLayout
	paragraphBuf []byte
	tabWidth     int
	wrapLine     bool

	// Positions contain all possible caret positions, sorted by rune index.
	Positions []CombinedPos
	// lines contain metadata about the size and position of each line of
	// text on the screen.
	Lines []Line
	// Paragraphs contain size and position of each paragraph of text on the screen.
	Paragraphs []Paragraph
	// Graphemes tracks the indices of grapheme cluster boundaries within text source.
	Graphemes []int
	// bounds is the logical bounding box of the text.
	bounds image.Rectangle
	// baseline tracks the location of the first line's baseline.
	baseline int

	// foldManager manages code folding regions.
	foldManager *folding.Manager
	// visibleParagraphs maps visible paragraph indices to actual paragraph indices.
	visibleParagraphs []int

	// colorOffsets maps line number to character positions where color indicators should be inserted.
	colorOffsets map[int]map[int]int

	// foldState is the fold manager's version at the last layout, used to tell
	// whether the fold filtering in Paragraphs is still valid.
	foldState uint64
	// hiddenLines marks the lines folding hides. visibleLines is the subset the
	// painter walks: hidden lines must be skipped entirely, or their glyphs would
	// show through wherever the visible text does not cover them.
	hiddenLines  []bool
	visibleLines []Line
	// hiddenSpans holds the rune ranges folding hides, merged per contiguous run,
	// so caret movement can step over a whole collapsed region at once.
	hiddenSpans []hiddenSpan
	// cachedPlaceholder holds the shaped fold placeholder. It depends on the
	// shaper, so it is dropped with the glyph cache.
	cachedPlaceholder []text.Glyph
}

func NewTextLayout(src buffer.TextSource) TextLayout {
	return TextLayout{
		src:        src,
		reader:     bufio.NewReader(buffer.NewReader(src)),
		glyphCache: make(map[string][]text.Glyph),
		nextCache:  make(map[string][]text.Glyph),
	}
}

// SetFoldManager sets the folding manager for this layout.
func (tl *TextLayout) SetFoldManager(fm *folding.Manager) {
	tl.foldManager = fm
}

// Calculate line height. Maybe there's a better way?
func (tl *TextLayout) calcLineHeight(params *text.Parameters) fixed.Int26_6 {
	lineHeight := params.LineHeight
	// align with how text.Shaper handles default value of params.LineHeight.
	if lineHeight == 0 {
		lineHeight = params.PxPerEm
	}
	lineHeightScale := params.LineHeightScale
	// align with how text.Shaper handles default value of tv.params.LineHeightScale.
	if lineHeightScale == 0 {
		lineHeightScale = 1.2
	}

	return floatToFixed(fixedToFloat(lineHeight) * lineHeightScale)
}

// reset prepares the index for reuse.
func (tl *TextLayout) reset() {
	tl.reader.Reset(buffer.NewReader(tl.src))
	tl.Positions = tl.Positions[:0]
	tl.Lines = tl.Lines[:0]
	tl.Paragraphs = tl.Paragraphs[:0]
	tl.Graphemes = tl.Graphemes[:0]
	tl.bounds = image.Rectangle{}
	tl.baseline = 0
	tl.hiddenLines = tl.hiddenLines[:0]
	tl.visibleLines = tl.visibleLines[:0]
}

func (tl *TextLayout) readParagraph() ([]byte, error) {
	var paragraph []byte
	for {
		chunk, err := tl.reader.ReadSlice('\n')
		if len(paragraph) > 0 || err == bufio.ErrBufferFull {
			if len(paragraph) == 0 {
				tl.paragraphBuf = tl.paragraphBuf[:0]
			}
			tl.paragraphBuf = append(tl.paragraphBuf, chunk...)
			paragraph = tl.paragraphBuf
		} else {
			return chunk, err
		}
		if err != bufio.ErrBufferFull {
			return paragraph, err
		}
	}
}

func (tl *TextLayout) Layout(shaper *text.Shaper, params *text.Parameters, tabWidth int, wrapLine bool) layout.Dimensions {
	// Folding hides lines without touching the text, so the fold state joins the
	// cache key: a collapse must rebuild the lines, their vertical offsets, the
	// caret positions and the visible slice, not just the tracked paragraphs.
	foldState := uint64(0)
	if tl.foldManager != nil {
		foldState = tl.foldManager.Version()
	}
	foldsUnchanged := tl.foldState == foldState
	tl.foldState = foldState

	cacheValid := tl.shaper == shaper && tl.params == *params && tl.tabWidth == tabWidth && tl.wrapLine == wrapLine &&
		foldsUnchanged
	if !cacheValid {
		clear(tl.glyphCache)
		tl.cachedPlaceholder = nil
		tl.paragraphs = tl.paragraphs[:0]
	}
	tl.shaper = shaper
	tl.tabWidth = tabWidth
	tl.wrapLine = wrapLine
	clear(tl.nextCache)
	tl.nextParas = tl.nextParas[:0]
	oldPositions := tl.Positions
	oldParagraphs := tl.Paragraphs
	tl.reset()
	tl.params = *params

	if shaper == nil {
		tl.fakeLayout()
	} else {
		tl.spaceGlyph, _ = tl.shapeRune(shaper, tl.params, '\u0020')
		cleanPrefix := cacheValid
		cleanParagraphs := 0
		cleanLines := 0
		totalBytes := tl.src.Size()
		if totalBytes > 0 {
			runeOffset := 0
			currentIdx := 0
			bytesRead := 0

			for bytesRead < totalBytes {
				paragraph, err := tl.readParagraph()
				if len(paragraph) == 0 {
					break
				}
				bytesRead += len(paragraph)
				isLastParagraph := bytesRead >= totalBytes || err != nil
				runes, reused := tl.layoutNextParagraph(shaper, paragraph, currentIdx, isLastParagraph, runeOffset, tabWidth, wrapLine)
				runeOffset += runes
				currentIdx++

				if cleanPrefix && reused {
					cleanParagraphs++
					cleanLines += len(tl.nextParas[len(tl.nextParas)-1].lines)
				} else {
					cleanPrefix = false
				}

				if isLastParagraph {
					break
				}
			}
		} else {
			_, reused := tl.layoutNextParagraph(shaper, nil, 0, true, 0, tabWidth, wrapLine)
			if cleanPrefix && reused {
				cleanParagraphs = 1
				cleanLines = len(tl.nextParas[0].lines)
			}
		}
		// Flag the lines folding hides before the vertical offsets are computed, so
		// the hidden ones can give their space back to the lines that follow.
		tl.markFoldHiddenLines()
		// A collapsed fold shows a placeholder where its body was, the way IntelliJ
		// renders a folded region, so the hidden code is not simply swallowed.
		tl.appendFoldPlaceholders(shaper)
		tl.calculateXOffsets(cleanLines)
		// The hidden rune spans need the rune offsets the X pass just assigned.
		tl.markHiddenSpans()
		tl.calculateYOffsets(cleanLines)

		positionPrefix := sort.Search(len(oldPositions), func(i int) bool {
			return oldPositions[i].LineCol.Line >= cleanLines
		})
		tl.Positions = oldPositions[:positionPrefix]
		for idx := cleanLines; idx < len(tl.Lines); idx++ {
			// A line a fold hides gets no caret positions. The caret must not be
			// able to enter collapsed code, and leaving the positions out means one
			// arrow press jumps the whole fold — IntelliJ keeps the caret out of a
			// collapsed region the same way. Offsets that resolve into the region
			// then snap back to its start, because ClosestToRune picks the nearest
			// remaining position rather than a hidden one.
			if tl.lineHidden(idx) {
				continue
			}
			line := tl.Lines[idx]
			tl.indexGlyphs(idx, line)
		}

		for _, line := range tl.Lines {
			tl.updateBounds(line)
		}

		// The tracked paragraphs are the ones the fold filter kept. A fold change
		// fails the cache check above, so the whole list is rebuilt in that case.
		cleanTrackedParagraphs := cleanParagraphs
		if cleanLines == len(tl.Lines) {
			cleanTrackedParagraphs = len(oldParagraphs)
		}
		tl.Paragraphs = oldParagraphs[:cleanTrackedParagraphs]
		if cleanLines < len(tl.Lines) {
			tl.trackLines(tl.Lines[cleanLines:], cleanParagraphs)
		}

		lineIdx := cleanLines
		for idx := cleanParagraphs; idx < len(tl.nextParas); idx++ {
			nextLine := lineIdx + len(tl.nextParas[idx].lines)
			copy(tl.nextParas[idx].lines, tl.Lines[lineIdx:nextLine])
			lineIdx = nextLine
		}
		// The geometry is final now, so the painter's slice can carry the compacted
		// offsets of the folded layout.
		tl.buildVisibleLines()
	}
	tl.glyphCache, tl.nextCache = tl.nextCache, tl.glyphCache
	tl.paragraphs, tl.nextParas = tl.nextParas, tl.paragraphs
	clear(tl.nextCache)
	clear(tl.nextParas)
	tl.nextParas = tl.nextParas[:0]
	clear(tl.paragraphs[len(tl.paragraphs):cap(tl.paragraphs)])
	clear(tl.Lines[len(tl.Lines):cap(tl.Lines)])

	dims := layout.Dimensions{Size: tl.bounds.Size()}
	dims.Baseline = dims.Size.Y - tl.baseline
	return dims
}

func (tl *TextLayout) layoutNextParagraph(shaper *text.Shaper, paragraph []byte, paragraphIdx int, isLastParagrah bool, runeOffset int, tabWidth int, wrapLine bool) (int, bool) {
	if paragraphIdx < len(tl.paragraphs) {
		cached := tl.paragraphs[paragraphIdx]
		if cached.text == string(paragraph) && cached.last == isLastParagrah {
			tl.Lines = append(tl.Lines, cached.lines...)
			tl.appendGraphemes(cached.graphemes, runeOffset)
			tl.nextParas = append(tl.nextParas, cached)
			return cached.runes, true
		}
	}

	paragraphText := string(paragraph)
	paragraphRunes := []rune(paragraphText)
	graphemes := tl.graphemeOffsets(paragraphRunes)
	tl.appendGraphemes(graphemes, runeOffset)

	params := tl.params
	maxWidth := params.MaxWidth
	params.MaxWidth = 1e6
	if !wrapLine {
		maxWidth = params.MaxWidth
	}
	glyphs, ok := tl.glyphCache[paragraphText]
	if !ok {
		shaper.LayoutString(params, paragraphText)
		for {
			glyph, ok := shaper.NextGlyph()
			if !ok {
				break
			}
			glyphs = append(glyphs, glyph)
		}
	}
	tl.nextCache[paragraphText] = glyphs

	lines := tl.wrapper.WrapParagraph(slices.Values(glyphs), paragraphRunes, maxWidth, tabWidth, &tl.spaceGlyph)
	if len(paragraph) > 0 && paragraph[len(paragraph)-1] == '\n' && len(lines) > 0 && !isLastParagrah {
		lines = lines[:len(lines)-1]
	}

	tl.Lines = append(tl.Lines, lines...)
	tl.nextParas = append(tl.nextParas, paragraphLayout{
		text:      paragraphText,
		last:      isLastParagrah,
		runes:     len(paragraphRunes),
		graphemes: graphemes,
		lines:     lines,
	})
	return len(paragraphRunes), false
}

func (tl *TextLayout) fakeLayout() {
	srcReader := buffer.NewReader(tl.src)
	// Make a fake glyph for every rune in the reader.
	b := bufio.NewReader(srcReader)
	for _, _, err := b.ReadRune(); err != io.EOF; _, _, err = b.ReadRune() {
		g := text.Glyph{Runes: 1, Flags: text.FlagClusterBreak}
		line := Line{}
		line.append(g)
		tl.indexGlyphs(0, line)
	}

	var graphemeReader graphemeReader
	graphemeReader.SetSource(tl.src)

	for g := graphemeReader.Graphemes(); len(g) > 0; g = graphemeReader.Graphemes() {
		if len(tl.Graphemes) > 0 && g[0] == tl.Graphemes[len(tl.Graphemes)-1] {
			g = g[1:]
		}
		tl.Graphemes = append(tl.Graphemes, g...)
	}
}

func (tl *TextLayout) calculateYOffsets(startLine int) {
	if startLine >= len(tl.Lines) {
		return
	}

	lineHeight := tl.calcLineHeight(&tl.params)
	currentY := 0
	if startLine == 0 {
		// Keep the first baseline far enough from the top to avoid clipping.
		currentY = tl.Lines[0].Ascent.Ceil()
	} else {
		currentY = tl.Lines[startLine-1].YOff + lineHeight.Round()
	}
	for i := startLine; i < len(tl.Lines); i++ {
		// A folded line does not advance the cursor, so the lines after it move up
		// and the fold leaves no blank gap behind.
		if i > startLine && !tl.lineHidden(i) {
			currentY += lineHeight.Round()
		}
		tl.Lines[i].adjustYOff(currentY)
	}
}

// markFoldHiddenLines flags every line a collapsed fold hides. It walks the same
// paragraph boundaries the tracker uses, so a hidden paragraph takes all of its
// wrapped lines with it. The visible slice is built later, once the vertical
// offsets are final — see buildVisibleLines.
func (tl *TextLayout) markFoldHiddenLines() {
	n := len(tl.Lines)
	if cap(tl.hiddenLines) < n {
		tl.hiddenLines = make([]bool, n)
	}
	tl.hiddenLines = tl.hiddenLines[:n]
	tl.visibleLines = tl.visibleLines[:0]

	if tl.foldManager == nil {
		return
	}

	paraIdx := 0
	visible := tl.foldManager.IsLineVisible(0)
	// Mirror the tracker exactly: a paragraph index only moves when a line ends a
	// paragraph, which is what Paragraph.Add reports.
	var rng Paragraph
	for i := range tl.Lines {
		line := tl.Lines[i]
		tl.hiddenLines[i] = !visible

		if rng.Add(line) {
			paraIdx++
			visible = tl.foldManager.IsLineVisible(paraIdx)
			rng = Paragraph{}
		}
	}
}

// markHiddenSpans rebuilds the rune range folding hides. It has to run after the
// X offsets are computed, because that is where a line learns its rune offset.
func (tl *TextLayout) markHiddenSpans() {
	tl.hiddenSpans = tl.hiddenSpans[:0]
	for i := range tl.Lines {
		if !tl.lineHidden(i) {
			continue
		}
		// Consecutive hidden lines form one span; the caret has to be kept out of
		// it in one step rather than rune by rune.
		line := tl.Lines[i]
		start, end := line.RuneOff, line.RuneOff+line.Runes
		if n := len(tl.hiddenSpans); n > 0 && tl.hiddenSpans[n-1].end == start {
			tl.hiddenSpans[n-1].end = end
		} else {
			tl.hiddenSpans = append(tl.hiddenSpans, hiddenSpan{start: start, end: end})
		}
	}
}

// SkipHiddenSpan moves a caret offset out of a span folding hides: a forward step
// lands after the span, a backward step before it. The span's edges are valid
// caret positions — they are the region's start and the line that follows it — so
// one arrow press jumps a collapsed region whole, the way IntelliJ does.
func (tl *TextLayout) SkipHiddenSpan(offset int, forward bool) int {
	for _, h := range tl.hiddenSpans {
		if offset > h.start && offset < h.end {
			if forward {
				return h.end
			}
			return h.start
		}
	}
	return offset
}

// buildVisibleLines collects the lines the painter should walk, once their
// vertical offsets are final so the copies carry the compacted positions.
func (tl *TextLayout) buildVisibleLines() {
	tl.visibleLines = tl.visibleLines[:0]
	if len(tl.hiddenLines) != len(tl.Lines) {
		// No fold marking happened (an empty document or a fake layout): paint
		// everything.
		tl.visibleLines = append(tl.visibleLines, tl.Lines...)
		return
	}
	for i := range tl.Lines {
		if tl.hiddenLines[i] {
			continue
		}
		tl.visibleLines = append(tl.visibleLines, tl.Lines[i])
	}
}

// appendFoldPlaceholders writes the fold placeholder at the end of every
// collapsed fold's header line, the way IntelliJ renders a folded region. The
// body's lines are hidden, so without it the fold would silently swallow code
// while showing nothing.
//
// The placeholder glyphs carry Runes == 0: they are decoration, not text, so the
// rune-to-line mapping and the editing paths stay exact.
func (tl *TextLayout) appendFoldPlaceholders(shaper *text.Shaper) {
	if tl.foldManager == nil || len(tl.Lines) == 0 {
		return
	}
	glyphs := tl.foldPlaceholderGlyphs(shaper)
	if len(glyphs) == 0 {
		return
	}

	paraIdx := 0
	var rng Paragraph
	for i := range tl.Lines {
		line := &tl.Lines[i]
		if !rng.Add(*line) {
			continue
		}
		// This line closes paragraph paraIdx, so it is the header line of a fold
		// that starts there.
		if f := tl.foldManager.GetFoldAtLine(paraIdx); f != nil && f.Collapsed && len(line.Glyphs) > 0 {
			appendGlyphs(line, glyphs)
		}
		paraIdx++
		rng = Paragraph{}
	}
}

// appendGlyphs places a decorative run after the last glyph of a line and widens
// the line to match. The glyphs keep Runes == 0, gio's marker for a glyph that
// belongs to a cluster without owning it, so they are drawn but not counted as
// text.
func appendGlyphs(line *Line, glyphs []text.Glyph) {
	last := line.Glyphs[len(line.Glyphs)-1]
	// Remember whether this line closed a paragraph before the placeholder takes
	// over as the last glyph; the tracker reads that off the last glyph.
	if last.Flags&text.FlagParagraphBreak != 0 {
		line.paragraphBreak = true
	}
	x := last.X + last.Advance
	width := fixed.Int26_6(0)
	for i := range glyphs {
		g := glyphs[i]
		g.X = x
		g.Y = last.Y
		g.Runes = 0
		x += g.Advance
		width += g.Advance
		line.Glyphs = append(line.Glyphs, &g)
	}
	line.Width += width
}

// foldPlaceholderGlyphs shapes the placeholder text once per layout.
func (tl *TextLayout) foldPlaceholderGlyphs(shaper *text.Shaper) []text.Glyph {
	if tl.cachedPlaceholder != nil {
		return tl.cachedPlaceholder
	}

	// Prefer the single ellipsis character; fall back to three periods when the
	// font has no glyph for it.
	glyphs := make([]text.Glyph, 0, 1)
	if g, err := tl.shapeRune(shaper, tl.params, '\u2026'); err == nil && g.Advance > 0 {
		glyphs = append(glyphs, g)
	} else {
		dot, err := tl.shapeRune(shaper, tl.params, '.')
		if err != nil || dot.Advance <= 0 {
			return nil
		}
		for range 3 {
			glyphs = append(glyphs, dot)
		}
	}
	tl.cachedPlaceholder = glyphs
	return glyphs
}

// lineHidden reports whether folding hides the line at index i.
func (tl *TextLayout) lineHidden(i int) bool {
	return i >= 0 && i < len(tl.hiddenLines) && tl.hiddenLines[i]
}

// VisibleLines returns the lines the painter should walk: every line when nothing
// is folded, minus the lines a collapsed region hides.
func (tl *TextLayout) VisibleLines() []Line {
	if len(tl.visibleLines) == 0 && len(tl.Lines) > 0 {
		return tl.Lines
	}
	return tl.visibleLines
}

func (tl *TextLayout) calculateXOffsets(startLine int) {
	runeOff := 0
	if startLine > 0 {
		previous := tl.Lines[startLine-1]
		runeOff = previous.RuneOff + previous.Runes
	}
	for i := startLine; i < len(tl.Lines); i++ {
		line := tl.Lines[i]
		alignOff := tl.params.Alignment.Align(tl.params.Locale.Direction, line.Width, tl.params.MaxWidth)

		// Get color offsets for this line
		var lineColorOffsets map[int]int
		if tl.colorOffsets != nil {
			lineColorOffsets = tl.colorOffsets[i]
		}

		tl.Lines[i].recompute(alignOff, runeOff, lineColorOffsets)
		runeOff += line.Runes
	}
}

// SetColorOffsets sets the color offsets for the text layout.
func (tl *TextLayout) SetColorOffsets(offsets map[int]map[int]int) {
	tl.colorOffsets = offsets
}

func (tl *TextLayout) shapeRune(shaper *text.Shaper, params text.Parameters, r rune) (text.Glyph, error) {
	shaper.LayoutString(params, string(r))
	glyph, ok := shaper.NextGlyph()
	if !ok {
		return text.Glyph{}, fmt.Errorf("shaper.LayoutString failed for rune: %s", string(r))
	}

	return glyph, nil
}

func (tl *TextLayout) graphemeOffsets(paragraph []rune) []int {
	if len(paragraph) == 0 {
		return nil
	}

	offsets := []int{0}
	tl.seg.Init(paragraph)
	iter := tl.seg.GraphemeIterator()
	for iter.Next() {
		grapheme := iter.Grapheme()
		offsets = append(offsets, grapheme.Offset+len(grapheme.Text))
	}
	return offsets
}

func (tl *TextLayout) appendGraphemes(offsets []int, runeOffset int) {
	for _, offset := range offsets {
		offset += runeOffset
		if len(tl.Graphemes) == 0 || tl.Graphemes[len(tl.Graphemes)-1] != offset {
			tl.Graphemes = append(tl.Graphemes, offset)
		}
	}
}

func (tl *TextLayout) updateBounds(line Line) {
	logicalBounds := line.bounds()
	if tl.bounds == (image.Rectangle{}) {
		tl.baseline = int(line.YOff)
		tl.bounds = logicalBounds
	} else {
		tl.bounds.Min.X = min(tl.bounds.Min.X, logicalBounds.Min.X)
		tl.bounds.Min.Y = min(tl.bounds.Min.Y, logicalBounds.Min.Y)
		tl.bounds.Max.X = max(tl.bounds.Max.X, logicalBounds.Max.X)
		tl.bounds.Max.Y = max(tl.bounds.Max.Y, logicalBounds.Max.Y)
	}
}

func (tl *TextLayout) trackLines(lines []Line, basePara int) {
	if len(lines) <= 0 {
		tl.Paragraphs = append(tl.Paragraphs, Paragraph{})
		return
	}

	rng := Paragraph{}
	// Paragraph numbers are document-wide: the lines handed in may be the tail of
	// a layout whose earlier paragraphs were reused, and both the fold filter and
	// the logical line numbers count every paragraph.
	paraIdx := basePara
	for _, l := range lines {
		hasBreak := rng.Add(l)

		if hasBreak {
			// Check if this paragraph should be visible (not folded)
			if tl.foldManager == nil || tl.foldManager.IsLineVisible(paraIdx) {
				rng.LogicalIndex = paraIdx
				tl.Paragraphs = append(tl.Paragraphs, rng)
			}
			paraIdx++
			rng = Paragraph{}
		}
	}

	if rng != (Paragraph{}) {
		// Check if this paragraph should be visible (not folded)
		if tl.foldManager == nil || tl.foldManager.IsLineVisible(paraIdx) {
			rng.LogicalIndex = paraIdx
			tl.Paragraphs = append(tl.Paragraphs, rng)
		}
	}
}

func (tl *TextLayout) insertPosition(pos CombinedPos) {
	lastIdx := len(tl.Positions) - 1
	if lastIdx >= 0 {
		lastPos := tl.Positions[lastIdx]
		if lastPos.Runes == pos.Runes && (lastPos.Y != pos.Y || (lastPos.X == pos.X)) {
			// If we insert a consecutive position with the same logical position,
			// overwrite the previous position with the new one.
			tl.Positions[lastIdx] = pos
			return
		}
	}
	tl.Positions = append(tl.Positions, pos)
}

// Glyph indexes the provided glyph, generating text cursor positions for it.
func (tl *TextLayout) indexGlyphs(idx int, line Line) {
	pos := CombinedPos{
		Runes: line.RuneOff}
	pos.LineCol.Line = idx

	midCluster := false
	clusterAdvance := fixed.I(0)
	var direction text.Flags

	for _, gl := range line.Glyphs {
		// needsNewLine := gl.Flags&text.FlagLineBreak != 0
		needsNewRun := gl.Flags&text.FlagRunBreak != 0
		breaksParagraph := gl.Flags&text.FlagParagraphBreak != 0
		breaksCluster := gl.Flags&text.FlagClusterBreak != 0
		// We should insert new positions if the glyph we're processing terminates
		// a glyph cluster, has nonzero runes, and is not a hard newline.
		insertPositionsWithin := breaksCluster && !breaksParagraph && gl.Runes > 0

		// Get the text direction.
		direction = gl.Flags & text.FlagTowardOrigin
		pos.TowardOrigin = direction == text.FlagTowardOrigin
		if !midCluster {
			// Create the text position prior to the glyph.
			pos.X = gl.X
			pos.Y = int(gl.Y)
			pos.Ascent = gl.Ascent
			pos.Descent = gl.Descent
			if pos.TowardOrigin {
				pos.X += gl.Advance
			}
			tl.insertPosition(pos)
		}

		midCluster = !breaksCluster
		if breaksParagraph {
			// Paragraph breaking clusters shouldn't have positions generated for both
			// sides of them. They're always zero-width, so doing so would
			// create two visually identical cursor positions. Just reset
			// cluster state, increment by their runes, and move on to the
			// next glyph.
			clusterAdvance = 0
			pos.Runes += int(gl.Runes)
		}

		// Always track the cumulative advance added by the glyph, even if it
		// doesn't terminate a cluster itself.
		clusterAdvance += gl.Advance
		if insertPositionsWithin {
			// Construct the text positions _within_ gl.
			pos.Y = int(gl.Y)
			pos.Ascent = gl.Ascent
			pos.Descent = gl.Descent
			width := clusterAdvance
			positionCount := int(gl.Runes)
			runesPerPosition := 1
			if gl.Flags&text.FlagTruncator != 0 {
				// Treat the truncator as a single unit that is either selected or not.
				positionCount = 1
				runesPerPosition = int(gl.Runes)
			}
			perRune := width / fixed.Int26_6(positionCount)
			adjust := fixed.Int26_6(0)
			if pos.TowardOrigin {
				// If RTL, subtract increments from the width of the cluster
				// instead of adding.
				adjust = width
				perRune = -perRune
			}
			for i := 1; i <= positionCount; i++ {
				pos.X = gl.X + adjust + perRune*fixed.Int26_6(i)
				pos.Runes += runesPerPosition
				pos.LineCol.Col += runesPerPosition
				tl.insertPosition(pos)
			}
			clusterAdvance = 0
		}

		if needsNewRun {
			pos.RunIndex++
		}
	}

}

// This method and some of the following methods are adapted from the Gio's package gioui.org/widget.
// Original copyright (c) 2018-2025 Elias Naur and Gio contributors.
//
// incrementPosition returns the next position after pos (if any). Pos _must_ be
// an unmodified position acquired from one of the closest* methods. If eof is
// true, there was no next position.
func (tl *TextLayout) incrementPosition(pos CombinedPos) (next CombinedPos, eof bool) {
	candidate, index := tl.ClosestToRune(pos.Runes)
	for candidate != pos && index+1 < len(tl.Positions) {
		index++
		candidate = tl.Positions[index]
	}
	if index+1 < len(tl.Positions) {
		return tl.Positions[index+1], false
	}
	return candidate, true
}

func (tl *TextLayout) ClosestToRune(runeIdx int) (CombinedPos, int) {
	if len(tl.Positions) == 0 {
		return CombinedPos{}, 0
	}
	i := sort.Search(len(tl.Positions), func(i int) bool {
		pos := tl.Positions[i]
		return pos.Runes >= runeIdx
	})
	if i > 0 {
		i--
	}
	closest := tl.Positions[i]
	closestI := i
	for ; i < len(tl.Positions); i++ {
		if tl.Positions[i].Runes == runeIdx {
			return tl.Positions[i], i
		}
	}
	return closest, closestI
}

func (tl *TextLayout) ClosestToLineCol(lineCol ScreenPos) CombinedPos {
	if len(tl.Positions) == 0 {
		return CombinedPos{}
	}
	i := sort.Search(len(tl.Positions), func(i int) bool {
		pos := tl.Positions[i]
		return pos.LineCol.Line > lineCol.Line || (pos.LineCol.Line == lineCol.Line && pos.LineCol.Col >= lineCol.Col)
	})
	if i > 0 {
		i--
	}
	prior := tl.Positions[i]
	if i+1 >= len(tl.Positions) {
		return prior
	}
	next := tl.Positions[i+1]
	if next.LineCol != lineCol {
		return prior
	}
	return next
}

func (tl *TextLayout) ClosestToXY(x fixed.Int26_6, y int) CombinedPos {
	if len(tl.Positions) == 0 {
		return CombinedPos{}
	}
	i := sort.Search(len(tl.Positions), func(i int) bool {
		pos := tl.Positions[i]
		return pos.Y+pos.Descent.Round() >= y
	})
	// If no position was greater than the provided Y, the text is too
	// short. Return either the last position or (if there are no
	// positions) the zero position.
	if i == len(tl.Positions) {
		return tl.Positions[i-1]
	}
	first := tl.Positions[i]
	// Find the best X coordinate.
	closest := i
	closestDist := dist(first.X, x)
	line := first.LineCol.Line
	// NOTE(whereswaldon): there isn't a simple way to accelerate this. Bidi text means that the x coordinates
	// for positions have no fixed relationship. In the future, we can consider sorting the positions
	// on a line by their x coordinate and caching that. It'll be a one-time O(nlogn) per line, but
	// subsequent uses of this function for that line become O(logn). Right now it's always O(n).
	for i := i + 1; i < len(tl.Positions) && tl.Positions[i].LineCol.Line == line; i++ {
		candidate := tl.Positions[i]
		distance := dist(candidate.X, x)
		// If we are *really* close to the current position candidate, just choose it.
		if distance.Round() == 0 {
			return tl.Positions[i]
		}
		if distance < closestDist {
			closestDist = distance
			closest = i
		}
	}
	return tl.Positions[closest]
}

// locate returns highlight regions covering the glyphs that represent the runes in
// [startRune,endRune). If the rects parameter is non-nil, locate will use it to
// return results instead of allocating, provided that there is enough capacity.
// The returned regions have their Bounds specified relative to the provided
// viewport.
func (tl *TextLayout) Locate(viewport image.Rectangle, startRune, endRune int, rects []Region) []Region {
	if startRune > endRune {
		startRune, endRune = endRune, startRune
	}
	rects = rects[:0]
	caretStart, _ := tl.ClosestToRune(startRune)
	caretEnd, _ := tl.ClosestToRune(endRune)

	for lineIdx := caretStart.LineCol.Line; lineIdx < len(tl.Lines); lineIdx++ {
		if lineIdx > caretEnd.LineCol.Line {
			break
		}
		pos := tl.ClosestToLineCol(ScreenPos{Line: lineIdx})
		if int(pos.Y)+pos.Descent.Ceil() < viewport.Min.Y {
			continue
		}
		if int(pos.Y)-pos.Ascent.Ceil() > viewport.Max.Y {
			break
		}
		line := tl.Lines[lineIdx]
		if lineIdx > caretStart.LineCol.Line && lineIdx < caretEnd.LineCol.Line {
			startX := line.XOff
			endX := startX + line.Width
			// The entire line is selected.
			rects = append(rects, makeRegion(line, pos.Y, startX, endX))
			continue
		}
		selectionStart := caretStart
		selectionEnd := caretEnd
		if lineIdx != caretStart.LineCol.Line {
			// This line does not contain the beginning of the selection.
			selectionStart = tl.ClosestToLineCol(ScreenPos{Line: lineIdx})
		}
		if lineIdx != caretEnd.LineCol.Line {
			// This line does not contain the end of the selection.
			selectionEnd = tl.ClosestToLineCol(ScreenPos{Line: lineIdx, Col: math.MaxInt})
		}

		var (
			startX, endX fixed.Int26_6
			eof          bool
		)
	lineLoop:
		for !eof {
			startX = selectionStart.X
			if selectionStart.RunIndex == selectionEnd.RunIndex {
				// Commit selection.
				endX = selectionEnd.X
				rects = append(rects, makeRegion(line, pos.Y, startX, endX))
				break
			} else {
				currentDirection := selectionStart.TowardOrigin
				previous := selectionStart
			runLoop:
				for !eof {
					// Increment the start position until the next logical run.
					for startRun := selectionStart.RunIndex; selectionStart.RunIndex == startRun; {
						previous = selectionStart
						selectionStart, eof = tl.incrementPosition(selectionStart)
						if eof {
							endX = selectionStart.X
							rects = append(rects, makeRegion(line, pos.Y, startX, endX))
							break runLoop
						}
					}
					if selectionStart.TowardOrigin != currentDirection {
						endX = previous.X
						rects = append(rects, makeRegion(line, pos.Y, startX, endX))
						break
					}
					if selectionStart.RunIndex == selectionEnd.RunIndex {
						// Commit selection.
						endX = selectionEnd.X
						rects = append(rects, makeRegion(line, pos.Y, startX, endX))
						break lineLoop
					}
				}
			}
		}
	}
	for i := range rects {
		rects[i].Bounds = rects[i].Bounds.Sub(viewport.Min)
	}
	return rects
}

func dist(a, b fixed.Int26_6) fixed.Int26_6 {
	if a > b {
		return a - b
	}
	return b - a
}

func absFixed(i fixed.Int26_6) fixed.Int26_6 {
	if i < 0 {
		return -i
	}
	return i
}

func fixedToFloat(i fixed.Int26_6) float32 {
	return float32(i) / 64.0
}

func floatToFixed(f float32) fixed.Int26_6 {
	return fixed.Int26_6(f * 64)
}
