package postfix

import (
	"strings"
	"testing"
)

// TestDefaultTemplatesCarryIntelliJKeys checks the keys the built-in set has to
// expose, including the four the editor documents.
func TestDefaultTemplatesCarryIntelliJKeys(t *testing.T) {
	p := NewProvider(DefaultTemplates()...)
	for _, key := range []string{".if", ".else", ".for", ".forr", ".while", ".var", ".err", ".ret", ".not", ".notnull", ".null", ".par", ".print", ".switch"} {
		if _, ok := p.Find(key); !ok {
			t.Errorf("the built-in set has no %s template", key)
		}
	}
	for _, tmpl := range p.Templates() {
		if !strings.HasPrefix(tmpl.Key(), ".") {
			t.Errorf("template key %q is not a \".key\"", tmpl.Key())
		}
	}
}

// TestProviderMatchFindsTheExpression covers PostfixLiveTemplate's syntactic
// scan: the key is the ".name" ending at the caret and the expression is the
// primary expression in front of the dot.
func TestProviderMatchFindsTheExpression(t *testing.T) {
	p := NewProvider(DefaultTemplates()...)
	tests := []struct {
		text      string
		key       string
		expr      string
		wantStart int
	}{
		{"x.if", ".if", "x", 0},
		{"value.notnull", ".notnull", "value", 0},
		{"result := compute(a, b).if", ".if", "compute(a, b)", 10},
		{"obj.field.var", ".var", "obj.field", 0},
		{"arr[i].par", ".par", "arr[i]", 0},
		{"  fetch().err", ".err", "fetch()", 2},
	}
	for _, tt := range tests {
		tmpl, expr, start, ok := p.Match(tt.text, len([]rune(tt.text)))
		if !ok {
			t.Errorf("Match(%q) found nothing, want %s", tt.text, tt.key)
			continue
		}
		if tmpl.Key() != tt.key || expr != tt.expr || start != tt.wantStart {
			t.Errorf("Match(%q) = (%s, %q, %d), want (%s, %q, %d)",
				tt.text, tmpl.Key(), expr, start, tt.key, tt.expr, tt.wantStart)
		}
	}
}

func TestProviderMatchRejectsNonTemplates(t *testing.T) {
	p := NewProvider(DefaultTemplates()...)
	tests := []string{
		"foo",         // no dot
		"foo.",        // no key
		"foo.unknown", // unknown key
		"foo.err",     // ".err" needs a call, not a bare identifier
	}
	for _, text := range tests {
		if _, _, _, ok := p.Match(text, len([]rune(text))); ok {
			t.Errorf("Match(%q) matched, want no template", text)
		}
	}
}

func TestTemplateExpandUsesSnippetSyntax(t *testing.T) {
	p := NewProvider(DefaultTemplates()...)
	tests := []struct {
		key, expr, want string
	}{
		{".if", "x", "if x {\n\t$0\n}"},
		{".notnull", "v", "if v != nil {\n\t$0\n}"},
		{".var", "fetch()", "${1:v} := fetch()$0"},
		{".err", "fetch()", "if err := fetch(); err != nil {\n\treturn $0\n}"},
		{".not", "ok", "!ok$0"},
	}
	for _, tt := range tests {
		tmpl, ok := p.Find(tt.key)
		if !ok {
			t.Fatalf("no %s template", tt.key)
		}
		if got := tmpl.Expand(tt.expr); got != tt.want {
			t.Errorf("%s.Expand(%q) = %q, want %q", tt.key, tt.expr, got, tt.want)
		}
	}
}

// TestScanExpressionStart covers the backwards scan over a primary expression.
func TestScanExpressionStart(t *testing.T) {
	tests := []struct {
		text string
		want string
	}{
		{"x.", "x"},
		{"a.b.c.", "a.b.c"},
		{"f(1, g(2)).", "f(1, g(2))"},
		{"a[0].", "a[0]"},
		{"return x.", "x"},
		{"= y.", "y"},
	}
	for _, tt := range tests {
		runes := []rune(tt.text)
		dot := len(runes) - 1 // the trailing "."
		start := scanExpressionStart(runes, dot)
		if got := string(runes[start:dot]); got != tt.want {
			t.Errorf("scanExpressionStart(%q) = %q, want %q", tt.text, got, tt.want)
		}
	}
}
