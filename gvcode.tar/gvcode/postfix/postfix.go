// Package postfix implements IntelliJ's postfix templates: a ".key" typed after
// an expression is replaced by a snippet that wraps the expression. It mirrors
// com.intellij.codeInsight.template.postfix.templates.PostfixTemplate.
package postfix

import (
	"strings"
	"unicode"
)

// Template is the Go counterpart of
// com.intellij.codeInsight.template.postfix.templates.PostfixTemplate: a key of
// the form ".name", a presentable name, an applicability test and an expansion.
type Template interface {
	// Key is the template's ".key". IntelliJ's PostfixTemplate builds it as
	// "." + name, and a few templates override it (".!" for ".not", ".nn" for
	// ".notnull").
	Key() string
	// Name is the name shown in the completion popup (IntelliJ's
	// getPresentableName).
	Name() string
	// Example is the one-line example IntelliJ shows (getExample).
	Example() string
	// Available reports whether the template applies to the expression before
	// the dot (IntelliJ's isApplicable). It is a syntactic test here, since the
	// editor has no type system.
	Available(expr string) bool
	// Expand returns the snippet body that replaces "expr.key". The body uses
	// the LSP snippet syntax, so a template can place tab stops.
	Expand(expr string) string
}

type template struct {
	key     string
	name    string
	example string
	avail   func(expr string) bool
	expand  func(expr string) string
}

func (t *template) Key() string                { return t.key }
func (t *template) Name() string               { return t.name }
func (t *template) Example() string            { return t.example }
func (t *template) Available(expr string) bool { return t.avail == nil || t.avail(expr) }
func (t *template) Expand(expr string) string  { return t.expand(expr) }

// Provider holds the registered templates. It is the analogue of IntelliJ's
// PostfixTemplateProvider, which owns the set a language contributes.
type Provider struct {
	templates []Template
}

// NewProvider creates a provider holding the given templates.
func NewProvider(templates ...Template) *Provider {
	p := &Provider{}
	for _, t := range templates {
		p.Register(t)
	}
	return p
}

// Register adds a template, replacing one that already owns the key.
func (p *Provider) Register(t Template) {
	for i, existing := range p.templates {
		if existing.Key() == t.Key() {
			p.templates[i] = t
			return
		}
	}
	p.templates = append(p.templates, t)
}

// Templates returns the registered templates.
func (p *Provider) Templates() []Template {
	return p.templates
}

// Find returns the template with the given ".key".
func (p *Provider) Find(key string) (Template, bool) {
	for _, t := range p.templates {
		if t.Key() == key {
			return t, true
		}
	}
	return nil, false
}

// Match finds the template whose ".key" ends exactly at offset, the expression
// it applies to, and the offset the replaced region starts at.
//
// It is the syntactic half of PostfixLiveTemplate: scan the identifier before
// the caret, require a "." in front of it, and take the primary expression that
// ends at that dot.
func (p *Provider) Match(text string, offset int) (t Template, expr string, start int, ok bool) {
	runes := []rune(text)
	if offset < 0 || offset > len(runes) {
		return nil, "", 0, false
	}

	i := offset
	for i > 0 && isIdentifierPart(runes[i-1]) {
		i--
	}
	if i == offset {
		return nil, "", 0, false // the caret is not at the end of a word
	}
	if i == 0 || runes[i-1] != '.' {
		return nil, "", 0, false
	}

	t, found := p.Find("." + string(runes[i:offset]))
	if !found {
		return nil, "", 0, false
	}

	dot := i - 1
	start = scanExpressionStart(runes, dot)
	expr = strings.TrimSpace(string(runes[start:dot]))
	if expr == "" || !t.Available(expr) {
		return nil, "", 0, false
	}
	return t, expr, start, true
}

func isIdentifierPart(r rune) bool {
	return r == '_' || unicode.IsLetter(r) || unicode.IsDigit(r)
}

// scanExpressionStart walks back over the primary expression that ends at end:
// an identifier, a dotted selector chain, and bracketed groups (with the callee
// or qualifier in front of them).
func scanExpressionStart(runes []rune, end int) int {
	i := end
	for i > 0 {
		c := runes[i-1]
		if c == ')' || c == ']' || c == '}' {
			open := matchingOpen(runes, i-1)
			if open < 0 {
				return 0
			}
			i = open
			continue
		}
		if isIdentifierPart(c) || c == '.' {
			i--
			continue
		}
		break
	}
	return i
}

// matchingOpen returns the index of the bracket that opens the group closed at
// closeIdx, or -1.
func matchingOpen(runes []rune, closeIdx int) int {
	depth := 0
	for i := closeIdx; i >= 0; i-- {
		switch runes[i] {
		case ')', ']', '}':
			depth++
		case '(', '[', '{':
			depth--
			if depth == 0 {
				return i
			}
		}
	}
	return -1
}

// DefaultTemplates returns the built-in Go templates. The keys follow IntelliJ's
// Java set (platform/lang-impl/.../templates and the Java provider) with the
// bodies rewritten for Go.
func DefaultTemplates() []Template {
	return []Template{
		&template{
			key: ".if", name: "if expr", example: "if expr {\n\t...\n}",
			expand: func(expr string) string { return "if " + expr + " {\n\t$0\n}" },
		},
		&template{
			key: ".else", name: "if !expr", example: "if !expr {\n\t...\n}",
			expand: func(expr string) string { return "if !" + expr + " {\n\t$0\n}" },
		},
		&template{
			key: ".for", name: "for range expr", example: "for _, v := range expr {\n\t...\n}",
			expand: func(expr string) string { return "for _, v := range " + expr + " {\n\t$0\n}" },
		},
		&template{
			key: ".forr", name: "for i := len(expr) - 1; i >= 0; i--",
			example: "for i := len(expr) - 1; i >= 0; i-- {\n\t...\n}",
			expand: func(expr string) string {
				return "for i := len(" + expr + ") - 1; i >= 0; i-- {\n\t$0\n}"
			},
		},
		&template{
			key: ".while", name: "for expr", example: "for expr {\n\t...\n}",
			expand: func(expr string) string { return "for " + expr + " {\n\t$0\n}" },
		},
		&template{
			key: ".var", name: "name := expr", example: "v := expr",
			expand: func(expr string) string { return "${1:v} := " + expr + "$0" },
		},
		&template{
			key: ".err", name: "if err := expr; err != nil",
			example: "if err := expr; err != nil {\n\treturn\n}",
			// The expression has to look like a call: only a call returns an
			// error to test. This is the syntactic stand-in for IntelliJ's
			// type-based isApplicable.
			avail: func(expr string) bool { return strings.Contains(expr, "(") },
			expand: func(expr string) string {
				return "if err := " + expr + "; err != nil {\n\treturn $0\n}"
			},
		},
		&template{
			key: ".ret", name: "return expr", example: "return expr",
			expand: func(expr string) string { return "return " + expr + "$0" },
		},
		&template{
			key: ".not", name: "!expr", example: "!expr",
			expand: func(expr string) string { return "!" + expr + "$0" },
		},
		&template{
			key: ".notnull", name: "if expr != nil", example: "if expr != nil {\n\t...\n}",
			expand: func(expr string) string { return "if " + expr + " != nil {\n\t$0\n}" },
		},
		&template{
			key: ".null", name: "if expr == nil", example: "if expr == nil {\n\t...\n}",
			expand: func(expr string) string { return "if " + expr + " == nil {\n\t$0\n}" },
		},
		&template{
			key: ".par", name: "(expr)", example: "(expr)",
			expand: func(expr string) string { return "(" + expr + ")$0" },
		},
		&template{
			key: ".print", name: "fmt.Println(expr)", example: "fmt.Println(expr)",
			expand: func(expr string) string { return "fmt.Println(" + expr + ")$0" },
		},
		&template{
			key: ".switch", name: "switch expr", example: "switch expr {\n\t...\n}",
			expand: func(expr string) string { return "switch " + expr + " {\n$0\n}" },
		},
	}
}
