package gvcode

import (
	"sort"

	"github.com/oligo/gvcode/lsp"
	"github.com/oligo/gvcode/textstyle/syntax"
)

// SemanticScope maps an LSP semantic token type onto the syntax scope the
// application's colour scheme understands. Refining the lexer's guess with the
// server's classification is exactly what IntelliJ's semantic highlighter does
// with its TextAttributesKeys.
func SemanticScope(kind lsp.SemanticTokenType) syntax.StyleScope {
	switch kind {
	case lsp.SemanticKeyword, lsp.SemanticOperator:
		return "Keyword"
	case lsp.SemanticString:
		return "LiteralString"
	case lsp.SemanticNumber:
		return "LiteralNumber"
	case lsp.SemanticComment:
		return "Comment"
	case lsp.SemanticFunction, lsp.SemanticMethod:
		return "NameFunction"
	case lsp.SemanticType, lsp.SemanticStruct, lsp.SemanticInterface:
		return "KeywordType"
	case lsp.SemanticNamespace, lsp.SemanticProperty:
		return "NameNamespace"
	case lsp.SemanticVariable, lsp.SemanticParameter:
		return "Name"
	}
	return ""
}

// semanticSpan is one semantic token resolved to rune offsets.
type semanticSpan struct {
	start, end int
	scope      syntax.StyleScope
}

// MergeSemanticTokens overlays the language server's semantic classification on
// the tokens the lexer produced: the syntax tokens are cut at the semantic
// boundaries and the semantic scope wins where the two overlap, so anything the
// server stays silent about keeps the lexer's colour.
//
// offsetAt converts an LSP position into a rune offset; pass Editor.OffsetAt when
// merging for an editor.
func MergeSemanticTokens(base []syntax.Token, semantic []lsp.SemanticToken, offsetAt func(lsp.Position) int) []syntax.Token {
	if len(semantic) == 0 || offsetAt == nil {
		return base
	}
	spans := make([]semanticSpan, 0, len(semantic))
	length := 0
	for _, token := range semantic {
		scope := SemanticScope(token.Type)
		if scope == "" {
			continue
		}
		from, to := offsetAt(token.Range.Start), offsetAt(token.Range.End)
		if from >= to {
			continue
		}
		spans = append(spans, semanticSpan{start: from, end: to, scope: scope})
		if to > length {
			length = to
		}
	}
	if len(spans) == 0 {
		return base
	}
	for _, token := range base {
		if token.End > length {
			length = token.End
		}
	}

	// Boundary sweep: cut the document at every token edge, then give each
	// interval the innermost semantic scope that covers it, falling back to the
	// lexer's token.
	bounds := make([]int, 0, 2*(len(base)+len(spans))+2)
	bounds = append(bounds, 0, length)
	for _, token := range base {
		bounds = append(bounds, token.Start, token.End)
	}
	for _, s := range spans {
		bounds = append(bounds, s.start, s.end)
	}
	sort.Ints(bounds)

	out := make([]syntax.Token, 0, len(base))
	for i := 0; i+1 < len(bounds); i++ {
		start, end := bounds[i], bounds[i+1]
		if start >= end {
			continue
		}
		scope := innermostSpanScope(spans, start)
		if scope == "" {
			scope = innermostBaseScope(base, start)
		}
		if scope == "" {
			continue
		}
		if n := len(out); n > 0 && out[n-1].End == start && out[n-1].Scope == scope {
			out[n-1].End = end
			continue
		}
		out = append(out, syntax.Token{Start: start, End: end, Scope: scope})
	}
	return out
}

// innermostSpanScope returns the scope of the smallest semantic span covering
// off, so a nested token (a function name inside a declaration) wins over the
// range that contains it.
func innermostSpanScope(spans []semanticSpan, off int) syntax.StyleScope {
	best := -1
	var scope syntax.StyleScope
	for _, s := range spans {
		if off < s.start || off >= s.end {
			continue
		}
		if best < 0 || s.end-s.start < best {
			best, scope = s.end-s.start, s.scope
		}
	}
	return scope
}

// innermostBaseScope returns the scope of the smallest lexer token covering off.
func innermostBaseScope(tokens []syntax.Token, off int) syntax.StyleScope {
	best := -1
	var scope syntax.StyleScope
	for _, t := range tokens {
		if off < t.Start || off >= t.End {
			continue
		}
		if best < 0 || t.End-t.Start < best {
			best, scope = t.End-t.Start, t.Scope
		}
	}
	return scope
}
