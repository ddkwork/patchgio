package gvcode

import "github.com/oligo/gvcode/postfix"

// WithPostfixTemplates enables IntelliJ's postfix templates: typing an
// expression followed by ".key" and pressing Tab replaces both with the
// template's snippet.
func WithPostfixTemplates(provider *postfix.Provider) EditorOption {
	return func(e *Editor) {
		e.postfixProvider = provider
	}
}

// DefaultPostfixTemplates registers the built-in Go templates.
func DefaultPostfixTemplates() EditorOption {
	return WithPostfixTemplates(postfix.NewProvider(postfix.DefaultTemplates()...))
}

// expandPostfixTemplate replaces "expr.key" with the template's expansion when
// the text right before the caret names one. It mirrors
// PostfixLiveTemplate.expandTemplate: the key (and the expression it wraps) is
// deleted and the template body is started in its place.
//
// Tab is IntelliJ's default "expand the selected postfix template" key, so this
// runs from onTab before the plain indent.
func (e *Editor) expandPostfixTemplate() bool {
	if e.postfixProvider == nil {
		return false
	}
	start, end := e.Selection()
	if start != end {
		return false
	}

	tmpl, expr, replaceStart, ok := e.postfixProvider.Match(e.Text(), start)
	if !ok {
		return false
	}

	body := tmpl.Expand(expr)
	// Drop "expr.key" first, then start the template where the expression was.
	e.text.Replace(replaceStart, start, "")
	e.text.SetCaret(replaceStart, replaceStart)
	if _, err := e.InsertSnippet(body); err != nil {
		// No tab stops or an unparsable body: fall back to plain text so the
		// expansion is never silently lost.
		e.Insert(body)
	}
	e.scrollCaret = true
	return true
}
