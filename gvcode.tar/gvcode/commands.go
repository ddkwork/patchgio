package gvcode

import (
	"slices"

	"gioui.org/io/clipboard"
	"gioui.org/io/event"
	"gioui.org/io/key"
	"gioui.org/io/system"
	"gioui.org/layout"
	"github.com/oligo/gvcode/textview"
)

// CommandHandler defines a callback function for the specific key event. It returns
// an EditorEvent if there is any.
type CommandHandler func(gtx layout.Context, evt key.Event) EditorEvent

type keyCommand struct {
	tag     any
	filter  key.Filter
	handler CommandHandler
}

// RegisterCommand register an extra command handler responding to key events.
// If there is an existing handler, it appends to the existing ones. Only the
// last key filter is checked during event handling. This method is expected to
// be invoked dynamically during layout.
func (e *Editor) RegisterCommand(srcTag any, filter key.Filter, handler CommandHandler) {
	if e.commands == nil {
		e.commands = make(map[key.Name][]keyCommand)
	}

	if len(e.commands) == 0 {
		e.buildBuiltinCommands()
	}

	if srcTag == nil || handler == nil {
		return
	}

	filter.Focus = e
	cmd := keyCommand{tag: srcTag, filter: filter, handler: handler}

	// overwrite the existing handler.
	idx := slices.IndexFunc(e.commands[filter.Name],
		func(c keyCommand) bool {
			return c.filter == cmd.filter && c.tag == cmd.tag
		})
	if idx >= 0 {
		e.commands[filter.Name][idx] = cmd
	} else {
		e.commands[filter.Name] = append(e.commands[filter.Name], cmd)
	}
}

// RemoveCommands unregister command handlers from tag.
func (e *Editor) RemoveCommands(tag any) {
	for k, cmds := range e.commands {
		e.commands[k] = slices.DeleteFunc(cmds, func(cmd keyCommand) bool {
			return cmd.tag == tag
		})

		if len(e.commands[k]) == 0 {
			delete(e.commands, k)
		}
	}
}

func (e *Editor) buildBuiltinCommands() {
	if e.commands == nil {
		e.commands = make(map[key.Name][]keyCommand)
	}
	clear(e.commands)

	registerCommand := func(filter key.Filter, handler CommandHandler) {
		filter.Focus = e
		e.commands[filter.Name] = append(e.commands[filter.Name], keyCommand{filter: filter, handler: handler})
	}

	registerCommand(key.Filter{Focus: e, Name: key.NameEnter, Optional: key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			return e.onInsertLineBreak(evt)
		},
	)

	registerCommand(key.Filter{Focus: e, Name: key.NameReturn, Optional: key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			return e.onInsertLineBreak(evt)
		},
	)

	registerCommand(key.Filter{Focus: e, Name: "C", Required: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			return e.onCopyCut(gtx, evt)
		},
	)

	// Initiate a paste operation, by requesting the clipboard contents; other
	// half is in Editor.processKey() under clipboard.Event.
	registerCommand(key.Filter{Focus: e, Name: "V", Required: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode != ModeReadOnly {
				gtx.Execute(clipboard.ReadCmd{Tag: e})
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: "X", Required: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			return e.onCopyCut(gtx, evt)
		})

	registerCommand(key.Filter{Focus: e, Name: "Z", Required: key.ModShortcut, Optional: key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode != ModeReadOnly {
				if evt.Modifiers.Contain(key.ModShift) {
					if ev, ok := e.redo(); ok {
						return ev
					}
				} else {
					if ev, ok := e.undo(); ok {
						return ev
					}
				}
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: "A", Required: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			e.text.SetCaret(0, e.text.Len())
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: "D", Required: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode != ModeReadOnly {
				if e.DuplicateLine() != 0 {
					return ChangeEvent{}
				}
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NameHome, Optional: key.ModShortcut | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			// In column edit mode the whole column jumps: Shift+Home trims the
			// block back to the line start (plus every line above it with Ctrl),
			// a plain Home parks the carets on the block's left edge.
			if e.ColumnEditEnabled() && len(e.columnEdit.selections) > 0 {
				if evt.Modifiers.Contain(key.ModShift) {
					e.columnExtendToEdge(true, evt.Modifiers.Contain(key.ModShortcut))
				} else if !evt.Modifiers.Contain(key.ModShortcut) {
					e.columnCaretToEdge(false, false)
				} else {
					// Ctrl+Home keeps its ordinary meaning, as it does in GoLand
					// for the primary caret.
					e.text.MoveTextStart(textview.SelectionClear)
				}
				return nil
			}

			selAct := textview.SelectionClear
			if evt.Modifiers.Contain(key.ModShift) {
				selAct = textview.SelectionExtend
			}

			if evt.Modifiers.Contain(key.ModShortcut) {
				e.text.MoveTextStart(selAct)
			} else {
				e.text.MoveLineStart(selAct)
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NameEnd, Optional: key.ModShortcut | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			// In column edit mode the whole column jumps: Shift+End grows the
			// block out to the end of its widest line (plus every line below it
			// with Ctrl), a plain End parks the carets on the block's right edge.
			if e.ColumnEditEnabled() && len(e.columnEdit.selections) > 0 {
				if evt.Modifiers.Contain(key.ModShift) {
					e.columnExtendToEdge(false, evt.Modifiers.Contain(key.ModShortcut))
				} else if !evt.Modifiers.Contain(key.ModShortcut) {
					e.columnCaretToEdge(true, false)
				} else {
					e.text.MoveTextEnd(textview.SelectionClear)
				}
				return nil
			}

			selAct := textview.SelectionClear
			if evt.Modifiers.Contain(key.ModShift) {
				selAct = textview.SelectionExtend
			}
			if evt.Modifiers.Contain(key.ModShortcut) {
				e.text.MoveTextEnd(selAct)
			} else {
				e.text.MoveLineEnd(selAct)
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NameEnter, Required: key.ModShift, Optional: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			// Ctrl+Shift+Enter is IntelliJ's CompleteStatementAction: close every
			// bracket the caret still sits inside.
			if e.mode != ModeReadOnly {
				if ev, ok := e.completeStatement(); ok {
					return ev
				}
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NameTab, Optional: key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			return e.onTab(evt)
		})

	registerCommand(key.Filter{Focus: e, Name: key.NameDeleteBackward, Optional: key.ModShortcutAlt | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode != ModeReadOnly {
				moveByWord := evt.Modifiers.Contain(key.ModShortcutAlt)

				if moveByWord {
					if e.deleteWord(-1) != 0 {
						return ChangeEvent{}
					}
				} else {
					if e.Delete(-1) != 0 {
						return ChangeEvent{}
					}
				}
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NameDeleteForward, Optional: key.ModShortcutAlt | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode != ModeReadOnly {
				moveByWord := evt.Modifiers.Contain(key.ModShortcutAlt)
				if moveByWord {
					if e.deleteWord(1) != 0 {
						return ChangeEvent{}
					}
				} else {
					if e.Delete(1) != 0 {
						return ChangeEvent{}
					}
				}
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NamePageDown, Optional: key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			// In column edit mode Shift+PageDown grows the block a page of lines
			// at a time, which is GoLand's clone handler run once per visible line.
			if e.ColumnEditEnabled() && evt.Modifiers.Contain(key.ModShift) && len(e.columnEdit.selections) > 0 {
				e.cloneColumnCaretsByPage(false, e.visibleColumnLines(gtx))
				return nil
			}

			selAct := textview.SelectionClear
			if evt.Modifiers.Contain(key.ModShift) {
				selAct = textview.SelectionExtend
			}
			e.text.MovePages(+1, selAct)
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NamePageUp, Optional: key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			// In column edit mode Shift+PageUp takes back a page of lines, or adds
			// one above the block once nothing is left to take back.
			if e.ColumnEditEnabled() && evt.Modifiers.Contain(key.ModShift) && len(e.columnEdit.selections) > 0 {
				e.cloneColumnCaretsByPage(true, e.visibleColumnLines(gtx))
				return nil
			}

			selAct := textview.SelectionClear
			if evt.Modifiers.Contain(key.ModShift) {
				selAct = textview.SelectionExtend
			}
			e.text.MovePages(-1, selAct)
			return nil
		})

	checkPos := func(gtx layout.Context) (bool, bool) {
		caret, _ := e.text.Selection()
		atBeginning := caret == 0
		atEnd := caret == e.text.Len()
		if gtx.Locale.Direction.Progression() != system.FromOrigin {
			atEnd, atBeginning = atBeginning, atEnd
		}
		return atBeginning, atEnd
	}

	registerCommand(key.Filter{Focus: e, Name: key.NameLeftArrow, Optional: key.ModShortcutAlt | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			// Handle column editing mode: move all carets left. Alt moves by a
			// whole word, Shift keeps and extends the block — both exactly like
			// GoLand.
			if e.ColumnEditEnabled() && len(e.columnEdit.selections) > 0 {
				shift := evt.Modifiers.Contain(key.ModShift)
				byWord := evt.Modifiers.Contain(key.ModShortcutAlt)
				switch {
				case shift && byWord:
					e.extendColumnCaretsByWord(-1)
				case shift:
					e.extendColumnCarets(-1)
				case byWord:
					e.moveColumnCaretsByWord(-1)
				default:
					e.moveColumnCarets(-1)
				}
				return nil
			}

			atBeginning, _ := checkPos(gtx)
			if atBeginning {
				return nil
			}

			moveByWord := evt.Modifiers.Contain(key.ModShortcutAlt)
			direction := 1
			if gtx.Locale.Direction.Progression() == system.TowardOrigin {
				direction = -1
			}
			selAct := textview.SelectionClear
			if evt.Modifiers.Contain(key.ModShift) {
				selAct = textview.SelectionExtend
			}

			if moveByWord {
				e.text.MoveWords(-1*direction, selAct)
			} else {
				if selAct == textview.SelectionClear {
					e.text.ClearSelection()
				}
				e.text.MoveCaret(-1*direction, -1*direction*int(selAct))
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NameUpArrow, Optional: key.ModShortcutAlt | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			// In column edit mode Shift+Up clones the caret column onto the line
			// above (or takes back the last line added above), like GoLand. A
			// plain Up keeps its normal behaviour.
			if e.ColumnEditEnabled() && evt.Modifiers.Contain(key.ModShift) && len(e.columnEdit.selections) > 0 {
				e.cloneColumnCarets(true)
				return nil
			}

			atBeginning, _ := checkPos(gtx)
			if atBeginning {
				return nil
			}

			selAct := textview.SelectionClear
			if evt.Modifiers.Contain(key.ModShift) {
				selAct = textview.SelectionExtend
			}
			e.text.MoveLines(-1, selAct)
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NameRightArrow, Optional: key.ModShortcutAlt | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			// Handle column editing mode: move all carets right. Alt moves by a
			// whole word, Shift keeps and extends the block — both exactly like
			// GoLand.
			if e.ColumnEditEnabled() && len(e.columnEdit.selections) > 0 {
				shift := evt.Modifiers.Contain(key.ModShift)
				byWord := evt.Modifiers.Contain(key.ModShortcutAlt)
				switch {
				case shift && byWord:
					e.extendColumnCaretsByWord(1)
				case shift:
					e.extendColumnCarets(1)
				case byWord:
					e.moveColumnCaretsByWord(1)
				default:
					e.moveColumnCarets(1)
				}
				return nil
			}

			_, atEnd := checkPos(gtx)
			if atEnd {
				return nil
			}

			moveByWord := evt.Modifiers.Contain(key.ModShortcutAlt)
			direction := 1
			if gtx.Locale.Direction.Progression() == system.TowardOrigin {
				direction = -1
			}
			selAct := textview.SelectionClear
			if evt.Modifiers.Contain(key.ModShift) {
				selAct = textview.SelectionExtend
			}

			if moveByWord {
				e.text.MoveWords(1*direction, selAct)
			} else {
				if selAct == textview.SelectionClear {
					e.text.ClearSelection()
				}
				e.text.MoveCaret(1*direction, int(selAct)*direction)
			}
			return nil
		})

	registerCommand(key.Filter{Focus: e, Name: key.NameDownArrow, Optional: key.ModShortcutAlt | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			// In column edit mode Shift+Down clones the caret column onto the line
			// below (or takes back the last line added below), like GoLand. A
			// plain Down keeps its normal behaviour.
			if e.ColumnEditEnabled() && evt.Modifiers.Contain(key.ModShift) && len(e.columnEdit.selections) > 0 {
				e.cloneColumnCarets(false)
				return nil
			}

			_, atEnd := checkPos(gtx)
			if atEnd {
				return nil
			}

			selAct := textview.SelectionClear
			if evt.Modifiers.Contain(key.ModShift) {
				selAct = textview.SelectionExtend
			}
			e.text.MoveLines(+1, selAct)
			return nil
		})

	// ESC drops the extra carets and leaves column editing mode, the way IntelliJ
	// collapses a multi-caret session. It also closes the language popups.
	registerCommand(key.Filter{Focus: e, Name: key.NameEscape},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			e.HidePopups()
			if e.ColumnEditEnabled() {
				e.clearColumnEdit()
				e.ClearSelection()
			}
			if e.MultiCaretEnabled() {
				e.clearMultiCarets()
				e.ClearSelection()
			}
			return nil
		})

	// Alt+Enter is IntelliJ's ShowIntentionActions: the quick fixes and
	// intentions available at the caret (see language.go).
	registerCommand(key.Filter{Focus: e, Name: key.NameEnter, Required: key.ModAlt},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode == ModeReadOnly {
				return nil
			}
			if event, ok := e.RequestIntentions(); ok {
				return event
			}
			return nil
		})

	// Ctrl+Q is IntelliJ's Quick Documentation.
	registerCommand(key.Filter{Focus: e, Name: "Q", Required: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			e.ShowQuickDocumentation()
			return nil
		})

	// Ctrl+P is IntelliJ's Parameter Info. (Use Ctrl+Space for completion.)
	registerCommand(key.Filter{Focus: e, Name: "P", Required: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			e.ShowParameterInfo()
			return nil
		})

	// Ctrl+/ toggles line comments on the affected lines; Ctrl+Shift+/ (which most
	// layouts report as Ctrl+?) wraps the selection in a block comment. Both use
	// the file type's comment syntax (see comment.go).
	//
	// The less specific filter is registered first: the command stack matches the
	// LAST registered command first, so the Shift variant has to come last.
	registerCommand(key.Filter{Focus: e, Name: "/", Required: key.ModShortcut, Optional: key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode == ModeReadOnly {
				return nil
			}
			if event, ok := e.ToggleLineComment(); ok {
				return event
			}
			return nil
		})
	blockComment := func(gtx layout.Context, evt key.Event) EditorEvent {
		if e.mode == ModeReadOnly {
			return nil
		}
		if event, ok := e.ToggleBlockComment(); ok {
			return event
		}
		return nil
	}
	registerCommand(key.Filter{Focus: e, Name: "/", Required: key.ModShortcut | key.ModShift}, blockComment)
	registerCommand(key.Filter{Focus: e, Name: "?", Required: key.ModShortcut | key.ModShift}, blockComment)

	// Alt+J is IntelliJ's SelectNextOccurrenceAction: select the word (or the
	// current selection) and add a caret at its next occurrence.
	registerCommand(key.Filter{Focus: e, Name: "J", Required: key.ModAlt},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode != ModeReadOnly {
				e.selectNextOccurrence()
			}
			return nil
		})

	// Ctrl+Alt+Shift+J is IntelliJ's SelectAllOccurrencesAction: a caret at every
	// occurrence of the word or selection at the primary caret.
	registerCommand(key.Filter{Focus: e, Name: "J", Required: key.ModShortcut | key.ModAlt | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode != ModeReadOnly {
				e.selectAllOccurrences()
			}
			return nil
		})

	// Alt+C toggles column editing mode
	registerCommand(key.Filter{Focus: e, Name: "C", Required: key.ModAlt},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode != ModeReadOnly {
				// Disabling converts the block back into a linear selection
				// (SetColumnEditMode does that), so nothing is cleared here.
				e.SetColumnEditMode(!e.ColumnEditEnabled())
			}
			return nil
		})

	// ---- IntelliJ navigation and refactoring actions (see navigation.go) ----

	// Ctrl+Alt+B is Go to Implementation(s).
	registerCommand(key.Filter{Focus: e, Name: "B", Required: key.ModShortcut | key.ModAlt},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if event, ok := e.ShowImplementations(); ok {
				return event
			}
			return nil
		})

	// Alt+F7 is Find Usages. The editor cannot open a tool window itself, so it
	// hands the host a NavigationEvent to render.
	registerCommand(key.Filter{Focus: e, Name: key.NameF7, Required: key.ModAlt},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if event, ok := e.ShowUsages(); ok {
				return event
			}
			return nil
		})

	// Ctrl+H is the type hierarchy. IntelliJ's Ctrl+Alt+H is the call hierarchy,
	// which the mock has no call graph for, so it maps to the same view.
	hierarchy := func(gtx layout.Context, evt key.Event) EditorEvent {
		if event, ok := e.ShowTypeHierarchy(); ok {
			return event
		}
		return nil
	}
	registerCommand(key.Filter{Focus: e, Name: "H", Required: key.ModShortcut}, hierarchy)
	registerCommand(key.Filter{Focus: e, Name: "H", Required: key.ModShortcut | key.ModAlt}, hierarchy)

	// Ctrl+Alt+L is Reformat Code.
	registerCommand(key.Filter{Focus: e, Name: "L", Required: key.ModShortcut | key.ModAlt},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if e.mode == ModeReadOnly {
				return nil
			}
			if e.FormatDocument() {
				return ChangeEvent{}
			}
			return nil
		})

	// Shift+F6 is Rename. Asking for the new name is the host's job, so the
	// editor only reports which symbol is being renamed.
	registerCommand(key.Filter{Focus: e, Name: key.NameF6, Required: key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if name := e.SymbolAtCaret(); name != "" {
				return RenameEvent{Symbol: name, Line: e.positionAt(e.caretOffset()).Line}
			}
			return nil
		})

	// Ctrl+F11 toggles a bookmark; F11 / Shift+F11 walk them (see marks.go).
	registerCommand(key.Filter{Focus: e, Name: key.NameF11, Required: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			e.ToggleBookmark()
			return nil
		})
	registerCommand(key.Filter{Focus: e, Name: key.NameF11, Optional: key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			if evt.Modifiers.Contain(key.ModShift) {
				e.GoToPreviousBookmark()
			} else {
				e.GoToNextBookmark()
			}
			return nil
		})

	// Ctrl+F8 toggles a breakpoint.
	registerCommand(key.Filter{Focus: e, Name: key.NameF8, Required: key.ModShortcut},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			e.ToggleBreakpoint()
			return nil
		})

	// Alt+Shift+Insert is IntelliJ's Edit > Column Selection Mode.
	registerCommand(key.Filter{Focus: e, Name: key.Name("Insert"), Required: key.ModAlt | key.ModShift},
		func(gtx layout.Context, evt key.Event) EditorEvent {
			e.SetColumnSelectionMode(!e.ColumnSelectionMode())
			return ColumnSelectionModeEvent{Enabled: e.ColumnSelectionMode()}
		})

}

func (e *Editor) processCommands(gtx layout.Context) EditorEvent {
	if len(e.commands) == 0 {
		e.buildBuiltinCommands()
	}

	for _, cmdStack := range e.commands {
		// reverse the commands & filters in the key group, and then
		// pass the filters to the input source get matched key events.
		// So the last registered command can be first matched.
		//
		// If the same filter exists, the commands registered earlier will not be activated.
		// If the top most command does not match, commands below will be matched. The first matched win.
		var filters = make([]event.Filter, 0, len(cmdStack))
		var cmds = make([]keyCommand, 0, len(cmdStack))
		for _, c := range slices.Backward(cmdStack) {
			filters = append(filters, c.filter)
			cmds = append(cmds, c)
		}

		for {
			ke, ok := gtx.Event(filters...)
			if !ok {
				break
			}

			e.blinkStart = gtx.Now
			if ke, ok := ke.(key.Event); ok {
				if !gtx.Focused(e) || ke.State != key.Press {
					break
				}
				e.scrollCaret = true
				e.scroller.Stop()

				// do a similar match process like gtx.Event to find out which command
				// should be activated.
				idx := matchedCmd(ke, cmds)
				if idx < 0 {
					// should not happen.
					continue
				}

				cmd := cmds[idx]
				evt := cmd.handler(gtx, ke)
				if evt != nil {
					return evt
				}
			}
		}
	}

	return nil
}

func matchedCmd(ke key.Event, cmds []keyCommand) int {
	for idx, cmd := range cmds {
		if keyFilterMatch(cmd.filter, ke) {
			return idx
		}
	}
	return -1
}

// Similar logic to one used by the builtin router.
func keyFilterMatch(f key.Filter, e key.Event) bool {
	if f.Name != "" && f.Name != e.Name {
		return false
	}

	if e.Modifiers&f.Required != f.Required {
		return false
	}
	if e.Modifiers&^(f.Required|f.Optional) != 0 {
		return false
	}
	return true
}
