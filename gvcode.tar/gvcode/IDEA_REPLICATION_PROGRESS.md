# gvcode × IntelliJ IDEA 复刻进度

本文件记录 `d:/ux/flowui/patchgio/gvcode`（基于 Gio 的 Go 编辑器）逐条复刻 IntelliJ IDEA 编辑器特性的进度。

- **权威规格**：`D:\ux\新建文件夹\intellij-community-master`（唯一对照源，行为/图标/常量均以它为准）
- **复刻原则**：不近似、不取巧；对齐 IDEA 的真实行为，并用 **headless 渲染单测 + 截图** 证明
- **验证方式**：`go test -count=1 ./...`（`gioui.org/gpu/headless` + `input.Router` 注入真实 pointer/key）
- **截图输出**：`d:/ux/flowui/bin/screenshots/`

## 状态速览

- **「进度总览」表的 #1–#33：全部 ✅ 完成**，每项都有实现文件 + 测试 + 截图（见下表）。
- **本文件下方「仍未复刻（按能力归类）」与「IDEA 插件目录调研结论」里的机制：尚未全部实现。** 逐条状态见下面的
  **待办清单**；那张表是唯一权威的待办源，做完一项就把它挪进「进度总览」并在这里刷新状态。
- 最近一次全量核对（2026-09-13）：`gvcode` 侧 `go build/test ./...` 全绿；flowui 侧
  `./ui/... ./internal/... ./examples/goland ./examples/components` 全绿。
  既有无关失败：`examples/keygen`、`examples/machinecode` 缺 `github.com/ddkwork/keygen` 模块；
  `go vet` 报 `patchgio/gvcode/internal/stroke` 未命名字段。

## 待办清单（TODO）

**用法**：直接回我 `做 T3`（或 `T3、T5`）即可。做完我会更新这里的状态、把条目移入「进度总览」并跑一遍验证。
工作量是相对量级（小 = 半天内，中 = 需要新增一个组件/子系统，大 = 需要引入外部依赖或重写一层）。

### A. 自包含，可立即做（不依赖外部工具或服务）

| ID | 待办 | 现状 / 缺口 | 对照 IDEA | 验收方式 | 量级 | 状态 |
|---|---|---|---|---|---|---|
| T1 | **结构视图（Structure 工具窗）** | 只有 `Editor.LanguageSymbols()`/`SymbolPath()` 供面包屑与 code lens 用；`DocumentSymbols.Children` mock 未填；示例里没有面板 | `StructureViewComponent`、`StructureViewTreeElement`、`StructureViewModel` | 单测（嵌套符号/可见性过滤/islands）+ 新渲染视图 + 点节点跳转 | 中 | ⬜ 未做 |
| T2 | **code lens 点击行为** | 只绘制不响应点击 | `CodeLensActionGroup`、`CodeLensProvider` | 点击 `N usages` / `N implementations` 触发已有的 `find-usages` / `goto-implementation` 命令 | 小 | ⬜ 未做 |
| T3 | **书签 / 断点持久化** | 只存在内存（`editorMarks`） | `BookmarkManager`（workspace 序列化、助记符、描述） | 单测：序列化/反序列化往返、助记符跳转、重启后仍在（示例虚拟 workspace） | 小 | ⬜ 未做 |
| T4 | **把 `VCSDiffProvider` 接进 flowui 编辑器** | provider 已存在（`gutter/providers/diff.go`）但 `ui/` 未暴露，示例未启用；无 blame（blame 见 T18） | `LineStatusTracker`、`EditorGutterComponentImpl.paintGutter` | 单测：与 mock base content 的行级 diff 落点 + 双色 gutter 像素；渲染视图 | 中 | ⬜ 未做 |
| T5 | **终端命令块模型（OSC 133 / 1341）** | 完全没有；控制台只是 ANSI 行缓冲 | `plugins/terminal`：命令边界 + 退出码 + 工作目录 → 复制块/跳错误 | 单测：解析 `OSC 133;A/B/C/D` 与 `1341`、块边界、退出码；示例里可复制块/跳错误 | 中 | ⬜ 未做 |
| T6 | **补全的其余排序因子** | 已有 `middleMatching/priority/prefix/liftShorter`；缺统计热度、邻近度、分组、类型期望、模板占位符镜像 | `StatisticsWeigher`、`proximity`、`grouping`、`PreferExpected`、`$EXPR$` | 单测：每个因子单独断言 + 组合顺序 | 中 | ⬜ 未做 |
| T7 | **粘贴 / 拖拽的缩进后处理 + 块注释智能处理** | `CopyPastePostProcessor` 未移植；块注释目前是朴素包裹/脱掉 | `CopyPastePostProcessor`、`CommentByBlockCommentAction` 的嵌套/部分注释处理 | 单测：多行缩进对齐、`Shift+Insert` 行为、块注释嵌套与部分覆盖 | 中 | ⬜ 未做 |
| T8 | **拼写检查（SpellCheckingInspection）** | 完全没有（`textview/text.go` 只有一句注释） | `SpellCheckingInspection`、`SpellChecker` | 内置小词典 + 单测：波浪线落点、`Alt+Enter` 的"改为/加入词典"意图、渲染截图 | 中 | ⬜ 未做 |
| T9 | **markdown 双视图滚动同步** | 预览是整篇一次性布局，无滚动偏移可读写 | `MarkdownSplitEditorProvider` 的 `ScrollSync` 设置项 | 单测：源码滚动 → 预览偏移映射（也可先把预览改成可滚动列表） | 小 | ⬜ 未做 |
| T10 | **TextMate 语法引擎（替换 chroma）** | 仍用 chroma；未接 `go.tmLanguage.json` | `plugins/textmate`（可 vendor 它的 grammar） | 单测：同一份 Go 源码的 token 与 IDEA 高亮逐段比对；渲染前后对比图 | 大 | ⬜ 未做 |
| T11 | **统一「配置语言 + JSON Schema」引擎** | 没有；json/yaml/toml 只靠 chroma 上色 | `json/backend` + `plugins/yaml` + `plugins/toml`（校验/补全/悬停/跳转/注入复用一套代码） | 单测：同一份 schema 的校验/补全/悬停/跳转；示例中真实生效 | 大 | ⬜ 未做 |
| T12 | **EditorConfig 分层配置 + 设置预览** | 示例里只有个假 `.editorconfig` 文件，无配置引擎 | `plugins/editorconfig` 的分层解析 + 预览编辑器 | 单测：目录层级覆盖顺序、glob 匹配、`indent_size` 生效到编辑器 | 中 | ⬜ 未做 |
| T13 | **Minimap 分层渲染管线** | 编辑器没有 minimap（`minimap` 只存在于 nodegraph 组件） | `plugins/minimap`：token/选区/诊断/折叠/断点/光标各一层 | 单测：每层像素 + 总览点击跳转；渲染截图 | 中 | ⬜ 未做 |
| T14 | **终端增量缓冲 + 最小编辑同步** | 控制台每次追加都重建行 | `TerminalOutputModelController`（局部替换以保住 range marker） | 单测：追加 ANSI 不破坏已建高亮/超链接；性能断言 | 中 | ⬜ 未做 |
| T15 | **示例工程读写真实磁盘 / 跑真实进程** | 虚拟 FS；仅"磁盘上有实体"的脚本才真跑 | —（工程化改进） | 需要把渲染测试的确定性保住（虚拟 FS 保留为测试用），并加真实工程的冒烟测试 | 中 | ⬜ 未做 |

### B. 需要外部 CLI / 进程

| ID | 待办 | 现状 / 缺口 | 对照 IDEA | 验收方式 | 量级 | 状态 |
|---|---|---|---|---|---|---|
| T16 | **真实 LSP 客户端（替换 `MockServer`）** | 边界已就绪（`lsp.Server` 一个方法一个特性） | LSP 客户端 + `LspServerSupportProvider` | 起一个真 server（gopls），把所有 `lsp.Server` 方法跑到；保留 mock 供测试 | 大 | ⬜ 未做 |
| T17 | **外部工具即服务**（shellcheck / shfmt / gofumpt…） | 没有 | `plugins/sh` 的外部工具集成 | 单测：CLI 不存在/超时/输出的降级路径；示例里真实调用 | 中 | ⬜ 未做 |
| T18 | **Gutter blame**（git） | 没有（T4 只做 diff 标记） | `plugins/git4idea` 的 blame 注解 | 单测：解析 `git blame --porcelain` 并渲染；无 git 时优雅降级 | 中 | ⬜ 未做 |

### C. 需要模型 / 外部服务

| ID | 待办 | 现状 / 缺口 | 对照 IDEA | 验收方式 | 量级 | 状态 |
|---|---|---|---|---|---|---|
| T19 | **ML 补全重排序** | 没有；`rank.go` 是规则排序 | `plugins/completion-ml-ranking` 的 `CompletionFinalSorter`（只重排 top-K、按元素身份缓存分数） | 先在最后一步留出 hook + 用假分数验证缓存与 top-K 语义；接模型另议 | 大 | ⬜ 未做 |
| T20 | **对话面板接真实模型 / 工具调用** | `mockAgentReply` 是唯一替换入口 | —（agent 侧） | 保持 `mockAgentReply` 为默认，真实 provider 走同一接口；渲染测试仍用 mock | 大 | ⬜ 未做 |

> 建议顺序（我自己的判断，供参考）：**T1 → T2 → T3**（小、可见、能立刻截图）→ **T5 → T4**（终端与 gutter 的观感提升明显）
> → T6/T7/T9 → 其余。要跳过哪个直接说。

## 进度总览

| # | 特性 | 状态 | gvcode 实现 | 测试 | 截图 |
|---|------|------|-------------|------|------|
| 1 | gutter 列模型（优先级排布） | ✅ 完成 | `gutter/manager.go` | `gutter_features_test.go` | — |
| 2 | 代码折叠（识别/范围/渲染） | ✅ 完成 | `internal/folding/folding.go`、`gutter/providers/foldbutton.go` | `internal/folding/folding_test.go` | `gvcode-gutter-folding-*` |
| 3 | 折叠 outline（展开区间实线） | ✅ 完成 | `gutter/providers/foldbutton.go` | `TestGutterFoldGuideLineSpansAnExpandedRegion` | `gvcode-gutter-fold-guide.png` |
| 4 | 折叠/展开图标（IDEA SVG） | ✅ 完成 | `gutter/providers/foldbutton.go` | `TestGutterFoldButtonClickCollapses` | `gvcode-gutter-foldbutton-*` |
| 5 | 逻辑行号（折叠后不重排） | ✅ 完成 | `internal/layout/text_layout.go` | `TestGutterLineNumbersAreLogical` | `gvcode-gutter-logical-linenumbers.png` |
| 6 | 光标不可进入折叠区 | ✅ 完成 | `internal/layout/text_layout.go` | `TestGutterCaretCannotEnterCollapsedFold` | — |
| 7 | 运行按钮（main/test） | ✅ 完成 | `gutter/providers/runbutton.go` | `TestGutterRunButtonRenders`、`TestGutterRunButtonClickEmitsEvent` | `gvcode-gutter-runbutton*.png` |
| 8 | 粘性行（sticky lines） | ✅ 完成 | `gutter/providers/stickylines.go` | `TestGutterStickyLineClickNavigatesSmoothly` 等 | `gvcode-gutter-stickylines-clicked.png` |
| 9 | 实现/覆写 gutter 图标 | ✅ 完成 | `gutter/providers/methodicon.go` | `method_icon_test.go` | `gvcode-method-icons*.png` |
| 10 | 回车处理链 + 智能按键 | ✅ 完成 | `enter.go`、`event.go`、`commands.go` | `enter_test.go` | `gvcode-enter-*.png` |
| 11 | 多光标（Alt+J 等） | ✅ 完成 | `multicaret.go`、`commands.go` | `multicaret_test.go` | `gvcode-multicaret-carets.png` |
| 12 | 补全匹配 CamelHump/Fuzzy | ✅ 完成 | `addons/completion/matcher.go` | `matcher_test.go` | — |
| 13 | 补全相关性排序 | ✅ 完成 | `addons/completion/rank.go` | `rank_test.go` | — |
| 14 | `.` 自动弹出 + middle matching | ✅ 完成 | `addons/completion/default.go` | `autopopup_test.go` | — |
| 15 | 后置补全 PostfixTemplate | ✅ 完成 | `postfix/postfix.go`、`postfix.go` | `postfix/postfix_test.go`、`postfix_test.go` | `gvcode-postfix-if.png` |
| 16 | **mock LSP 层**（可替换为真 LSP） | ✅ 完成 | `lsp/protocol.go`、`lsp/mock.go` | `lsp/mock_test.go`（11 项） | — |
| 17 | **语言服务接入**（诊断波浪线 / TODO / 快速修复 / 文档 / 参数信息 / inlay hints / 面包屑 / 语义 token） | ✅ 完成 | `language.go`、`editor.go`、`commands.go` | `language_test.go`（5 项） | `gvcode-language-*.png` |
| 18 | **拖拽选区到任意位置** | ✅ 完成 | `dragtext.go`、`textview/text.go`（`QueryPosClamped`） | `dragtext_test.go` | `gvcode-drag-selection.png` |
| 19 | 命令行后端（照抄 IDEA `commandInterface`） | ✅ 完成（在 flowui 仓） | `flowui/internal/components/commandline/*`、`flowui/ui/command_line.go` | `commandline_test.go` | — |
| 20 | 示例工程接入本地 gvcode | ✅ 完成 | `flowui/go.mod`（replace）、`codeeditor` 增加 `Options/OnSelection` | `flowui/examples/goland/render_check_test.go` | `goland-*.png` |
| 21 | ZCode 风格 AI agent 对话面板 | ✅ 完成 | `flowui/examples/goland/chat.go` | 渲染测试 `goland-chat` | `goland-chat-*.png` |
| 22 | 全表面右键菜单（树/编辑器/tab/控制台/对话/go.mod/go.work） | ✅ 完成 | `flowui/examples/goland/contextmenus.go` | 渲染测试 `goland-go-mod` | `goland-go-mod-*.png` |
| 23 | **按文件类型注释**（Ctrl+/ 行注释、Ctrl+Shift+/ 块注释，含 bat/cmd） | ✅ 完成 | `comment.go`、`commands.go` | `comment_test.go`（11 项） | — |
| 24 | **脚本文件右键运行**（.bat/.cmd/.ps1 → Run/Terminal） | ✅ 完成 | `flowui/examples/goland/scripts.go` | 渲染测试 `goland-script-run` | `goland-script-run-*.png` |
| 25 | **markdown 表格自动对齐/格式化**（对齐风格 + CJK/emoji 宽度 + 分隔行归一化） | ✅ 完成 | `flowui/internal/components/markdown/format.go`、`flowui/ui/markdown.go` | `format_test.go`（15 项） | `goland-markdown-format-*.png` |
| 26 | **markdown 表格 inlay 工具条**（列条/行把手 → 单击弹工具条 → 9/6 个动作改写源码） | ✅ 完成 | `flowui/internal/components/markdown/{tabletools,tableicons,tableops}.go` | `tabletools_test.go`、`tableops_test.go` | `markdown-table-toolbar.png` |
| 27 | **markdown 双视图**（左源码 + 右实时预览 + 三按钮顶栏 + 可拖分割线） | ✅ 完成 | `flowui/internal/components/markdowneditor/*`、`flowui/ui/markdown_editor.go` | `markdowneditor_test.go`（8 项） | `markdown-editor-*.png`、`goland-markdown-split-*.png` |
| 28 | **实现 / 用法 / 接口方法导航**（Go to Implementation(s)、Find Usages、类型层次 + 宿主渲染与跳转） | ✅ 完成 | `gvcode/navigation.go`、`gvcode/lsp/{protocol,mock}.go` | `navigation_test.go`、`lsp/mock_test.go`（14 项） | `gvcode-navigation-*.png`、`goland-usages-*.png`、`goland-hierarchy-*.png` |
| 29 | **code lens + 重命名 + 格式化动作**（N usages / N implementations、Shift+F6、Ctrl+Alt+L） | ✅ 完成 | `gvcode/navigation.go`、`gvcode/lsp/mock.go` | `navigation_test.go` | `gvcode-navigation-code-lens.png` |
| 30 | **书签与断点 gutter**（Ctrl+F11 / F11 / Shift+F11 / Ctrl+F8，列条可点击切换） | ✅ 完成 | `gvcode/marks.go`、`gvcode/gutter/providers/marks.go` | `navigation_test.go` | `gvcode-navigation-{bookmark,breakpoint}-gutter.png` |
| 31 | **列选择模式**（Alt+Shift+Insert；开启后普通拖拽即矩形选择） | ✅ 完成 | `gvcode/{navigation,event,commands}.go`、`flowui/ui/code_editor.go` | `navigation_test.go` | `goland-editor-marks-*.png` |
| 32 | **语义 token 与 chroma 语法 token 合并** | ✅ 完成 | `gvcode/semantic.go`、`flowui/internal/components/codeeditor` | `navigation_test.go` | — |
| 33 | **虚拟工程覆盖全部文件类型 + 菜单补齐**（列选择模式/转到/折叠/重构/Go 工具、go.work 全部子命令、右键运行与注释测试） | ✅ 完成 | `flowui/examples/goland/{project,contextmenus,menus,tools,panels}.go` | `contextmenus_test.go`（13 项） | `goland-vfs-tree-*.png`、`goland-usages-*.png` |

---

## 16–18. 语言服务（mock LSP）

### 16. `lsp` 包：可替换的语言服务边界

**对照 IDEA**：`CompletionContributor` / `HighlightInfo` / `IntentionAction` / `InlayHintsProvider` /
`QuickDocumentation` / `ParameterInfoHandler` / `BreadcrumbsProvider` / `SemanticTokensProvider`

**实现要点**：
- `lsp.Server` 接口＝一个方法一个特性：`Diagnostics / Completions / Hover / SignatureHelp /
  InlayHints / SemanticTokens / CodeActions / DocumentSymbols`，位置与区间全部是 0-based
  半开区间的 LSP 语义，**接真 LSP 客户端时只替换这一个实现**。
- `lsp.MockServer` 用一个小型 Go 词法扫描器（注释/字符串/raw/数字/标识符/标点 + 行列换算）
  在纯语法层面推导出：
  - **诊断**：括号不匹配（error）、局部变量声明但未使用（warning，Go 语义）、TODO/FIXME（information）
  - **符号/面包屑**：`func` / `type`（含 struct/interface）/ `var` / `const`
  - **补全**：文档符号 + Go 关键字 + 内建函数，按 `0/1/2` 的 SortText 分层
  - **hover**：声明签名 + 紧邻其上的 `//` 注释块
  - **签名帮助**：向内回溯未闭合的 `(` 找被调函数，按顶层逗号算 active parameter
  - **inlay hints**：对**同文件内声明**的函数调用给出参数名提示（IDEA 的 parameter hints）
  - **语义 token**：关键字/字符串/数字/注释/函数/类型/变量 + `declaration` 修饰
  - **代码动作**：未使用变量→删除该行（quickfix，preferred）；`x := ...`→`var x = ...`（intention，
    只删 `:` 以保留原有空格）
- 分析结果按文档缓存，编辑改变后重跑。

### 17. 编辑器接入（`language.go`）

| 特性 | 键 | 行为 |
|---|---|---|
| Alt+Enter 意图动作 | `Alt+Enter` | 收集光标处的 code action；**唯一时直接应用**，多个时产出 `IntentionEvent` 交给宿主弹菜单（对齐 IDEA `ShowIntentionActions`） |
| 快速文档 | `Ctrl+Q` | hover 内容渲染成弹出框（`PaintOverlay` + 自绘背景/边框），再按一次或 Esc 关闭 |
| 参数信息 | `Ctrl+P` | 签名 + 当前形参高亮，同样按一次关闭 |
| 诊断波浪线 | — | error→红 `#DB5C5C`、warning→黄 `#E8A44A`，用 `decoration.Squiggle` |
| TODO 高亮 | — | `decoration.Background` 半透明黄 + `Bold`（IDEA 的 TODO 文本属性） |
| inlay hints | — | 在 rune 坐标的**基线**上绘制灰色标签，纯 overlay，不参与 shaping（不移位正文） |
| 面包屑 | — | `Editor.SymbolPath()` 返回包含光标的 outline 链，宿主渲染成 `a › b › c` |
| 语义 token | — | `Editor.SemanticTokens()` **只暴露不自动应用**：语法高亮归宿主所有，由宿主合并 |

**测试**：`language_test.go` —— 波浪线/TODO 像素校验、inlay hint 像素校验、Alt+Enter 双动作与单动作、
面包屑路径、Ctrl+Q / Ctrl+P 弹窗与 Esc 关闭。截图 `gvcode-language-diagnostics.png`（可见波浪线 + TODO
高亮 + `name:`/`times:` inlay hint）、`gvcode-language-inlay-hints.png`、`gvcode-language-parameter-info.png`、
`gvcode-language-quick-doc.png`。

**修复记录**：inlay hint 最初把文本布局里的 **Y（基线）** 当成文本框顶部，导致提示整体下移一行并压住下一行
文字；`RuneCoords` 返回的 Y 就是基线，改为直接以此为基线绘制（`paintTextAtBaseline`）后对齐。

### 18. 拖拽选区到任意位置（GoLand 的 move-selection drag）

**实现要点**（`dragtext.go` + `event.go` + `textview.QueryPosClamped`）：
- 按下时若落点在**非空选区内**（`armedTextMove`），记住选区并**保持选中态**——不折叠、不移光标，
  视觉上就是「把这段文字拿起来」。
- 移动超过 `3dp` slop 才算拖动（`updateTextMove`）；未超过则释放时退回「普通点击放置光标」。
- 落点用 `QueryPosClamped`：指针越过行尾时钳到该行末（普通 `QueryPos` 会返回 -1）。
- 视口上下 24dp 边缘带内自动滚动（`autoScrollDuringMove`）+ `op.InvalidateCmd` 持续重绘。
- 拖动中绘制插入点竖线（`paintTextMoveCaret`）。
- 释放时 `GroupOp` → 删除原区间 → 在新位置 `Insert` → `UnGroupOp`，**一次撤销**。
- 与既有交互的边界：Ctrl+Click 加光标、Shift 扩展、Alt 列选择、双击选词都不进入该路径。

**测试**：`dragtext_test.go` —— 真实 press/move/move/release 序列、落点偏移、结果文本、光标位置，
以及「选区内单击仍是普通点击」的回退。截图 `gvcode-drag-selection.png`。

---

## 19–22. 示例工程（flowui/examples/goland）

### 19. 命令行后端（跨仓：`d:\ux\flowui`）

调研结论：`d:\ux\widget` 里**没有** console/terminal/REPL 后端（`logview` 只读、`treetable` 是数据表格）；
flowui 已有 `internal/components/console`（行输入 + 100 条历史 + ANSI SGR + 跟随滚动），但**没有命令语法后端**。
因此照抄 IDEA `commandInterface` 实现了一个：

- `internal/components/commandline/`：GNU/POSIX 单行命令行语言
  - 词法（`command_line.bnf` 的 token 正则逐条移植）：命令名（字母开头字面量）+ 位置参数 + 短选项 `-x` /
    长选项 `--xxx`；引号字面量可含空格；`=` 只能紧贴长选项（`--opt=value` 合法，`--opt = value`/`--opt=` 报错）
  - 校验状态机（`ValidationResultImpl`）：未知命令/未知选项/非法值/多余参数；`-aARG` 与 `-a ARG` 的区别
  - 补全（三个 reference provider）：命令名 → 命令帮助；`-`/`--` → 未用短/长选项名；位置参数 →
    枚举值（priority 1 + 加粗）排在未用选项（priority 0）之前；帮助文本按最长候选对齐
  - 高亮（`CommandLineSyntaxHighlighter`）：字母/数字/短选项/长选项四类 token
  - `DefaultCommandSet()`（go 工具链）与 `GitCommandSet()` 作为示例命令集
- `ui/command_line.go`：门面再导出（沿用 `ui/console.go` 的风格）

### 20. 接入本地 gvcode

- `flowui/go.mod` 增加 `replace github.com/oligo/gvcode => ./patchgio/gvcode`，示例因此用上 fork 的全部特性。
- `internal/components/codeeditor` 增补两个能力（其余不动）：
  - `Options(...gvcode.EditorOption)`：把 fork 的扩展选项透传给编辑器；
  - `OnSelection(func(string))`：转发 `gvcode.SelectEvent` 的选中文本（供「选中片段加入对话」）。
- 示例打开的选项：折叠、粘性行、运行按钮、mock 语言服务、后置补全模板。
- 示例的虚拟 `demo/main.go` 特意加了一个 `// TODO:` 与一次 `addr("0.0.0.0", 8080)` 调用，
  于是截图里能直接看到 **TODO 高亮 + 参数名 inlay hint + 折叠 chevron + 运行按钮**。

### 21. ZCode 风格 AI agent 对话面板（`chat.go`）

- 布局对齐 ZCode：标题栏（Sparkles + 「ZCode」+ 上下文计数 + 清空/收起）→ 消息列表（`ui.List` 虚拟滚动，
  助手侧 `ui.Markdown`、用户侧右对齐气泡 + 附件 chips）→ 上下文 chips → 多行输入（`ui.TextArea`，
  占位符「向 ZCode 提问，使用 @ 添加上下文，使用 / 选择命令或能力」）→ 工具行（`+` / 完全访问 / 模型 /
  思考强度 / ↑ 发送）→ 建议动作（周报总结 / 报错修复 / 接口文档 / 代码审查）。
- 状态：`ChatState{Messages, Input, Attachments, Model, Access, Effort}`；附件 4 类：
  文件 / 代码片段 / 控制台输出 / 变更。
- 对话是**本地 mock**：`mockAgentReply` 会把提示词、模型、权限与每个附件（含首段内容摘录）写进 Markdown 回复，
  以证明上下文确实被带进了对话；接真实 agent 时只替换这一个函数。
- **消息右键菜单＝增删改查**：复制 / 引用到输入框 / 编辑并重发（载入输入框并删除原消息）/ 重新生成 /
  删除；附件 chip 也有右键菜单（移除 / 只保留该上下文）。

### 22. 全表面右键菜单（`contextmenus.go`）

| 表面 | 菜单内容 |
|---|---|
| 工程树 | 将文件/路径加入对话、打开、复制路径、在资源管理器显示、新建、重命名、删除；**go.mod / go.work 追加 Go 模块子菜单** |
| 代码编辑器 | 将选中内容/整个文件加入对话、引用选中内容到输入框、复制/剪切/粘贴、格式化、查找、解释这段代码 |
| 编辑器 tab | 将文件加入对话、复制文件路径、关闭/关闭其他/全部关闭（内建 tab 菜单已关闭，避免双菜单） |
| 控制台（Run/Terminal） | 将最近输出加入对话、将报错行加入对话、复制输出、让 ZCode 修复、清空、重新运行 |
| go.mod / go.work | Go Mod Tidy / Vendor / Download / 同步 Go 模块 / Go Work Use / 依赖图（模块图·包图）/ why —— 真实写入 Run 控制台并输出 ANSI 结果 |

实现方式：树用内建 `ContextMenu + OnContextMenu`（右键先写 `Model.ContextTarget`，菜单动作通过 `send`
读最新模型）；编辑器/控制台/对话用 `ui.ContextMenu(key, trigger, content)` 包裹，不改动底层控件。

**测试**：`examples/goland/render_check_test.go` 新增 `goland-chat`（一轮带上下文问答）与
`goland-go-mod`（go 模块命令 + 加入对话）两个视图，双主题出图：
`goland-chat-{light,dark}.png`、`goland-go-mod-{light,dark}.png`。

---

## 23–24. 注释语法与脚本运行

### 23. 按文件类型的注释（`comment.go`）

**对照 IDEA**：`com.intellij.lang.Commenter` + `CommentByLineCommentAction` / `CommentByBlockCommentAction`

- **语法表**：`commentSyntaxes` 以「语言 id 或扩展名（小写、无点）」为键，覆盖 C 系/哈希系/Windows 脚本系/
  SQL·Lua·Haskell/分号系/百分号系/感叹号系/标记语言/纯文本等 150+ 条目，例如：
  `go → //…/* */`、`python/sh/yaml/dockerfile → #`、**`bat/cmd → REM`**、`ps1 → # / <# #>`、
  `sql → --…/* */`、`lua → --…--[[ ]]`、`html/xml/markdown → <!-- -->`（无行注释）、
  `pascal → //…{ }`、`text/csv/json → 无注释`。
  解析入口：`CommentSyntaxForLanguage("bat")`、`CommentSyntaxForPath("demo/scripts/build.bat")`
  （后者还能识别 `Makefile`/`Dockerfile`/`.gitignore` 这类无扩展名文件）。
- **行注释**（Ctrl+/，`ToggleLineComment`）：
  - 取选区覆盖的行；选区正好停在下一行行首时**不含**那一行（IDEA 行为）；
  - 只要有一行没被注释 → 全部加注释，否则全部去注释（`CommentByLineCommentAction` 的判定）；
  - 标记插在**首个非空白字符**处，保留缩进（GoLand 对 Go 的行为，也保证脚本语义不变）；
  - 空行只插裸标记（不留尾随空格）；
  - 去注释时同时吃掉标记后的那个空格，所以 `// x` → `x`；
  - 标记以字母结尾时（`REM`）要求后一个字符不是标识符字符，避免把 `REMOVE` 当成 `REM OVE`；
  - 编辑从文档尾部往前应用，并同步修正光标（插入时把光标推到标记之后，删除时留在原位）；
  - 整段被注释的行在操作后保持选中，便于再次 Ctrl+/ 撤销。
- **块注释**（Ctrl+Shift+/，`ToggleBlockComment`）：选区两端已是 `BlockStart/BlockEnd` 则脱掉，
  否则在选区两端插入（光标/选区随之调整）；语言没有块注释语法时返回 false。
- **接线**：`WithCommentLanguage(lang)` 从表里选语法；`codeeditor` 把 `w.lang` 透传进来，
  所以同一份代码里 `.go` 用 `//`、`.bat` 用 `REM`、`.ps1` 用 `#`。
  命令注册在 `/`（Ctrl）与 `?`（Ctrl+Shift，多数键盘布局上报的是 `?`）两个名字上。

**测试**：`comment_test.go`（11 项）—— 语法表逐条校验（含 bat/cmd 的 REM）、按路径解析（大小写/无扩展名/
未知扩展名）、Go 的加注释·去注释往返、空行、批处理的 `REM` 与 `REMOVE` 边界、混合选区只加不删、
折叠光标的位置、选区停在行首的边界、无注释语法时是 no-op、块注释包裹/脱掉、以及**真实 Ctrl+/ 与
Ctrl+Shift+/ 按键**（走 input router，覆盖命令注册本身）。

### 24. 脚本文件右键运行（`flowui/examples/goland/scripts.go`）

- `isScriptFile` 识别 `.bat` / `.cmd` / `.ps1`；工程树、编辑器、编辑器 tab 三个右键菜单都把
  **「运行 <文件名>（Shift+F10）」放在第一项**，并附「在 Terminal 中运行」。
- 命令行走各自的解释器：`cmd /c demo\scripts\build.bat`（Windows 路径分隔符）、
  `powershell -NoProfile -ExecutionPolicy Bypass -File …`。
- **磁盘上真实存在的脚本会被真实执行**（`exec.Command(...).CombinedOutput()`），输出按 ANSI 解析后
  写进 Run 控制台，失败时把错误以红色写入并弹警告 toast；
  示例工程的虚拟脚本没有磁盘实体，则回放一段**确定**的演示输出，保证演示与渲染测试可复现。
- 虚拟工程新增 `demo/scripts/{build.bat, clean.cmd, deploy.ps1}`，编辑器按其文件类型高亮
  （bat/cmd → chroma `batch`，ps1 → `powershell`），Ctrl+/ 分别用 `REM` / `#`。

**测试/截图**：渲染测试新增 `goland-script-run` 视图（运行 build.bat 并打开它），双主题出图
`goland-script-run-{light,dark}.png`：可见批处理的 `REM` 注释高亮、Run 控制台里的命令回显与
`[build] …` 输出、以及状态栏/ toast。

> 附：`flowui/go.mod` 因接入本地 fork 需要把 `github.com/rdleal/intervalst` 从 v1.4.1 提升到 v1.5.0
> （fork 的依赖版本），并保留 `replace github.com/oligo/gvcode => ./patchgio/gvcode`。

---

## 25. markdown 表格自动对齐 / 格式化

**对照 IDEA**（`plugins/markdown`，注意区分两套机制）：

| IDEA 类 | 作用 |
|---|---|
| `editor/tables/TableFormattingUtils.kt` | 逐列重排的驱动（`reformatAllColumns` / `reformatColumnOnChange`） |
| `editor/tables/TableModificationUtils.kt` | 单元格 / 分隔行的填充公式（`buildRealignedCellContent`、`buildSeparatorCellContent`、`getCellAlignment`） |
| `editor/tables/TableCharacterWidthUtils.kt` | 显示宽度（全角 2、零宽 0、按字素簇只计簇首） |
| `lang/formatter/TablePostFormatProcessor.kt` | Ctrl+Alt+L 时对所有表格重排 |
| `.../ui/alignment/MarkdownTableAlignmentController.kt` | **另一种**：只插透明 inlay 让竖线在屏幕上对齐，不改文本（本渲染器用列宽自适应达到同样效果，故未移植） |

**实现要点**（`internal/components/markdown/format.go`）：

- **列宽**：`W = max_i(displayWidth(trim(单元格)) + 2)`，下限 1（IDEA `calculateContentsMaxWidth`）。
- **单元格填充**：`pad = W - displayWidth(内容)`；
  左/默认 `" "+内容+" "×(pad-1)`、右 `" "×(pad-1)+内容+" "`、居中 `" "×(pad/2)+内容+" "×(pad-pad/2)`。
- **分隔行**：长度等于列宽，按对齐冒号生成 —— 无冒号 `-`×W、左 `:`+`-`×(W-1)、右 `-`×(W-1)+`:`、
  居中 `:`+`-`×(W-2)+`:`（W<3 退化为 `:-:`）。
- **对齐判定**（`getCellAlignment`）：无冒号→NONE、左右都有冒号→CENTER、冒号前全空格→LEFT、否则 RIGHT。
- **显示宽度**：半角 1 / 全角 2 / 控制字符与组合符号 0；`⚠️`(变体选择符) = 2、`👍🏿`(肤色修饰符) = 2、
  `🇺🇸`(两个区域指示符＝一个字素簇) = 2 —— 与 IDEA 的 `TableCharacterWidthUtils` 一致。
- **样式**：`TableAligned`（默认，按列宽对齐）、`TableCompact`（两侧各 1 空格，分隔行固定 ` --- `）、
  `TableTight`（无空格，分隔行固定 `---`）。
- **安全边界**（都有测试）：围栏代码块 ``` / ~~~ 内的「表格」不动；引用行 `> | a |` 不动；
  列数与表头不一致的残缺表格保守跳过（IDEA 在那种输入上会走到可能越界的路径）；
  `\|` 视为单元格内容，裸 `|` 即使在行内代码里也按 GFM 切列（IDEA 为此有
  `MarkdownTablePipeInCodeSpanInspection` 提醒加转义）；CRLF 行尾原样保留；
  格式化幂等（`IsTableFormatted` 对自身输出恒为真）。

**接线**：
- `ui.FormatMarkdown(source)` / `ui.FormatMarkdownTables(source, options)` / `ui.IsMarkdownTableFormatted(...)`
  与 `ui.MarkdownTableAligned/Compact/Tight`、`ui.DefaultMarkdownFormatOptions()`（门面再导出）。
- 示例里「格式化代码」菜单对 `.md` 文件**真实生效**：`formatActiveFile` 把编辑器草稿里的表格重排后写回
  `FileDrafts`，编辑器的受控同步会把它推进编辑器 —— 相当于 GoLand 在 markdown 上按 Reformat Code。
  虚拟工程新增 `demo/docs/guide.md`（故意写成未对齐、且含中文与全角逗号的表格，另有一个围栏代码块里的
  表格用于证明"代码块不动"）。

**测试/截图**：`format_test.go` 15 项（基础对齐、列宽扩展、三种对齐冒号、CJK 宽度、emoji/国旗宽度、
转义管道、代码跨度里的裸管道、幂等、只改表格不动正文、跳过围栏代码块、跳过残缺表格、跳过引用表格、
无边框行、compact/tight 样式、CRLF、多表格、真实 guide.md 表格、分隔行对齐解析）。
渲染测试新增 `goland-markdown-format` 视图 → `goland-markdown-format-{light,dark}.png`。

> 说明：IDEA 的 markdown 格式化器还包含「块间距」（标题/列表/代码围栏/表格周围空行、列表标记后 1 空格、
> `>` 后 1 空格等，`MarkdownSpacingBuilder` + `MarkdownFormattingBlock`）；本组件是渲染器，
> 这些空行/缩进由渲染层吸收，因此只移植了**表格内容重排**（`TablePostFormatProcessor` 的职责）。

---

## 26. markdown 表格 inlay 工具条（最容易用错的那一步）

**对照 IDEA**：`editor/tables/ui/MarkdownTableInlayProvider.kt` 与
`ui/presentation/{HorizontalBarPresentation,VerticalBarPresentation}.kt`

- **几何**：表头上方画「列条」（`barSize=6` + `padding=2`），每行左侧画「行把手」；条带默认 **50% 灰**，
  hover 变蓝。表头行也要留出上方空间（`reserveTop`），所以表格整体下移，不能浮在正文上。
- **单击才弹工具条**：点列条弹**列工具条**（8 个动作 + 关闭），点行把手弹**行工具条**（5 个动作 + 关闭）。
  这 9/6 个按钮的顺序、图标、启用条件都照抄 IDEA 的 `actions/column`、`actions/row` 清单：
  左移列 / 右移列 / 左侧插入列 / 右侧插入列 / 左对齐 / 居中 / 右对齐 / 删除列 / ✕；
  上移行 / 下移行 / 上方插入行 / 下方插入行 / 删除行 / ✕（最后一列不可删、表头行不能删）。
- **动作改写源码**：`tableops.go` 把源码解析成 `sourceTable{cols, aligns, header, rows}`，动作改结构后
  重新生成整段文本。**有意的差异**：IDEA 的结构动作不重排列宽（只改单元格内容），本实现每个动作后
  整表重排，等价于 `TablePostFormatProcessor` —— 因为我们的预览是即时重排的渲染器。
- **图标自绘**：`tableicons.go` 用归一化折线/矩形（0..100）画 13 个图标，不依赖上层图标组件，
  这样 markdown 组件保持自包含（不 import `ui`）。

**踩坑（Gio 专属）**：绘制阶段与测量阶段必须拿到**同一套** `tableToolsState` + `tableButtons`，
否则工具条矩形与预留高度和命中测试错位——现象只是「点了没反应」，必须对比两阶段的几何才能定位。
另外 `hoverColumn` 的零值就是第 0 列，首次进入要用 `ready` 显式置 -1，否则第一帧就高亮第一列。

**测试/截图**：`tabletools_test.go`、`tableops_test.go`（打开工具条、点按钮改写源码、关闭、默认关闭、
渲染出图 `markdown-table-toolbar.png`）；`tableops_test.go` 覆盖插入/删除/移动列行、对齐、幂等、
不动围栏代码块、越界 no-op、三种 `TableStyle`。

---

## 27. markdown 双视图（源码 + 预览）

**对照 IDEA**：`platform/.../TextEditorWithPreview.kt`、`MarkdownSplitEditorProvider.kt`、
`MarkdownEditorWithPreview.java`、`ChangePreviewLayoutAction.kt`

- **默认左右并排**：源码在左（完整 `codeeditor`/gvcode，含折叠、粘性行、注释语法）、预览在右
  （`markdown` 组件，含表格工具条），比例 0.5，预览**随输入实时刷新**。
- **顶栏三个布局按钮**：Editor / Editor and Preview / Preview —— 用**现成控件**
  `internal/components/togglebutton` + `internal/components/toolbar` 组装（不再手绘 Clickable），
  hover/press/selected 与全应用一致；按钮组靠右。
- **可拖分割线**：6dp 命中区、超过 slop 才拖动、`clampRatio` 限 10%..90%。
- **双向回灌**：预览里的表格工具条改写的源码经 `OnChange` 回到宿主，宿主的受控更新再推回源码编辑器。
- **两个 Gio 坑（都是真实 bug，已修）**：
  1. `layout.Flexed` 的子节点**必须返回 flex 分给它的尺寸**；返回零尺寸时 Flex 不推进偏移，
     右侧按钮组会跑到最左边。空白项要返回 `Dimensions{Size: gtx.Constraints.Min}`。
  2. 父级若用 `layout.Exact`（Min == Max）传约束，会把最小高度传进编辑器的文字布局，正文画不出来；
     `Layout` 开头把 `gtx.Constraints.Min` 归零即可（容器本来就是"填满可用空间"）。

**测试/截图**：`markdowneditor_test.go`（8 项：默认左右并排且预览在右、仅源码/仅预览、预览随源码变化、
比例覆盖与钳制、竖向堆叠）。**注意**：共享的 `testutil.RenderWidget` 脚手架没有带字体的 Material，
gvcode 正文只能靠带字体的 `examples/goland` 渲染测试出图 —— 所以源码侧的证据是
`goland-markdown-split-{light,dark}.png`，组件级测试断言预览侧像素与分栏几何。

---

## 28–31. 导航（实现 / 用法 / 接口方法）、lens、重命名、书签断点、列选择模式

### 28. 实现 / 用法 / 接口方法导航

**对照 IDEA**：`GotoImplementationHandler`（Ctrl+Alt+B）、`FindUsagesHandler`（Alt+F7）、
`TypeHierarchyBrowser`（Ctrl+H）、`ShowIntentionActions` 的**渲染侧**约定

- **LSP 边界扩展**（`lsp/protocol.go`）：`Location`、`HierarchyNode{Name,Detail,Kind,Location,Supers,Subs}`、
  `CodeLens`，以及 6 个新方法 `Implementations / References / TypeHierarchy / CodeLenses / Rename / Formatting`。
  位置语义仍是 0-based 半开区间，接真 LSP 只替换 `MockServer`。
- **mock 侧**（`lsp/mock.go`）：给 `decl` 补了 `receiver`（方法接收者）、`ifaceMethods`/`ifaceEmbeds`
  （接口方法集与嵌入接口）、`bodyStart/bodyEnd`（接口体范围），于是：
  - `Implementations`：光标在**接口名**上 → 找出方法集覆盖该接口的所有接收者类型；
    光标在**接口体内的某个方法签名**上（它本身不是声明，`byName` 查不到）→ 返回所有同名方法。
  - `References`：同一标识符的全部出现，`includeDeclaration=false` 时剔除声明本身（用 `nameStart` 判断，
    所以同名的字段/参数仍算用法）。
  - `TypeHierarchy`：接口 → 子类型；结构体 → 它实现的接口（超类型）；方法 → 声明它的接口（超）+
    其它实现（子）。双向都能走。
- **编辑器 API**（`gvcode/navigation.go`）：`ImplementationsAt / ReferencesAt / TypeHierarchyAt /
  ShowUsages / ShowImplementations / ShowTypeHierarchy / SymbolAtCaret / GoToPosition`，
  并新增 `applyTextEdits`（**唯一**的编辑落地路径，被 Alt+Enter、重命名、格式化共用，降序应用保证偏移有效）。
- **渲染归宿主**：`ShowXxx` 不弹窗，而是产出 `NavigationEvent{Kind, Title, Items, Hierarchy}`；
  示例把它渲染成底部 **Find 工具窗**（b\* 符号名 + 灰字源码行 + `文件:行号`），点行 → `GoToPosition` 跳转；
  层次用缩进的「父类型/超类型」「子类型/实现」两组。快捷键与菜单都走同一条路。
- **自动用法高亮**（`WithUsageHighlighting`）：光标所在符号的所有用法加半透明底色；它**替代**内置的
  按字匹配 word highlighter（后者仍在默认开启，两者不会重复叠加）。`UsageHighlights()` 暴露当前范围供断言。

**测试/截图**：`lsp/mock_test.go` 新增 10 项（接口实现、接口方法实现、纯函数无实现、引用的声明开关、
双向层次、方法层次、重命名全部引用、空名 no-op、code lens 计数、格式化展开制表符）；
`navigation_test.go` 覆盖事件内容、重命名、格式化、lens 像素、用法高亮、书签/断点、列选择模式。

### 29. code lens、重命名、格式化动作

- **code lens**：函数标 `N usages`、接口标 `N implementations`，绘制在声明行**右对齐**（不压住代码），
  命令名与 IDEA 一致（`find-usages` / `goto-implementation`）。
- **重命名**（Shift+F6）：`RenameSymbol(newName)` 走 `lsp.Rename` 的全部引用重写；编辑器自己弹不出输入框，
  所以先发 `RenameEvent{Symbol, Line}`，宿主（示例）在编辑器上方显示内联输入框。
- **格式化动作**（Ctrl+Alt+L）：`FormatDocument()` 应用 `lsp.Formatting` 的编辑（mock 版保守：行首制表符
  展开成 tab stop、去行尾空白），幂等。

### 30. 书签与断点 gutter

- `gvcode/marks.go`：按 **document line** 记账（折叠不移位）。API：`ToggleBookmark`/`Bookmarks`/
  `NextBookmark`/`PreviousBookmark`/`GoToNextBookmark`/`GoToPreviousBookmark`、`ToggleBreakpoint`/
  `Breakpoints`/`HasBreakpoint`。
- `gutter/providers/marks.go`：一个 `markProvider` 同构地画两种列，颜色/形状取自 IntelliJ：
  断点是红点（`#E05555` + 深红描边）、书签是蓝灰缎带（带 V 形缺口）。
- **列序**：provider 按 priority **降序**从左到右 → 断点(110) 在行号(100) 左边，书签(99) 在行号右边，
  与 IDEA 的 gutter 顺序一致。列条可点击切换（`InteractiveGutter.HandleClick`），回调直接改编辑器状态。

### 31. 列选择模式（Alt+Shift+Insert）

IDEA 的 Edit > Column Selection Mode：开启后**普通拖拽**即矩形选择（不必按 Alt）。
实现只在 `event.go` 的按下分支加一个条件：`evt.Modifiers.Contain(key.ModAlt) || e.columnSelectionMode`，
于是复用既有的列选择状态机（像素级列选、Ctrl+方向键、Shift 克隆、ESC 收起）。
`ColumnSelectionModeEvent` 回灌宿主以同步菜单勾选；`ui.CodeEditorCommandColumnSelection` 供菜单反向驱动。

---

## 32. 语义 token 与 chroma 合并

**对照 IDEA**：`SemanticHighlightingPass` / `TextAttributesKey`（语义高亮修正词法高亮的猜测）

`gvcode/semantic.go` 提供 `SemanticScope(type)`（LSP 语义类型 → chroma scope：
`SemanticFunction→NameFunction`、`SemanticInterface→KeywordType`、`SemanticVariable→Name` …）与
`MergeSemanticTokens(base, semantic, offsetAt)`：**按边界切分**词法 token，每个区间取最内层的语义 scope
（没被语义覆盖的区间保留词法 scope），再合并相邻同 scope 区间。宿主侧的接法：

- `codeeditor` 在 `Editor.Layout` **之后**合并（那时本次文本的语义分析才存在），变了就 `op.InvalidateCmd` 再画一帧；
  用 `Editor.SemanticRevision()` 做键，保证每个分析只合并一次。
- 顺手把 `codeeditor` 的 `Editor.Update` 循环补齐：`ChangeEvent`/`SelectEvent` 之外的编辑器事件
  经 `OnEditorEvent` 交给宿主（这就是导航/重命名/列选择模式能到 UI 的通道）。
- 另加 `ui.CodeEditorCommand`（模型携带的声明式命令：`Seq + Kind + Text + Line/Column/Enabled`），
  让宿主不需要持有 `gvcode.Editor` 也能触发不可用文本表达的动作（跳转、重命名、查用法、切换 gutter 标记）。

**测试**：`navigation_test.go` 的 `TestMergeSemanticTokens*`（词法 token 被切成 `Keyword`/`NameFunction`
边界、无语义时原样返回）+ `TestSemanticScopeCoversEveryType`。

---

## 33. 虚拟工程与菜单的可用性补齐

- **虚拟文件系统覆盖全部文件类型**：`demo` 下按目录摆了 Go / md / 各种配置（yaml,yml,json,toml,ini,
  properties,.env,.editorconfig,.gitignore）/ SQL / web（html,js,ts,tsx,css,scss,vue）/ 构建
  （Dockerfile,Makefile,CMakeLists.txt,build.gradle,main.tf）/ 脚本（bat,cmd,ps1,sh,py）/
  多语言样例（rs,java,kt,c,h,cpp,rb,php,lua,proto,graphql）/ 杂项（csv,txt,svg,xml,LICENSE），
  并补齐 `fileLanguage` 与 `fileIcon` 映射。**目的**：语法的注释表、语法高亮、文件图标、右键菜单
  都能在各个文件类型上被真实走一遍（`contextmenus_test.go` 会遍历 `fileContents()` 断言每种文件
  都能解析出语言与注释语法）。`demo/main.go` 加长到 163 行（struct + interface + 多个函数 + `//region`
  + 注释掉的旧块），让折叠、粘性行、实现/覆写图标、code lens、层次视图都有内容。
- **右键菜单补齐**（对齐截图里的 GoLand 菜单）：编辑器菜单含 显示上下文操作 / 复制粘贴特殊 / **列选择模式**
  （勾选项，Alt+Shift+Insert）/ 查找用法 / 转到（声明、实现、类型声明、父方法）/ 折叠 / 重命名 / 重构 /
  生成 / 运行 'go build' / 调试 / 更多运行调试 / 打开于 / 本地历史记录 / Go 工具 / 与剪贴板比较 / 图表；
  其中「查找用法、转到>实现/类型声明/父方法、重命名、列选择模式、格式化」是**真实动作**（走
  `ui.CodeEditorCommand` / `Renaming` 状态），其余为演示反馈。
- **go.work 的 go work 子命令全量**：`go help work` 的 `init / use / sync / edit / vendor` 五项
  全部进菜单（go.mod 保持自己的一组 `go mod` 命令），每条都真实写进 Run 控制台（彩色命令行 + ANSI 输出）。
- **面板**：底部工具窗新增 **Find** tab 渲染导航结果（含层次视图）。

**测试**：`contextmenus_test.go`（13 项）—— 脚本文件的运行项在最前且真的驱动 Run/Terminal 控制台、
go.work 含全部 go work 子命令而 go.mod 不含、每条 go work 命令都写进 Run、注释语法按文件类型解析
（bat/cmd→REM、ps1/sh/py→#、sql→--、go→//、css 无行注释）、列选择模式菜单双向同步、
Find Usages 菜单发出编辑器命令、导航事件打开 Find 工具窗、每种虚拟文件都能解析出语言。

---

## IDEA 插件目录调研结论（可复刻的机制）

`intellij-community-master/plugins` 下有 115+ 个插件。与编辑器相关、值得复刻的机制（按价值排序，
**状态列对应顶部「待办清单」的 T 编号**）：

| # | 机制 | 状态 |
|---|---|---|
| 1 | **TextMate 语法引擎**（`plugins/textmate`）：一套 grammar 引擎高亮几十种语言；内置 `go.tmLanguage.json`。我们现在用 chroma | ❌ 未做（→ T10） |
| 2 | **统一「配置语言 + JSON Schema」引擎**（`json/backend` + `plugins/yaml` + `plugins/toml`）：校验/补全/悬停/跳转/注入一套代码三处复用 | ❌ 未做（→ T11） |
| 3 | **终端命令块模型 + Shell 集成（OSC 1341）**（`plugins/terminal`）：给输出建立「命令边界 + 退出码 + 工作目录」结构，才有复制块/跳转输出/错误导航 | ❌ 未做（→ T5）。注意 #19 做的是 IDEA `commandInterface` 的**命令行语言**后端，不是这个 |
| 4 | **增量文本缓冲 + 最小编辑同步**（`TerminalOutputModelController`）：ANSI 追加只做局部替换以保住 range marker（高亮/超链接不闪） | ❌ 未做（→ T14） |
| 5 | **ML 补全重排序**（`plugins/completion-ml-ranking`，`CompletionFinalSorter` 模式）：只在最后一步重排 top-K、按元素身份缓存分数 | ❌ 未做（→ T19） |
| 6 | **Minimap 分层渲染管线**（`plugins/minimap`）：token/选区/诊断/折叠/断点/光标拆成独立 layer | ❌ 未做（→ T13；`minimap` 目前只存在于 nodegraph 组件） |
| 7 | **Gutter 变更标记 + blame**（`plugins/git4idea`）：与 base content 做行级 diff，画双色 gutter | ⚠️ 部分：`VCSDiffProvider` 已存在（`gutter/providers/diff.go`）但没接进 flowui 编辑器；blame 无（→ T4、T18） |
| 8 | **Markdown 分屏预览 + 实时协调 + 表格 inlay**（`plugins/markdown`） | ✅ 已做（#26 表格 inlay 工具条、#27 双视图；缺滚动同步 → T9） |
| 9 | **外部工具即服务**（`plugins/sh` 的 shellcheck/shfmt、`plugins/editorconfig`）：格式化/静态检查委托 CLI | ❌ 未做（→ T17） |
| 10 | **EditorConfig 分层配置 + 设置预览编辑器**（`plugins/editorconfig`） | ❌ 未做（→ T12；示例里的 `.editorconfig` 只是一个假文件） |

---

## 仍未复刻（按能力归类）

> **权威待办源在文件顶部的「待办清单」**（带 T 编号与验收方式）。这里只按能力归类，方便对照 IDEA。

1. **无真实语言模型 / 无真实 LSP**：折叠、postfix 适用性、补全匹配、实现/用法/层次仍是语法近似
   （`MockServer` 没有类型系统，接口实现靠"方法集覆盖"判定）；接真 LSP 只需替换 `MockServer`（→ T16）。
2. **结构视图（Structure tool window）**：只有 `Symbols` / `SymbolPath` 供面包屑与 code lens 用，
   还没有按层级展开的树面板（`DocumentSymbols` 的 `Children` 也未由 mock 填充）（→ T1）。
3. **拼写检查（SpellCheckingInspection）** 与 **code lens 的点击行为**（本实现只画不响应点击）未做
   （→ T8、T2）。
4. **补全的其余排序因子**：统计热度（`StatisticsWeigher`）、邻近度（`proximity`）、分组（`grouping`）、
   类型期望（`PreferExpected`）、实时模板占位符镜像（`$EXPR$`）（→ T6、T19）。
5. **粘贴/拖拽的缩进后处理**（`CopyPastePostProcessor`）与块级注释的智能处理未按 IDEA 全量对齐（→ T7）。
6. **书签/断点没有持久化**（IDEA 写 workspace，`BookmarkManager` 还支持助记符与描述）（→ T3）。
7. **示例工程仍是虚拟文件系统**：不读写磁盘、不跑真实进程，控制台与 go 模块命令都是 mock 输出
   （脚本文件走的是"磁盘上有实体就真跑、否则回放演示输出"）（→ T15）。
8. **对话面板未接真实模型/工具调用**（`mockAgentReply` 是唯一需要替换的入口）（→ T20）。
9. **markdown 双视图未做滚动同步**（IDEA 也是可关的设置项），且预览是整篇一次性布局（→ T9）。

---

## 1. gutter 列模型

**IDEA 源码**：`EditorGutterComponentImpl`、各 `GutterIconRenderer` 的排序

**实现要点**：provider 按 `Priority()` **降序**从左到右渲染，因此列顺序为

```
行号(100) → 实现/覆写图标(97) → 运行按钮(95) → 折叠 chevron(90) → 代码
```

**测试**：`TestGutterColumnOrder` 断言行号列 < 运行按钮列 < 折叠列。

---

## 2. 代码折叠

**IDEA 源码**：`platform/lang-impl/.../FoldingUpdate`、`FoldingUtil.adjustOffset`、Go 语言 `FoldingBuilder`

**实现要点**：
- 词法扫描识别函数/方法、类型、import/const/var 声明组、块注释、`//region`
- 嵌套块、注释与字符串内的括号不计入
- 折叠区间 `EndLine = 收尾行 - 1`（收尾的 `}` 行保持可见，与 GoLand 一致）

**测试**：`internal/folding/folding_test.go`。

---

## 3. 折叠 outline（展开区间）

**IDEA 源码**：`EditorGutterComponentImpl.paintFoldingLines`

**实现要点**：对每个**展开**的折叠区间，从首行中心到闭合行中心画一条**实线**（不是虚线）；折叠时该线段消失；区间滚出视口时裁到视口内。颜色取 IDEA 暗色主题的折叠线灰 `#6F737A`（`foldGuideAlpha = 0x60`）。

**测试**：`TestGutterFoldGuideLineSpansAnExpandedRegion` → `gvcode-gutter-fold-guide.png`。

---

## 4. 折叠/展开图标

**IDEA 源码**：`platform/icons/src/expui/gutter/unfold.svg`、`fold.svg`

**实现要点**：逐点转写 SVG 路径，用 `internal/stroke`（RoundCap + RoundJoin）描边，chevron 9×9：

- 展开（`unfold`）：`M3 8L6.5 4.5L3 1`
- 折叠（`fold`）：`M8 2.75L4.5 6.25L1 2.75`

**测试**：`TestGutterFoldButtonClickCollapses` —— 用真实 pointer 点击 chevron → `gvcode-gutter-foldbutton-before/collapsed.png`。

---

## 5. 逻辑行号

**IDEA 源码**：行号按 **document line** 而非可见序号绘制

**实现要点**：`internal/layout.Paragraph` 增加 `LogicalIndex`（文档行号）与 `Index`（可见序号）；折叠隐藏行后行号不重排。

**测试**：`TestGutterLineNumbersAreLogical` → `gvcode-gutter-logical-linenumbers.png`。

---

## 6. 光标不可进入折叠区

**IDEA 源码**：`FoldingUtil.adjustOffset`、`FoldingModel` 的 `getVisibleRange`

**实现要点**：
- 折叠行不生成 caret 位置（`text_layout.go`：`if tl.lineHidden(idx) { continue }`）
- `hiddenSpans`（合并隐藏 rune 区间）+ `SkipHiddenSpan(offset, forward)`：一次方向键跳整个折叠

**测试**：`TestGutterCaretCannotEnterCollapsedFold`。

---

## 7. 运行按钮

**IDEA 源码**：`platform/icons/src/expui/run/run.svg`

**实现要点**：转写 run.svg 的三次贝塞尔（填充 + 描边两遍），暗色主题取色：
- main：描边 `#57965C` / 填充 `#253627`
- test：描边 `#2196F3` / 填充 `#162B3D`

按 **document line** 定位（折叠后不漂移）；点击产出 `gutter.RunButtonEvent` → 编辑器包成 `RunButtonEventWrapper`。

**测试**：`TestGutterRunButtonRenders`、`TestGutterRunButtonClickEmitsEvent`。

---

## 8. 粘性行（sticky lines）

**IDEA 源码**：`StickyLinesModel` / `EditorStickyLinesPainter`

**实现要点**：
- band 内容**只由滚动位置决定**（`top = ctx.Viewport.Min.Y`），禁止 band 高度自我反馈（否则点击后逐帧振荡）
- 点击走编辑器**唯一指针路径**（`StickyLineAt`）：band 内导航到声明行，band 外仍是普通光标点击
- 一帧只读一次文档（`buffer.Revision()` 判废 + `feedGutterProviders()`）

**测试**：`TestGutterStickyLineClickNavigatesSmoothly`、`TestGutterStickyClickBelowTheBandBelongsToTheText`、`TestGutterDocumentIsReadOncePerChange`。

---

## 9. 实现/覆写 gutter 图标

**IDEA 源码**：`platform/icons/src/expui/gutter/overridingMethod_dark.svg`、`implementingMethod_dark.svg`

**实现要点**：`MethodIconProvider`（`Priority() = 97`）绘制 14×14 图标：
- 蓝 `#548AF7` 圆环 + "O"（Overrides/Overridden）
- 绿 `#57965C` 圆环 + "I"（Implements/Implemented）
- 红 `#DB5C5C` 上箭头（覆写/实现）/ 下箭头（被覆写/被实现）

按 **document line** 喂入（`Editor.SetMethodIcons` / `MarkMethodIcon`），点击产出 `MethodIconEventWrapper`。

**测试**（`method_icon_test.go`）：
- `TestMethodIconRendersInheritanceMarkers` → 颜色落点校验 + `gvcode-method-icons.png`
- `TestMethodIconClickEmitsEvent` → 真实点击 → `gvcode-method-icons-clicked.png`
- `TestMethodIconLandsOnTheDocumentLineAfterFolding` → 折叠后图标跟随文档行 → `gvcode-method-icons-folded.png`

---

## 10. 回车处理链 + 智能按键

**IDEA 源码**：
- `platform/lang-impl/.../codeInsight/editorActions/enter/{EnterHandlerDelegate,EnterInLineCommentHandler,EnterAfterUnmatchedBraceHandler,EnterInBlockCommentHandler}.java`
- `CompleteStatementAction` / `BaseSmartEnterProcessor`

**实现要点**：
- `EnterHandlerDelegate` 链，`EnterResult{Continue, Default, DefaultForceIndent, DefaultSkipIndent, Stop}`；内置顺序与 IDEA 扩展注册顺序一致
- 行注释中间按 Enter 才拆行（行尾不续注释）
- `{` 后 Enter 用 `unmatchedLBraces` 走**全文件**判定是否补 `}`
- 未闭合块注释补 `*/`
- Ctrl+Shift+Enter → `completeStatement()`（`unclosedBrackets` 栈扫描，跳过字符串/raw/注释）
- Tab 跳出空括号对 / 自动插入的括号对；Backspace 整删空括号对

**测试**（`enter_test.go`，9 项）：`TestEnterAfterUnmatchedBraceInsertsTheCloser`（`gvcode-enter-brace-expansion.png`）、`TestCompleteStatementClosesTheBrackets`（`gvcode-enter-complete-statement.png`）等。

---

## 11. 多光标

**IDEA 源码**：`platform/lang-impl/.../openapi/editor/actions/SelectNextOccurrenceAction.java`、`EditorMultiCaretMode`

**实现要点**：
- 主光标留在 TextView（index 0），额外光标在 `multiCaret.carets`
- 编辑按 **降序** apply（不破坏高位偏移）→ 再升序重算位置
- Alt+J 首次只选中词并返回（对齐 `SelectNextOccurrenceAction.doExecute` 的 `hasSelection=false` 分支）
- Ctrl+Alt+Shift+J 全选出现；Ctrl+Click 加光标；Esc 收起

**测试**（`multicaret_test.go`，7 项）：含 `TestMultiCaretPaintsEveryCaret`（`gvcode-multicaret-carets.png`）。

---

## 12. 补全匹配：CamelHump / Fuzzy

**IDEA 源码**：
- `platform/util/text-matching/src/com/intellij/psi/codeStyle/MinusculeMatcherImpl.kt`
- `.../MinusculeMatcher.kt`（`calculateHumpedMatchingScore`、`evaluateCaseMatching`）
- `platform/util/base/src/com/intellij/util/text/NameUtilCore.kt`（`isWordStart` / `nextWord`）
- `platform/util/text-matching/.../MatchingMode.kt`
- `platform/analysis-impl/.../completion/impl/CamelHumpMatcher.java`

**实现要点**（`addons/completion/matcher.go`）：
- `MatchingMode{IgnoreCase, FirstLetter, MatchCase}`；默认 `FIRST_LETTER`（`CodeInsightSettings.COMPLETION_CASE_SENSITIVE` 默认值）
- 通配符 `' '`/`'*'`；词分隔符 空白/`_`/`-`/`:`/`+`/`.`
- `containsMeaningfulInOrder` O(n) 预筛 + 回溯式 fragment 搜索（支持跨词驼峰，如 `PDM` → `PsiDocumentManager`）
- 评分严格照搬 `calculateHumpedMatchingScore`：
  `(wordStart?1000:0) + matchingCase - len(fragments) - skippedHumps*10 + (afterSeparator?0:2) + (startMatch?1:0) + (finalMatch?1:0)`
- `evaluateCaseMatching` 权重表：`150`（首字符大小写吻合）/ `50`（大写命中）/ `1` / `0` / `-1` / `-10`

**测试**：`matcher_test.go`（驼峰、分隔符、通配、FirstLetter/MatchCase、评分、`isWordStart`）。

---

## 13. 补全相关性排序

**IDEA 源码**：`BaseCompletionService.defaultSorter` 的分类器链
（`PreferStartMatching` → `RealPrefixMatchingWeigher` → … → `LiftShorterItemsClassifier`）

**实现要点**（`addons/completion/rank.go`）：
- 链：`middleMatching`（起点匹配优先）→ `priority`（`SortText`）→ `prefix`（`-max(matchingDegree)`，越大越前）→ `liftShorter`（短且为前缀者优先）
- `FilterAndRank(pattern, candidates, opts)` + `DefaultFilterAndRank(...)`，completor 可直接用作 `FilterAndRank`
- 匹配文本取 LSP `FilterText`，缺省回退 `Label`

**测试**：`rank_test.go`（起点匹配优先、非匹配淘汰、驼峰、SortText、liftShorter、FilterText）。

---

## 14. `.` 自动弹出 + middle matching

**IDEA 源码**：
- `platform/lang-impl/.../codeInsight/editorActions/TypedAutoPopupImpl.autoPopupCompletion`：`charTyped == '.'` 即弹出
- `.../CompletionAutoPopupHandler`
- `CamelHumpMatcher.applyMiddleMatching`：`"*" + replace(prefix, ".", ". ")`（Registry `ide.completion.middle.matching`）

**实现要点**（`addons/completion/default.go`）：
- 输入 `.` **无条件**弹出补全（不看 completor 是否声明 `.` 为触发字符），并优先路由到声明了 `.` 的 completor；`DisableAutoPopupOnDot` 可关闭（零值即开启，对齐 IDEA 默认）
- 会话被 `.` 的终止判定结束后，立即以空前缀重开（`.` 之后的补全）
- `NewCamelHumpMatcher(prefix, mode, middleMatching)` 支持 middle matching

**测试**：`autopopup_test.go`（`.` 弹出、可关闭、优先选择声明了 `.` 的 completor）。

---

## 15. 后置补全 PostfixTemplate

**IDEA 源码**：
- `platform/lang-impl/.../codeInsight/template/postfix/templates/PostfixTemplate.java`、`PostfixLiveTemplate.java`
- `java/java-impl/.../codeInsight/template/postfix/templates/JavaPostfixTemplateProvider.java`（内置清单）

**实现要点**：
- `postfix.Template`（`Key/Name/Example/Available/Expand`）+ `postfix.Provider`（注册表），`key = "." + name`
- 扫描：光标前为标识符，其前必须为 `.`；表达式由 `scanExpressionStart`（标识符 / 点选择链 / 平衡括号组）向前回扫
- 展开：先删除 `expr.key`，再在表达式位置用 LSP snippet 启动模板（`$0` 等 tab stop 生效）
- 入口：Tab（IDEA 中 postfix 的展开键），在智能 Tab（跳出括号）之前
- 内置 Go 模板（照搬 IDEA 键名、按 Go 重写模板体）：`.if` `.else` `.for` `.forr` `.while` `.var` `.err` `.ret` `.not` `.notnull` `.null` `.par` `.print` `.switch`

**测试**：
- `postfix/postfix_test.go`：键清单、`Match` 表达式扫描、非模板拒绝、展开文本
- `postfix_test.go`：`TestPostfixTemplateTabExpands`（`gvcode-postfix-if.png`）、`TestPostfixTemplateWrapsTheWholeCall`、`TestPostfixTemplateRequiresAnApplicableKey`、`TestPostfixTemplateWithoutProviderIsPlainTab`

---

> 说明：本清单只列出**当前仓库确实没有**的能力；已实现项均以第 1–22 节的测试与截图为证。
