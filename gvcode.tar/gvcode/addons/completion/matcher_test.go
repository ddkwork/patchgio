package completion

import (
	"math"
	"testing"
)

func TestCamelHumpMatcherMatchesCamelHumps(t *testing.T) {
	tests := []struct {
		pattern string
		name    string
		want    bool
	}{
		// Acronyms match the humps of a camel-cased name.
		{"PDM", "PsiDocumentManager", true},
		{"PSIDM", "PsiDocumentManager", true},
		{"PDM", "ApplePie", false},
		// A plain prefix is a match.
		{"psi", "PsiDocumentManager", true},
		{"Psi", "PsiDocumentManager", true},
		// Separators are skipped like humps.
		{"gd", "go_dev", true},
		{"gp", "go.dep", true},
		// A space is a wildcard that may skip a whole word.
		{"psi doc", "PsiDocumentManager", true},
		// A '*' skips anything.
		{"psi*ger", "PsiDocumentManager", true},
		{"zzz", "PsiDocumentManager", false},
	}
	for _, tt := range tests {
		m := NewCamelHumpMatcher(tt.pattern, MatchIgnoringCase, false)
		if got := m.Matches(tt.name); got != tt.want {
			t.Errorf("NewCamelHumpMatcher(%q).Matches(%q) = %v, want %v", tt.pattern, tt.name, got, tt.want)
		}
	}
}

// TestCamelHumpMatcherFirstLetterMode pins IntelliJ's default
// CodeInsightSettings.COMPLETION_CASE_SENSITIVE == FIRST_LETTER: the pattern's
// first letter has to agree with the name's first letter in case.
func TestCamelHumpMatcherFirstLetterMode(t *testing.T) {
	tests := []struct {
		pattern string
		name    string
		want    bool
	}{
		{"foo", "FooBar", false},
		{"Foo", "FooBar", true},
		{"Foo", "fooBar", false},
		{"foo", "foobar", true},
	}
	for _, tt := range tests {
		m := NewCamelHumpMatcher(tt.pattern, MatchFirstLetter, false)
		if got := m.Matches(tt.name); got != tt.want {
			t.Errorf("FIRST_LETTER: matcher(%q).Matches(%q) = %v, want %v", tt.pattern, tt.name, got, tt.want)
		}
	}
}

func TestCamelHumpMatcherMatchCaseMode(t *testing.T) {
	m := NewCamelHumpMatcher("psi", MatchCase, false)
	if m.Matches("PsiDocumentManager") {
		t.Error("MATCH_CASE: the lower-case pattern matched an upper-case name")
	}
	if !NewCamelHumpMatcher("Psi", MatchCase, false).Matches("PsiDocumentManager") {
		t.Error("MATCH_CASE: the exact-case pattern did not match")
	}
}

// TestCamelHumpMatcherDegree pins the scoring: a match at the start of the name
// beats a middle match, and a shorter skip beats a longer one.
func TestCamelHumpMatcherDegree(t *testing.T) {
	m := NewCamelHumpMatcher("foo", MatchIgnoringCase, false)
	start := m.BestMatchingDegree("foobar")
	middle := m.BestMatchingDegree("myfoobar")
	if start <= middle {
		t.Fatalf("start-match degree %d should beat middle-match degree %d", start, middle)
	}
	if m.BestMatchingDegree("zzz") != math.MinInt {
		t.Error("a non-matching name should score math.MinInt")
	}
}

func TestCamelHumpMatcherIsStartMatch(t *testing.T) {
	m := NewCamelHumpMatcher("foo", MatchIgnoringCase, false)
	if !m.IsStartMatch("foobar") {
		t.Error("foo should be a start match for foobar")
	}
	if m.IsStartMatch("barfoo") {
		t.Error("foo should not be a start match for barfoo")
	}
}

// TestApplyMiddleMatching pins IntelliJ's CamelHumpMatcher.applyMiddleMatching:
// the prefix is prefixed with '*' and every '.' becomes '. ' so a completion
// typed after a qualifier can match in the middle of a name.
func TestApplyMiddleMatching(t *testing.T) {
	tests := []struct{ in, want string }{
		{"", ""},
		{"ab", "*ab"},
		{"ab.cd", "*ab. cd"},
	}
	for _, tt := range tests {
		if got := ApplyMiddleMatching(tt.in); got != tt.want {
			t.Errorf("ApplyMiddleMatching(%q) = %q, want %q", tt.in, got, tt.want)
		}
	}
}

func TestIsWordStart(t *testing.T) {
	tests := []struct {
		text []rune
		i    int
		want bool
	}{
		{[]rune("PsiDocumentManager"), 0, true},
		{[]rune("PsiDocumentManager"), 1, false},
		{[]rune("PsiDocumentManager"), 3, true},
		{[]rune("ABC"), 1, false}, // an all-caps run is one word
		{[]rune("ABCd"), 2, true}, // ...until a lower-case letter starts the next hump
		{[]rune("fooBar"), 3, true},
		{[]rune("foo_bar"), 4, true},
	}
	for _, tt := range tests {
		if got := isWordStart(tt.text, tt.i); got != tt.want {
			t.Errorf("isWordStart(%q, %d) = %v, want %v", string(tt.text), tt.i, got, tt.want)
		}
	}
}
