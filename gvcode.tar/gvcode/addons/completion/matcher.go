package completion

import (
	"math"
	"strings"
	"unicode"
)

// MatchingMode mirrors IntelliJ's
// com.intellij.util.text.matching.MatchingMode.
type MatchingMode int

const (
	// MatchIgnoringCase ignores case entirely: "WL" matches WebLogic too.
	MatchIgnoringCase MatchingMode = iota
	// MatchFirstLetter requires the pattern's first letter to match the name's
	// first letter in case, the remaining letters being case-insensitive. It is
	// IntelliJ's default (CodeInsightSettings.COMPLETION_CASE_SENSITIVE ==
	// FIRST_LETTER), so "foo" does not match "FooBar" while "Foo" does.
	MatchFirstLetter
	// MatchCase is fully case sensitive.
	MatchCase
)

// DefaultMatchingMode is the default CodeInsightSettings.COMPLETION_CASE_SENSITIVE
// value.
const DefaultMatchingMode = MatchFirstLetter

// Fragment is a contiguous run of name characters matched by the pattern, as
// rune offsets. It mirrors IntelliJ's MatchedFragment.
type Fragment struct {
	Start int
	End   int
}

// patternChar is one compiled pattern character with the flags the matcher needs.
type patternChar struct {
	r        rune
	lower    bool
	upper    bool
	wildcard bool
	sep      bool
}

// hardSeparators are the characters IntelliJ treats as word separators when it
// measures whether a match starts after one (MinusculeMatcher.myHardSeparators).
const hardSeparators = "_."

// CamelHumpMatcher is a port of IntelliJ's
// com.intellij.psi.codeStyle.MinusculeMatcher, the matcher the completion engine
// uses to decide whether a name matches the typed prefix and how well. It
// understands camel humps ("PDM" matches "PsiDocumentManager"), treats " " and
// "*" as wildcards, and scores a match so that word starts, contiguous runs and
// matching case rank higher.
type CamelHumpMatcher struct {
	prefix string
	mode   MatchingMode

	pattern       []patternChar
	mixedCase     bool
	hasSeparator  bool
	trailingSpace bool
	// meaningful lists the pattern's non-wildcard characters lower-cased; a name
	// that does not carry them all in order cannot match, which is the cheap
	// pre-filter MinusculeMatcherImpl.nameContainsAllMeaningfulCharsInOrder does.
	meaningful []rune
}

// NewCamelHumpMatcher builds the matcher for a typed prefix.
//
// middleMatching enables IntelliJ's CamelHumpMatcher.applyMiddleMatching, which
// turns the prefix into "*prefix" and a "." into ". " so that a prefix typed
// after a qualifier can still match inside the name
// (Registry "ide.completion.middle.matching").
func NewCamelHumpMatcher(prefix string, mode MatchingMode, middleMatching bool) *CamelHumpMatcher {
	if middleMatching {
		prefix = ApplyMiddleMatching(prefix)
	}
	m := &CamelHumpMatcher{prefix: prefix, mode: mode}
	m.compile()
	return m
}

// ApplyMiddleMatching mirrors CamelHumpMatcher.applyMiddleMatching.
func ApplyMiddleMatching(prefix string) string {
	if prefix == "" {
		return prefix
	}
	return strings.TrimSpace("*" + strings.ReplaceAll(prefix, ".", ". "))
}

// Pattern returns the pattern actually matched, after middle matching.
func (m *CamelHumpMatcher) Pattern() string {
	return m.prefix
}

func (m *CamelHumpMatcher) compile() {
	// MatchedFragment tracking starts from the pattern with the trailing "* "
	// marker removed, exactly as MinusculeMatcherImpl.init does.
	raw := []rune(strings.TrimSuffix(m.prefix, "* "))
	seenLower, seenUpper, seenMeaningful := false, false, false
	for _, c := range raw {
		wildcard := c == ' ' || c == '*'
		sep := unicode.IsSpace(c) || c == '_' || c == '-' || c == ':' || c == '+' || c == '.'
		pc := patternChar{r: c, wildcard: wildcard, sep: sep}
		if !wildcard {
			pc.lower = unicode.IsLower(c)
			pc.upper = unicode.IsUpper(c)
			seenLower = seenLower || pc.lower
			seenUpper = seenUpper || pc.upper
			if seenMeaningful && sep {
				m.hasSeparator = true
			}
			seenMeaningful = true
			m.meaningful = append(m.meaningful, unicode.ToLower(c))
		}
		m.pattern = append(m.pattern, pc)
	}
	m.mixedCase = seenLower && seenUpper
	m.trailingSpace = len(raw) > 0 && raw[len(raw)-1] == ' '
}

// Matches reports whether name matches the pattern.
func (m *CamelHumpMatcher) Matches(name string) bool {
	_, ok := m.Match(name)
	return ok
}

// Match returns the matched fragments in ascending order, or ok == false.
func (m *CamelHumpMatcher) Match(name string) (fragments []Fragment, ok bool) {
	matched, ok := m.match([]rune(name))
	if !ok {
		return nil, false
	}
	fragments = make([]Fragment, 0, len(matched))
	for _, f := range matched {
		fragments = append(fragments, f.Fragment)
	}
	return fragments, true
}

// IsStartMatch reports whether the match starts at the name's first character.
// IntelliJ's PreferStartMatching classifier uses it to float exact-prefix
// candidates above middle matches.
func (m *CamelHumpMatcher) IsStartMatch(name string) bool {
	fragments, ok := m.Match(name)
	return ok && len(fragments) > 0 && fragments[0].Start == 0
}

// BestMatchingDegree returns IntelliJ's matching degree for name: the larger the
// value the better the match. It is the number
// RealPrefixMatchingWeigher.getBestMatchingDegree negates when it sorts.
// math.MinInt means "no match".
func (m *CamelHumpMatcher) BestMatchingDegree(name string) int {
	matched, ok := m.match([]rune(name))
	if !ok {
		return math.MinInt
	}
	return m.matchingDegree([]rune(name), matched)
}

// matchFragment is a fragment plus the pattern index it starts at, which the
// case scoring needs.
type matchFragment struct {
	Fragment
	patternStart int
}

func (m *CamelHumpMatcher) match(name []rune) ([]matchFragment, bool) {
	if len(name) < len(m.meaningful) {
		return nil, false
	}
	if !containsMeaningfulInOrder(name, m.meaningful) {
		return nil, false
	}
	return m.matchWildcards(name, 0, 0)
}

// containsMeaningfulInOrder is MinusculeMatcherImpl
// .nameContainsAllMeaningfulCharsInOrder: an O(n) pre-filter that rejects most
// non-matching names before the backtracking search starts.
func containsMeaningfulInOrder(name, meaningful []rune) bool {
	if len(meaningful) == 0 {
		return true
	}
	pi := 0
	for _, c := range name {
		if unicode.ToLower(c) == meaningful[pi] {
			pi++
			if pi == len(meaningful) {
				return true
			}
		}
	}
	return false
}

// matchWildcards walks the pattern: wildcards may skip any number of name runes,
// and a fragment may not; after a wildcard the search restarts at every position
// so the best split is found.
func (m *CamelHumpMatcher) matchWildcards(name []rune, patternIdx, nameIdx int) ([]matchFragment, bool) {
	for patternIdx < len(m.pattern) && m.pattern[patternIdx].wildcard {
		patternIdx++
	}
	if patternIdx >= len(m.pattern) {
		if m.trailingSpace && !containsSpace(name[nameIdx:]) {
			return nil, false
		}
		return nil, true
	}

	for i := nameIdx; i < len(name); i++ {
		if !m.firstCharMatches(name, patternIdx, i) {
			continue
		}
		length := m.maxMatchingFragment(name, patternIdx, i)
		if length == 0 {
			continue
		}
		rest, ok := m.matchWildcards(name, patternIdx+length, i+length)
		if !ok {
			continue
		}
		out := make([]matchFragment, 0, len(rest)+1)
		out = append(out, matchFragment{Fragment: Fragment{Start: i, End: i + length}, patternStart: patternIdx})
		return append(out, rest...), true
	}
	return nil, false
}

// firstCharMatches reports whether pattern[patternIdx] may match name[nameIdx],
// including IntelliJ's FIRST_LETTER rule for the pattern's first letter.
func (m *CamelHumpMatcher) firstCharMatches(name []rune, patternIdx, nameIdx int) bool {
	pc := m.pattern[patternIdx]
	if pc.wildcard {
		return true
	}
	nc := name[nameIdx]
	if !m.charEquals(pc, nc) {
		return false
	}
	if m.mode == MatchFirstLetter && (pc.upper || pc.lower) {
		// The first pattern letter's case has to agree with the name's first
		// letter; leading wildcards are skipped first.
		if patternIdx == 0 || (patternIdx == 1 && m.pattern[0].wildcard) {
			if pc.upper != unicode.IsUpper(name[0]) {
				return false
			}
		}
	}
	return true
}

func (m *CamelHumpMatcher) charEquals(pc patternChar, nc rune) bool {
	if m.mode == MatchCase {
		return pc.r == nc
	}
	return unicode.ToLower(pc.r) == unicode.ToLower(nc)
}

// maxMatchingFragment is MinusculeMatcherImpl.maxMatchingFragment: the length of
// the longest contiguous pattern prefix that matches the name from nameIdx.
func (m *CamelHumpMatcher) maxMatchingFragment(name []rune, patternIdx, nameIdx int) int {
	length := 0
	for patternIdx+length < len(m.pattern) && nameIdx+length < len(name) {
		pc := m.pattern[patternIdx+length]
		if pc.wildcard {
			break
		}
		if !m.charEquals(pc, name[nameIdx+length]) {
			break
		}
		length++
	}
	return length
}

// matchingDegree is MinusculeMatcher.calculateHumpedMatchingScore: the exact
// weights IntelliJ uses, so a word-start match (+1000) dominates, a skipped hump
// costs 10, and matching case at the start of the name is worth 150.
func (m *CamelHumpMatcher) matchingDegree(name []rune, fragments []matchFragment) int {
	if len(fragments) == 0 {
		return 0
	}

	first, last := fragments[0], fragments[len(fragments)-1]
	startMatch := first.Start == 0
	valuedStartMatch := startMatch

	patternOf := make(map[int]int, len(name))
	for _, f := range fragments {
		for k := 0; k < f.End-f.Start; k++ {
			patternOf[f.Start+k] = f.patternStart + k
		}
	}
	inFragment := func(i int) bool { _, ok := patternOf[i]; return ok }

	matchingCase := 0
	for i := first.Start; i < last.End; i++ {
		pi, matched := patternOf[i]
		if !matched {
			continue
		}
		afterGap := i > 0 && !inFragment(i-1)
		matchingCase += m.evaluateCaseMatching(name, pi, i, isWordStart(name, i), valuedStartMatch, afterGap)
	}

	// Humps the pattern skipped cost 10 each: "PD" matching "PsiDocument" beats
	// "PD" matching "PsiExtraDocument".
	skippedHumps := 0
	for i := first.Start; i < last.End; i++ {
		if !inFragment(i) && isWordStart(name, i) {
			skippedHumps++
		}
	}

	afterSeparator := false
	for _, sep := range hardSeparators {
		if indexRuneIn(name, sep, 0, first.Start) >= 0 {
			afterSeparator = true
			break
		}
	}
	wordStart := first.Start == 0 ||
		(isWordStart(name, first.Start) && !isWordStart(name, first.Start-1))
	finalMatch := last.End == len(name)

	degree := 0
	if wordStart {
		degree += 1000
	}
	degree += matchingCase - len(fragments) - skippedHumps*10
	if !afterSeparator {
		degree += 2
	}
	if startMatch {
		degree += 1
	}
	if finalMatch {
		degree += 1
	}
	return degree
}

// evaluateCaseMatching is MinusculeMatcher.evaluateCaseMatching's table.
func (m *CamelHumpMatcher) evaluateCaseMatching(name []rune, patternIdx, nameIdx int, humpStart, valuedStartMatch, afterGap bool) int {
	pc := m.pattern[patternIdx]
	nc := name[nameIdx]
	if afterGap && humpStart && pc.lower {
		return -10
	}
	if nc == pc.r {
		switch {
		case pc.upper:
			return 50
		case nameIdx == 0 && valuedStartMatch:
			return 150
		case humpStart:
			return 1
		default:
			return 0
		}
	}
	if humpStart {
		return -1
	}
	return 0
}

// isWordStart is NameUtilCore.isWordStart: the start of a camel hump or of a
// number run inside an identifier.
func isWordStart(text []rune, i int) bool {
	if i < 0 || i >= len(text) {
		return false
	}
	c := text[i]
	if unicode.IsUpper(c) {
		if i > 0 && unicode.IsUpper(text[i-1]) {
			// All-caps runs are one word; the run only breaks before a
			// lower-case letter ("ABCd" starts a hump at "d").
			return i+1 < len(text) && unicode.IsLower(text[i+1])
		}
		return true
	}
	if unicode.IsDigit(c) {
		return true
	}
	if !unicode.IsLetter(c) && !unicode.IsDigit(c) {
		return false
	}
	if i == 0 {
		return true
	}
	prev := text[i-1]
	return !unicode.IsLetter(prev) && !unicode.IsDigit(prev)
}

func containsSpace(name []rune) bool {
	for _, c := range name {
		if unicode.IsSpace(c) {
			return true
		}
	}
	return false
}

// indexRuneIn returns the index of r in text[from:to), or -1.
func indexRuneIn(text []rune, r rune, from, to int) int {
	if from < 0 {
		from = 0
	}
	if to > len(text) {
		to = len(text)
	}
	for i := from; i < to; i++ {
		if text[i] == r {
			return i
		}
	}
	return -1
}
