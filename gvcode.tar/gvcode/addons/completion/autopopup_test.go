package completion

import (
	"testing"

	"github.com/oligo/gvcode"
)

func candidatesFromLabels(labels ...string) []gvcode.CompletionCandidate {
	out := make([]gvcode.CompletionCandidate, 0, len(labels))
	for _, l := range labels {
		out = append(out, gvcode.CompletionCandidate{Label: l})
	}
	return out
}

// TestAutoPopupOnDotStartsASession pins IntelliJ's
// TypedAutoPopupImpl.autoPopupCompletion: "." pops the lookup even when the
// completor never listed it as a trigger character. The mock's Trigger is empty,
// so without the dot handling nothing would start.
func TestAutoPopupOnDotStartsASession(t *testing.T) {
	editor := newTestEditor("foo.", 4)
	dc := &DefaultCompletion{Editor: editor}
	if err := dc.AddCompletor(&mockCompletor{candidates: candidatesFromLabels("Bar", "Baz")}, nil); err != nil {
		t.Fatalf("AddCompletor: %v", err)
	}

	dc.OnText(gvcode.CompletionContext{Input: ".", Position: gvcode.Position{Line: 0, Column: 4, Runes: 4}})

	if !dc.IsActive() {
		t.Fatal("typing '.' did not pop the completion lookup")
	}
	if got := labels(dc.candidates); len(got) != 2 {
		t.Fatalf("candidates = %v, want the completor's two", got)
	}
}

func TestAutoPopupOnDotCanBeDisabled(t *testing.T) {
	editor := newTestEditor("foo.", 4)
	dc := &DefaultCompletion{Editor: editor, DisableAutoPopupOnDot: true}
	if err := dc.AddCompletor(&mockCompletor{candidates: candidatesFromLabels("Bar")}, nil); err != nil {
		t.Fatalf("AddCompletor: %v", err)
	}

	dc.OnText(gvcode.CompletionContext{Input: ".", Position: gvcode.Position{Line: 0, Column: 4, Runes: 4}})

	if dc.IsActive() {
		t.Fatal("the dotted lookup popped even though it was disabled")
	}
}

// TestAutoPopupOnDotPrefersTheDotCompletor checks that the dot is routed to a
// completor that declares it rather than blindly to the first one.
func TestAutoPopupOnDotPrefersTheDotCompletor(t *testing.T) {
	editor := newTestEditor("a.", 2)
	first := &mockCompletor{candidates: candidatesFromLabels("first")}
	second := &mockCompletor{
		trigger:    gvcode.Trigger{Characters: []string{"."}},
		candidates: candidatesFromLabels("second"),
	}
	dc := &DefaultCompletion{Editor: editor}
	if err := dc.AddCompletor(first, nil); err != nil {
		t.Fatalf("AddCompletor(first): %v", err)
	}
	if err := dc.AddCompletor(second, nil); err != nil {
		t.Fatalf("AddCompletor(second): %v", err)
	}

	dc.OnText(gvcode.CompletionContext{Input: ".", Position: gvcode.Position{Line: 0, Column: 2, Runes: 2}})

	if !dc.IsActive() {
		t.Fatal("typing '.' did not pop the completion lookup")
	}
	if got := labels(dc.candidates); len(got) != 1 || got[0] != "second" {
		t.Fatalf("candidates = %v, want the dot completor's", got)
	}
}
