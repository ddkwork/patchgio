package completion

import (
	"testing"

	"github.com/oligo/gvcode"
)

func labels(candidates []gvcode.CompletionCandidate) []string {
	out := make([]string, 0, len(candidates))
	for _, c := range candidates {
		out = append(out, c.Label)
	}
	return out
}

// TestFilterAndRankPrefersStartMatches pins the middleMatching classifier: an
// exact prefix floats above a name that merely contains the letters.
func TestFilterAndRankPrefersStartMatches(t *testing.T) {
	candidates := []gvcode.CompletionCandidate{
		{Label: "barfoo"},
		{Label: "foobar"},
	}
	got := labels(DefaultFilterAndRank("foo", candidates))
	if len(got) != 2 || got[0] != "foobar" {
		t.Fatalf("ranking = %v, want foobar first", got)
	}
}

func TestFilterAndRankDropsNonMatches(t *testing.T) {
	candidates := []gvcode.CompletionCandidate{
		{Label: "bar"},
		{Label: "baz"},
	}
	if got := DefaultFilterAndRank("foo", candidates); len(got) != 0 {
		t.Fatalf("ranking = %v, want nothing", labels(got))
	}
}

// TestFilterAndRankCamelHump is the camel-hump case the feature exists for:
// "PDM" must admit the humps of "PsiDocumentManager" and reject an unrelated name.
func TestFilterAndRankCamelHump(t *testing.T) {
	candidates := []gvcode.CompletionCandidate{
		{Label: "PsiDocumentManager"},
		{Label: "ApplePie"},
		{Label: "PostDataModel"},
	}
	got := labels(DefaultFilterAndRank("PDM", candidates))
	if len(got) != 2 {
		t.Fatalf("ranking = %v, want the two camel-hump matches", got)
	}
	for _, l := range got {
		if l == "ApplePie" {
			t.Fatalf("ranking = %v, ApplePie carries no P/D/M humps", got)
		}
	}
}

func TestFilterAndRankRespectsSortText(t *testing.T) {
	candidates := []gvcode.CompletionCandidate{
		{Label: "aaa", SortText: "2"},
		{Label: "bbb", SortText: "1"},
	}
	got := labels(DefaultFilterAndRank("", candidates))
	if len(got) != 2 || got[0] != "bbb" {
		t.Fatalf("ranking = %v, want the smaller SortText first", got)
	}
}

// TestFilterAndRankLiftsShorterPrefix pins the liftShorter classifier: "foo" is
// offered before "foobar".
func TestFilterAndRankLiftsShorterPrefix(t *testing.T) {
	candidates := []gvcode.CompletionCandidate{
		{Label: "foobar"},
		{Label: "foo"},
	}
	got := labels(DefaultFilterAndRank("foo", candidates))
	if len(got) != 2 || got[0] != "foo" {
		t.Fatalf("ranking = %v, want foo first", got)
	}
}

// TestFilterAndRankUsesFilterText proves the LSP FilterText is what the matcher
// sees, so a candidate can display a label that differs from its match text.
func TestFilterAndRankUsesFilterText(t *testing.T) {
	candidates := []gvcode.CompletionCandidate{
		{Label: "display name", FilterText: "foobar"},
		{Label: "other", FilterText: "bar"},
	}
	got := DefaultFilterAndRank("foo", candidates)
	if len(got) != 1 || got[0].Label != "display name" {
		t.Fatalf("ranking = %v, want only the FilterText match", labels(got))
	}
}
