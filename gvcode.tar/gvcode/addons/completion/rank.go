package completion

import (
	"sort"
	"strings"

	"github.com/oligo/gvcode"
)

// SortOptions configures FilterAndRank.
type SortOptions struct {
	// Mode is the matcher's case sensitivity. The zero value is
	// MatchIgnoringCase; DefaultSortOptions uses IntelliJ's default instead.
	Mode MatchingMode
	// MiddleMatching lets a prefix match inside a name, the way IntelliJ's
	// "ide.completion.middle.matching" registry flag does.
	MiddleMatching bool
}

// DefaultSortOptions returns the options IntelliJ ships with:
// CodeInsightSettings.COMPLETION_CASE_SENSITIVE == FIRST_LETTER and middle
// matching enabled.
func DefaultSortOptions() SortOptions {
	return SortOptions{Mode: DefaultMatchingMode, MiddleMatching: true}
}

// FilterAndRank keeps the candidates whose name matches pattern and orders them
// by relevance, following IntelliJ's completion classifier chain
// (BaseCompletionService.defaultSorter):
//
//	middleMatching → priority (SortText) → prefix (matching degree) → liftShorter
//
// The chain is what makes typing "PDM" float "PsiDocumentManager" above an
// unrelated name that merely contains the letters, and an exact prefix above a
// middle match.
func FilterAndRank(pattern string, candidates []gvcode.CompletionCandidate, opts SortOptions) []gvcode.CompletionCandidate {
	type ranked struct {
		candidate  gvcode.CompletionCandidate
		name       string
		startMatch bool
		degree     int
		index      int
	}

	// The middle matcher does the filtering; the plain one decides whether the
	// match starts at the name's first character, which middle matching by
	// definition can hide.
	matcher := NewCamelHumpMatcher(pattern, opts.Mode, opts.MiddleMatching)
	startMatcher := NewCamelHumpMatcher(pattern, MatchIgnoringCase, false)

	kept := make([]ranked, 0, len(candidates))
	for i, candidate := range candidates {
		name := lookupText(candidate)
		if pattern != "" && !matcher.Matches(name) {
			continue
		}
		item := ranked{candidate: candidate, name: name, index: i}
		if pattern != "" {
			item.startMatch = startMatcher.IsStartMatch(name)
			item.degree = matcher.BestMatchingDegree(name)
		}
		kept = append(kept, item)
	}

	sort.SliceStable(kept, func(i, j int) bool {
		a, b := kept[i], kept[j]
		// middleMatching: a match at the start of the name beats a middle match.
		if a.startMatch != b.startMatch {
			return a.startMatch
		}
		// priority: an explicit SortText orders before the inferred relevance.
		if a.candidate.SortText != b.candidate.SortText {
			return a.candidate.SortText < b.candidate.SortText
		}
		// prefix: the larger matching degree wins.
		if a.degree != b.degree {
			return a.degree > b.degree
		}
		// liftShorter: a name that is a proper prefix of another comes first, so
		// "foo" is offered before "foobar".
		aPrefix, bPrefix := isProperPrefix(a.name, b.name), isProperPrefix(b.name, a.name)
		if aPrefix != bPrefix {
			return aPrefix
		}
		if a.name != b.name {
			return a.name < b.name
		}
		return a.index < b.index
	})

	out := make([]gvcode.CompletionCandidate, 0, len(kept))
	for _, item := range kept {
		out = append(out, item.candidate)
	}
	return out
}

// DefaultFilterAndRank filters and ranks with IntelliJ's default options. A
// completor can use it as its FilterAndRank so it gets camel-hump matching,
// middle matching and relevance sorting for free.
func DefaultFilterAndRank(pattern string, candidates []gvcode.CompletionCandidate) []gvcode.CompletionCandidate {
	return FilterAndRank(pattern, candidates, DefaultSortOptions())
}

// lookupText is the text a candidate is matched and sorted by: the LSP
// FilterText when given, the Label otherwise.
func lookupText(candidate gvcode.CompletionCandidate) string {
	if candidate.FilterText != "" {
		return candidate.FilterText
	}
	return candidate.Label
}

func isProperPrefix(a, b string) bool {
	return len(a) < len(b) && strings.HasPrefix(strings.ToLower(b), strings.ToLower(a))
}
