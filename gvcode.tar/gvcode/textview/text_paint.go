package textview

import (
	"image"
	"image/color"
	"math"

	"gioui.org/f32"
	"gioui.org/io/key"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/op/clip"
	"gioui.org/op/paint"
	"gioui.org/text"
	"gioui.org/unit"
	lt "github.com/oligo/gvcode/internal/layout"
	"github.com/oligo/gvcode/internal/painter"
	"github.com/oligo/gvcode/internal/stroke"
)

// calculateViewSize determines the size of the current visible content,
// ensuring that even if there is no text content, some space is reserved
// for the caret.
func (e *TextView) calculateViewSize(gtx layout.Context) image.Point {
	base := e.dims.Size
	if caretWidth := gtx.Dp(e.CaretWidth); base.X < caretWidth {
		base.X = caretWidth
	}
	return gtx.Constraints.Constrain(base)
}

func (e *TextView) layoutText(shaper *text.Shaper) {
	//e.layoutByParagraph(shaper, &it)
	e.dims = e.layouter.Layout(shaper, &e.params, e.TabWidth, e.WrapLine)
}

// PaintText clips and paints the visible text glyph outlines using the provided
// material to fill the glyphs.
func (e *TextView) PaintText(gtx layout.Context, material op.CallOp) {
	viewport := image.Rectangle{
		Min: e.scrollOff,
		Max: e.viewSize.Add(e.scrollOff),
	}

	e.textPainter.SetViewport(viewport, e.scrollOff)
	e.textPainter.SetLineHeight(e.lineHeight)
	e.decorations.Refresh()
	// Walk the VISIBLE lines: a collapsed fold must not paint its hidden lines,
	// whose compacted offsets would otherwise show through the text below them.
	e.textPainter.Paint(gtx, e.shaper, e.layouter.VisibleLines(), material, e.syntaxStyles, e.decorations)
}

// selectionPolygons creates clip.PathSpecs for the given selection regions,
// grouping non-overlapping rectangles into separate polygons.
func (e *TextView) selectionPolygons(gtx layout.Context, regions []lt.Region) []clip.PathSpec {
	if len(regions) == 0 {
		return nil
	}

	// Prepare rectangles with padding
	rects := make([]image.Rectangle, len(regions))
	for i, region := range regions {
		if i == 0 || i == len(regions)-1 {
			rects[i] = e.adjustPadding(region.Bounds)
		} else {
			rects[i] = region.Bounds
		}
	}

	expandEmptyRegion := len(regions) > 1
	minWidth := gtx.Dp(unit.Dp(6))
	// Build paths with rounded corners for each group
	radius := gtx.Dp(e.CornerRadius)
	if radius <= 0 {
		radius = gtx.Dp(unit.Dp(2))
	}

	polygonBuilder := painter.NewPolygonBuilder(expandEmptyRegion, minWidth, float32(radius))
	polygonBuilder.Group(rects)
	return polygonBuilder.Paths(gtx)
}

// PaintSelection clips and paints the visible text selection rectangles using
// the provided material to fill the rectangles.
func (e *TextView) PaintSelection(gtx layout.Context, material op.CallOp) {
	e.PaintSelectionRange(gtx, e.caret.start, e.caret.end, material)
}

// PaintSelectionRange paints a selection between two rune offsets. It is the
// range-taking twin of PaintSelection, which multi-caret editing needs for the
// carets beyond the primary one.
func (e *TextView) PaintSelectionRange(gtx layout.Context, start, end int, material op.CallOp) {
	localViewport := image.Rectangle{Max: e.viewSize}
	docViewport := image.Rectangle{Max: e.viewSize}.Add(e.scrollOff)
	defer clip.Rect(localViewport).Push(gtx.Ops).Pop()
	e.regions = e.layouter.Locate(docViewport, start, end, e.regions)
	if len(e.regions) == 0 {
		return
	}
	paths := e.selectionPolygons(gtx, e.regions)
	for _, path := range paths {
		outline := clip.Outline{Path: path}.Op().Push(gtx.Ops)
		material.Add(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
		outline.Pop()
	}
}

// PaintCaretAt clips and paints a caret rectangle at a rune offset, the way
// PaintCaret does for the caret itself. Multi-caret editing draws one per caret.
func (e *TextView) PaintCaretAt(gtx layout.Context, runeIdx int, material op.CallOp) {
	carWidth2 := gtx.Dp(e.CaretWidth)
	caretPos, carAsc, carDesc := e.caretInfoAt(runeIdx)

	carRect := image.Rectangle{
		Min: caretPos.Sub(image.Pt(carWidth2, carAsc)),
		Max: caretPos.Add(image.Pt(carWidth2, carDesc)),
	}
	cl := image.Rectangle{Max: e.viewSize}
	carRect = cl.Intersect(carRect)
	if !carRect.Empty() {
		defer clip.Rect(e.adjustPadding(carRect)).Push(gtx.Ops).Pop()
		material.Add(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
	}
}

func (e *TextView) PaintOverlay(gtx layout.Context, offset image.Point, overlay layout.Widget) {
	viewport := image.Rectangle{
		Min: e.scrollOff,
		Max: e.viewSize.Add(e.scrollOff),
	}

	macro := op.Record(gtx.Ops)
	dims := overlay(gtx)
	call := macro.Stop()

	if dims.Size == (image.Point{}) {
		return
	}

	if offset.X+dims.Size.X-e.scrollOff.X > gtx.Constraints.Max.X {
		offset.X = max(offset.X-dims.Size.X, 0)
	}

	padding := e.adjustDescentPadding()
	if offset.Y+dims.Size.Y+padding-e.scrollOff.Y > gtx.Constraints.Max.Y {
		offset.Y = max(offset.Y-dims.Size.Y-int(e.lineHeight.Ceil())+padding, 0)
	} else {
		offset.Y += padding
	}

	// Calculate adjusted offset for drawing
	adjustedOffset := offset.Sub(e.scrollOff)

	// Draw shadow layers before the overlay content
	cornerRadius := gtx.Dp(unit.Dp(6))
	shadowOffset := gtx.Dp(unit.Dp(2))
	shadowBlur := gtx.Dp(unit.Dp(8))

	shadowColors := []color.NRGBA{
		{A: 0x08},
		{A: 0x10},
		{A: 0x18},
	}

	for i, shadowColor := range shadowColors {
		layerOffset := shadowOffset + shadowBlur - i*(shadowBlur/len(shadowColors))
		shadowRect := image.Rectangle{
			Min: adjustedOffset.Add(image.Point{X: layerOffset / 2, Y: layerOffset / 2}),
			Max: adjustedOffset.Add(image.Point{X: dims.Size.X + layerOffset, Y: dims.Size.Y + layerOffset}),
		}
		paint.FillShape(gtx.Ops, shadowColor,
			clip.UniformRRect(shadowRect, cornerRadius+layerOffset/4).Op(gtx.Ops))
	}

	defer op.Offset(adjustedOffset).Push(gtx.Ops).Pop()
	defer clip.Rect(viewport.Sub(e.scrollOff)).Push(gtx.Ops).Pop()
	call.Add(gtx.Ops)
}

func (e *TextView) HighlightMatchingBrackets(gtx layout.Context, material op.CallOp) {
	left, right := e.NearestMatchingBrackets()
	if left < 0 || right < 0 {
		// no matching found
		return
	}
	localViewport := image.Rectangle{Max: e.viewSize}
	docViewport := image.Rectangle{Max: e.viewSize}.Add(e.scrollOff)
	leftRegion := e.layouter.Locate(docViewport, left, left+1, nil)
	rightRegion := e.layouter.Locate(docViewport, right, right+1, nil)

	e.regions = e.regions[:0]
	e.regions = append(e.regions, leftRegion...)
	e.regions = append(e.regions, rightRegion...)

	defer clip.Rect(localViewport).Push(gtx.Ops).Pop()
	for _, region := range e.regions {
		area := clip.Rect(e.adjustPadding(region.Bounds))
		stack := area.Push(gtx.Ops)
		material.Add(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
		stack.Pop()

		stroke := clip.Stroke{
			Path:  area.Path(),
			Width: float32(gtx.Dp(unit.Dp(1))),
		}.Op().Push(gtx.Ops)
		material.Add(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
		stroke.Pop()
	}
}

func (e *TextView) PaintComposition(gtx layout.Context, rng key.Range, material op.CallOp, pattern string) {
	if rng == (key.Range{}) || rng.Start < 0 || rng.End < 0 || rng.Start == rng.End {
		return
	}

	localViewport := image.Rectangle{Max: e.viewSize}
	docViewport := image.Rectangle{Max: e.viewSize}.Add(e.scrollOff)
	defer clip.Rect(localViewport).Push(gtx.Ops).Pop()

	e.regions = e.layouter.Locate(docViewport, rng.Start, rng.End, e.regions)
	if len(e.regions) == 0 {
		return
	}

	thickness := max(gtx.Dp(unit.Dp(1)), 1)

	for _, region := range e.regions {
		y := region.Bounds.Max.Y - max(region.Baseline*2/3, thickness) // 1/3 below the baseline.
		underline := image.Rect(region.Bounds.Min.X, y, region.Bounds.Max.X, y+thickness)
		underline = underline.Intersect(localViewport)
		if underline.Empty() {
			continue
		}

		switch pattern {

		case "dash":
			path := stroke.Path{}
			path.Segments = append(path.Segments, stroke.MoveTo(f32.Pt(float32(underline.Min.X), float32(underline.Max.Y))))
			path.Segments = append(path.Segments, stroke.LineTo(f32.Pt(float32(underline.Max.X), float32(underline.Max.Y))))

			cl := stroke.Stroke{
				Path:  path,
				Width: float32(thickness),
				Cap:   stroke.FlatCap,
				Join:  stroke.BevelJoin,
				Dashes: stroke.Dashes{
					Dashes: []float32{4, 2},
				},
			}.Op(gtx.Ops).Push(gtx.Ops)

			material.Add(gtx.Ops)
			paint.PaintOp{}.Add(gtx.Ops)

			cl.Pop()
		default:
			// simple underline
			stack := clip.Rect(underline).Push(gtx.Ops)
			material.Add(gtx.Ops)
			paint.PaintOp{}.Add(gtx.Ops)
			stack.Pop()
		}

	}

}

// caretCurrentLine returns the current paragraph that the carent is in.
// Only the start position is checked.
func (e *TextView) caretCurrentLine() (start lt.CombinedPos, end lt.CombinedPos, lineIndex int) {
	caretStart := e.closestToRune(e.caret.start)
	lines, lineIndex := e.selectedParagraphs()
	if len(lines) == 0 {
		return caretStart, caretStart, lineIndex
	}

	line := lines[0]
	start = e.closestToXY(line.StartX, line.StartY)
	end = e.closestToXY(line.EndX, line.EndY)

	return
}

// PaintCaret clips and paints the caret rectangle, adding material immediately
// before painting to set the appropriate paint material.
func (e *TextView) PaintCaret(gtx layout.Context, material op.CallOp) {
	carWidth2 := gtx.Dp(e.CaretWidth)
	caretPos, carAsc, carDesc := e.CaretInfo()

	carRect := image.Rectangle{
		Min: caretPos.Sub(image.Pt(carWidth2, carAsc)),
		Max: caretPos.Add(image.Pt(carWidth2, carDesc)),
	}
	cl := image.Rectangle{Max: e.viewSize}
	carRect = cl.Intersect(carRect)
	if !carRect.Empty() {
		defer clip.Rect(e.adjustPadding(carRect)).Push(gtx.Ops).Pop()
		material.Add(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
	}
}

func (e *TextView) CaretInfo() (pos image.Point, ascent, descent int) {
	return e.caretInfoAt(e.caret.start)
}

// CaretInfoAt is CaretInfo for an arbitrary rune offset, which multi-caret drawing
// needs for the carets beyond the primary one.
func (e *TextView) CaretInfoAt(runeIdx int) (pos image.Point, ascent, descent int) {
	return e.caretInfoAt(runeIdx)
}

// caretInfoAt is CaretInfo for an arbitrary caret position.
func (e *TextView) caretInfoAt(runeIdx int) (pos image.Point, ascent, descent int) {
	caretStart := e.closestToRune(runeIdx)

	ascent = caretStart.Ascent.Ceil()
	descent = caretStart.Descent.Ceil()

	pos = image.Point{
		X: caretStart.X.Round(),
		Y: caretStart.Y,
	}
	pos = pos.Sub(e.scrollOff)
	return
}

// adjustPadding adjusts the vertical padding of a bounding box around the texts.
// This improves the visual effects of selected texts, or any other texts to be highlighted.
func (e *TextView) adjustPadding(bounds image.Rectangle) image.Rectangle {
	if e.lineHeight <= 0 {
		e.lineHeight = e.calcLineHeight()
	}

	if e.lineHeight.Ceil() <= bounds.Dy() {
		return bounds
	}

	leading := e.lineHeight.Ceil() - bounds.Dy()
	adjust := int(math.Round(float64(float32(leading) / 2.0)))

	bounds.Min.Y -= adjust
	bounds.Max.Y += leading - adjust
	return bounds
}

func (e *TextView) adjustDescentPadding() int {
	caretStart := e.closestToRune(e.caret.start)
	height := caretStart.Ascent + caretStart.Descent

	if e.lineHeight <= 0 {
		e.lineHeight = e.calcLineHeight()
	}

	if e.lineHeight.Ceil() <= height.Ceil() {
		return 0
	}

	leading := (e.lineHeight - height).Round()
	return int(math.Round(float64(float32(leading) / 2.0)))
}
