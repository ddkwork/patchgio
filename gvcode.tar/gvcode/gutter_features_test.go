package gvcode

import (
	"image"
	"image/color"
	"strconv"
	"strings"
	"testing"

	"gioui.org/f32"
	"gioui.org/io/key"
	"gioui.org/io/pointer"
	"gioui.org/unit"

	"github.com/oligo/gvcode/gutter"
	"github.com/oligo/gvcode/gutter/providers"
	"github.com/oligo/gvcode/internal/folding"
)

// clickGutter injects a real pointer press and release at (x, y) in window
// coordinates and returns every editor event the editor produced while the click
// was delivered. The gutter turns clicks into actions through its own input area,
// so a test that only calls provider methods would not exercise the wiring the
// user actually hits.
func (h *columnEditHarness) clickGutter(x, y int) []EditorEvent {
	return h.clickAt(x, y, 0)
}

// clickAt queues a mouse click at a position with the given modifiers, which is how
// the multi-caret tests reach Ctrl+Click.
func (h *columnEditHarness) clickAt(x, y int, mods key.Modifiers) []EditorEvent {
	h.t.Helper()

	// Editor.Layout drains the pending queue at the start of every frame, so the
	// events have to be collected as the frames go by, not afterwards.
	var events []EditorEvent
	pump := func() {
		for {
			ev, ok := h.ed.Update(h.gtx)
			if !ok {
				break
			}
			events = append(events, ev)
		}
	}

	pos := f32.Pt(float32(x), float32(y))
	h.router.Queue(pointer.Event{
		Kind:      pointer.Press,
		Buttons:   pointer.ButtonPrimary,
		Source:    pointer.Mouse,
		Position:  pos,
		Modifiers: mods,
	})
	// One frame carries the press to the registered areas, one carries the
	// release, and the following frames let the gutter consume the click and
	// render the result.
	for range 2 {
		h.frame(true)
		pump()
	}
	h.router.Queue(pointer.Event{
		Kind:      pointer.Release,
		Buttons:   pointer.ButtonPrimary,
		Source:    pointer.Mouse,
		Position:  pos,
		Modifiers: mods,
	})
	for range 4 {
		h.frame(true)
		pump()
	}
	return events
}

// runButtonGreen is the outline colour of the run marker, taken from IntelliJ's
// own icon (platform/icons/src/expui/run/run.svg, dark theme).
var runButtonGreen = color.NRGBA{R: 0x57, G: 0x96, B: 0x5C, A: 0xFF}

// countGreenishIn counts pixels whose green channel clearly dominates the red and
// blue ones. The run marker is a dark green triangle with a green outline, so this
// matches the outline (the part that carries the colour) without depending on the
// exact antialiased values.
func countGreenishIn(img *image.RGBA, x0, x1, y0, y1 int) int {
	n := 0
	for y := y0; y < y1; y++ {
		for x := x0; x < x1; x++ {
			r, g, b, _ := img.At(x, y).RGBA()
			rr, gg, bb := int(r>>8), int(g>>8), int(b>>8)
			if gg >= 0x40 && gg > rr+16 && gg > bb+16 {
				n++
			}
		}
	}
	return n
}

// runeOffsetOfDocumentLine returns the rune offset where a document line starts.
func runeOffsetOfDocumentLine(content string, line int) int {
	off := 0
	for i, l := range strings.Split(content, "\n") {
		if i == line {
			return off
		}
		off += len([]rune(l)) + 1
	}
	return off
}

// newGutterFeatureHarness builds an editor wired the way the example app wires it:
// line numbers, run buttons, fold buttons and sticky lines all enabled. The test
// creates the providers itself so it can read their state as well as render them.
func newGutterFeatureHarness(t *testing.T, content string, size image.Point) (*columnEditHarness, *providers.RunButtonProvider, *folding.Manager, *providers.StickyLinesProvider) {
	t.Helper()
	h := newColumnEditHarness(t, content, size, unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	// The gutter features have nothing to do with column mode, and its carets
	// would only add noise to the pixel checks.
	e.SetColumnEditMode(false)

	runButtons := providers.NewRunButtonProvider()
	folds := folding.NewManager()
	sticky := providers.NewStickyLinesProvider()
	e.WithOptions(
		WithDefaultGutters(),
		WithGutter(runButtons),
		WithGutter(providers.NewFoldButtonProvider(folds)),
		WithGutter(sticky),
	)
	e.text.SetFoldManager(folds)
	for range 3 {
		h.frame(true)
	}
	return h, runButtons, folds, sticky
}

// countColorIn counts pixels close to want inside the given rectangle. The GPU
// antialiases every edge, so an exact match would be too strict.
func countColorIn(img *image.RGBA, x0, x1, y0, y1 int, want color.NRGBA) int {
	n := 0
	for y := y0; y < y1; y++ {
		for x := x0; x < x1; x++ {
			r, g, b, _ := img.At(x, y).RGBA()
			dr := int(r>>8) - int(want.R)
			dg := int(g>>8) - int(want.G)
			db := int(b>>8) - int(want.B)
			if dr < 0 {
				dr = -dr
			}
			if dg < 0 {
				dg = -dg
			}
			if db < 0 {
				db = -db
			}
			if dr <= 24 && dg <= 24 && db <= 24 {
				n++
			}
		}
	}
	return n
}

// TestGutterRunButtonRenders pins the run-button gutter: a Go main function must
// get a run marker drawn in the gutter, in the provider's green. It fails if the
// provider is not laid out, never receives the line contents, or the pattern no
// longer matches.
func TestGutterRunButtonRenders(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tprintln(42)\n}\n"
	h, _, _, _ := newGutterFeatureHarness(t, content, image.Pt(420, 160))
	e := h.ed
	if e.gutterWidth <= 0 {
		t.Fatal("no gutter was laid out at all")
	}

	h.frame(true)
	img := image.NewRGBA(image.Rect(0, 0, 420, 160))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dir := screenshotDir(t)
	dumpPNG(t, dir, "gvcode-gutter-runbutton", img)

	lineHeight := e.text.GetLineHeight().Round()
	// The marker belongs on the "func main()" line, which is line 2 here.
	if n := countGreenishIn(img, 0, e.gutterWidth, 2*lineHeight, 3*lineHeight); n < 8 {
		t.Fatalf("no run button painted in the gutter on the func main() line (%d green pixels)", n)
	}
	// ...and nowhere else, so a stray marker on every line would be caught.
	if n := countGreenishIn(img, 0, e.gutterWidth, 0, 2*lineHeight); n != 0 {
		t.Fatalf("a run button appeared above the main function (%d pixels)", n)
	}
}

// TestGutterFoldButtonAndCollapse pins folding: the brace detector must turn a
// braced function into a fold range, the fold button must be drawn for it, and
// collapsing must hide the body from the layout (the rendered content gets
// shorter).
func TestGutterFoldButtonAndCollapse(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tprintln(1)\n\tprintln(2)\n}\n"
	h, _, folds, _ := newGutterFeatureHarness(t, content, image.Pt(420, 200))
	e := h.ed

	ranges := folds.GetFoldRanges()
	found := false
	for _, r := range ranges {
		if r.StartLine == 2 {
			found = true
		}
	}
	if !found {
		t.Fatalf("no fold range was detected for the func body: %+v", ranges)
	}

	h.frame(true)
	expanded := image.NewRGBA(image.Rect(0, 0, 420, 200))
	if err := h.win.Screenshot(expanded); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dir := screenshotDir(t)
	dumpPNG(t, dir, "gvcode-gutter-folding-expanded", expanded)

	heightBefore := len(e.text.TextLayout().Paragraphs)
	if !folds.CollapseFold(2) {
		t.Fatal("CollapseFold reported no change for the detected range")
	}
	for range 2 {
		h.frame(true)
	}
	if folds.IsLineVisible(4) {
		t.Fatal("the folded body is still reported visible")
	}
	// The layout must drop the hidden paragraphs from what it tracks, otherwise
	// the collapsed body keeps rendering.
	if heightAfter := len(e.text.TextLayout().Paragraphs); heightAfter >= heightBefore {
		t.Fatalf("collapsing did not drop the hidden paragraphs: %d -> %d", heightBefore, heightAfter)
	}

	h.frame(true)
	collapsed := image.NewRGBA(image.Rect(0, 0, 420, 200))
	if err := h.win.Screenshot(collapsed); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, dir, "gvcode-gutter-folding-collapsed", collapsed)

	// Only the body folds, so the closing brace stays on screen and moves up into
	// the band the body's first line occupied; anything below is blank.
	textColor := color.NRGBA{R: 0xd4, G: 0xd4, B: 0xd4, A: 0xff}
	lineHeight := e.text.GetLineHeight().Round()
	band := func(line int) (int, int) { return line * lineHeight, (line + 1) * lineHeight }
	textAt := func(img *image.RGBA, line int) int {
		y0, y1 := band(line)
		return countColorIn(img, e.gutterWidth, 420, y0, y1, textColor)
	}
	if textAt(collapsed, 2) == 0 {
		t.Fatal("the folded header vanished")
	}
	if textAt(collapsed, 3) == 0 {
		t.Fatal("the closing brace did not stay visible after collapsing")
	}
	// The expanded frame holds text where the body is, so the blank bands above
	// are not just an empty document.
	if textAt(expanded, 4) == 0 {
		t.Fatal("the expanded frame has no text where the body should be")
	}
	for line := 4; line <= 5; line++ {
		if n := textAt(collapsed, line); n != 0 {
			t.Fatalf("line %d is still painted (%d text pixels) although the fold hides it", line, n)
		}
	}
	// A collapsed fold must show the placeholder IntelliJ draws for a folded
	// region: a decorative glyph (Runes == 0) appended after the header's text.
	placeholder := func() bool {
		for _, line := range e.text.TextLayout().Lines {
			for _, g := range line.Glyphs {
				if g.Runes == 0 {
					return true
				}
			}
		}
		return false
	}
	if !placeholder() {
		t.Fatal("the collapsed fold shows no placeholder")
	}
}

// TestGutterLineNumbersAreLogical pins line numbers to the document's numbering:
// folding the function body hides lines 4 and 5, but the closing brace on line 6
// must still be numbered 6 rather than renumbered to 4. IntelliJ numbers by the
// logical line, so a collapsed fold never changes another line's number.
func TestGutterLineNumbersAreLogical(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tprintln(1)\n\tprintln(2)\n}\n"
	h, _, folds, _ := newGutterFeatureHarness(t, content, image.Pt(420, 200))
	e := h.ed

	// The document holds seven paragraphs (the trailing newline leaves an empty
	// one), and the closing brace is the sixth: visible index 5, logical index 5.
	paras := e.text.TextLayout().Paragraphs
	if len(paras) != 7 || paras[5].LogicalIndex != 5 {
		t.Fatalf("unexpected expanded layout: %d paragraphs, brace logical index %d",
			len(paras), paras[5].LogicalIndex)
	}

	h.frame(true)
	expanded := image.NewRGBA(image.Rect(0, 0, 420, 200))
	if err := h.win.Screenshot(expanded); err != nil {
		t.Fatalf("screenshot: %v", err)
	}

	if !folds.CollapseFold(2) {
		t.Fatal("CollapseFold reported no change for the detected range")
	}
	for range 2 {
		h.frame(true)
	}

	paras = e.text.TextLayout().Paragraphs
	if len(paras) != 5 {
		t.Fatalf("visible paragraph count after collapsing = %d, want 5", len(paras))
	}
	if got := paras[3].LogicalIndex; got != 5 {
		t.Fatalf("after collapsing, the closing brace carries logical index %d, want 5", got)
	}

	collapsed := image.NewRGBA(image.Rect(0, 0, 420, 200))
	if err := h.win.Screenshot(collapsed); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-gutter-logical-linenumbers", collapsed)

	// The brace sits on visible paragraph 5 while expanded, and moves up to
	// visible paragraph 3 once the body is hidden. Its gutter number must read the
	// same "6" in both bands, which is what logical numbering buys.
	numRect, ok := e.GutterManager().ProviderBounds(gutter.LineNumberProviderID)
	if !ok {
		t.Fatal("the line number column was never laid out")
	}
	lineHeight := e.text.GetLineHeight().Round()
	if !gutterBandEqual(expanded, collapsed, numRect.Min.X, numRect.Max.X, 5, 3, lineHeight) {
		t.Fatal("the closing brace was renumbered after collapsing the fold")
	}
}

// TestGutterColumnOrder pins the gutter's column order: the line numbers, then
// the run buttons, then the fold chevrons hugging the code, the way IntelliJ
// stacks its gutter columns.
func TestGutterColumnOrder(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tprintln(1)\n}\n"
	h, _, _, _ := newGutterFeatureHarness(t, content, image.Pt(420, 200))
	e := h.ed
	h.frame(true)

	numbers, ok := e.GutterManager().ProviderBounds(gutter.LineNumberProviderID)
	if !ok {
		t.Fatal("the line number column was never laid out")
	}
	run, ok := e.GutterManager().ProviderBounds(providers.RunButtonProviderID)
	if !ok {
		t.Fatal("the run button column was never laid out")
	}
	fold, ok := e.GutterManager().ProviderBounds(providers.FoldButtonProviderID)
	if !ok {
		t.Fatal("the fold button column was never laid out")
	}

	if run.Min.X < numbers.Max.X {
		t.Fatalf("the run button column (%v) is not right of the line numbers (%v)", run, numbers)
	}
	if fold.Min.X < run.Max.X {
		t.Fatalf("the fold column (%v) is not right of the run buttons (%v)", fold, run)
	}
}

// gutterBandEqual reports whether the gutter pixels of one frame's line band
// match another frame's band. It compares a line number drawn at two different
// vertical positions; the rasteriser quantises coverage per absolute position, so
// a couple of levels of antialiasing noise are tolerated while a different digit
// (a different glyph) stands out far beyond that.
func gutterBandEqual(a, b *image.RGBA, x0, x1, bandA, bandB, lineHeight int) bool {
	if (bandA+1)*lineHeight > a.Bounds().Dy() || (bandB+1)*lineHeight > b.Bounds().Dy() {
		return false
	}
	const tolerance = 3
	for y := range lineHeight {
		for x := x0; x < x1; x++ {
			ar, ag, ab, _ := a.At(x, bandA*lineHeight+y).RGBA()
			br, bg, bb, _ := b.At(x, bandB*lineHeight+y).RGBA()
			if absInt(int(ar>>8)-int(br>>8)) > tolerance ||
				absInt(int(ag>>8)-int(bg>>8)) > tolerance ||
				absInt(int(ab>>8)-int(bb>>8)) > tolerance {
				return false
			}
		}
	}
	return true
}

func absInt(v int) int {
	if v < 0 {
		return -v
	}
	return v
}

// TestGutterFoldButtonClickCollapses drives a real pointer press+release at the
// chevron, the way a user collapses a region, and checks both the editor state
// and the rendered frame. It also guards the gutter manager's routing: the click
// must reach the provider exactly once, so the fold flips instead of toggling
// back and forth.
func TestGutterFoldButtonClickCollapses(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tprintln(1)\n\tprintln(2)\n}\n"
	h, _, folds, _ := newGutterFeatureHarness(t, content, image.Pt(420, 200))
	e := h.ed
	h.frame(true)

	before := image.NewRGBA(image.Rect(0, 0, 420, 200))
	if err := h.win.Screenshot(before); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-gutter-foldbutton-before", before)

	fold, ok := e.GutterManager().ProviderBounds(providers.FoldButtonProviderID)
	if !ok {
		t.Fatal("the fold button column was never laid out")
	}
	lineHeight := e.text.GetLineHeight().Round()
	// The func body's chevron sits on the "func main() {" line: logical line 2,
	// which is the third visible band.
	clickX := fold.Min.X + fold.Dx()/2
	clickY := 2*lineHeight + lineHeight/2
	h.clickGutter(clickX, clickY)

	if folds.IsLineVisible(3) || folds.IsLineVisible(4) {
		t.Fatalf("clicking the chevron did not collapse the body: %+v", folds.GetFoldRanges())
	}
	if !folds.IsLineVisible(2) || !folds.IsLineVisible(5) {
		t.Fatal("collapsing hid the header or the closing brace")
	}

	after := image.NewRGBA(image.Rect(0, 0, 420, 200))
	if err := h.win.Screenshot(after); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-gutter-foldbutton-collapsed", after)

	// The collapse must be visible: the band the body occupied is blank now but
	// held text before.
	textColor := color.NRGBA{R: 0xd4, G: 0xd4, B: 0xd4, A: 0xff}
	band := func(img *image.RGBA, line int) int {
		return countColorIn(img, e.gutterWidth, 420, line*lineHeight, (line+1)*lineHeight, textColor)
	}
	if band(before, 4) == 0 {
		t.Fatal("the expanded frame has no text where the body should be")
	}
	if band(after, 4) != 0 {
		t.Fatal("the collapsed frame still paints the hidden body")
	}
}

// TestGutterRunButtonClickEmitsEvent drives a real pointer click on the run
// marker and checks the editor hands the application a run event for the main
// function — exactly once, so the button is not wired up twice.
func TestGutterRunButtonClickEmitsEvent(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tprintln(42)\n}\n"
	h, _, _, _ := newGutterFeatureHarness(t, content, image.Pt(420, 200))
	e := h.ed
	h.frame(true)

	run, ok := e.GutterManager().ProviderBounds(providers.RunButtonProviderID)
	if !ok {
		t.Fatal("the run button column was never laid out")
	}
	lineHeight := e.text.GetLineHeight().Round()
	clickX := run.Min.X + run.Dx()/2
	clickY := 2*lineHeight + lineHeight/2
	events := h.clickGutter(clickX, clickY)

	img := image.NewRGBA(image.Rect(0, 0, 420, 200))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-gutter-runbutton-clicked", img)

	var runs []gutter.RunButtonEvent
	for _, ev := range events {
		if wrapper, ok := ev.(RunButtonEventWrapper); ok {
			runs = append(runs, wrapper.Event)
		}
	}
	if len(runs) != 1 {
		t.Fatalf("run button emitted %d events, want exactly 1 (%+v)", len(runs), runs)
	}
	if runs[0].ButtonType != gutter.RunButtonMain || runs[0].Line != 2 {
		t.Fatalf("run event = %+v, want the main function on line 2", runs[0])
	}
}

// stickyStressDocument builds a document of n four-line functions, so there is
// plenty to scroll through and the sticky band has a deep stack to show.
func stickyStressDocument(n int) string {
	var b strings.Builder
	b.WriteString("package main\n\n")
	for i := range n {
		b.WriteString("func f" + strconv.Itoa(i) + "() {\n")
		b.WriteString("\tprintln(1)\n\tprintln(2)\n}\n\n")
	}
	return b.String()
}

// paragraphTopY returns the viewport-relative top of the paragraph showing the
// given DOCUMENT line, and fails when that line is not on screen.
func paragraphTopY(t *testing.T, e *Editor, line int) int {
	t.Helper()
	for _, p := range e.text.TextLayout().Paragraphs {
		if p.LogicalIndex == line {
			return p.StartY - e.text.ScrollOff().Y
		}
	}
	t.Fatalf("document line %d is not on screen", line)
	return 0
}

// TestGutterStickyLineClickNavigatesSmoothly stress-tests the sticky band: every
// row is clicked repeatedly, and each click must navigate to the declaration it
// shows, leave that declaration visible BELOW the band instead of hidden behind
// it, keep the view settled afterwards, and never move the caret into the text
// underneath.
func TestGutterStickyLineClickNavigatesSmoothly(t *testing.T) {
	content := stickyStressDocument(40)
	h, _, _, sticky := newGutterFeatureHarness(t, content, image.Pt(420, 160))
	e := h.ed

	lineHeight := e.text.GetLineHeight().Round()
	scrollIntoDocument := func() {
		e.text.ScrollRel(0, 60*lineHeight)
		for range 2 {
			h.frame(true)
		}
	}
	scrollIntoDocument()

	band, bandHeight := sticky.StickyLines()
	if len(band) == 0 {
		t.Fatal("no sticky lines after scrolling into the document")
	}
	if bandHeight != len(band)*lineHeight {
		t.Fatalf("band height %d does not match %d lines of %d px", bandHeight, len(band), lineHeight)
	}

	clickX := e.gutterWidth + 20
	const rounds = 3
	for round := range rounds {
		// Clicking walks the view upwards, so a round may start with an empty band.
		if band, _ := sticky.StickyLines(); len(band) == 0 {
			scrollIntoDocument()
		}

		// The band can change as clicking navigates, so it is re-read for every
		// row instead of being captured once.
		for row := 0; ; row++ {
			band, _ = sticky.StickyLines()
			if row >= len(band) {
				break
			}
			want := band[row]

			selBefore, _ := e.text.Selection()
			events := h.clickGutter(clickX, row*lineHeight+lineHeight/2)

			var got []gutter.StickyLineEvent
			for _, ev := range events {
				if wrapper, ok := ev.(StickyLineEventWrapper); ok {
					got = append(got, wrapper.Event)
				}
			}
			if len(got) != 1 || got[0].Line != want.Line {
				t.Fatalf("round %d row %d: events = %+v, want exactly one for line %d (band %+v)",
					round, row, got, want.Line, band)
			}
			if selAfter, _ := e.text.Selection(); selAfter != selBefore {
				t.Fatalf("round %d row %d: clicking the band moved the caret (%d -> %d)",
					round, row, selBefore, selAfter)
			}

			// The declaration has to end up below the band, otherwise the click
			// looks like it did nothing.
			top := paragraphTopY(t, e, want.Line)
			if top < stickyBandHeight(sticky)-1 {
				t.Fatalf("round %d row %d: line %d ended up hidden behind the band (top %d, band %d)",
					round, row, want.Line, top, stickyBandHeight(sticky))
			}
			if top >= 160 {
				t.Fatalf("round %d row %d: line %d is off screen (top %d)", round, row, want.Line, top)
			}

			// ...and the view must settle: further frames must not scroll or
			// re-shuffle the band. That is what a user perceives as smoothness.
			settledScroll := e.text.ScrollOff().Y
			settledBand, settledHeight := sticky.StickyLines()
			settled := append([]gutter.StickyLineInfo(nil), settledBand...)
			for range 3 {
				h.frame(true)
			}
			if got := e.text.ScrollOff().Y; got != settledScroll {
				t.Fatalf("round %d row %d: the view kept scrolling after the click (%d -> %d)",
					round, row, settledScroll, got)
			}
			bandNow, heightNow := sticky.StickyLines()
			if heightNow != settledHeight || len(bandNow) != len(settled) {
				t.Fatalf("round %d row %d: the band kept changing after the click (%d rows/%d px -> %d rows/%d px)",
					round, row, len(settled), settledHeight, len(bandNow), heightNow)
			}
			for i := range settled {
				if bandNow[i].Line != settled[i].Line {
					t.Fatalf("round %d row %d: the band rows changed after the click (%+v -> %+v)",
						round, row, settled, bandNow)
				}
			}
		}
	}

	img := image.NewRGBA(image.Rect(0, 0, 420, 160))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-gutter-stickylines-clicked", img)
}

// stickyBandHeight returns the current height of the sticky band.
func stickyBandHeight(sticky *providers.StickyLinesProvider) int {
	_, height := sticky.StickyLines()
	return height
}

// TestGutterStickyClickBelowTheBandBelongsToTheText: a click under the band is an
// ordinary caret click. The band used to register its input area over the whole
// text area, so such a click both moved the caret and jumped somewhere else.
func TestGutterStickyClickBelowTheBandBelongsToTheText(t *testing.T) {
	content := stickyStressDocument(40)
	h, _, _, sticky := newGutterFeatureHarness(t, content, image.Pt(420, 200))
	e := h.ed

	e.text.ScrollRel(0, 60*e.text.GetLineHeight().Round())
	for range 2 {
		h.frame(true)
	}

	lineHeight := e.text.GetLineHeight().Round()
	_, bandHeight := sticky.StickyLines()
	if bandHeight == 0 {
		t.Fatal("no sticky band to click under")
	}

	selBefore, _ := e.text.Selection()
	events := h.clickGutter(e.gutterWidth+20, bandHeight+lineHeight/2)
	for _, ev := range events {
		if wrapper, ok := ev.(StickyLineEventWrapper); ok {
			t.Fatalf("a click below the band produced a sticky event: %+v", wrapper.Event)
		}
	}
	if selAfter, _ := e.text.Selection(); selAfter == selBefore {
		t.Fatal("a click below the sticky band did not move the caret")
	}
}

// TestGutterDocumentIsReadOncePerChange guards the per-frame cost of the gutter:
// the providers that analyse the whole document must not make the editor read and
// split the file again while the text is unchanged.
func TestGutterDocumentIsReadOncePerChange(t *testing.T) {
	content := stickyStressDocument(20)
	h, _, _, _ := newGutterFeatureHarness(t, content, image.Pt(420, 160))
	e := h.ed

	h.frame(true)
	if len(e.gutterLines) == 0 {
		t.Fatal("the gutter document was never read")
	}
	first := &e.gutterLines[0]
	for range 5 {
		h.frame(true)
	}
	if len(e.gutterLines) == 0 || &e.gutterLines[0] != first {
		t.Fatal("the document was read and split again although the text did not change")
	}

	// An edit has to refresh the cache, otherwise the providers would keep
	// analysing stale text.
	h.pressText("x")
	h.frame(true)
	h.frame(true)
	if &e.gutterLines[0] == first {
		t.Fatal("the document was not re-read after the text changed")
	}
}

// TestGutterCaretCannotEnterCollapsedFold pins IntelliJ's rule that the caret
// never sits inside collapsed code: an offset inside the hidden body snaps back to
// the region's start, and one arrow press jumps the whole region.
func TestGutterCaretCannotEnterCollapsedFold(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tprintln(1)\n\tprintln(2)\n}\n"
	h, _, folds, _ := newGutterFeatureHarness(t, content, image.Pt(420, 200))
	e := h.ed
	h.frame(true)

	if !folds.CollapseFold(2) {
		t.Fatal("CollapseFold reported no change for the detected range")
	}
	for range 2 {
		h.frame(true)
	}

	// Lines 3 and 4 are hidden. The region starts where the first hidden line
	// begins, which is also where the header line ends.
	foldStart := runeOffsetOfDocumentLine(content, 3)
	closing := runeOffsetOfDocumentLine(content, 5)

	inside := runeOffsetOfDocumentLine(content, 4) + 5
	if inside >= closing {
		t.Fatalf("bad fixture: offset %d is not inside the collapsed body", inside)
	}
	e.SetCaret(inside, inside)
	h.frame(true)
	if got, _ := e.text.Selection(); got != foldStart {
		t.Fatalf("caret landed at %d after asking for %d inside the collapsed body, want the region start %d",
			got, inside, foldStart)
	}

	// The whole region is jumped in one press, in both directions.
	e.SetCaret(foldStart, foldStart)
	h.frame(true)
	h.pressKey(key.NameRightArrow, 0)
	h.frame(true)
	if got, _ := e.text.Selection(); got != closing {
		t.Fatalf("right arrow from the region start landed at %d, want the closing line %d (the fold must be jumped whole)",
			got, closing)
	}
	h.pressKey(key.NameLeftArrow, 0)
	h.frame(true)
	if got, _ := e.text.Selection(); got != foldStart {
		t.Fatalf("left arrow from the closing line landed at %d, want the region start %d", got, foldStart)
	}
}

// TestGutterFoldGuideLineSpansAnExpandedRegion pins the folding outline: while a
// region is expanded IntelliJ draws a hairline down the fold column from its first
// line to the line that closes it, and drops it once the region is collapsed.
func TestGutterFoldGuideLineSpansAnExpandedRegion(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tprintln(1)\n\tprintln(2)\n}\n"
	h, _, folds, _ := newGutterFeatureHarness(t, content, image.Pt(420, 200))
	e := h.ed
	h.frame(true)

	fold, ok := e.GutterManager().ProviderBounds(providers.FoldButtonProviderID)
	if !ok {
		t.Fatal("the fold button column was never laid out")
	}
	guideX := fold.Min.X + fold.Dx()/2
	lineHeight := e.text.GetLineHeight().Round()

	expanded := image.NewRGBA(image.Rect(0, 0, 420, 200))
	if err := h.win.Screenshot(expanded); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-gutter-fold-guide", expanded)

	inkAt := func(img *image.RGBA, y int) bool {
		r, g, b, _ := img.At(guideX, y).RGBA()
		// Sample the plain background well below the document: the caret's line
		// highlight covers the first row, so it cannot serve as the reference.
		br, bg, bb, _ := img.At(guideX, 190).RGBA()
		return r != br || g != bg || b != bb
	}
	// The guide runs from the header line (2) down to the closing brace (5).
	for line := 3; line <= 5; line++ {
		if !inkAt(expanded, line*lineHeight+lineHeight/2) {
			t.Fatalf("no fold guide line at line %d, x %d", line, guideX)
		}
	}

	if !folds.CollapseFold(2) {
		t.Fatal("CollapseFold reported no change for the detected range")
	}
	for range 2 {
		h.frame(true)
	}
	collapsed := image.NewRGBA(image.Rect(0, 0, 420, 200))
	if err := h.win.Screenshot(collapsed); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	// Below the header line the collapsed region leaves no outline behind.
	for line := 3; line <= 5; line++ {
		if inkAt(collapsed, line*lineHeight+lineHeight/2) {
			t.Fatalf("a fold guide line survived the collapse at line %d", line)
		}
	}
}

// TestGutterStickyLinesShowWhenScrolled pins sticky lines: while the viewport is
// scrolled into the middle of a function, the enclosing declaration must be
// offered as a sticky line, and it must be painted in the gutter's top band.
func TestGutterStickyLinesShowWhenScrolled(t *testing.T) {
	var b strings.Builder
	b.WriteString("package main\n\n")
	for i := range 12 {
		b.WriteString("func f" + strconv.Itoa(i) + "() {\n")
		b.WriteString("\tprintln(1)\n\tprintln(2)\n}\n\n")
	}
	content := b.String()

	// A viewport far shorter than the document, so scrolling is meaningful.
	h, _, _, sticky := newGutterFeatureHarness(t, content, image.Pt(420, 120))
	e := h.ed

	// Scroll into the middle of the third function.
	e.text.ScrollRel(0, 10*e.text.GetLineHeight().Round())
	for range 2 {
		h.frame(true)
	}

	lines, _ := sticky.StickyLines()
	if len(lines) == 0 {
		t.Fatal("no sticky line while scrolled inside a function body")
	}

	img := image.NewRGBA(image.Rect(0, 0, 420, 120))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-gutter-stickylines", img)

	// The sticky line is drawn over the text area's first band; the plain
	// background there must differ from the untouched background lower down.
	lineHeight := e.text.GetLineHeight().Round()
	band := img.Bounds()
	_ = band
	top := countColorIn(img, e.gutterWidth, 420, 0, lineHeight, runButtonGreen)
	_ = top
	if !stickyBandDiffers(img, e.gutterWidth, 420, 0, lineHeight) {
		t.Fatal("the sticky line band looks identical to the plain background")
	}
}

// stickyBandDiffers reports whether the given band holds more than the flat
// editor background, i.e. whether something was painted over it.
func stickyBandDiffers(img *image.RGBA, x0, x1, y0, y1 int) bool {
	bg, _, _, _ := img.At(x1-1, y1-1).RGBA()
	diff := 0
	for y := y0; y < y1; y++ {
		for x := x0; x < x1; x++ {
			r, g, b, _ := img.At(x, y).RGBA()
			if r != bg || g != bg || b != bg {
				diff++
			}
		}
	}
	// The text of the sticky line is several glyphs wide.
	return diff > (x1-x0)/8
}
