package gvcode

import (
	"image"
	"strings"
	"testing"

	"gioui.org/io/key"
	"gioui.org/unit"
)

// newPostfixHarness builds a focused editor with the built-in postfix templates,
// the caret at the end of content.
func newPostfixHarness(t *testing.T, content string) (*columnEditHarness, *Editor) {
	t.Helper()
	h := newColumnEditHarness(t, content, image.Pt(520, 160), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	h.ed.WithOptions(DefaultPostfixTemplates())
	h.ed.SetCaret(h.ed.Len(), h.ed.Len())
	h.frame(true)
	return h, h.ed
}

// TestPostfixTemplateTabExpands pins the feature end to end: an expression
// followed by ".if" and a Tab press becomes the template's snippet, the way
// tabbing a postfix completion does in IntelliJ.
func TestPostfixTemplateTabExpands(t *testing.T) {
	h, e := newPostfixHarness(t, "x.if")
	h.pressKey(key.NameTab, 0)
	// One frame delivers the key, the next repaints the expanded snippet.
	h.frame(true)
	h.frame(true)

	want := "if x {\n\t\n}"
	if got := e.Text(); got != want {
		t.Fatalf("after Tab:\n%q\nwant\n%q", got, want)
	}

	img := image.NewRGBA(image.Rect(0, 0, 520, 160))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-postfix-if", img)
}

// TestPostfixTemplateWrapsTheWholeCall checks that the expression the template
// wraps is the whole primary expression, not just the identifier before the dot.
func TestPostfixTemplateWrapsTheWholeCall(t *testing.T) {
	h, e := newPostfixHarness(t, "fetch().err")
	h.pressKey(key.NameTab, 0)
	h.frame(true)

	want := "if err := fetch(); err != nil {\n\treturn \n}"
	if got := e.Text(); got != want {
		t.Fatalf("after Tab:\n%q\nwant\n%q", got, want)
	}
}

// TestPostfixTemplateRequiresAnApplicableKey keeps the applicability test honest:
// ".err" only applies to a call, so tabbing "value.err" must indent as usual
// instead of expanding.
func TestPostfixTemplateRequiresAnApplicableKey(t *testing.T) {
	h, e := newPostfixHarness(t, "value.err")
	h.pressKey(key.NameTab, 0)
	h.frame(true)

	if !strings.Contains(e.Text(), ".err") {
		t.Fatalf("Tab expanded a template that does not apply: %q", e.Text())
	}
}

// TestPostfixTemplateWithoutProviderIsPlainTab guards the default: with no
// provider registered, "x.if" plus Tab must indent, not expand.
func TestPostfixTemplateWithoutProviderIsPlainTab(t *testing.T) {
	h := newColumnEditHarness(t, "x.if", image.Pt(520, 160), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	h.ed.SetCaret(h.ed.Len(), h.ed.Len())
	h.frame(true)

	h.pressKey(key.NameTab, 0)
	h.frame(true)

	if !strings.Contains(h.ed.Text(), ".if") {
		t.Fatalf("Tab expanded a template with no provider registered: %q", h.ed.Text())
	}
}
