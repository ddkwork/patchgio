package gvcode

import (
	"image"
	"io"
	"math"
	"runtime"
	"strings"
	"unicode"
	"unicode/utf8"

	"gioui.org/gesture"
	"gioui.org/io/clipboard"
	"gioui.org/io/event"
	"gioui.org/io/key"
	"gioui.org/io/pointer"
	"gioui.org/io/transfer"
	"gioui.org/layout"
	"github.com/oligo/gvcode/gutter"
	gestureExt "github.com/oligo/gvcode/internal/gesture"
	"github.com/oligo/gvcode/textview"
)

func (e *Editor) processEvents(gtx layout.Context) (ev EditorEvent, ok bool) {
	if len(e.pending) > 0 {
		out := e.pending[0]
		e.pending = e.pending[:copy(e.pending, e.pending[1:])]
		return out, true
	}
	selStart, selEnd := e.Selection()
	defer func() {
		afterSelStart, afterSelEnd := e.Selection()
		if selStart != afterSelStart || selEnd != afterSelEnd {
			// Selection changed - mark word highlighter active regardless
			// of whether SelectEvent is returned now or queued for later
			e.wordHighlighter.MarkActive(true)
			if ok {
				e.pending = append(e.pending, SelectEvent{})
			} else {
				ev = SelectEvent{}
				ok = true
			}
		}

		if isChangeEvent(ev) {
			e.wordHighlighter.MarkActive(false)
			e.updateCompletor()
		} else if _, ok := ev.(SelectEvent); ok {
			e.updateCompletor()
		}
	}()

	ev, ok = e.processPointer(gtx)
	if ok {
		return ev, ok
	}
	ev, ok = e.processKey(gtx)
	if ok {
		return ev, ok
	}
	return nil, false
}

func (e *Editor) processPointer(gtx layout.Context) (EditorEvent, bool) {
	var scrollX, scrollY pointer.ScrollRange
	textDims := e.text.FullDimensions()
	visibleDims := e.text.Dimensions()

	scrollOffX := e.text.ScrollOff().X
	scrollX.Min = -scrollOffX
	scrollX.Max = max(0, textDims.Size.X-(scrollOffX+visibleDims.Size.X))

	scrollOffY := e.text.ScrollOff().Y
	scrollY.Min = -scrollOffY
	scrollY.Max = max(0, textDims.Size.Y-(scrollOffY+visibleDims.Size.Y))
	sbounds := e.text.ScrollBounds()

	var soff, smin, smax int
	sdist := e.scroller.Update(gtx.Metric, gtx.Source, gtx.Now, scrollX, scrollY)
	if e.scroller.Direction() == gestureExt.Horizontal {
		e.text.ScrollRel(sdist, 0)
		soff = e.text.ScrollOff().X
		smin, smax = sbounds.Min.X, sbounds.Max.X
	} else {
		e.text.ScrollRel(0, sdist)
		soff = e.text.ScrollOff().Y
		smin, smax = sbounds.Min.Y, sbounds.Max.Y
	}

	for {
		evt, ok := e.clicker.Update(gtx.Source)
		if !ok {
			break
		}
		ev, ok := e.processPointerEvent(gtx, evt)
		if ok {
			return ev, ok
		}
	}
	for {
		evt, ok := e.dragger.Update(gtx.Metric, gtx.Source, gesture.Both)
		if !ok {
			break
		}
		ev, ok := e.processPointerEvent(gtx, evt)
		if ok {
			return ev, ok
		}
	}

	if (sdist > 0 && soff >= smax) || (sdist < 0 && soff <= smin) {
		e.scroller.Stop()
	}

	// detects hover event.
	hoverEvent, ok := e.hover.Update(gtx)
	if ok {
		switch hoverEvent.Kind {
		case gestureExt.KindHovered:
			line, col, runeOff := e.text.QueryPos(hoverEvent.Position)
			if runeOff >= 0 {
				return HoverEvent{PixelOff: hoverEvent.Position, Pos: Position{Line: line, Column: col, Runes: runeOff}}, ok
			}
		case gestureExt.KindCancelled:
			return HoverEvent{IsCancel: true}, ok
		}
	}

	return nil, false
}

func (e *Editor) processPointerEvent(gtx layout.Context, ev event.Event) (EditorEvent, bool) {
	switch evt := ev.(type) {
	case gesture.ClickEvent:
		switch {
		case evt.Kind == gesture.KindPress && evt.Source == pointer.Mouse,
			evt.Kind == gesture.KindClick && evt.Source != pointer.Mouse:
			clickPos := image.Point{
				X: int(math.Round(float64(evt.Position.X))),
				Y: int(math.Round(float64(evt.Position.Y))),
			}

			// Sticky lines are painted over the first rows of the text area. A
			// click there belongs to the band: it navigates to the declaration it
			// shows. Moving the caret as well would drop it into the text hidden
			// underneath the band, so this click is consumed here.
			if info, ok := e.stickyLineAt(clickPos); ok {
				e.blinkStart = gtx.Now
				e.moveToLine(info.Line)
				gtx.Execute(key.FocusCmd{Tag: e})
				e.pending = append(e.pending, StickyLineEventWrapper{
					Event: gutter.StickyLineEvent{Line: info.Line, Text: info.Text},
				})
				return nil, false
			}

			prevCaretPos, _ := e.text.Selection()
			e.blinkStart = gtx.Now

			// A plain press inside the selection arms a move drag: the selection
			// stays painted, and only a drag past the slop threshold moves the
			// text (see dragtext.go). A click without a drag falls back to
			// placing the caret, which the release path does.
			if evt.NumClicks == 1 && evt.Modifiers == 0 && e.armedTextMove(clickPos) {
				e.startTextMove(clickPos)
				gtx.Execute(key.FocusCmd{Tag: e})
				return nil, false
			}
			// Ctrl+Click adds a caret instead of moving the primary one, the way
			// IntelliJ's "add caret on Ctrl+Click" works; a plain click collapses
			// the extra carets again.
			if e.mode != ModeReadOnly && evt.Modifiers.Contain(key.ModShortcut) {
				// The primary caret stays where it was; the click adds one more.
				primaryStart, primaryEnd := e.text.Selection()
				e.text.MoveCoord(clickPos)
				clicked, _ := e.text.Selection()
				// Restore the primary before adding: adding compares the new caret
				// against the primary one and would otherwise drop it.
				e.text.SetCaret(primaryStart, primaryEnd)
				e.addCaretAt(clicked)
				gtx.Execute(key.FocusCmd{Tag: e})
				return nil, false
			}
			if e.MultiCaretEnabled() {
				e.clearMultiCarets()
			}
			e.text.MoveCoord(clickPos)
			gtx.Execute(key.FocusCmd{Tag: e})
			if e.mode != ModeReadOnly {
				gtx.Execute(key.SoftKeyboardCmd{Show: true})
			}
			if e.scroller.State() != gestureExt.StateFlinging {
				e.scrollCaret = true
			}

			// Alt+mouse drag for column selection. Column Selection Mode
			// (Alt+Shift+Insert) turns the same rectangle selection on for a plain
			// drag, which is the whole point of the mode.
			if evt.Modifiers.Contain(key.ModAlt) || e.columnSelectionMode {
				e.SetColumnEditMode(true)
				e.startColumnSelection(image.Point{
					X: int(math.Round(float64(evt.Position.X))),
					Y: int(math.Round(float64(evt.Position.Y))),
				})
			} else if evt.Modifiers == key.ModShift {
				start, end := e.text.Selection()
				// If they clicked closer to the end, then change the end to
				// where the caret used to be (effectively swapping start & end).
				if abs(end-start) < abs(start-prevCaretPos) {
					e.text.SetCaret(start, prevCaretPos)
				}
			} else {
				e.text.ClearSelection()
			}
			e.dragging = true

			// Process multi-clicks.
			switch {
			case evt.NumClicks == 2:
				e.text.MoveWords(-1, textview.SelectionClear)
				e.text.MoveWords(1, textview.SelectionExtend)
				e.dragging = false
			case evt.NumClicks >= 3:
				e.text.MoveLineStart(textview.SelectionClear)
				e.text.MoveLineEnd(textview.SelectionExtend)
				e.dragging = false
			}

			if e.completor != nil {
				e.completor.Cancel()
			}
			// switch to normal mode when clicked.
			if e.mode == ModeSnippet {
				e.setMode(ModeNormal)
			}
		}
	case pointer.Event:
		release := false
		switch {
		case evt.Kind == pointer.Release && evt.Source == pointer.Mouse:
			release = true
			fallthrough
		case evt.Kind == pointer.Drag && evt.Source == pointer.Mouse:
			dragPos := image.Point{
				X: int(math.Round(float64(evt.Position.X))),
				Y: int(math.Round(float64(evt.Position.Y))),
			}
			// A move drag takes precedence: the press armed it, so the usual
			// selection-extending path must not run.
			if e.updateTextMove(gtx, dragPos) {
				e.blinkStart = gtx.Now
				if release {
					return e.finishTextMove()
				}
				return nil, false
			}
			if e.dragging {
				e.blinkStart = gtx.Now
				// If column edit mode is active, update column selection
				if e.ColumnEditEnabled() {
					e.updateColumnSelection(gtx, image.Point{
						X: int(math.Round(float64(evt.Position.X))),
						Y: int(math.Round(float64(evt.Position.Y))),
					})
				} else {
					e.text.MoveCoord(image.Point{
						X: int(math.Round(float64(evt.Position.X))),
						Y: int(math.Round(float64(evt.Position.Y))),
					})
				}
				e.scrollCaret = true

				if release {
					e.dragging = false
				}
			}
		}
	}
	return nil, false
}

func (e *Editor) processKey(gtx layout.Context) (EditorEvent, bool) {
	if e.text.Changed() {
		return ChangeEvent{}, true
	}

	if evt := e.processEditEvents(gtx); evt != nil {
		return evt, true
	}

	if evt := e.processCommands(gtx); evt != nil {
		// The command already reported this change; consume the buffer flag so
		// the next Update call does not report it again.
		if isChangeEvent(evt) {
			e.text.Changed()
		}
		return evt, true
	}

	if e.text.Changed() {
		return ChangeEvent{}, true
	}

	return nil, false
}

func isChangeEvent(evt EditorEvent) bool {
	switch evt.(type) {
	case ChangeEvent, *ChangeEvent:
		return true
	default:
		return false
	}
}

func (e *Editor) processEditEvents(gtx layout.Context) EditorEvent {
	filters := []event.Filter{
		key.FocusFilter{Target: e},
		transfer.TargetFilter{Target: e, Type: "application/text"},
	}

	for {
		evt, ok := gtx.Event(filters...)
		if !ok {
			break
		}

		e.blinkStart = gtx.Now

		switch ke := evt.(type) {
		case key.FocusEvent:
			e.resetIME()
			if ke.Focus && e.mode != ModeReadOnly {
				gtx.Execute(key.SoftKeyboardCmd{Show: true})
			}
		case key.SnippetEvent:
			e.updateSnippet(gtx, ke.Start, ke.End)
		case key.EditEvent:
			e.onTextInput(ke)
		case key.CompositionEvent:
			// Since v0.10.1, gio delivers IME composition event. During composition stage,
			// range marks the current text range of composition. When composition confirmed/canceled,
			// range becomes (-1, -1).
			// When there is no IME for text input, no CompositionEvent is delivered.
			e.ime.composition = key.Range(ke)

			isStart := false
			isFinish := false

			if ke.Start != -1 && ke.Start != ke.End {
				if !e.ime.isComposing {
					isStart = true
				}
				e.ime.isComposing = true
			} else {
				if e.ime.isComposing {
					isFinish = true
				}
				e.ime.isComposing = false
			}

			// GroupOp and UnGroupOp must be paired.
			if isStart {
				// composition started, ensure the undo transaction has started, and all text of a IME composition
				// can be undone in a batch.
				e.buffer.GroupOp()
			}

			if isFinish {
				// composition is done, seal the undo transaction.
				e.buffer.UnGroupOp()
			}

		case key.SelectionEvent:
			e.scrollCaret = true
			e.scroller.Stop()
			e.text.SetCaret(ke.Start, ke.End)

			// Complete a paste event, initiated by Shortcut-V in Editor.command().
		case transfer.DataEvent:
			if evt := e.onPasteEvent(ke); evt != nil {
				return evt
			}
		}
	}
	if e.text.Changed() {
		return ChangeEvent{}
	}

	return nil
}

// updateSnippet queues a key.SnippetCmd if the snippet content or position
// have changed. off and len are in runes.
func (e *Editor) updateSnippet(gtx layout.Context, start, end int) {
	if start > end {
		start, end = end, start
	}
	length := e.text.Len()
	if start > length {
		start = length
	}
	if end > length {
		end = length
	}
	e.ime.start = start
	e.ime.end = end
	startOff := e.text.ByteOffset(start)
	endOff := e.text.ByteOffset(end)
	n := endOff - startOff
	if n > int64(len(e.ime.scratch)) {
		e.ime.scratch = make([]byte, n)
	}
	scratch := e.ime.scratch[:n]
	read, _ := e.buffer.ReadAt(scratch, startOff)

	if read != len(scratch) {
		panic("e.rr.Read truncated data")
	}
	newSnip := key.Snippet{
		Start: e.ime.start,
		End:   e.ime.end,
		Text:  e.ime.snippet.Text,
	}
	if string(scratch) != newSnip.Text {
		newSnip.Text = string(scratch)
	}
	if newSnip == e.ime.snippet {
		return
	}
	e.ime.snippet = newSnip
	gtx.Execute(key.SnippetCmd{Tag: e, Snippet: newSnip})
}

func (e *Editor) onCopyCut(gtx layout.Context, k key.Event) EditorEvent {
	// A column block has no textview selection, so it would fall through to the
	// whole-line branch below. Copy the BLOCK instead: one padded line per
	// covered line, which is what makes a block paste column-aligned.
	if e.ColumnEditEnabled() {
		if text, ok := e.columnBlockText(); ok {
			gtx.Execute(clipboard.WriteCmd{Type: "application/text", Data: normalizeCopyContent(text)})
			if k.Name == "X" && e.mode != ModeReadOnly {
				if e.Delete(1) != 0 {
					return ChangeEvent{}
				}
			}
			return nil
		}
	}

	lineOp := false
	if e.text.SelectionLen() == 0 {
		lineOp = true
		e.scratch, _, _ = e.text.SelectedLineText(e.scratch)
		if len(e.scratch) > 0 && e.scratch[len(e.scratch)-1] != '\n' {
			e.scratch = append(e.scratch, '\n')
		}
	} else {
		e.scratch = e.text.SelectedText(e.scratch)
	}

	if text := string(e.scratch); text != "" {
		gtx.Execute(clipboard.WriteCmd{Type: "application/text", Data: normalizeCopyContent(text)})
		if k.Name == "X" && e.mode != ModeReadOnly {
			if !lineOp {
				if e.Delete(1) != 0 {
					return ChangeEvent{}
				}
			} else {
				if e.DeleteLine() != 0 {
					return ChangeEvent{}
				}
			}
		}
	}

	return nil
}

// normalizeCopyContent convert CRLF text to OS-native line ending character, so other apps
// can read and display it right.
func normalizeCopyContent(text string) io.ReadCloser {
	if runtime.GOOS == "windows" {
		return io.NopCloser(strings.NewReader(ToCRLF(text)))
	}

	return io.NopCloser(strings.NewReader(text))
}

// onTab handles tab key event. If there is no selection of lines, intert a tab character
// at position of the cursor, else indent or unindent the selected lines, depending on if
// the event contains the shift modifier.
func (e *Editor) onTab(k key.Event) EditorEvent {
	if e.mode == ModeReadOnly {
		return nil
	}

	shiftPressed := k.Modifiers.Contain(key.ModShift)

	if e.mode == ModeSnippet {
		if shiftPressed {
			e.snippetCtx.PrevTabStop()
		} else {
			e.snippetCtx.NextTabStop()
		}
		return nil
	}

	// Smart keys: with the caret right before a closing bracket or quote and
	// nothing selected, Tab jumps past it instead of indenting — IntelliJ's
	// "jump outside closing bracket/quote" (CodeInsightSettings
	// .JUMP_OUTSIDE_ON_SMART_TYPE).
	if !shiftPressed {
		// A ".key" right before the caret expands its postfix template, which is
		// IntelliJ's Tab behaviour for postfix completion.
		if e.expandPostfixTemplate() {
			e.text.MoveCaret(0, 0)
			return ChangeEvent{}
		}
		if e.tabOutOfBracket() {
			e.text.MoveCaret(0, 0)
			return nil
		}
	}

	if e.text.IndentLines(shiftPressed) > 0 {
		// Reset xoff.
		e.text.MoveCaret(0, 0)
		e.scrollCaret = true
		return ChangeEvent{}
	}

	return nil

}

func (e *Editor) onTextInput(ke key.EditEvent) {
	if e.mode == ModeReadOnly {
		return
	}

	// Multi-caret: the text goes to every caret at once.
	if e.MultiCaretEnabled() {
		e.multiCaretInsert(ke.Text)
		e.lastInput = &ke
		finalStart, finalEnd := e.Selection()
		e.snippetCtx.OnInsertAt(finalStart, finalEnd)
		return
	}

	// In column editing mode the typed text belongs to every caret at once and
	// must land INSIDE the selection rectangle. The single main caret lives
	// outside it, so falling through would type at the wrong place entirely.
	if e.ColumnEditEnabled() && len(e.columnEdit.selections) > 0 && ke.Text != "" &&
		e.onColumnEditInsert(ke.Text) {
		e.lastInput = &ke
		return
	}

	// When the input is from IME, backspace key event will not go to Gio.
	// Instead the editor will receive updated IME pre-edit text vai EditEvent,
	// until all pre-edit characters are deleted, so we need to handle empty input here.
	if ke.Text == "" {
		e.replace(ke.Range.Start, ke.Range.End, "")

		e.scrollCaret = true
		e.scroller.Stop()
		// Reset caret xoff.
		e.text.MoveCaret(0, 0)
		// record lastInput for auto-complete.
		e.lastInput = &ke

		// If there is an ongoing snippet context, check if the edit is inside of
		// a tabstop.
		finalStart, finalEnd := e.Selection()
		e.snippetCtx.OnInsertAt(finalStart, finalEnd)
		return
	}

	// call text input hook
	if e.onTextInputHook != nil && e.onTextInputHook(e, ke) {
		e.scrollCaret = true
		e.scroller.Stop()
		e.text.MoveCaret(0, 0)
		e.lastInput = &ke

		finalStart, finalEnd := e.Selection()
		e.snippetCtx.OnInsertAt(finalStart, finalEnd)
		return
	}

	if e.autoInsertions == nil {
		e.autoInsertions = make(map[int]rune)
	}

	// check if the input character is a bracket or a quote.
	r, sz := utf8.DecodeRuneInString(ke.Text)
	if sz == 0 {
		// invalid input
		return
	}

	counterpart, isOpening := e.text.BracketsQuotes.GetCounterpart(r)

	if counterpart > 0 && isOpening {
		// Assume we will auto-insert by default.
		shouldAutoInsert := true

		if counterpart != r {
			// only check the next char.
			if e.isNearWordChar(ke.Range.Start, false) {
				shouldAutoInsert = false
			}
		} else {
			// check both the previous and next char.
			if e.isNearWordChar(ke.Range.Start, true) || e.isNearWordChar(ke.Range.Start, false) {
				shouldAutoInsert = false
			}
		}

		replaced := ke.Text
		if shouldAutoInsert {
			replaced += string(counterpart)
		}

		e.replace(ke.Range.Start, ke.Range.End, replaced)
		if shouldAutoInsert {
			e.text.MoveCaret(-1, -1)
			start, _ := e.text.Selection() // start and end should be the same
			e.autoInsertions[start] = counterpart
		}

	} else if counterpart > 0 {
		// The input character is a bracket or a quote, but it is a closing part.
		//
		// check if we can just move the cursor to the next position
		// if the input is a just inserted closing part.
		nextRune, err := e.text.ReadRuneAt(ke.Range.Start)

		if err == nil && nextRune == e.autoInsertions[ke.Range.Start] {
			e.text.MoveCaret(1, 1)
			delete(e.autoInsertions, ke.Range.Start)
		} else {
			e.replace(ke.Range.Start, ke.Range.End, ke.Text)
		}
	} else {
		e.replace(ke.Range.Start, ke.Range.End, ke.Text)
	}

	e.scrollCaret = true
	e.scroller.Stop()
	// Reset caret xoff.
	e.text.MoveCaret(0, 0)
	// record lastInput for auto-complete.
	e.lastInput = &ke

	// If there is an ongoing snippet context, check if the edit is inside of
	// a tabstop.
	finalStart, finalEnd := e.Selection()
	e.snippetCtx.OnInsertAt(finalStart, finalEnd)

}

func (e *Editor) isNearWordChar(runeOff int, backward bool) bool {
	pos := runeOff
	if backward {
		pos = runeOff - 1
	}

	nearbyChar, err := e.text.ReadRuneAt(pos)
	if err == nil {
		return unicode.IsLetter(nearbyChar) || unicode.IsDigit(nearbyChar) || nearbyChar == '_'
	}

	return false

}

func (e *Editor) currentCompletionCtx() CompletionContext {
	_, end := e.text.Selection()
	input := ""
	if e.lastInput != nil && e.lastInput.Range.End+utf8.RuneCountInString(e.lastInput.Text) == end {
		input = e.lastInput.Text
	}

	ctx := CompletionContext{Input: input}
	ctx.Position.Line, ctx.Position.Column = e.text.CaretPos()
	// scroll off will change after we update the position, so we use doc
	// view position instead of viewport position.
	ctx.Coords = e.text.CaretCoords().Round().Add(e.text.ScrollOff())
	ctx.Position.Runes = end
	e.lastInput = nil
	return ctx
}

// GetCompletionContext returns a context from the current caret position.
// This is usually used in the condition of a key triggered completion.
func (e *Editor) GetCompletionContext() CompletionContext {
	return e.currentCompletionCtx()
}

// updateCompletor should be called after normal keyboard input to update the
// auto completion engine, usually when received a ChangeEvent.
func (e *Editor) updateCompletor() {
	if e.completor == nil {
		return
	}

	ctx := e.currentCompletionCtx()
	if ctx == (CompletionContext{}) {
		return
	}

	e.completor.OnText(ctx)
}

func (e *Editor) onPasteEvent(ke transfer.DataEvent) EditorEvent {
	if e.mode == ModeReadOnly {
		return nil
	}

	e.scrollCaret = true
	e.scroller.Stop()
	content, err := io.ReadAll(ke.Open())
	if err != nil {
		return nil
	}

	text := string(content)
	if e.onPaste != nil {
		text = e.onPaste(text)
	}

	runes := 0
	if e.ColumnEditEnabled() {
		if n, ok := e.onColumnPaste(text); ok {
			if n != 0 {
				return ChangeEvent{}
			}
			return nil
		}
	}
	if isSingleLine(text) {
		runes = e.InsertLine(text)
	} else {
		runes = e.Insert(text)
	}

	if runes != 0 {
		return ChangeEvent{}
	}

	return nil
}

func (e *Editor) onInsertLineBreak(ke key.Event) EditorEvent {
	if e.mode == ModeReadOnly {
		return nil
	}

	if e.onEnterHook != nil && e.onEnterHook(e) {
		e.scrollCaret = true
		e.scroller.Stop()
		e.text.MoveCaret(0, 0)
		return ChangeEvent{}
	}

	// The Enter delegates run first, exactly like IntelliJ's
	// com.intellij.enterHandlerDelegate chain, and tell us how the line break and
	// its indentation should be handled.
	start, _ := e.Selection()
	// forceIndent needs no separate handling: this editor always re-indents on a
	// line break, which is what IntelliJ's DefaultForceIndent asks for.
	ctx, _, skipIndent, stop := e.runEnterHandlers(start)
	if stop {
		e.scrollCaret = true
		e.scroller.Stop()
		return ChangeEvent{}
	}
	if ctx.CaretOffset != start {
		e.text.SetCaret(ctx.CaretOffset, ctx.CaretOffset)
	}

	if skipIndent {
		e.text.Replace(ctx.CaretOffset, ctx.CaretOffset, "\n")
		e.text.SetCaret(ctx.CaretOffset+1, ctx.CaretOffset+1)
	} else {
		e.text.IndentOnBreak("\n")
		if ctx.CaretAdvance > 0 {
			caret, _ := e.Selection()
			e.text.SetCaret(caret+ctx.CaretAdvance, caret+ctx.CaretAdvance)
		}
	}

	// Reset xoff.
	e.scrollCaret = true
	e.scroller.Stop()
	e.text.MoveCaret(0, 0)
	return ChangeEvent{}
}

// onDeleteBackward update the selection when we are deleting the indentation, or
// an auto inserted bracket/quote pair.
func (e *Editor) onDeleteBackward() {
	start, end := e.Selection()
	if start != end || start <= 0 {
		return
	}

	prev, err := e.text.ReadRuneAt(start - 1)
	if err != nil && err != io.EOF {
		panic("Read rune panic: " + err.Error())
	}

	space := ' '
	// When the leading of the line are spaces and tabs, delete up to the
	// number of tab width spaces before the cursor.
	if prev == space {
		// Find the current paragraph.
		var lineStart int
		var hasNonSpaceOrTab bool

		e.scratch, lineStart, _ = e.text.SelectedLineText(e.scratch)

		remaining := e.scratch
		runeCnt := 0
		bytesOff := 0
		for len(remaining) > 0 && runeCnt < end-lineStart {
			r, sz := utf8.DecodeRune(remaining)
			if r != space && r != '\t' {
				hasNonSpaceOrTab = true
				break
			}
			remaining = remaining[sz:]
			runeCnt++
			bytesOff += sz
		}

		if hasNonSpaceOrTab {
			return
		}

		// calculate how many spaces to delete in a key press.
		moves := 0
		leading := e.scratch[:bytesOff]
		for len(leading) > 0 {
			r, sz := utf8.DecodeLastRune(leading)
			if r == '\t' || moves >= e.text.TabWidth {
				break
			}

			moves++
			leading = leading[:len(leading)-sz]
		}

		if moves > 0 {
			e.text.MoveCaret(0, -moves)
		}

	} else {
		// Backspace inside an empty pair deletes both halves — IntelliJ's smart
		// backspace does this for an auto-inserted pair and for an empty one the
		// user typed himself.
		if inserted, exists := e.autoInsertions[start]; exists {
			defer delete(e.autoInsertions, start)
			counterpart, isOpening := e.text.BracketsQuotes.GetCounterpart(inserted)
			if !isOpening && counterpart > 0 || inserted == counterpart {
				if prev == counterpart {
					e.text.MoveCaret(-1, 1)
					return
				}
			}
		}
		if next, err := e.text.ReadRuneAt(start); err == nil && closingPair(prev) == next {
			// prev opens a pair that next closes immediately: nothing between them.
			e.text.MoveCaret(-1, 1)
		}
	}

}
