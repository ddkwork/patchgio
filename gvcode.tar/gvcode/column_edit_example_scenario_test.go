package gvcode

import (
	"fmt"
	"image"
	"os"
	"strings"
	"testing"

	"gioui.org/font"
	"gioui.org/font/opentype"
	"gioui.org/text"
	"gioui.org/unit"
	"golang.org/x/image/font/gofont/gomono"
)

// TestColumnEditExampleAppScenario replicates the REAL example app
// configuration (d:\ux\flowui\patchgio\gvcode\example\main.go): gutter with
// line numbers, code folding, run buttons, sticky lines, WrapLine(true),
// LineHeight 1.5, 12sp text, and the example's own main.go content.
//
// It verifies the "carets must form a straight vertical line" requirement:
// after every Right press, every non-empty selected line's caret must share
// the same pixel X (±2px), even though the content mixes tab indentation and
// ragged line lengths. Movement is leader-lockstep in pixel space, so with a
// monospace font all boundaries sit on the same pixel grid.
//
// The harness ships the Go Proportional fonts, which would silently defeat a
// "monospace" typeface query, so this test builds a Go-Mono-only shaper.
//
// Coordinate spaces: ConvertPos / pointer events are TEXT-LOCAL (x=0 at the
// text area start, after the gutter); the headless screenshot is in SCREEN
// coordinates where the text area starts at gutterWidth (line numbers + gap).
// Every pixel scan therefore offsets by e.gutterWidth.
func TestColumnEditExampleAppScenario(t *testing.T) {
	raw, err := os.ReadFile("example/main.go")
	if err != nil {
		t.Skipf("example/main.go not found: %v", err)
	}
	content := string(raw)

	h := newColumnEditHarness(t, content, image.Pt(1000, 640), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed

	// Swap the harness's proportional-font shaper for a Go Mono only one so
	// the typeface query below really resolves to a monospace face — the same
	// situation as the example app, whose theme shaper resolves the generic
	// "monospace" family against the system font collection.
	monoFaces, err := opentype.ParseCollection(gomono.TTF)
	if err != nil {
		t.Fatalf("parse Go Mono: %v", err)
	}
	h.shaper = text.NewShaper(text.NoSystemFonts(), text.WithCollection(monoFaces))

	e.WithOptions(
		WithFont(font.Font{Typeface: "Go Mono"}),
		WithTextSize(unit.Sp(12)),
		WithLineHeight(0, 1.5),
		WrapLine(true),
		WithGutterGap(unit.Dp(12)),
		WithDefaultGutters(),
		WithRunButtons(),
		WithStickyLines(),
		WithCodeFolding(),
	)
	// Re-warm after the config change so glyph layout matches the options.
	for range 3 {
		h.frame(true)
	}

	gutterW := e.gutterWidth // screen offset of the text area (includes gap)
	lineHeight := e.text.GetLineHeight().Round()
	contentLines := strings.Split(content, "\n")
	totalLines := e.text.Paragraphs()
	if len(contentLines) != totalLines {
		t.Fatalf("paragraph count %d != content lines %d", totalLines, len(contentLines))
	}
	t.Logf("lineHeight=%d paragraphs=%d gutterWidth=%d", lineHeight, totalLines, gutterW)

	pkgLine := -1
	for i, s := range contentLines {
		if strings.HasPrefix(s, "package main") {
			pkgLine = i
			break
		}
	}
	if pkgLine < 0 {
		t.Fatal("package main line not found")
	}

	// Sanity: the resolved font really is monospace — the per-rune advance of
	// the all-ASCII "package main" line must be uniform (±1px of int
	// truncation), otherwise the straight-line assertion below would be
	// meaningless.
	prevX, prevAdv := 0, -1
	for col := 1; col <= 12; col++ {
		_, pos := e.ConvertPos(pkgLine, col)
		x := int(pos.X)
		step := x - prevX
		if step < 3 {
			t.Fatalf("bad advance on col %d: step=%d", col, step)
		}
		if prevAdv >= 0 && (step > prevAdv+1 || step < prevAdv-1) {
			t.Fatalf("font is not monospace: advance step at col %d = %d, want %d±1", col, step, prevAdv)
		}
		prevAdv, prevX = step, x
	}

	// Rectangle mirroring the user's drag: anchor right at ~col 12 of the
	// "package main" line, down-left to col 0 fourteen lines below.
	_, ax := e.ConvertPos(pkgLine, 12)
	endX := int(ax.X)
	bottom := pkgLine + 14
	if bottom >= totalLines {
		bottom = totalLines - 1
	}
	_, bx := e.ConvertPos(bottom, 0)
	startX := int(bx.X)

	e.startColumnSelection(image.Pt(endX, lineHeight*pkgLine))
	e.updateColumnSelection(h.gtx, image.Pt(startX, lineHeight*bottom))
	if len(e.columnEdit.selections) == 0 {
		t.Fatal("no selections created")
	}
	if len(e.columnEdit.selections) != bottom-pkgLine+1 {
		t.Fatalf("selections=%d, want %d", len(e.columnEdit.selections), bottom-pkgLine+1)
	}
	t.Logf("rect lines %d..%d x %d..%d", pkgLine, bottom, startX, endX)
	if endX <= startX {
		t.Fatalf("degenerate rect: startX=%d endX=%d", startX, endX)
	}

	// Snapshot of the initial rect.
	h.frame(true)
	img := image.NewRGBA(image.Rect(0, 0, 1000, 640))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-exampleapp-initial", img)

	bandTop := func(line int) int { return line*lineHeight + 2 }
	bandBot := func(line int) int { return (line+1)*lineHeight - 2 }

	emptyLine := make(map[int]bool)
	for i := pkgLine; i <= bottom; i++ {
		emptyLine[i] = strings.TrimSpace(contentLines[i]) == ""
	}

	caretXOnLine := func(line int) (int, bool) {
		// Scan SCREEN coordinates: text-local range shifted by the gutter.
		return h.caretXByBlinkDiff(t, bandTop(line), bandBot(line),
			gutterW+startX, gutterW+endX+8)
	}

	// Blink-diff sanity: the initial caret must be VISIBLE on every line.
	for line := pkgLine; line <= bottom; line++ {
		if _, ok := caretXOnLine(line); !ok && !emptyLine[line] {
			t.Fatalf("initial state: caret missing on line %d (%q)", line, contentLines[line])
		}
	}

	for press := 1; press <= 30; press++ {
		e.moveColumnCarets(1)

		h.frame(true)
		img := image.NewRGBA(image.Rect(0, 0, 1000, 640))
		if err := h.win.Screenshot(img); err != nil {
			t.Fatalf("screenshot: %v", err)
		}
		dumpPNG(t, screenshotDir(t), fmt.Sprintf("gvcode-exampleapp-press%02d", press), img)

		// Straight-line assertion: on a monospace grid every non-empty
		// selected line's caret must sit on the SAME pixel X (±2px for the
		// blink-diff scan's rightmost-column rounding). Empty lines are
		// exempt: their caret legitimately rests at the line start.
		var report []string
		refX := -1
		for line := pkgLine; line <= bottom; line++ {
			if emptyLine[line] {
				report = append(report, fmt.Sprintf("L%d=empty", line))
				continue
			}
			x, ok := caretXOnLine(line)
			if !ok {
				t.Fatalf("press %d: caret missing on line %d (%q)", press, line, contentLines[line])
			}
			if refX < 0 {
				refX = x
			} else if d := x - refX; d > 2 || d < -2 {
				t.Fatalf("press %d: carets are not a straight line: L%d x=%d vs L%d x=%d (Δ=%d)",
					press, pkgLine, refX, line, x, d)
			}
			report = append(report, fmt.Sprintf("L%d=%d", line, x-gutterW))
		}
		t.Logf("press %2d carets(text-local): %v", press, strings.Join(report, " "))

		if refX >= 0 && refX-gutterW >= endX-2 {
			t.Logf("caret column reached the right edge as a straight line at press %d", press)
			return
		}
	}
	t.Fatalf("caret column never reached the right edge as a straight line (endX=%d)", endX)
}
