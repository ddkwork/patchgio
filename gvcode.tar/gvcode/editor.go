package gvcode

import (
	"image"
	"image/color"
	"io"
	"slices"
	"sort"
	"strings"
	"time"
	"unicode"

	"gioui.org/f32"
	"gioui.org/gesture"
	"gioui.org/io/event"
	"gioui.org/io/key"
	"gioui.org/io/pointer"
	"gioui.org/io/semantic"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/op/clip"
	"gioui.org/op/paint"
	"gioui.org/text"
	"gioui.org/unit"
	"gioui.org/widget/material"
	gvcolor "github.com/oligo/gvcode/color"
	"github.com/oligo/gvcode/gutter"
	"github.com/oligo/gvcode/gutter/providers"
	"github.com/oligo/gvcode/internal/buffer"
	gestureExt "github.com/oligo/gvcode/internal/gesture"
	"github.com/oligo/gvcode/postfix"
	"github.com/oligo/gvcode/textview"
)

// Editor implements an editable and scrollable text area.
type Editor struct {
	// mode sets the mode of the editor to work in.
	mode EditorMode

	// text manages the text buffer and provides shaping and cursor positioning
	// services.
	text       *textview.TextView
	buffer     buffer.TextSource
	snippetCtx *snippetContext
	// colorPalette configures the color scheme used for syntax highlighting.
	colorPalette *gvcolor.ColorPalette
	// gutterGap specifies the right inset between the gutter and the
	// editor text area.
	gutterGap unit.Dp
	// gutterManager manages multiple gutter providers (line numbers, breakpoints, etc.)
	gutterManager *gutter.Manager
	// hooks
	onPaste         BeforePasteHook
	onEnterHook     EnterHook
	onTextInputHook TextInputHook
	// enterHandlers are the user-registered Enter delegates; see enter.go.
	enterHandlers []EnterHandlerDelegate

	// postfixProvider holds the postfix templates Tab expands; see postfix.go.
	postfixProvider *postfix.Provider

	// language is the language-service state: diagnostics, inlay hints and the
	// quick-documentation / parameter-info popups; see language.go.
	language *languageService

	// usageHighlighting paints every usage of the symbol under the caret, the way
	// IntelliJ highlights identifiers automatically; see navigation.go.
	usageHighlighting bool
	// codeLens paints the "N usages" / "N implementations" annotations IntelliJ
	// shows next to declarations; see navigation.go.
	codeLens bool
	// columnSelectionMode is IntelliJ's Column Selection Mode (Alt+Shift+Insert):
	// while it is on a plain mouse drag selects a rectangle instead of a text
	// range. See event.go.
	columnSelectionMode bool
	// marks holds the editor's bookmarks and breakpoints; see marks.go.
	marks editorMarks

	// commentSyntax is the file type's comment syntax Ctrl+/ uses; see comment.go.
	commentSyntax CommentSyntax

	// textMove tracks dragging a selection to another position; see dragtext.go.
	textMove textMoveDrag

	completor Completion
	// last input when the editor received an EditEvent.
	lastInput *key.EditEvent

	// scratch is a byte buffer that is reused to efficiently read portions of text
	// from the textView.
	scratch    []byte
	blinkStart time.Time

	// gutterLines caches the document split into lines for the gutter providers
	// that analyse the whole document, together with the buffer revision it was
	// read at and how many providers it was handed to.
	gutterLines    []string
	gutterLinesRev uint64
	gutterLinesFed int

	// ime tracks the state relevant to input methods.
	ime struct {
		imeState
		scratch []byte
	}

	dragging    bool
	dragger     gesture.Drag
	scroller    gestureExt.Scroll
	hover       gestureExt.Hover
	scrollCaret bool
	showCaret   bool
	clicker     gesture.Click
	pending     []EditorEvent
	// commands is a registry of key commands.
	commands map[key.Name][]keyCommand
	// autoInsertions tracks recently inserted closing brackets or quotes.
	autoInsertions map[int]rune
	// gutterWidth can be used to guide to set the horizontal offset when
	// laying out a horizontal scrollbar.
	gutterWidth int
	// word highlighting state
	wordHighlighter wordHighlighter
	// selection highlighting state
	selectionHighlighter selectionHighlighter
	// column edit mode state
	columnEdit columnEditState
	// multiCaret holds the carets beyond the primary one; see multicaret.go.
	multiCaret multiCaretState

	// line ending detected when the editor loads content
	lineEnding LineEnding
}

// GetGutterManager returns the gutter manager instance
func (e *Editor) GetGutterManager() *gutter.Manager {
	return e.gutterManager
}

// columnEditState tracks state for column/vertical editing mode
type columnEditState struct {
	// enabled indicates whether column editing mode is active
	enabled bool
	// selections holds multiple cursor positions for column editing
	// each cursor represents a position on a different line
	selections []columnCursor
	// anchor stores the initial mouse position when starting a column selection
	anchor image.Point
	// caretX is the shared text-local pixel X where every column caret is
	// painted. Column carets must form ONE straight vertical line, but each
	// line's rune boundaries sit on a different pixel grid (tab indentation,
	// proportional fonts, ragged line ends), so painting each caret at its own
	// boundary makes the column ragged. Movement/drag instead snap every caret
	// onto this single pixel (their logical col is the largest boundary at or
	// before it) and painting just draws here.
	caretX float32
	// anchorX is the fixed end of a Shift-extended selection: the block spans
	// the pixels between caretX and anchorX, and the carets sit on whichever end
	// they moved to. A plain arrow collapses the block, which sets anchorX back
	// onto caretX. This mirrors GoLand, where the caret moves on Shift+arrow and
	// the selection keeps its other end (see
	// EditorMultiCaretColumnModeTest.testSelectionWithKeyboard).
	anchorX float32
	// levelValid marks the clone levels as usable. GoLand only honours them for
	// a repeated invocation of the clone/move actions (EditorLastActionTracker),
	// so any other action — a drag, a plain arrow, an edit — resets them.
	levelValid bool
}

// columnCursor represents a cursor position for column editing
type columnCursor struct {
	// line is the line number (0-based)
	line int
	// col is the column position (in runes, 0-based)
	col int
	// selStart and selEnd are this line's own block selection, half-open and in
	// runes, clamped to the line's text. They make the caret a real BLOCK
	// selection like GoLand's: typing REPLACES [selStart, selEnd) instead of
	// inserting beside it (EditorMultiCaretColumnModeTest.testTyping: "bbb"
	// typed with "S" over columns 2..3 becomes "bbS"). The range is empty when
	// the rectangle covers no character on this line (a line shorter than the
	// block) and after any caret movement, which collapses the block the way
	// GoLand collapses a selection on an arrow key — then typing inserts at the
	// caret again.
	selStart, selEnd int
	// level is the clone level of a caret added by a vertical Shift+arrow, the
	// bookkeeping GoLand's CloneCaretActionHandler uses to decide whether the
	// next vertical press adds a line or takes the last one back.
	level int
	// startX is the pixel X coordinate of this cursor
	startX int
	// endX is the pixel X coordinate of the selection end (if different from startX)
	endX int
}

type imeState struct {
	selection struct {
		rng   key.Range
		caret key.Caret
	}
	snippet     key.Snippet
	start, end  int
	isComposing bool
	composition key.Range
}

type EditorEvent interface {
	isEditorEvent()
}

// A ChangeEvent is generated for every user change to the text.
type ChangeEvent struct{}

// A SelectEvent is generated when the user selects some text, or changes the
// selection (e.g. with a shift-click), including if they remove the
// selection. The selected text is not part of the event, on the theory that
// it could be a relatively expensive operation (for a large editor), most
// applications won't actually care about it, and those that do can call
// Editor.SelectedText() (which can be empty).
type SelectEvent struct{}

// A HoverEvent is generated if the pointer hovers and keep still or maybe some
// small movement for some time.
type HoverEvent struct {
	PixelOff image.Point
	Pos      Position
	IsCancel bool
}

const (
	blinksPerSecond  = 1
	maxBlinkDuration = 10 * time.Second
)

// initBuffer should be invoked first in every exported function that accesses
// text state. It ensures that the underlying text widget is both ready to use
// and has its fields synced with the editor.
func (e *Editor) initBuffer() {
	if e.buffer == nil {
		e.text = textview.NewTextView()
		e.buffer = e.text.Source()
	}

	e.text.CaretWidth = unit.Dp(1)
	e.wordHighlighter.editor = e
	e.selectionHighlighter.editor = e
}

// Invalidate forces a re-layout of the editor content on the next frame.
// This is useful when external changes (like folding) affect the layout.
func (e *Editor) Invalidate() {
	e.initBuffer()
	e.text.Invalidate()
}

// Update the state of the editor in response to input events. Update consumes editor
// input events until there are no remaining events or an editor event is generated.
// To fully update the state of the editor, callers should call Update until it returns
// false.
func (e *Editor) Update(gtx layout.Context) (EditorEvent, bool) {
	e.initBuffer()
	event, ok := e.processEvents(gtx)
	// Notify IME of selection if it changed.
	newSel := e.ime.selection
	start, end := e.text.Selection()
	newSel.rng = key.Range{
		Start: start,
		End:   end,
	}
	caretPos, carAsc, carDesc := e.text.CaretInfo()
	newSel.caret = key.Caret{
		Pos:     layout.FPt(caretPos),
		Ascent:  float32(carAsc),
		Descent: float32(carDesc),
	}
	if newSel != e.ime.selection {
		e.ime.selection = newSel
		gtx.Execute(key.SelectionCmd{Tag: e, Range: newSel.rng, Caret: newSel.caret})
	}

	e.updateSnippet(gtx, e.ime.start, e.ime.end)
	return event, ok
}

func (e *Editor) Layout(gtx layout.Context, lt *text.Shaper) layout.Dimensions {
	for {
		_, ok := e.Update(gtx)
		if !ok {
			break
		}
	}

	// Adjust scrolling for new viewport and layout.
	e.text.ScrollRel(0, 0)

	if e.scrollCaret {
		e.scrollCaret = false
		e.text.ScrollToCaret()
	}

	// Refresh the language analysis when the document changed, so squiggles and
	// inlay hints track the text.
	e.syncLanguage()

	defer clip.Rect(image.Rectangle{Max: gtx.Constraints.Max}).Push(gtx.Ops).Pop()
	e.scroller.Add(gtx.Ops)
	if e.colorPalette != nil && e.colorPalette.Background.IsSet() {
		e.colorPalette.Background.Op(nil).Add(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
	}

	return layout.Flex{
		Axis: layout.Horizontal,
	}.Layout(gtx,
		layout.Rigid(func(gtx layout.Context) layout.Dimensions {
			if e.gutterManager != nil && e.gutterManager.HasProviders() {
				ctx := e.buildGutterContext(gtx, lt)

				// Process gutter events
				for {
					evt, ok := e.gutterManager.Update(gtx)
					if !ok {
						break
					}
					e.pending = append(e.pending, GutterEventWrapper{Event: evt})
				}

				dims := layout.Inset{Right: max(0, e.gutterGap)}.Layout(gtx,
					func(gtx layout.Context) layout.Dimensions {
						return e.gutterManager.Layout(gtx, ctx)
					})

				e.gutterWidth = dims.Size.X

				// Paint provider-based line highlights (full-width, behind content)
				highlights := e.gutterManager.CollectHighlights()
				e.paintProviderHighlights(gtx, ctx, highlights)

				// Collect run button events
				runButtonEvents := e.gutterManager.CollectRunButtonEvents()
				for _, evt := range runButtonEvents {
					e.pending = append(e.pending, RunButtonEventWrapper{Event: evt})
				}

				// Collect inheritance marker clicks
				methodIconEvents := e.gutterManager.CollectMethodIconEvents()
				for _, evt := range methodIconEvents {
					e.pending = append(e.pending, MethodIconEventWrapper{Event: evt})
				}

				return dims
			}

			return layout.Dimensions{}
		}),
		layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
			// Set color offsets before layout
			e.setColorOffsets(gtx)
			e.text.Layout(gtx, lt)
			dims := e.layout(gtx, lt)
			if e.completor != nil {
				e.text.PaintOverlay(gtx, e.completor.Offset(), e.completor.Layout)
			}
			// Render color picker overlay if needed
			e.renderColorPickerOverlay(gtx)
			return dims
		}),
	)

}

func (e *Editor) layout(gtx layout.Context, shaper *text.Shaper) layout.Dimensions {
	defer clip.Rect(image.Rectangle{Max: gtx.Constraints.Max}).Push(gtx.Ops).Pop()
	pointer.CursorText.Add(gtx.Ops)

	// Check if color picker is open
	colorPickerOpen := false
	if e.gutterManager != nil {
		providers := e.gutterManager.Providers()
		for _, p := range providers {
			if colorPickerProvider, ok := p.(gutter.ColorPickerProvider); ok && colorPickerProvider.ShowColorPicker() {
				colorPickerOpen = true
				break
			}
		}
	}

	// Only add event handler if color picker is not open
	if !colorPickerOpen {
		event.Op(gtx.Ops, e)
	}

	//e.scroller.Add(gtx.Ops)

	// Only add event handlers if color picker is not open
	if !colorPickerOpen {
		e.clicker.Add(gtx.Ops)
		e.dragger.Add(gtx.Ops)
		e.hover.Add(gtx.Ops)
	}
	e.showCaret = false
	if gtx.Focused(e) {
		now := gtx.Now
		dt := now.Sub(e.blinkStart)
		blinking := dt < maxBlinkDuration
		const timePerBlink = time.Second / blinksPerSecond
		nextBlink := now.Add(timePerBlink/2 - dt%(timePerBlink/2))
		if blinking {
			gtx.Execute(op.InvalidateCmd{At: nextBlink})
		}
		e.showCaret = !blinking || dt%timePerBlink < timePerBlink/2
	}
	semantic.Editor.Add(gtx.Ops)

	// determine the various colors to use.
	if e.colorPalette == nil {
		panic("No color palette is set!")
	}

	var textColor, selectColor gvcolor.Color
	if e.colorPalette.Foreground.IsSet() {
		textColor = e.colorPalette.Foreground
	}
	if e.colorPalette.SelectColor.IsSet() {
		selectColor = e.colorPalette.SelectColor
	} else {
		selectColor = textColor.MulAlpha(0x60)
	}

	if e.Len() > 0 {
		e.paintSelection(gtx, selectColor)
		// Extra carets of a multi-caret session select like the primary one.
		e.paintMultiCaretSelections(gtx, selectColor)
		e.text.HighlightMatchingBrackets(gtx, selectColor.Op(gtx.Ops))
		// The word highlighter highlights the word under the caret; the
		// language-service usage highlight is the semantic version of the same
		// idea, so it replaces it instead of double-painting.
		if e.wordHighlighter.IsDirty() && !e.usageHighlighting {
			e.wordHighlighter.HighlightAtCaret(e.colorPalette.SelectColor)
		}
		if e.selectionHighlighter.IsDirty() {
			e.selectionHighlighter.HighlightSelection(e.colorPalette.SelectColor)
		}

		e.paintText(gtx, textColor)
		e.paintComposition(gtx, textColor)

		e.renderColorIndicatorsInText(gtx, shaper)
	}

	// Paint column selection if active
	if e.ColumnEditEnabled() && len(e.columnEdit.selections) > 0 {
		e.paintColumnSelection(gtx, selectColor)
		// Paint multiple carets for column editing mode
		e.paintColumnCarets(gtx, textColor)
	}

	if gtx.Enabled() {
		e.paintCaret(gtx, textColor)
		// The carets beyond the primary one of a multi-caret session.
		e.paintMultiCaretCarets(gtx, textColor)
		// The insertion point of a drag-the-selection move.
		e.paintTextMoveCaret(gtx, textColor)
	}

	// Inlay hints and the language popups sit above the text.
	e.paintLanguageOverlays(gtx, shaper)

	// Render sticky lines if enabled
	e.renderStickyLines(gtx, shaper, textColor)

	return layout.Dimensions{Size: gtx.Constraints.Max}
}

// PaintOverlay draws a overlay widget over the main editor area.
func (e *Editor) PaintOverlay(gtx layout.Context, position image.Point, w layout.Widget) {
	offset := position.Add(e.text.ScrollOff()).Add(image.Point{X: e.gutterWidth})
	e.text.PaintOverlay(gtx, offset, w)
}

// paintSelection paints the contrasting background for selected text using the provided
// material to set the painting material for the selection.
func (e *Editor) paintSelection(gtx layout.Context, material gvcolor.Color) {
	e.initBuffer()
	e.text.PaintSelection(gtx, material.Op(gtx.Ops))
}

// paintText paints the text glyphs using the provided material to set the fill of the
// glyphs.
func (e *Editor) paintText(gtx layout.Context, material gvcolor.Color) {
	e.initBuffer()
	e.text.PaintText(gtx, material.Op(gtx.Ops))
}

// paintCaret paints the text glyphs using the provided material to set the fill material
// of the caret rectangle.
func (e *Editor) paintCaret(gtx layout.Context, material gvcolor.Color) {
	e.initBuffer()
	if !e.showCaret || e.mode == ModeReadOnly {
		return
	}
	e.text.PaintCaret(gtx, material.Op(gtx.Ops))
}

// paintColumnSelection paints the column selection rectangles for column editing mode
func (e *Editor) paintColumnSelection(gtx layout.Context, material gvcolor.Color) {
	e.initBuffer()

	lineHeight := e.text.GetLineHeight().Round()
	scrollOff := e.text.ScrollOff()

	for _, cursor := range e.columnEdit.selections {
		// Calculate screen position for this line
		lineY := cursor.line * lineHeight
		screenY := lineY - scrollOff.Y

		// Only draw if visible
		if screenY < -lineHeight || screenY > gtx.Constraints.Max.Y {
			continue
		}

		// Draw selection rectangle from startX to endX
		startX := cursor.startX - scrollOff.X
		endX := cursor.endX - scrollOff.X

		width := endX - startX
		if width <= 0 {
			width = 2 // Minimum visible width for cursor
		}

		// Draw the selection rectangle
		material.Op(gtx.Ops).Add(gtx.Ops)
		stack := clip.Rect(image.Rect(startX, screenY, startX+width, screenY+lineHeight)).Push(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
		stack.Pop()
	}
}

// columnLineLength returns the number of runes in the given (visible) line.
func (e *Editor) columnLineLength(line int) int {
	return e.text.ConvertPos(line+1, 0) - e.text.ConvertPos(line, 0)
}

// columnLineRunes returns the line's text content as runes, EXCLUDING the
// line-ending newline. Paragraph rune counts include the trailing "\n"
// (internal/layout keeps it in the paragraph), so the column caret domain
// (which parks carets at col == columnLineLength) is off by one from the
// line's real text — anything that deletes runes must use this instead, or a
// parked caret will happily delete the newline and merge lines.
func (e *Editor) columnLineRunes(line int) []rune {
	start := e.text.ConvertPos(line, 0)
	end := e.text.ConvertPos(line+1, 0)
	r := []rune(e.text.ReadTextBetween(start, end))
	if n := len(r); n > 0 && r[n-1] == '\n' {
		r = r[:n-1]
	}
	return r
}

// paragraphEndX returns the text-local pixel X of the end-of-line insert
// position: the right edge of the line's text. The layout has no on-line
// cursor pixel one past the last rune — ConvertPos(line, lineLen) leaks to
// the NEXT paragraph's line start — so callers use this for that position.
func (e *Editor) paragraphEndX(line int) float32 {
	_, p := e.text.FindParagraph(e.text.ConvertPos(line, 0))
	return float32(p.EndX)/64 - float32(e.text.ScrollOff().X)
}

// paintedCaretX returns the text-local pixel X of the rune boundary at col on
// the given line, mapping an end-of-line col to the line's end-of-line insert
// position (see paragraphEndX). Used by movement to pick the leader caret and
// its next boundary target — NOT by painting, which draws every caret at the
// shared columnEdit.caretX so the caret column stays a straight vertical line.
func (e *Editor) paintedCaretX(line, col int) float32 {
	if col < e.columnLineLength(line) {
		_, pos := e.ConvertPos(line, col)
		return pos.X
	}
	return e.paragraphEndX(line)
}

// largestColAtOrBefore returns the largest col in [0, lineLen-1] whose rune
// start pixel X is <= targetX (both text-local). Returns 0 when no boundary
// qualifies. X grows monotonically with col for LTR text, so the first
// boundary past the target ends the scan. Comparison happens in truncated
// pixel space: rectangle edges come from pointer events as int pixels, and a
// float compare would leave the caret one boundary short of an edge that
// truncates onto the boundary itself.
func (e *Editor) largestColAtOrBefore(line int, targetX float32) int {
	best := 0
	for col := 0; col < e.columnLineLength(line); col++ {
		_, pos := e.ConvertPos(line, col)
		if int(pos.X) > int(targetX) {
			break
		}
		best = col
	}
	return best
}

// maxColumnPadSpaces bounds how many spaces a column insert may add to push a
// short line out to the caret column. The block can never be wider than the
// window, so this only guards against a pathological caretX (e.g. from a stale
// scroll offset) turning one keystroke into an unbounded edit.
const maxColumnPadSpaces = 512

// columnSelectionRunes returns the half-open rune range the pixel rectangle
// [startX, endX) covers on the given line. A rune belongs to the block when its
// left edge starts at or after startX and before endX — the same test
// columnRuneInSelection applies to single runes — and the range is clamped to
// the line's own text, so a block selection can never reach the line-ending
// newline. Rune X grows with the col, so the bounds come from two short scans.
func (e *Editor) columnSelectionRunes(line, startX, endX int) (lo, hi int) {
	textLen := len(e.columnLineRunes(line))
	lo = textLen
	for col := range textLen {
		_, pos := e.ConvertPos(line, col)
		if int(pos.X) >= startX {
			lo = col
			break
		}
	}
	for col := range textLen {
		_, pos := e.ConvertPos(line, col)
		if int(pos.X) >= endX {
			break
		}
		hi = col + 1
	}
	if hi < lo {
		hi = lo
	}
	return lo, hi
}

// columnRuneInSelection reports whether the rune at col on the given line lies
// INSIDE the column selection rectangle: the rune must exist (so the line's
// trailing newline is never selectable — that is what keeps every column edit
// line-local and stops lines from merging) and its left edge must start at or
// after startX and before endX. A caret may legitimately sit on the rectangle's
// exclusive right edge (col whose left edge == endX), which is why the endX
// comparison is strict: the rune there is OUTSIDE the selection.
func (e *Editor) columnRuneInSelection(line, col, startX, endX int) bool {
	if col < 0 || col >= len(e.columnLineRunes(line)) {
		return false
	}
	_, pos := e.ConvertPos(line, col)
	x := int(pos.X)
	return x >= startX && x < endX
}

// paintColumnCarets paints multiple carets for column editing mode
func (e *Editor) paintColumnCarets(gtx layout.Context, material gvcolor.Color) {
	e.initBuffer()
	if !e.showCaret || e.mode == ModeReadOnly {
		return
	}

	lineHeight := e.text.GetLineHeight().Round()
	scrollOff := e.text.ScrollOff()
	// Convert unit.Dp to pixels using gtx.Dp()
	caretWidthPx := gtx.Dp(unit.Dp(1))

	// Paint every caret at the SHARED caretX so the caret column is one
	// straight vertical line. Painting at each cursor's own rune boundary
	// instead made the column ragged: tab-indented lines, proportional fonts
	// and parked short lines all sit on different pixel grids. The logical col
	// already snapped to the largest boundary at or before caretX during
	// movement, so a caret may visually touch a glyph — the insert position is
	// still well defined.
	caretX := int(e.columnEdit.caretX)
	for _, cursor := range e.columnEdit.selections {
		// Calculate screen position for this line
		lineY := cursor.line * lineHeight
		screenY := lineY - scrollOff.Y

		// Only draw if visible
		if screenY < -lineHeight || screenY > gtx.Constraints.Max.Y {
			continue
		}

		caretY := screenY

		// Draw caret as a thin vertical line
		material.Op(gtx.Ops).Add(gtx.Ops)
		stack := clip.Rect(image.Rect(caretX, caretY, caretX+caretWidthPx, caretY+lineHeight)).Push(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
		stack.Pop()
	}
}

func (e *Editor) paintComposition(gtx layout.Context, material gvcolor.Color) {
	e.initBuffer()
	if !e.ime.isComposing {
		return
	}

	e.text.PaintComposition(gtx, e.ime.composition, material.Op(gtx.Ops), "dash")

}

// Len is the length of the editor contents, in runes.
func (e *Editor) Len() int {
	e.initBuffer()
	return e.buffer.Len()
}

// Text returns the contents of the editor. This method is not concurrent safe,
// and you should use the Reader returned from GetReader to read from multiple
// goroutines.
//
// Text does not convert \n to \r\n if the detected lineEnding is \r\n, it's the
// caller's responsibility to do the convertion.
func (e *Editor) Text() string {
	e.initBuffer()

	srcReader := buffer.NewReader(e.text.Source())
	e.scratch = srcReader.ReadAll(e.scratch)
	return string(e.scratch)
}

// TextView returns the underlying text view for advanced text manipulation.
func (e *Editor) TextView() *textview.TextView {
	e.initBuffer()
	return e.text
}

// ReadTextBetween reads text between two rune offsets (start inclusive, end exclusive).
func (e *Editor) ReadTextBetween(start, end int) string {
	return e.text.ReadTextBetween(start, end)
}

// GetReader returns a [io.ReadSeeker] to the caller to read the text buffer. This
// is the preferred way to read from the editor, especially when reading from
// multiple goroutines.
//
// GetReader does not convert \n to \r\n if the detected lineEnding is \r\n, it's the
// caller's responsibility to do the convertion.
func (e *Editor) GetReader() io.ReadSeeker {
	return buffer.NewReader(e.text.Source())
}

// SetText init the editor with content s.
// It also detects the content indent kind, indent size, and the line ending style.
// Internally the editor uses \n for line ending, so it also convert all \r\n to \n
// before populate the internal text buffer.
func (e *Editor) SetText(s string) {
	e.initBuffer()
	e.resetIME()
	clear(e.autoInsertions)
	e.lastInput = nil

	indent, _, size := GuessIndentation(s)
	e.text.SoftTab = indent == Spaces
	e.text.TabWidth = size

	e.lineEnding = DetectLineEnding(s)

	e.text.SetText(StripLineEnding(s))
	// Reset xoff and move the caret to the beginning.
	e.SetCaret(0, 0)
}

func (e *Editor) resetIME() {
	if e.ime.isComposing {
		e.buffer.UnGroupOp()
	}
	e.ime.imeState = imeState{}
}

// CaretPos returns the line & column numbers of the caret.
func (e *Editor) CaretPos() (line, col int) {
	e.initBuffer()
	return e.text.CaretPos()
}

// CaretCoords returns the coordinates of the caret, relative to the
// editor itself.
func (e *Editor) CaretCoords() f32.Point {
	e.initBuffer()
	return e.text.CaretCoords()
}

// ConvertPos convert a line/col position to rune offset and its pixel position relative to
// the editor itself.
func (e *Editor) ConvertPos(line, col int) (runeOff int, pos f32.Point) {
	e.initBuffer()
	runeOff = e.text.ConvertPos(line, col)
	pos = e.text.RuneCoords(runeOff)
	return
}

// Lines returns the total number of rendered logical lines.
func (e *Editor) Lines() int {
	e.initBuffer()
	return e.text.Paragraphs()
}

// ReadUntil reads in the specified direction from the current caret position until the
// seperator returns false. It returns the read text.
func (e *Editor) ReadUntil(direction int, seperator func(r rune) bool) string {
	return e.text.ReadUntil(direction, seperator)
}

// Delete runes from the caret position. The sign of the argument specifies the
// direction to delete: positive is forward, negative is backward.
//
// If there is a selection, it is deleted and counts as a single grapheme
// cluster.
func (e *Editor) Delete(graphemeClusters int) (deletedRunes int) {
	e.initBuffer()
	if graphemeClusters == 0 {
		return 0
	}

	// Handle column editing mode
	if e.ColumnEditEnabled() && len(e.columnEdit.selections) > 0 {
		return e.onColumnEditDelete(graphemeClusters)
	}

	// Multi-caret: every caret deletes its own selection or one rune.
	if e.MultiCaretEnabled() {
		return e.multiCaretDelete(graphemeClusters < 0)
	}

	if graphemeClusters < 0 {
		// update selection based on some rules.
		e.onDeleteBackward()
	}

	start, end := e.text.Selection()
	if start != end {
		graphemeClusters -= sign(graphemeClusters)
	}

	// Move caret by the target quantity of clusters.
	e.text.MoveCaret(0, graphemeClusters)
	// Get the new rune offsets of the selection.
	start, end = e.text.Selection()
	e.replace(start, end, "")
	// Reset xoff.
	e.text.MoveCaret(0, 0)
	e.ClearSelection()
	return end - start
}

// DeleteLine delete the current line, and place the caret at the
// start of the next line.
func (e *Editor) DeleteLine() (deletedRunes int) {
	e.initBuffer()

	start, end := e.text.SelectedLineRange()
	if start == end {
		return 0
	}

	e.replace(start, end, "")
	// Reset xoff.
	e.text.MoveCaret(0, 0)
	e.SetCaret(start, start)

	e.ClearSelection()
	return end - start
}

// Inert insert text s at the cursor position. If there is a selection,
// it replace the selection with text s.
func (e *Editor) Insert(s string) (insertedRunes int) {
	e.initBuffer()

	if s == "" {
		return
	}

	s = StripLineEnding(s)

	start, end := e.text.Selection()
	moves := e.replace(start, end, s)
	if end < start {
		start = end
	}
	// Reset xoff.
	e.text.MoveCaret(0, 0)
	e.SetCaret(start+moves, start+moves)
	e.scrollCaret = true
	return moves
}

func isSingleLine(s string) bool {
	return len(s) > 1 && strings.Count(s, "\n") == 1 && s[len(s)-1] == '\n'
}

// InsertLine insert a line of text before the current line, and place the caret at the
// start of the current line.
//
// This single line insertion is mainly for paste operation after copying/cutting the
// current line(paragraph) when there is no selection, but it can also used outside of
// the editor to insert a entire line(paragraph).
func (e *Editor) InsertLine(s string) (insertedRunes int) {
	e.initBuffer()

	if s == "" {
		return
	}

	s = StripLineEnding(s)

	if isSingleLine(s) && e.text.SelectionLen() == 0 {
		// If s is a paragraph of text, insert s between the current line
		// and the previous line.
		start, end := e.text.SelectedLineRange()
		moves := e.replace(start, start, s)
		// Reset xoff.
		e.text.MoveCaret(0, 0)
		e.SetCaret(end, end)
		e.scrollCaret = true
		return moves
	}

	return
}

// DuplicateLine duplicates the current line and places the caret at the end of the duplicated line.
// Similar to GoLand's Ctrl+D functionality.
func (e *Editor) DuplicateLine() (duplicatedRunes int) {
	e.initBuffer()
	if e.mode == ModeReadOnly {
		return 0
	}

	start, end := e.text.SelectedLineRange()
	if start == end {
		return 0
	}

	// Read the current line content
	e.scratch = e.scratch[:0]
	startOff := e.buffer.RuneOffset(start)
	endOff := e.buffer.RuneOffset(end)
	if cap(e.scratch) < endOff-startOff {
		e.scratch = make([]byte, endOff-startOff)
	}
	e.scratch = e.scratch[:endOff-startOff]
	n, _ := e.buffer.ReadAt(e.scratch, int64(startOff))
	lineContent := e.scratch[:n]

	// Duplicate the line: insert the line content at the end of current line
	// Group operations for undo
	e.buffer.GroupOp()
	moves := e.replace(end, end, string(lineContent))
	e.buffer.UnGroupOp()

	// Move caret to the end of the duplicated line
	newCaretPos := end + moves
	e.text.MoveCaret(0, 0)
	e.SetCaret(newCaretPos, newCaretPos)
	e.scrollCaret = true

	return moves
}

// undo revert the last operation(s).
func (e *Editor) undo() (EditorEvent, bool) {
	e.initBuffer()

	positions, ok := e.text.Undo()
	if !ok {
		return nil, false
	}

	var start, end int
	for _, pos := range positions {
		start = pos.Start
		end = pos.End
	}

	e.SetCaret(end, start)
	return ChangeEvent{}, true
}

// redo revert the last undo operation.
func (e *Editor) redo() (EditorEvent, bool) {
	e.initBuffer()

	positions, ok := e.text.Redo()
	if !ok {
		return nil, false
	}

	var start, end int
	for _, pos := range positions {
		start = pos.Start
		end = pos.End
	}

	e.SetCaret(end, start)
	return ChangeEvent{}, true
}

// replace the text between start and end with s. Indices are in runes.
// It returns the number of runes inserted.
func (e *Editor) replace(start, end int, s string) int {
	length := e.text.Len()
	if start > end {
		start, end = end, start
	}
	start = min(start, length)
	end = min(end, length)

	sc := e.text.Replace(start, end, s)
	newEnd := start + sc
	if len(e.autoInsertions) > 0 && (start != end || sc != 0) {
		updated := make(map[int]rune, len(e.autoInsertions))
		for pos, r := range e.autoInsertions {
			switch {
			case pos < start:
				updated[pos] = r
			case pos >= end:
				updated[pos+newEnd-end] = r
			}
		}
		e.autoInsertions = updated
	}
	adjust := func(pos int) int {
		switch {
		case newEnd < pos && pos <= end:
			pos = newEnd
		case end < pos:
			diff := newEnd - end
			pos = pos + diff
		}
		return pos
	}
	e.ime.start = adjust(e.ime.start)
	e.ime.end = adjust(e.ime.end)
	e.text.UpdateSyntaxTokensOffset(start, end, newEnd)
	return sc
}

// ReplaceAll replaces all texts specifed in TextRange with newStr.
// It returns the number of occurrences replaced.
func (e *Editor) ReplaceAll(texts []TextRange, newStr string) int {
	if len(texts) <= 0 {
		return 0
	}

	// Traverse in reverse order to prevent match offsets from changing after
	// each replace.
	e.buffer.GroupOp()
	finalPos := 0
	for _, text := range slices.Backward(texts) {
		start, end := text.Start, text.End
		e.replace(start, end, newStr)
		finalPos = start
	}
	e.buffer.UnGroupOp()

	e.SetCaret(finalPos, finalPos)
	return len(texts)
}

// MoveCaret moves the caret (aka selection start) and the selection end
// relative to their current positions. Positive distances moves forward,
// negative distances moves backward. Distances are in grapheme clusters,
// which closely match what users perceive as "characters" even when the
// characters are multiple code points long.
func (e *Editor) MoveCaret(startDelta, endDelta int) {
	e.initBuffer()
	e.text.MoveCaret(startDelta, endDelta)
}

// deleteWord deletes the next word(s) in the specified direction.
// Unlike moveWord, deleteWord treats whitespace as a word itself.
// Positive is forward, negative is backward.
// Absolute values greater than one will delete that many words.
// The selection counts as a single word.
func (e *Editor) deleteWord(distance int) (deletedRunes int) {
	if distance == 0 {
		return
	}

	start, end := e.text.Selection()
	if start != end {
		deletedRunes = e.Delete(1)
		distance -= sign(distance)
	}
	if distance == 0 {
		return deletedRunes
	}

	// split the distance information into constituent parts to be
	// used independently.
	words, direction := distance, 1
	if distance < 0 {
		words, direction = distance*-1, -1
	}
	caret, _ := e.text.Selection()
	// atEnd if offset is at or beyond either side of the buffer.
	atEnd := func(runes int) bool {
		idx := caret + runes*direction
		return idx <= 0 || idx >= e.Len()
	}
	// next returns the appropriate rune given the direction and offset in runes.
	next := func(runes int) rune {
		idx := caret + runes*direction
		if idx < 0 {
			idx = 0
		} else if idx > e.Len() {
			idx = e.Len()
		}
		var r rune
		if direction < 0 {
			r, _ = e.buffer.ReadRuneAt(idx - 1)
		} else {
			r, _ = e.buffer.ReadRuneAt(idx)
		}
		return r
	}
	runes := 1
	for ii := 0; ii < words; ii++ {
		r := next(runes)
		isSeperator := e.text.IsWordSeperator(r)

		for r := next(runes); (isSeperator == e.text.IsWordSeperator(r)) && !atEnd(runes); r = next(runes) {
			runes += 1
		}
	}
	deletedRunes += e.Delete(runes * direction)
	return deletedRunes
}

// SelectionLen returns the length of the selection, in runes; it is
// equivalent to utf8.RuneCountInString(e.SelectedText()).
func (e *Editor) SelectionLen() int {
	e.initBuffer()
	return e.text.SelectionLen()
}

// Selection returns the start and end of the selection, as rune offsets.
// start can be > end.
func (e *Editor) Selection() (start, end int) {
	e.initBuffer()
	return e.text.Selection()
}

// SelectLines select logical lines starting from the current line(inclusive).
// The number of lines to be selected is specified by totalLines. If backward
// is true, it select lines backward.
func (e *Editor) SelectLines(totalLines int, backward bool) {
	e.initBuffer()

	start, end := e.text.Selection()
	caretStart := min(start, end)
	firstLine, _ := e.text.FindParagraph(caretStart)

	start, end = e.text.RangeOfLines(firstLine, totalLines, backward)
	if start == 0 && end == 0 {
		return
	}
	e.SetCaret(start, end)
}

// SetCaret moves the caret to start, and sets the selection end to end. start
// and end are in runes, and represent offsets into the editor text.
func (e *Editor) SetCaret(start, end int) {
	e.initBuffer()
	e.text.SetCaret(start, end)
	e.scrollCaret = true
	e.scroller.Stop()
}

// SelectedText returns the currently selected text (if any) from the editor.
func (e *Editor) SelectedText() string {
	e.initBuffer()
	e.scratch = e.text.SelectedText(e.scratch)
	return string(e.scratch)
}

// ClearSelection clears the selection, by setting the selection end equal to
// the selection start.
func (e *Editor) ClearSelection() {
	e.initBuffer()
	e.text.ClearSelection()
}

// ScrollRatio returns the viewport's start and end scrolling offset in ratio
// relating to the reandered document coordinate space.
func (e *Editor) ScrollRatio() (minX, maxX float32, minY, maxY float32) {
	textDims := e.text.FullDimensions()
	visibleDims := e.text.Dimensions()
	scrollOff := e.text.ScrollOff()

	minX = float32(scrollOff.X) / float32(textDims.Size.X)
	maxX = float32(scrollOff.X+visibleDims.Size.X) / float32(textDims.Size.X)
	minY = float32(scrollOff.Y) / float32(textDims.Size.Y)
	maxY = float32(scrollOff.Y+visibleDims.Size.Y) / float32(textDims.Size.Y)
	return
}

// Scroll scrolls the horizontal or vertical scrollbar, using ratio related to
// the rendered document size.
func (e *Editor) Scroll(gtx layout.Context, xRatio, yRatio float32) {
	textDims := e.text.FullDimensions().Size
	xRatio = min(1.0, xRatio)
	xRatio = max(xRatio, -1.0)
	yRatio = min(1.0, yRatio)
	yRatio = max(yRatio, -1.0)

	e.text.ScrollRel(int(float32(textDims.X)*xRatio), int(float32(textDims.Y)*yRatio))
}

// GutterWidth returns the width of the gutter in pixel, which can be used to
// guide to set the horizontal offset when laying out a horizontal scrollbar.
func (e *Editor) GutterWidth() int {
	return e.gutterWidth
}

// Deprecated: use Mode() method please.
func (e *Editor) ReadOnly() bool {
	return e.mode == ModeReadOnly
}

func (e *Editor) Mode() EditorMode {
	return e.mode
}

func (e *Editor) TabStyle() (TabStyle, int) {
	if e.text.SoftTab {
		return Spaces, e.text.TabWidth
	}

	return Tabs, e.text.TabWidth
}

func (e *Editor) ColorPalette() *gvcolor.ColorPalette {
	return e.colorPalette
}

func (e *Editor) DetectedLineEnding() LineEnding {
	return e.lineEnding
}

// SetDebug enable or disable the debug mode.
// In debug mode, internal buffer state is printed.
func SetDebug(enable bool) {
	buffer.SetDebug(enable)
}

func abs(n int) int {
	if n < 0 {
		return -n
	}
	return n
}

func sign(n int) int {
	switch {
	case n < 0:
		return -1
	case n > 0:
		return 1
	default:
		return 0
	}
}

// onColumnEditDelete handles delete operations in column editing mode with
// GoLand semantics. Two cases, exactly like GoLand's DeleteInColumnModeHandler:
//
//   - The caret HAS a block selection on its line: the whole selection is
//     removed, whichever key was pressed. GoLand hands such a caret straight to
//     the ordinary delete handler, which deletes the selection, so the block
//     disappears in ONE keystroke instead of one character at a time.
//   - The caret has NO selection: graphemeClusters clusters after (positive) or
//     before (negative) the caret are deleted ON ITS OWN LINE, and only
//     characters INSIDE the selection rectangle may be touched.
//
// Either way a deletion never crosses the line boundary (lines can never merge)
// and never reaches past the rectangle: the caret can legally sit on the
// rectangle's exclusive right edge (Delete there has nothing left to take) or on
// its left edge (Backspace there has nothing before it inside the rectangle).
func (e *Editor) onColumnEditDelete(graphemeClusters int) (deletedRunes int) {
	if len(e.columnEdit.selections) == 0 {
		return 0
	}

	if graphemeClusters == 0 {
		return 0
	}

	// Group operations for undo
	e.buffer.GroupOp()

	for i := range e.columnEdit.selections {
		cursor := &e.columnEdit.selections[i]

		// A block selection is consumed as a whole. The range is already clamped
		// to the line's own text, so this can never eat the newline and merge
		// lines. Both keys do the same: the block is what is selected, and the
		// caret lands on the block's start.
		if cursor.selEnd > cursor.selStart {
			start, _ := e.ConvertPos(cursor.line, cursor.selStart)
			end, _ := e.ConvertPos(cursor.line, cursor.selEnd)
			if end > start {
				deletedRunes += end - start
				e.replace(start, end, "")
			}
			cursor.col = cursor.selStart
			cursor.selStart, cursor.selEnd = cursor.col, cursor.col
			continue
		}

		// Paragraph rune counts INCLUDE the trailing newline, so derive the
		// line's deletable text length from the buffer itself.
		textLen := len(e.columnLineRunes(cursor.line))

		var start, end, count int
		if graphemeClusters > 0 {
			// Delete forward, clamped to the rectangle: a rune whose left edge
			// is at or past endX belongs to a column OUTSIDE the selection and
			// must survive.
			for count < graphemeClusters &&
				e.columnRuneInSelection(cursor.line, cursor.col+count, cursor.startX, cursor.endX) {
				count++
			}
			if count == 0 {
				continue
			}
			start, _ = e.ConvertPos(cursor.line, cursor.col)
			end, _ = e.ConvertPos(cursor.line, cursor.col+count)
		} else {
			// Delete backward, symmetric clamp: col 0 and the rectangle's left
			// edge have nothing selected before them. A caret parked at its
			// end-of-line insert position (col == textLen+1) really sits at
			// textLen.
			effCol := min(cursor.col, textLen)
			for count < -graphemeClusters &&
				e.columnRuneInSelection(cursor.line, effCol-count-1, cursor.startX, cursor.endX) {
				count++
			}
			if count == 0 {
				continue
			}
			start, _ = e.ConvertPos(cursor.line, effCol-count)
			end, _ = e.ConvertPos(cursor.line, effCol)
		}

		if start >= end {
			continue
		}

		deleted := end - start
		e.replace(start, end, "")
		deletedRunes += deleted

		// Backward deletion moves the caret left by what it ACTUALLY deleted
		// (the clamps above may have deleted less than requested).
		if graphemeClusters < 0 {
			cursor.col -= deleted
			if cursor.col < 0 {
				cursor.col = 0
			}
		}
	}

	// Re-anchor the shared painted pixel: deletions shifted the text under
	// the caret column, so snap caretX onto the first non-parked caret's rune
	// boundary. Painting draws every caret there — the column stays a
	// straight vertical line that tracks the deleted width, like GoLand.
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		if c.col < e.columnLineLength(c.line) {
			e.columnEdit.caretX = e.paintedCaretX(c.line, c.col)
			break
		}
	}
	// Any selection has just been consumed, so the anchor follows the caret: a
	// later Shift+arrow starts a fresh selection instead of reopening the old
	// span. An edit also ends the vertical clone sequence.
	e.columnEdit.anchorX = e.columnEdit.caretX
	e.columnEdit.levelValid = false

	e.buffer.UnGroupOp()

	e.scrollCaret = true
	e.scroller.Stop()
	// Reset xoff.
	e.text.MoveCaret(0, 0)
	return deletedRunes
}

// onColumnEditInsert handles text input in column editing mode the way GoLand
// handles block editing: the input is inserted once per caret, ON ITS OWN LINE
// at the caret's own col, so the typed text lands INSIDE the selection
// rectangle instead of at the single main caret (which lives outside the
// rectangle and must not receive it). The rectangle's right edge grows by the
// inserted pixel width on every line so the fresh text stays selected — and
// therefore stays deletable. Returns false when the input cannot be handled as
// a column edit: empty input, or input carrying a line break, which would
// invalidate the line indices the rectangle is built on.
func (e *Editor) onColumnEditInsert(s string) bool {
	if len(e.columnEdit.selections) == 0 || s == "" || strings.ContainsRune(s, '\n') {
		return false
	}

	e.buffer.GroupOp()
	for i := range e.columnEdit.selections {
		cursor := &e.columnEdit.selections[i]

		// A block selection on this line is REPLACED by the typed text, the way
		// GoLand treats a block (EditorMultiCaretColumnModeTest.testTyping: "bbb"
		// typed with "S" over columns 2..3 becomes "bbS", "ccccc" becomes
		// "ccScc"). The selection is consumed, so further typing inserts at the
		// caret again — exactly GoLand's behaviour after the block is replaced.
		if cursor.selEnd > cursor.selStart {
			at, _ := e.ConvertPos(cursor.line, cursor.selStart)
			end, _ := e.ConvertPos(cursor.line, cursor.selEnd)
			n := e.replace(at, end, s)
			cursor.col = cursor.selStart + n
			cursor.selStart, cursor.selEnd = cursor.col, cursor.col
			continue
		}

		// No selection on this line: insert at the caret. A caret parked at its
		// end-of-line insert position (col == textLen+1) really sits at textLen;
		// converting the parked col would leak to the next paragraph and type at
		// the start of the following line.
		insCol := min(cursor.col, len(e.columnLineRunes(cursor.line)))
		at, _ := e.ConvertPos(cursor.line, insCol)
		startX := e.paintedCaretX(cursor.line, insCol)

		// A caret parked on a line SHORTER than the block must first be padded
		// out to the caret column with spaces, so the typed text starts where
		// every other line's does. IntelliJ keeps the block's desired column for
		// the whole line range and fills the gap the same way (see
		// EditorMultiCaretColumnModeTest.testTyping: "a" typed with "S" in a
		// block starting at column 2 becomes "a S"). Each space is inserted for
		// real, because the layout only reports a pixel for text that exists.
		pad := 0
		if cursor.col >= len(e.columnLineRunes(cursor.line)) {
			for pad < maxColumnPadSpaces && e.paintedCaretX(cursor.line, insCol+pad) < e.columnEdit.caretX {
				e.replace(at+pad, at+pad, " ")
				pad++
			}
		}

		insertAt := at + pad
		n := e.replace(insertAt, insertAt, s)

		// Measure the REAL pixel width of what was inserted: tab-indented and
		// space-padded lines are wider than plain ones, so a fixed per-rune
		// width would let the right edge drift off the caret.
		endX := e.paintedCaretX(cursor.line, insCol+pad+n)
		cursor.endX += int(endX - startX)
		cursor.col = insCol + pad + n
		cursor.selStart, cursor.selEnd = cursor.col, cursor.col
	}
	e.buffer.UnGroupOp()

	// Re-anchor the shared painted pixel on the widest caret so the caret column
	// tracks the typed text instead of jumping back.
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		if x := e.paintedCaretX(c.line, c.col); x > e.columnEdit.caretX {
			e.columnEdit.caretX = x
		}
	}
	// The block has been replaced or typed into, so the anchor follows the
	// caret: a later Shift+arrow starts a fresh selection. An edit also ends the
	// vertical clone sequence.
	e.columnEdit.anchorX = e.columnEdit.caretX
	e.columnEdit.levelValid = false

	e.scrollCaret = true
	e.scroller.Stop()
	// Reset xoff.
	e.text.MoveCaret(0, 0)
	return true
}

// columnBlockText returns the block's text for the clipboard: one line per
// covered line, each padded with trailing spaces out to the block's widest line
// so the block's columns survive a paste. GoLand pads short lines the same way
// (EditorMultiCaretColumnModeTest.testCopyPasteOfShortLines). Returns false when
// there is no block or it covers no character.
func (e *Editor) columnBlockText() (string, bool) {
	if len(e.columnEdit.selections) == 0 {
		return "", false
	}

	lines := make([]string, 0, len(e.columnEdit.selections))
	width := 0
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		runes := e.columnLineRunes(c.line)
		lo, hi := min(c.selStart, len(runes)), min(c.selEnd, len(runes))
		if hi < lo {
			hi = lo
		}
		lines = append(lines, string(runes[lo:hi]))
		if n := hi - lo; n > width {
			width = n
		}
	}
	if width == 0 {
		return "", false
	}

	var b strings.Builder
	for i, line := range lines {
		if i > 0 {
			b.WriteByte('\n')
		}
		b.WriteString(line)
		b.WriteString(strings.Repeat(" ", width-len([]rune(line))))
	}
	return b.String(), true
}

// onColumnPaste pastes into a block: one clipboard line per caret, replacing the
// selection on that line, so a block copied elsewhere lands column-aligned here.
// A single-line clipboard goes to every caret, which is the block equivalent of
// typing it. A clipboard TALLER than the block keeps writing on the lines below it
// at the same column, which is what GoLand does when a block is pasted at a single
// caret (EditorMultiCaretColumnModeTest.testPasteOfBlockToASingleCaret). Returns
// false when the column path does not apply.
func (e *Editor) onColumnPaste(text string) (int, bool) {
	carets := e.columnEdit.selections
	if len(carets) == 0 {
		return 0, false
	}

	lines := strings.Split(strings.ReplaceAll(text, "\r\n", "\n"), "\n")

	// One target line per clipboard line: the block's own lines first, then the
	// lines below it with no selection to replace.
	type pasteTarget struct{ line, lo, hi int }
	targets := make([]pasteTarget, 0, len(lines))
	switch {
	case len(lines) == 1:
		for i := range carets {
			c := &carets[i]
			targets = append(targets, pasteTarget{c.line, c.selStart, c.selEnd})
		}
	case len(lines) <= len(carets):
		for i := range lines {
			c := &carets[i]
			targets = append(targets, pasteTarget{c.line, c.selStart, c.selEnd})
		}
	default:
		first, _ := e.columnLineBounds()
		if first+len(lines)-1 >= e.text.Paragraphs() {
			return 0, false // the clipboard would run off the end of the document
		}
		col := e.columnColAtX(carets[0].line, e.columnEdit.caretX)
		for i := range lines {
			if i < len(carets) {
				c := &carets[i]
				targets = append(targets, pasteTarget{c.line, c.selStart, c.selEnd})
				continue
			}
			targets = append(targets, pasteTarget{first + i, col, col})
		}
	}

	inserted := 0
	e.buffer.GroupOp()
	for i, t := range targets {
		runes := e.columnLineRunes(t.line)
		lo, hi := min(t.lo, len(runes)), min(t.hi, len(runes))
		if hi < lo {
			hi = lo
		}
		start, _ := e.ConvertPos(t.line, lo)
		end, _ := e.ConvertPos(t.line, hi)
		n := e.replace(start, end, lines[i])
		inserted += n
		for k := range e.columnEdit.selections {
			c := &e.columnEdit.selections[k]
			if c.line == t.line {
				c.col = lo + n
				c.selStart, c.selEnd = c.col, c.col
			}
		}
	}
	e.buffer.UnGroupOp()

	// The block has been consumed, so re-anchor exactly like an insert does.
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		if x := e.paintedCaretX(c.line, c.col); x > e.columnEdit.caretX {
			e.columnEdit.caretX = x
		}
	}
	e.columnEdit.anchorX = e.columnEdit.caretX
	e.columnEdit.levelValid = false

	e.scrollCaret = true
	e.scroller.Stop()
	e.text.MoveCaret(0, 0)
	return inserted, true
}

// columnLogicalPos returns the line and col (both in runes) of a rune offset.
func (e *Editor) columnLogicalPos(offset int) (line, col int) {
	line, p := e.text.FindParagraph(offset)
	return line, offset - p.RuneOff
}

// columnBlockFromSelection turns the editor's linear selection into a column block
// the way GoLand's column-mode toggle does: the block covers the selection's lines
// and the COLUMNS of its two endpoints, so a rough linear selection becomes the
// rectangle the user meant (ToggleColumnModeAction, and
// ToggleColumnModeActionMultiCaretTest: a selection from (0,1) to (1,4) becomes a
// block over lines 0..1 and columns 1..4). The carets keep the caret's own column,
// which lands on the block's left edge because an editor caret always sits on the
// selection's earlier end. Returns false when there is nothing to convert.
func (e *Editor) columnBlockFromSelection() bool {
	start, end := e.text.Selection()
	if start == end {
		return false
	}
	if start > end {
		start, end = end, start
	}

	caretLine, caretCol := e.text.CaretPos()
	aLine, aCol := e.columnLogicalPos(start)
	bLine, bCol := e.columnLogicalPos(end)
	lo, hi := min(aCol, bCol), max(aCol, bCol)
	if hi == lo {
		return false // a one-column selection cannot make a block
	}

	// The whole column paints on ONE pixel, so the block's extent is measured on
	// the caret's own line.
	e.columnEdit.selections = nil
	e.columnEdit.caretX = e.paintedCaretX(caretLine, min(max(caretCol, lo), hi))
	e.columnEdit.anchorX = e.paintedCaretX(caretLine, hi)

	first, last := min(aLine, bLine), max(aLine, bLine)
	for line := first; line <= last; line++ {
		if line < 0 || line >= e.text.Paragraphs() {
			continue
		}
		e.addColumnCursor(line)
	}

	e.columnEdit.levelValid = false
	e.scrollCaret = true
	return len(e.columnEdit.selections) > 0
}

// columnToSelection converts the block back into a linear selection over the same
// text. Turning GoLand's column mode off restores a linear selection the same way,
// instead of leaving the editor with nothing selected.
func (e *Editor) columnToSelection() {
	if len(e.columnEdit.selections) == 0 {
		return
	}

	first, last := e.columnLineBounds()
	startOff, endOff := -1, -1
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		switch c.line {
		case first:
			startOff = e.text.ConvertPos(c.line, c.selStart)
		case last:
			endOff = e.text.ConvertPos(c.line, c.selEnd)
		}
	}
	if startOff >= 0 && endOff > startOff {
		e.text.SetCaret(startOff, endOff)
	}
}

// collapseColumnCaretsToEdge moves the whole caret column onto the block's left or
// right edge and clears the selection — what GoLand does when a plain arrow is
// pressed while a block is selected. The edge is measured on the SELECTED RUNES
// (the boundary after the block's last selected rune on the right, the first one on
// the left), not on the drag's pixel, so a drag that stopped mid-character still
// collapses onto a real rune boundary. The drag's band stays as it is, because it
// is what bounds the plain movement that follows.
func (e *Editor) collapseColumnCaretsToEdge(right bool) {
	target := float32(-1)
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		x := e.paintedCaretX(c.line, c.selStart)
		if right {
			x = e.paintedCaretX(c.line, c.selEnd)
		}
		if target < 0 || (right && x > target) || (!right && x < target) {
			target = x
		}
	}
	if target < 0 {
		return
	}

	e.columnEdit.caretX = target
	e.columnEdit.anchorX = target
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		c.col = e.columnColAtX(c.line, target)
		c.selStart, c.selEnd = c.col, c.col
	}
	e.columnEdit.levelValid = false
	e.scrollCaret = true
}

// columnSpan returns the block's pixel extent: the span between the caret column
// and the anchor, whichever way round they are.
func (e *Editor) columnSpan() (lo, hi float32) {
	lo, hi = e.columnEdit.caretX, e.columnEdit.anchorX
	if lo > hi {
		lo, hi = hi, lo
	}
	return lo, hi
}

// newColumnCursor builds a cursor for a line from the block's current columns:
// the rune under the shared caret pixel, and the selection the block covers on
// that line. Used when a vertical Shift+arrow adds a line to the block.
func (e *Editor) newColumnCursor(line int) columnCursor {
	lo, hi := e.columnSpan()
	c := columnCursor{
		line:   line,
		col:    e.columnColAtX(line, e.columnEdit.caretX),
		startX: int(lo),
		endX:   int(hi),
	}
	if hi-lo >= 1 {
		c.selStart, c.selEnd = e.columnSelectionRunes(line, c.startX, c.endX)
	} else {
		c.selStart, c.selEnd = c.col, c.col
	}
	return c
}

// columnColAtX returns the rune col at the given pixel X on a line, using the
// same rule as caret movement: the largest boundary at or before X, promoted to
// the end-of-line insert position once X reaches the line's text end.
func (e *Editor) columnColAtX(line int, x float32) int {
	col := e.largestColAtOrBefore(line, x)
	if lineLen := e.columnLineLength(line); lineLen > 0 && x >= e.paragraphEndX(line) {
		col = lineLen
	}
	return col
}

// columnWordCol returns the col one WORD away from startCol on the given line, in
// the given direction. A word is a run of letters, digits and underscores, which
// is what movement by word means for the default word rules; the jump skips the
// gap first so pressing it repeatedly lands on every word boundary instead of
// stopping inside a word.
func (e *Editor) columnWordCol(line, startCol, dir int) int {
	runes := e.columnLineRunes(line)
	n := len(runes)
	col := min(max(startCol, 0), n)

	isWord := func(r rune) bool {
		return r == '_' || unicode.IsLetter(r) || unicode.IsDigit(r)
	}
	if dir > 0 {
		for col < n && !isWord(runes[col]) {
			col++
		}
		for col < n && isWord(runes[col]) {
			col++
		}
		return col
	}
	for col > 0 && !isWord(runes[col-1]) {
		col--
	}
	for col > 0 && isWord(runes[col-1]) {
		col--
	}
	return col
}

// visibleColumnLines returns how many lines fit in the editor's viewport, which
// is the number of clones GoLand performs for one Shift+PageUp/PageDown
// (visible area height / line height).
func (e *Editor) visibleColumnLines(gtx layout.Context) int {
	lineHeight := e.text.GetLineHeight().Round()
	if lineHeight <= 0 {
		return 1
	}
	return max(1, gtx.Constraints.Max.Y/lineHeight)
}

// columnLineBounds returns the first and last line of the block.
func (e *Editor) columnLineBounds() (first, last int) {
	first, last = e.columnEdit.selections[0].line, e.columnEdit.selections[0].line
	for i := range e.columnEdit.selections {
		line := e.columnEdit.selections[i].line
		if line < first {
			first = line
		}
		if line > last {
			last = line
		}
	}
	return first, last
}

// addColumnCursor puts a cursor on the given line, keeping the cursors ordered by
// line and carrying the block's current columns onto it.
func (e *Editor) addColumnCursor(line int) {
	added := e.newColumnCursor(line)
	idx := len(e.columnEdit.selections)
	for i := range e.columnEdit.selections {
		if e.columnEdit.selections[i].line > line {
			idx = i
			break
		}
	}
	e.columnEdit.selections = append(e.columnEdit.selections, columnCursor{})
	copy(e.columnEdit.selections[idx+1:], e.columnEdit.selections[idx:])
	e.columnEdit.selections[idx] = added
}

// cloneColumnCarets handles a vertical Shift+arrow in column mode: it adds a line
// to the block, or takes the last added one back. GoLand routes Shift+Up/Down to
// CloneCaretActionHandler, whose "level" bookkeeping makes the pair behave like a
// stack — pressing Down twice then Up once leaves the block one line longer than
// it started, and only a further Up adds a line ABOVE the block. Out-of-range
// presses at the document edges do nothing (no wrap), exactly like the clones
// that run off the end in GoLand.
func (e *Editor) cloneColumnCarets(above bool) {
	if len(e.columnEdit.selections) == 0 {
		return
	}

	// Levels only count for a repeated invocation; anything else resets them.
	if !e.columnEdit.levelValid {
		for i := range e.columnEdit.selections {
			e.columnEdit.selections[i].level = 0
		}
	}

	level := 0
	for i := range e.columnEdit.selections {
		if l := e.columnEdit.selections[i].level; abs(l) > abs(level) {
			level = l
		}
	}

	// The outermost line is the one this press acts on: Down pops what an earlier
	// Down added, Up pops what an earlier Up added.
	if (level > 0 && above) || (level < 0 && !above) {
		kept := e.columnEdit.selections[:0]
		for i := range e.columnEdit.selections {
			if abs(e.columnEdit.selections[i].level) == abs(level) {
				continue
			}
			kept = append(kept, e.columnEdit.selections[i])
		}
		e.columnEdit.selections = kept
		e.columnEdit.levelValid = true
		e.scrollCaret = true
		return
	}

	first, last := e.columnLineBounds()
	target := last + 1
	if above {
		target = first - 1
	}
	if target < 0 || target >= e.text.Paragraphs() {
		e.columnEdit.levelValid = true
		return // the block already covers the document edge
	}

	e.addColumnCursor(target)
	if above {
		e.columnEdit.selections[0].level = level - 1
	} else {
		e.columnEdit.selections[len(e.columnEdit.selections)-1].level = level + 1
	}

	e.columnEdit.levelValid = true
	e.scrollCaret = true
}

// cloneColumnCaretsByPage is GoLand's Shift+PageUp/PageDown: it runs the clone
// handler once per visible line, so the block grows — or the last growth is taken
// back — a whole page at a time (PageUpWithSelectionAction). The clone levels
// accumulate across the repeat, exactly as they do in GoLand, because each call
// leaves levelValid set.
func (e *Editor) cloneColumnCaretsByPage(above bool, lines int) {
	if lines < 1 {
		lines = 1
	}
	for i := 0; i < lines; i++ {
		before := len(e.columnEdit.selections)
		e.cloneColumnCarets(above)
		if len(e.columnEdit.selections) == before {
			// The block already reaches the document edge on this side, so
			// further clones do nothing.
			break
		}
	}
}

// columnExtendToEdge extends the block to an edge of the document: homes the caret
// column on the line start, or grows the block out to the end of the widest line
// it covers. With wholeDocument it also takes in every line between the block and
// the document's first/last line, which is what GoLand's Shift+Home / Shift+End
// do by setting a block selection that reaches the document edge
// (TextEndWithSelectionAction).
func (e *Editor) columnExtendToEdge(start, wholeDocument bool) {
	if len(e.columnEdit.selections) == 0 {
		return
	}

	if wholeDocument {
		first, last := e.columnLineBounds()
		if start {
			for line := first - 1; line >= 0; line-- {
				e.addColumnCursor(line)
			}
		} else {
			for line := last + 1; line < e.text.Paragraphs(); line++ {
				e.addColumnCursor(line)
			}
		}
	}

	if start {
		// The carets walk to the line start; the block keeps the columns they
		// came from as its anchor, so it now spans [line start, old caret).
		first, _ := e.columnLineBounds()
		e.columnEdit.anchorX = e.columnEdit.caretX
		target := e.paintedCaretX(first, 0)
		for i := range e.columnEdit.selections {
			e.columnEdit.selections[i].col = 0
		}
		e.columnEdit.caretX = target
	} else {
		// The block grows rightward to the end of its widest line; the carets
		// stay on the block's left edge.
		hi := float32(0)
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			if x := e.paintedCaretX(c.line, len(e.columnLineRunes(c.line))); x > hi {
				hi = x
			}
		}
		if hi > e.columnEdit.anchorX {
			e.columnEdit.anchorX = hi
		}
	}

	e.refreshColumnCoverage()
	e.columnEdit.levelValid = false
	e.scrollCaret = true
}

// columnCaretToEdge moves the caret column onto the block's left or right edge,
// which is what an end-of-line jump means for a column whose carets must stay on
// one pixel: the block's edges are the only horizontal positions shared by every
// line. It collapses the block like any other plain move.
func (e *Editor) columnCaretToEdge(right, wholeDocument bool) {
	if len(e.columnEdit.selections) == 0 {
		return
	}
	if wholeDocument {
		first, last := e.columnLineBounds()
		if right {
			for line := last + 1; line < e.text.Paragraphs(); line++ {
				e.addColumnCursor(line)
			}
		} else {
			for line := first - 1; line >= 0; line-- {
				e.addColumnCursor(line)
			}
		}
	}

	// The block's extent lives on every cursor as the band (startX, endX); the
	// caret/anchor span may already have been collapsed by an earlier plain move,
	// so read the band instead of columnSpan.
	lo := float32(e.columnEdit.selections[0].startX)
	hi := float32(e.columnEdit.selections[0].endX)
	target := lo
	if right {
		target = hi
	}
	e.columnEdit.caretX = target
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		c.col = e.columnColAtX(c.line, target)
		c.selStart, c.selEnd = c.col, c.col
	}
	e.columnEdit.anchorX = target
	e.columnEdit.levelValid = false
	e.scrollCaret = true
}

// moveColumnCarets moves all column carets one step in the given direction
// (delta > 0 = right, delta < 0 = left) and COLLAPSES the block, exactly as
// GoLand collapses a selection on a plain arrow key.
//
// Movement is LEADER-LOCKSTEP in pixel space: the caret on the leading edge
// (rightmost for Right, leftmost for Left) advances one rune boundary, and
// every other caret is snapped onto the SAME target pixel. Snapping to a
// shared pixel keeps the caret column a straight vertical line even when
// lines mix tab indentation or the typeface is proportional — advancing each
// caret by its own logical column made carets drift apart (the "carets are
// not a straight line" bug). Lines too short to reach the target park at
// their end-of-line insert position without blocking the others.
func (e *Editor) moveColumnCarets(delta int) {
	e.moveColumnCaretsWith(delta, false, false)
}

// moveColumnCaretsByWord is moveColumnCarets with a whole word per step.
func (e *Editor) moveColumnCaretsByWord(delta int) {
	e.moveColumnCaretsWith(delta, false, true)
}

// extendColumnCarets moves all column carets one step in the given direction
// while KEEPING the block: the selection spans from the carets' new position to
// the block's anchor, the fixed end. Moving the carets back over the anchor
// collapses the span and then reopens it on the other side, so the carets end up
// on the block's opposite edge — the behaviour IntelliJ's
// EditorMultiCaretColumnModeTest.testSelectionWithKeyboard and
// testReverseBlockSelection describe for Shift+Left / Shift+Right.
func (e *Editor) extendColumnCarets(delta int) {
	e.moveColumnCaretsWith(delta, true, false)
}

// extendColumnCaretsByWord is extendColumnCarets with a whole word per step.
func (e *Editor) extendColumnCaretsByWord(delta int) {
	e.moveColumnCaretsWith(delta, true, true)
}

func (e *Editor) moveColumnCaretsWith(delta int, extend, byWord bool) {
	if len(e.columnEdit.selections) == 0 || delta == 0 {
		return
	}

	// A plain arrow with a block selected COLLAPSES the block onto the edge it
	// moves towards, the way GoLand collapses a selection: ONE press takes the
	// caret column to that edge. Only once the selection is gone do further
	// presses step one column, still bounded by the block.
	//
	// EditorMultiCaretColumnModeTest.testMoveToSelectionStart and
	// testMoveToSelectionEnd pin this down: a block [2,4) whose caret sits at col 4
	// collapses to col 2 on Left, and one whose caret sits at col 2 collapses to
	// col 4 on Right. Word moves keep stepping a word at a time, which is GoLand's
	// separate word-movement handler.
	if !extend && !byWord && e.columnCoverageSelected() {
		e.collapseColumnCaretsToEdge(delta > 0)
		return
	}

	// A Shift sequence that starts with nothing selected anchors on the caret,
	// so the first press selects the single column beside it.
	if extend && !e.columnCoverageSelected() {
		e.columnEdit.anchorX = e.columnEdit.caretX
	}

	if delta > 0 {
		e.moveColumnCaretsRight(extend, byWord)
	} else {
		e.moveColumnCaretsLeft(extend, byWord)
	}
	if !extend {
		// A plain move collapses the block onto the caret, but the anchor (the
		// block's far end) stays put: it is still what parks the carets on the
		// block's edge. A later Shift re-anchors on the caret, because the
		// coverage is now empty.
		//
		// It also ends the vertical clone sequence: GoLand only honours the clone
		// levels while the preceding action was one of its own arrow actions.
		e.columnEdit.levelValid = false
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			c.selStart, c.selEnd = c.col, c.col
		}
	} else {
		e.refreshColumnCoverage()
		e.columnEdit.levelValid = true
	}

	e.scrollCaret = true
}

// columnCoverageSelected reports whether any caret currently has a non-empty
// block selection.
func (e *Editor) columnCoverageSelected() bool {
	for i := range e.columnEdit.selections {
		if c := &e.columnEdit.selections[i]; c.selEnd > c.selStart {
			return true
		}
	}
	return false
}

// refreshColumnCoverage re-derives the block from its pixel extent: the span
// between the caret column and the anchor. It writes the span back into every
// cursor (startX, endX) so painting, movement bounds and the delete clamps keep
// working unchanged, and recomputes each line's own selected rune range.
//
// A collapsed span leaves the previous extent in place as the movement band —
// a zero-width band would freeze the carets — and simply clears the selection,
// so editing falls back to the caret.
func (e *Editor) refreshColumnCoverage() {
	if len(e.columnEdit.selections) == 0 {
		return
	}

	lo, hi := e.columnEdit.caretX, e.columnEdit.anchorX
	if lo > hi {
		lo, hi = hi, lo
	}
	if hi-lo < 1 {
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			c.selStart, c.selEnd = c.col, c.col
		}
		return
	}

	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		c.startX, c.endX = int(lo), int(hi)
		c.selStart, c.selEnd = e.columnSelectionRunes(c.line, c.startX, c.endX)
	}
}

// moveColumnCaretsRight advances the whole caret column one rune boundary to the
// right. When extend is false the target is clamped to the block's right edge,
// so a plain arrow parks the carets there; when extend is true (Shift+Right) the
// clamp is lifted and the carets walk past the block's far edge, which is what
// reopens the selection on the other side of the anchor. byWord makes the step a
// whole word.
func (e *Editor) moveColumnCaretsRight(extend, byWord bool) {
	sels := e.columnEdit.selections

	// Leader = the rightmost caret that can still advance. Carets parked at
	// their end-of-line insert position (col == lineLen, painted at EndX)
	// never lead: their line is exhausted, and they must not block the rest
	// of the column from advancing toward the rectangle's right edge.
	leader, leaderX := -1, float32(0)
	for i := range sels {
		c := &sels[i]
		if c.col >= e.columnLineLength(c.line) {
			continue // parked at end-of-line
		}
		if x := e.paintedCaretX(c.line, c.col); leader < 0 || x > leaderX {
			leader, leaderX = i, x
		}
	}
	if leader < 0 {
		return // every caret is parked
	}
	l := &sels[leader]

	// Target = the leader's next rune boundary (or its end-of-line insert
	// position when col+1 == lineLen — paintedCaretX maps that col to the
	// paragraph's EndX). It becomes the shared painted pixel for the whole caret
	// column.
	//
	// A plain move parks the carets on the block's far edge, so holding an arrow
	// never walks out of the block — the reported bug was exactly the opposite
	// (the caret bouncing off the block's right edge). An extending (Shift) move
	// never clamps, which is what lets the column walk past the block's far edge.
	target := e.paintedCaretX(l.line, l.col+1)
	if byWord {
		target = e.paintedCaretX(l.line, e.columnWordCol(l.line, l.col, 1))
	}
	if !extend && target > float32(l.endX) {
		target = float32(l.endX)
	}
	e.columnEdit.caretX = target

	for i := range sels {
		c := &sels[i]
		lineLen := e.columnLineLength(c.line)
		newCol := e.largestColAtOrBefore(c.line, target)
		// Reaching the end of a line's text promotes the caret to the
		// end-of-line insert position (col == lineLen): typing then appends
		// at the end, and painting aligns the caret with paragraphEndX.
		if lineLen > 0 && target >= e.paragraphEndX(c.line) {
			newCol = lineLen
		}
		if newCol < c.col {
			newCol = c.col // carets never move backwards on Right
		}
		if newCol > lineLen {
			newCol = lineLen
		}
		c.col = newCol
	}
}

// moveColumnCaretsLeft mirrors moveColumnCaretsRight: a plain move stops at the
// block's left edge, while an extending (Shift+Left) move walks past it and
// grows the selection leftward. byWord makes the step a whole word.
func (e *Editor) moveColumnCaretsLeft(extend, byWord bool) {
	sels := e.columnEdit.selections

	// Leader = the leftmost caret that can still move left; carets already at
	// col 0 never lead.
	leader, leaderX := -1, float32(0)
	for i := range sels {
		c := &sels[i]
		if c.col <= 0 {
			continue // parked at the line start
		}
		if x := e.paintedCaretX(c.line, c.col); leader < 0 || x < leaderX {
			leader, leaderX = i, x
		}
	}
	if leader < 0 {
		return // every caret is parked at col 0
	}
	l := &sels[leader]

	target := e.paintedCaretX(l.line, l.col-1)
	if byWord {
		target = e.paintedCaretX(l.line, e.columnWordCol(l.line, l.col, -1))
	}
	if !extend && target < float32(l.startX) {
		target = float32(l.startX)
	}
	e.columnEdit.caretX = target

	for i := range sels {
		c := &sels[i]
		newCol := min(e.largestColAtOrBefore(c.line, target),
			// carets never move right on Left
			c.col)
		if newCol < 0 {
			newCol = 0
		}
		c.col = newCol
	}
}

// startColumnSelection starts a new column selection at the given position.
func (e *Editor) startColumnSelection(pos image.Point) {
	e.initBuffer()

	// Record the anchor unconditionally: presses on folded/short/empty rows
	// return runeOff < 0, but the drag rectangle must still start at the real
	// press point, otherwise updateColumnSelection falls back to a stale (0,0)
	// anchor and builds a bogus rectangle.
	e.columnEdit.anchor = pos
	// The single caret paints at the press point until movement/drag re-anchors it.
	e.columnEdit.caretX = float32(pos.X)
	// Nothing is selected yet, so the anchor sits on the caret.
	e.columnEdit.anchorX = float32(pos.X)
	line, col, runeOff := e.text.QueryPos(pos)
	if runeOff >= 0 {
		e.columnEdit.selections = []columnCursor{{
			line:     line,
			col:      col,
			selStart: col,
			selEnd:   col, // a press selects nothing until the drag builds a block
			startX:   pos.X,
			endX:     pos.X,
		}}
	}
}

// updateColumnSelection updates the column selection based on mouse drag position.
// This is used for Alt+mouse drag to create rectangular selections.
func (e *Editor) updateColumnSelection(_ layout.Context, pos image.Point) {
	e.initBuffer()

	anchor := e.columnEdit.anchor

	// Calculate selection bounds
	startX := min(anchor.X, pos.X)
	endX := max(anchor.X, pos.X)
	startY := min(anchor.Y, pos.Y)
	endY := max(anchor.Y, pos.Y)

	// Get line height (Note: fixed.Int26_6 needs Round())
	lineHeight := e.text.GetLineHeight().Round()
	scrollOff := e.text.ScrollOff()

	// Convert Y coordinates to line numbers
	startLine := (startY + scrollOff.Y) / lineHeight
	endLine := (endY + scrollOff.Y) / lineHeight

	e.columnEdit.selections = nil
	totalLines := e.text.Paragraphs()

	// GoLand puts the caret where the drag ENDED and keeps the other end as the
	// anchor the selection grows away from. A right-to-left drag therefore leaves
	// the carets on the block's left edge (the shape every other operation here
	// builds on), while a left-to-right drag leaves them on the right edge — the
	// state in which GoLand's EditorMultiCaretColumnModeTest.testMoveToSelectionEnd
	// expects the caret, and in which Shift+Right extends the block straight away
	// instead of first collapsing it.
	releaseAtRight := pos.X >= anchor.X
	e.columnEdit.caretX = float32(startX)
	e.columnEdit.anchorX = float32(endX)
	if releaseAtRight {
		e.columnEdit.caretX, e.columnEdit.anchorX = float32(endX), float32(startX)
	}
	// A fresh drag restarts the vertical clone sequence.
	e.columnEdit.levelValid = false

	// Create a cursor for each line in the rectangle. Every line in the range
	// belongs to the block, exactly like GoLand's, which keeps the block's
	// desired column for the whole line range: a line that ends left of the
	// rectangle keeps a caret parked at its own end (col == textLen) and is
	// padded out when text is typed into it, instead of being dropped.
	for lineNum := startLine; lineNum <= endLine; lineNum++ {
		if lineNum < 0 || lineNum >= totalLines {
			continue
		}

		// The caret is the block's LEAD — the end the drag finished on — and the
		// block is the rune range the rectangle covers. Both come from the SAME
		// pixel test, so the caret can never disagree with the selection or with
		// the delete bounds.
		lo, hi := e.columnSelectionRunes(lineNum, startX, endX)
		col := lo
		if releaseAtRight {
			col = hi
		}

		e.columnEdit.selections = append(e.columnEdit.selections,
			columnCursor{
				line:     lineNum,
				col:      col,
				selStart: lo,
				selEnd:   hi,
				startX:   startX,
				endX:     endX,
			})
	}
}

func (s ChangeEvent) isEditorEvent()        {}
func (s SelectEvent) isEditorEvent()        {}
func (s HoverEvent) isEditorEvent()         {}
func (s GutterEventWrapper) isEditorEvent() {}

// gutterEventWrapper wraps gutter events to implement EditorEvent.
type GutterEventWrapper struct {
	Event gutter.GutterEvent
}

// RunButtonEventWrapper wraps a run button event.
type RunButtonEventWrapper struct {
	Event gutter.RunButtonEvent
}

func (RunButtonEventWrapper) isEditorEvent() {}

// MethodIconEventWrapper wraps a click on an inheritance marker in the gutter.
type MethodIconEventWrapper struct {
	Event gutter.MethodIconEvent
}

func (MethodIconEventWrapper) isEditorEvent() {}

// StickyLineEventWrapper wraps a sticky line click event.
type StickyLineEventWrapper struct {
	Event gutter.StickyLineEvent
}

func (StickyLineEventWrapper) isEditorEvent() {}

// stickyProvider returns the gutter provider that draws sticky lines, if one is
// registered.
func (e *Editor) stickyProvider() gutter.StickyLinesProvider {
	if e.gutterManager == nil {
		return nil
	}
	for _, p := range e.gutterManager.Providers() {
		if p.ID() == providers.StickyLinesProviderID {
			if sp, ok := p.(gutter.StickyLinesProvider); ok {
				return sp
			}
		}
	}
	return nil
}

// methodIconProvider returns the gutter provider that draws the inheritance
// markers, if one is registered.
func (e *Editor) methodIconProvider() *providers.MethodIconProvider {
	if e.gutterManager == nil {
		return nil
	}
	for _, p := range e.gutterManager.Providers() {
		if mp, ok := p.(*providers.MethodIconProvider); ok {
			return mp
		}
	}
	return nil
}

// SetMethodIcons replaces the inheritance markers the gutter draws. The map is
// keyed by DOCUMENT line, so collapsing a fold never moves a marker onto
// another method.
func (e *Editor) SetMethodIcons(icons map[int]gutter.MethodIconKind) {
	if p := e.methodIconProvider(); p != nil {
		p.SetMethodIcons(icons)
	}
}

// MarkMethodIcon sets one inheritance marker; gutter.MethodIconNone clears the
// line.
func (e *Editor) MarkMethodIcon(line int, kind gutter.MethodIconKind) {
	if p := e.methodIconProvider(); p != nil {
		p.MarkMethodIcon(line, kind)
	}
}

// renderStickyLines renders sticky lines at the top of the editor viewport.
// Sticky lines show code structure (functions, types, etc.) that has been scrolled
// out of view, helping users maintain context.
//
// Painting only: the clicks are routed through the editor's single pointer
// handler, which consults StickyLineAt before moving the caret. Registering a
// second click handler here made a click in the band both navigate and drop a
// caret into the text hidden behind the band.
func (e *Editor) renderStickyLines(gtx layout.Context, shaper *text.Shaper, textColor gvcolor.Color) {
	stickyProvider := e.stickyProvider()
	if stickyProvider == nil {
		return
	}

	stickyLines, stickyHeight := stickyProvider.StickyLines()
	if len(stickyLines) == 0 || stickyHeight == 0 {
		return
	}

	lineHeight := e.text.GetLineHeight().Round()

	// Set up colors
	var bgColor, borderColor color.NRGBA
	if e.colorPalette != nil && e.colorPalette.Background.IsSet() {
		bgColor = e.colorPalette.Background.NRGBA()
	} else {
		bgColor = color.NRGBA{R: 0xF0, G: 0xF0, B: 0xF0, A: 0xD0}
	}
	bgColor.A = 0xD0 // Slight transparency

	textColorNRGBA := textColor.NRGBA()
	borderColor = textColorNRGBA
	borderColor.A = 0x40

	// Render each sticky line
	for i, sticky := range stickyLines {
		stickyY := i * lineHeight

		// Draw background
		bgRect := image.Rect(0, stickyY, gtx.Constraints.Max.X, stickyY+lineHeight)
		bgStack := clip.Rect(bgRect).Push(gtx.Ops)
		paint.ColorOp{Color: bgColor}.Add(gtx.Ops)
		paint.PaintOp{}.Add(gtx.Ops)
		bgStack.Pop()

		// Draw border at bottom
		if i < len(stickyLines)-1 {
			borderRect := image.Rect(0, stickyY+lineHeight-1, gtx.Constraints.Max.X, stickyY+lineHeight)
			borderStack := clip.Rect(borderRect).Push(gtx.Ops)
			paint.ColorOp{Color: borderColor}.Add(gtx.Ops)
			paint.PaintOp{}.Add(gtx.Ops)
			borderStack.Pop()
		}

		// Draw text
		params := e.text.Params()
		params.MinWidth = 0
		params.MaxLines = 1

		// Trim whitespace for display
		displayText := strings.TrimLeft(sticky.Text, "\t")
		displayText = strings.TrimRight(displayText, " \t\r\n")

		if displayText != "" && shaper != nil {
			shaper.LayoutString(params, displayText)

			glyphs := make([]text.Glyph, 0)
			for {
				g, ok := shaper.NextGlyph()
				if !ok {
					break
				}
				glyphs = append(glyphs, g)
			}

			if len(glyphs) > 0 {
				// Sit the text in its band row the way a normal line sits in its
				// row: baseline one ascent below the top. Centering the baseline
				// instead clipped the ascenders against the top of the viewport.
				baseline := float32(stickyY) + float32(glyphs[0].Ascent.Ceil())
				trans := op.Affine(f32.Affine2D{}.Offset(
					f32.Point{X: float32(glyphs[0].X.Floor()) + 8, Y: baseline},
				)).Push(gtx.Ops)

				// Draw the glyphs
				path := shaper.Shape(glyphs)
				outline := clip.Outline{Path: path}.Op().Push(gtx.Ops)

				paint.ColorOp{Color: textColorNRGBA}.Add(gtx.Ops)
				paint.PaintOp{}.Add(gtx.Ops)

				outline.Pop()
				trans.Pop()
			}
		}
	}
}

// moveToLine scrolls the viewport so the given DOCUMENT line sits just below the
// sticky band. Folding hides lines from the layout, so the document line is
// resolved to the first paragraph at or after it that is actually on screen.
func (e *Editor) moveToLine(lineNum int) {
	textLayout := e.text.TextLayout()
	paragraphs := textLayout.Paragraphs
	if lineNum < 0 || len(paragraphs) == 0 {
		return
	}

	idx := sort.Search(len(paragraphs), func(i int) bool {
		return paragraphs[i].LogicalIndex >= lineNum
	})
	if idx >= len(paragraphs) {
		idx = len(paragraphs) - 1
	}

	// The band covers the first rows, so the target goes below it rather than
	// behind it.
	band := 0
	if sp := e.stickyProvider(); sp != nil {
		_, band = sp.StickyLines()
	}

	e.text.ScrollRel(0, paragraphs[idx].StartY-band-e.text.ScrollOff().Y)
}

// stickyLineAt reports the sticky line drawn at pos, in text-area coordinates.
func (e *Editor) stickyLineAt(pos image.Point) (gutter.StickyLineInfo, bool) {
	sp := e.stickyProvider()
	if sp == nil {
		return gutter.StickyLineInfo{}, false
	}
	return sp.StickyLineAt(pos.Y)
}

// renderColorPickerOverlay renders the color picker overlay if needed.
func (e *Editor) setColorOffsets(gtx layout.Context) {
	if e.gutterManager == nil {
		return
	}

	// Find the color indicator provider
	var colorPickerProvider gutter.ColorPickerProvider

	providers := e.gutterManager.Providers()
	for _, p := range providers {
		if p.ID() == "colorindicator" {
			if ci, ok := p.(gutter.ColorPickerProvider); ok {
				colorPickerProvider = ci
				break
			}
		}
	}

	if colorPickerProvider == nil {
		return
	}

	// Get color offsets from the provider
	colorOffsets := colorPickerProvider.GetColorOffsets()
	if len(colorOffsets) == 0 {
		return
	}

	// Convert color offsets to the format expected by text layout
	indicatorWidth := colorPickerProvider.GetIndicatorWidth(gtx)
	layoutOffsets := make(map[int]map[int]int)

	for line, offsets := range colorOffsets {
		lineOffsets := make(map[int]int)
		for _, offset := range offsets {
			lineOffsets[offset] = indicatorWidth
		}
		layoutOffsets[line] = lineOffsets
	}

	// Set the color offsets in the text layout
	e.text.SetColorOffsets(layoutOffsets)
}

func (e *Editor) renderColorPickerOverlay(gtx layout.Context) {
	if e.gutterManager == nil {
		return
	}

	var colorPickerProvider gutter.ColorPickerProvider

	providers := e.gutterManager.Providers()
	for _, p := range providers {
		if p.ID() == "colorindicator" {
			if ci, ok := p.(gutter.ColorPickerProvider); ok {
				colorPickerProvider = ci
				break
			}
		}
	}

	if colorPickerProvider == nil {
		return
	}

	if !colorPickerProvider.ShowColorPicker() {
		return
	}

	colorPicker := colorPickerProvider.GetEditorColorPicker()
	if colorPicker != nil {
		colorPicker.Update(gtx)
		th := material.NewTheme()
		colorPicker.Layout(gtx, th)
	}
}

func (e *Editor) renderColorIndicatorsInText(gtx layout.Context, shaper *text.Shaper) {
	if e.gutterManager == nil {
		return
	}

	providers := e.gutterManager.Providers()
	for _, p := range providers {
		if p.ID() == "colorindicator" {
			if ci, ok := p.(gutter.ColorPickerProvider); ok {
				ctx := e.buildGutterContext(gtx, shaper)
				ci.RenderInTextArea(gtx, ctx, e.gutterWidth)
				break
			}
		}
	}
}
