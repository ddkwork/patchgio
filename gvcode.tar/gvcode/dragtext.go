package gvcode

import (
	"image"

	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/op/clip"
	"gioui.org/op/paint"
	"gioui.org/unit"
	gvcolor "github.com/oligo/gvcode/color"
)

// textMoveDrag tracks GoLand's "drag the selected text somewhere else" gesture.
// It is deliberately separate from e.dragging, which extends the selection: a
// press inside an existing selection arms a move, and only a drag past the slop
// threshold turns it into one, so a plain click inside the selection still just
// places the caret.
type textMoveDrag struct {
	// armed is set when the press landed inside a non-empty selection.
	armed bool
	// active is set once the pointer moved far enough to be a drag.
	active bool
	// start/end are the selection rune offsets captured before the press was
	// handled, because the normal press path would clear them.
	start int
	end   int
	// press is where the pointer went down, in text-area coordinates.
	press image.Point
	// drop is the rune offset the text would be inserted at.
	drop int
}

// slopPx is the distance the pointer has to travel before a press inside the
// selection becomes a move, matching the 3dp threshold the tree's drag uses.
const textMoveSlopDp = 3

// textMoveEdgeDp is the band at the top and bottom of the viewport where a drag
// scrolls the document.
const textMoveEdgeDp = 24

// textMoveScrollSpeed is how many pixels the document scrolls per frame while
// the pointer sits in the edge band.
const textMoveScrollSpeed = 8

// armedTextMove reports whether a press inside the selection should start a move
// drag rather than a new selection.
func (e *Editor) armedTextMove(pos image.Point) bool {
	if e.mode == ModeReadOnly || e.ColumnEditEnabled() {
		return false
	}
	start, end := e.text.Selection()
	if start > end {
		start, end = end, start
	}
	if start == end {
		return false
	}
	_, _, off := e.text.QueryPos(pos)
	return off >= start && off < end
}

// startTextMove remembers the selection a move drag would move.
func (e *Editor) startTextMove(pos image.Point) {
	start, end := e.text.Selection()
	if start > end {
		start, end = end, start
	}
	e.textMove = textMoveDrag{armed: true, start: start, end: end, press: pos, drop: start}
	e.scrollCaret = false
}

// updateTextMove tracks an armed move drag. It reports whether the drag is a move
// (so the caller skips the selection-extending path).
func (e *Editor) updateTextMove(gtx layout.Context, pos image.Point) bool {
	if !e.textMove.armed {
		return false
	}
	if !e.textMove.active {
		dx := float32(pos.X - e.textMove.press.X)
		dy := float32(pos.Y - e.textMove.press.Y)
		slop := float32(gtx.Dp(unit.Dp(textMoveSlopDp)))
		if dx*dx+dy*dy <= slop*slop {
			return true
		}
		e.textMove.active = true
	}
	_, _, off := e.text.QueryPosClamped(pos)
	e.textMove.drop = clampInt(off, 0, e.Len())
	e.autoScrollDuringMove(gtx, pos)
	return true
}

// autoScrollDuringMove scrolls the document when the pointer is close to the top
// or the bottom of the viewport, so text can be dropped outside the visible area.
func (e *Editor) autoScrollDuringMove(gtx layout.Context, pos image.Point) {
	edge := gtx.Dp(unit.Dp(textMoveEdgeDp))
	height := gtx.Constraints.Max.Y
	direction := 0
	switch {
	case pos.Y < edge:
		direction = -1
	case pos.Y > height-edge:
		direction = 1
	}
	if direction == 0 {
		return
	}
	e.text.ScrollRel(0, direction*textMoveScrollSpeed)
	gtx.Execute(op.InvalidateCmd{})
}

// finishTextMove commits the move: the original range is removed and the text is
// inserted at the drop offset, in one undo group.
func (e *Editor) finishTextMove() (EditorEvent, bool) {
	move := e.textMove
	e.textMove = textMoveDrag{}
	if !move.active {
		// A click without a drag: place the caret where the user pressed, which
		// is what the normal press path would have done. The selection is set
		// explicitly because the press deliberately left it in place.
		_, _, off := e.text.QueryPos(move.press)
		if off < 0 {
			_, _, off = e.text.QueryPosClamped(move.press)
		}
		e.text.SetCaret(off, off)
		e.scrollCaret = true
		return nil, false
	}

	text := e.SelectedText()
	if text == "" {
		return nil, false
	}

	drop := move.drop
	switch {
	case drop >= move.end:
		drop -= move.end - move.start
	case drop > move.start:
		// Inside the moved range: nothing to do.
		drop = move.start
	}
	if drop < 0 {
		drop = 0
	}

	e.buffer.GroupOp()
	e.text.Replace(move.start, move.end, "")
	e.text.SetCaret(drop, drop)
	e.Insert(text)
	e.buffer.UnGroupOp()

	e.scrollCaret = true
	return ChangeEvent{}, true
}

// paintTextMoveCaret draws the insertion point the text would be dropped at.
func (e *Editor) paintTextMoveCaret(gtx layout.Context, color gvcolor.Color) {
	if !e.textMove.active {
		return
	}
	coords := e.text.RuneCoords(e.textMove.drop)
	height := e.text.GetLineHeight().Ceil()
	width := gtx.Dp(unit.Dp(2))
	rect := image.Rect(int(coords.X), int(coords.Y), int(coords.X)+width, int(coords.Y)+height)
	rect = rect.Intersect(image.Rectangle{Max: gtx.Constraints.Max})
	if rect.Empty() {
		return
	}
	stack := clip.Rect(rect).Push(gtx.Ops)
	paint.ColorOp{Color: color.NRGBA()}.Add(gtx.Ops)
	paint.PaintOp{}.Add(gtx.Ops)
	stack.Pop()
}

func clampInt(v, lo, hi int) int {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}
