package gvcode

import (
	"image"
	"testing"

	"gioui.org/io/key"
	"gioui.org/unit"
)

// TestCommentSyntaxTable pins the comment syntax of the file types the editor is
// expected to handle, including the script types (batch uses REM, not "::").
func TestCommentSyntaxTable(t *testing.T) {
	tests := []struct {
		lang       string
		line       string
		blockOpen  string
		blockClose string
	}{
		// C family.
		{"go", "//", "/*", "*/"},
		{"java", "//", "/*", "*/"},
		{"javascript", "//", "/*", "*/"},
		{"typescript", "//", "/*", "*/"},
		{"c", "//", "/*", "*/"},
		{"cpp", "//", "/*", "*/"},
		{"rust", "//", "/*", "*/"},
		{"swift", "//", "/*", "*/"},
		{"kotlin", "//", "/*", "*/"},
		// Hash family.
		{"python", "#", "", ""},
		{"shell", "#", "", ""},
		{"yaml", "#", "", ""},
		{"toml", "#", "", ""},
		{"ruby", "#", "", ""},
		{"dockerfile", "#", "", ""},
		{"makefile", "#", "", ""},
		{"properties", "#", "", ""},
		{"gitignore", "#", "", ""},
		// Windows script family.
		{"bat", "REM", "", ""},
		{"cmd", "REM", "", ""},
		{"batch", "REM", "", ""},
		{"vbs", "'", "", ""},
		// PowerShell has both.
		{"ps1", "#", "<#", "#>"},
		// SQL / Lua / Haskell.
		{"sql", "--", "/*", "*/"},
		{"lua", "--", "--[[", "]]"},
		{"haskell", "--", "{-", "-}"},
		// Semicolon family.
		{"lisp", ";", "", ""},
		{"clojure", ";", "", ""},
		{"asm", ";", "", ""},
		// Percent / bang.
		{"tex", "%", "", ""},
		{"erlang", "%", "", ""},
		{"matlab", "%", "%{", "%}"},
		{"fortran", "!", "", ""},
		// Markup: block only.
		{"html", "", "<!--", "-->"},
		{"xml", "", "<!--", "-->"},
		{"markdown", "", "<!--", "-->"},
		{"css", "", "/*", "*/"},
		// Pascal.
		{"pascal", "//", "{", "}"},
		// No comments at all.
		{"text", "", "", ""},
		{"csv", "", "", ""},
		{"json", "", "", ""},
	}
	for _, tt := range tests {
		syntax, ok := CommentSyntaxForLanguage(tt.lang)
		if !ok {
			t.Errorf("CommentSyntaxForLanguage(%q) is missing from the table", tt.lang)
			continue
		}
		if syntax.Line != tt.line || syntax.BlockStart != tt.blockOpen || syntax.BlockEnd != tt.blockClose {
			t.Errorf("%s = {%q %q %q}, want {%q %q %q}",
				tt.lang, syntax.Line, syntax.BlockStart, syntax.BlockEnd,
				tt.line, tt.blockOpen, tt.blockClose)
		}
	}
	if _, ok := CommentSyntaxForLanguage("nosuchlang"); ok {
		t.Error("an unknown language should not resolve")
	}
}

// TestCommentSyntaxForPath checks extension and base-name resolution, including a
// leading dot and an upper-case extension.
func TestCommentSyntaxForPath(t *testing.T) {
	tests := []struct {
		path string
		line string
	}{
		{"demo/scripts/build.bat", "REM"},
		{"demo/scripts/clean.CMD", "REM"},
		{"demo/main.go", "//"},
		{"demo/Makefile", "#"},
		{"demo/Dockerfile", "#"},
		{"demo/.gitignore", "#"},
		{"demo/deploy.ps1", "#"},
		{"demo/data.csv", ""},
	}
	for _, tt := range tests {
		syntax, ok := CommentSyntaxForPath(tt.path)
		if !ok {
			t.Errorf("CommentSyntaxForPath(%q) did not resolve", tt.path)
			continue
		}
		if syntax.Line != tt.line {
			t.Errorf("CommentSyntaxForPath(%q).Line = %q, want %q", tt.path, syntax.Line, tt.line)
		}
	}
	// A file whose name and extension are both unknown has no known syntax.
	if _, ok := CommentSyntaxForPath("demo/noextension"); ok {
		t.Error("an unknown extension-less file should not resolve")
	}
}

// newCommentHarness builds a harness whose editor uses the given comment syntax.
func newCommentHarness(t *testing.T, content, lang string) (*columnEditHarness, *Editor) {
	t.Helper()
	h := newColumnEditHarness(t, content, image.Pt(640, 220), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	h.ed.WithOptions(WithCommentLanguage(lang))
	h.frame(true)
	return h, h.ed
}

func selectRange(t *testing.T, h *columnEditHarness, e *Editor, start, end int) {
	t.Helper()
	e.SetCaret(start, end)
	h.frame(true)
}

// TestToggleLineCommentGo pins the Go behaviour: the marker goes after the
// indentation, blank lines may be included, and a second toggle restores the
// original text exactly.
func TestToggleLineCommentGo(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tx := 1\n\ty := 2\n}\n"
	h, e := newCommentHarness(t, content, "go")

	// Select the two statements (lines 3 and 4).
	selectRange(t, h, e, runeOffsetOfDocumentLine(content, 3), runeOffsetOfDocumentLine(content, 5)-1)
	if _, ok := e.ToggleLineComment(); !ok {
		t.Fatal("ToggleLineComment reported no syntax")
	}
	h.frame(true)

	want := "package main\n\nfunc main() {\n\t// x := 1\n\t// y := 2\n}\n"
	if got := e.Text(); got != want {
		t.Fatalf("after commenting:\n%q\nwant\n%q", got, want)
	}

	// The commented lines stay selected, so a second toggle uncomments them.
	if _, ok := e.ToggleLineComment(); !ok {
		t.Fatal("the second toggle reported no syntax")
	}
	h.frame(true)
	if got := e.Text(); got != content {
		t.Fatalf("after uncommenting:\n%q\nwant the original\n%q", got, content)
	}
}

// TestToggleLineCommentEmptyLine covers the blank-line case: an empty line in the
// selection gets a bare marker, without a trailing space.
func TestToggleLineCommentEmptyLine(t *testing.T) {
	content := "a\n\nb\n"
	h, e := newCommentHarness(t, content, "go")
	selectRange(t, h, e, 0, len([]rune(content))-1)

	if _, ok := e.ToggleLineComment(); !ok {
		t.Fatal("no syntax")
	}
	h.frame(true)
	want := "// a\n//\n// b\n"
	if got := e.Text(); got != want {
		t.Fatalf("after commenting:\n%q\nwant\n%q", got, want)
	}
}

// TestToggleLineCommentBatch pins the batch/cmd syntax: REM is the marker, and
// "REMOVE" must not be mistaken for a commented "OVE".
func TestToggleLineCommentBatch(t *testing.T) {
	content := "@echo off\nREMOVE /q temp\n"
	h, e := newCommentHarness(t, content, "bat")
	selectRange(t, h, e, 0, len([]rune(content))-1)

	if _, ok := e.ToggleLineComment(); !ok {
		t.Fatal("no syntax for bat")
	}
	h.frame(true)
	want := "REM @echo off\nREM REMOVE /q temp\n"
	if got := e.Text(); got != want {
		t.Fatalf("after commenting:\n%q\nwant\n%q", got, want)
	}

	// Toggling again removes exactly the markers that were added.
	if _, ok := e.ToggleLineComment(); !ok {
		t.Fatal("the second toggle reported no syntax")
	}
	h.frame(true)
	if got := e.Text(); got != content {
		t.Fatalf("after uncommenting:\n%q\nwant the original\n%q", got, content)
	}
}

// TestToggleLineCommentUncommentsOnlyWhenAllAreCommented pins IntelliJ's rule:
// with a mixed selection the action comments the whole block instead of removing
// the existing marker.
func TestToggleLineCommentUncommentsOnlyWhenAllAreCommented(t *testing.T) {
	content := "// a\nb\n"
	h, e := newCommentHarness(t, content, "go")
	selectRange(t, h, e, 0, len([]rune(content))-1)

	if _, ok := e.ToggleLineComment(); !ok {
		t.Fatal("no syntax")
	}
	h.frame(true)
	want := "// // a\n// b\n"
	if got := e.Text(); got != want {
		t.Fatalf("mixed selection:\n%q\nwant\n%q", got, want)
	}
}

// TestToggleLineCommentCaretKeepsItsPlace checks the collapsed-caret case: the
// marker is inserted at the caret and the caret moves past it, so a second toggle
// removes it again without eating a character.
func TestToggleLineCommentCaretKeepsItsPlace(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tx := 1\n}\n"
	h, e := newCommentHarness(t, content, "go")
	caret := runeOffsetOfDocumentLine(content, 3) + len("\tx")
	selectRange(t, h, e, caret, caret)
	h.frame(true)

	if _, ok := e.ToggleLineComment(); !ok {
		t.Fatal("no syntax")
	}
	h.frame(true)
	if got := e.Text(); got != "package main\n\nfunc main() {\n\t// x := 1\n}\n" {
		t.Fatalf("after commenting at the caret:\n%q", got)
	}
	start, end := e.Selection()
	if start != end {
		t.Fatalf("the caret became a selection: %d..%d", start, end)
	}

	if _, ok := e.ToggleLineComment(); !ok {
		t.Fatal("the second toggle reported no syntax")
	}
	h.frame(true)
	if got := e.Text(); got != content {
		t.Fatalf("after uncommenting at the caret:\n%q\nwant the original", got)
	}
}

// TestToggleLineCommentSelectionEndingAtLineStart guards the boundary: a
// selection that stops exactly at the next line's first column must not comment
// that line.
func TestToggleLineCommentSelectionEndingAtLineStart(t *testing.T) {
	content := "a\nb\nc\n"
	h, e := newCommentHarness(t, content, "go")
	// From the start of line 0 up to the start of line 2.
	selectRange(t, h, e, 0, runeOffsetOfDocumentLine(content, 2))

	if _, ok := e.ToggleLineComment(); !ok {
		t.Fatal("no syntax")
	}
	h.frame(true)
	want := "// a\n// b\nc\n"
	if got := e.Text(); got != want {
		t.Fatalf("boundary selection:\n%q\nwant\n%q", got, want)
	}
}

// TestToggleLineCommentWithoutSyntaxIsANoOp covers plain-text files: the command
// must report "nothing done" so Ctrl+/ stays available to the host.
func TestToggleLineCommentWithoutSyntaxIsANoOp(t *testing.T) {
	content := "hello world\n"
	h, e := newCommentHarness(t, content, "text")
	selectRange(t, h, e, 0, len([]rune(content))-1)

	if _, ok := e.ToggleLineComment(); ok {
		t.Fatal("a file type without comments must not comment")
	}
	h.frame(true)
	if got := e.Text(); got != content {
		t.Fatalf("the text was modified: %q", got)
	}
}

// TestToggleBlockCommentWrapsAndUnwraps pins Ctrl+Shift+/ for a C-like language.
// The pair is inserted exactly at the selection bounds: "a := 1" (without the
// trailing line feed) becomes "/*a := 1*/".
func TestToggleBlockCommentWrapsAndUnwraps(t *testing.T) {
	content := "a := 1\n"
	h, e := newCommentHarness(t, content, "go")
	// Select the statement, not the line feed.
	selectRange(t, h, e, 0, len([]rune(content))-1)

	if _, ok := e.ToggleBlockComment(); !ok {
		t.Fatal("no block syntax for go")
	}
	h.frame(true)
	wrapped := "/*a := 1*/\n"
	if got := e.Text(); got != wrapped {
		t.Fatalf("after wrapping:\n%q\nwant\n%q", got, wrapped)
	}

	// The wrapped content stays selected, so the second toggle removes the pair.
	if _, ok := e.ToggleBlockComment(); !ok {
		t.Fatal("the second toggle reported no syntax")
	}
	h.frame(true)
	if got := e.Text(); got != content {
		t.Fatalf("after unwrapping:\n%q\nwant the original", got)
	}
}

// TestToggleBlockCommentWithoutSyntaxIsANoOp covers a line-comment-only language.
func TestToggleBlockCommentWithoutSyntaxIsANoOp(t *testing.T) {
	content := "key: value\n"
	h, e := newCommentHarness(t, content, "yaml")
	selectRange(t, h, e, 0, len([]rune(content))-1)

	if _, ok := e.ToggleBlockComment(); ok {
		t.Fatal("yaml has no block comment")
	}
	h.frame(true)
	if got := e.Text(); got != content {
		t.Fatalf("the text was modified: %q", got)
	}
}

// TestCommentShortcutIsWired drives the real Ctrl+/ key through the input router,
// so the command registration itself is covered and not just the action.
func TestCommentShortcutIsWired(t *testing.T) {
	content := "package main\n\nfunc main() {\n\tx := 1\n}\n"
	h, e := newCommentHarness(t, content, "go")
	caret := runeOffsetOfDocumentLine(content, 3) + len("\tx")
	selectRange(t, h, e, caret, caret)
	h.frame(true)

	h.pressKey("/", key.ModShortcut)
	h.frame(true)
	h.frame(true)
	if got := e.Text(); got != "package main\n\nfunc main() {\n\t// x := 1\n}\n" {
		t.Fatalf("Ctrl+/ did not comment the line:\n%q", got)
	}

	h.pressKey("/", key.ModShortcut)
	h.frame(true)
	h.frame(true)
	if got := e.Text(); got != content {
		t.Fatalf("Ctrl+/ did not uncomment the line:\n%q", got)
	}

	// Ctrl+Shift+/ wraps the selection in a block comment instead.
	lineStart := runeOffsetOfDocumentLine(content, 3)
	selectRange(t, h, e, lineStart+1, lineStart+len("\tx := 1"))
	h.pressKey("/", key.ModShortcut|key.ModShift)
	h.frame(true)
	h.frame(true)
	want := "package main\n\nfunc main() {\n\t/*x := 1*/\n}\n"
	if got := e.Text(); got != want {
		t.Fatalf("Ctrl+Shift+/ did not wrap the selection:\n%q\nwant\n%q", got, want)
	}
}
