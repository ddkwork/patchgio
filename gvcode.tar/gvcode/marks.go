package gvcode

import (
	"sort"

	"github.com/oligo/gvcode/gutter"
	"github.com/oligo/gvcode/gutter/providers"
)

// editorMarks holds the two per-line mark sets IntelliJ keeps per editor:
// bookmarks (Ctrl+F11) and breakpoints (Ctrl+F8). They are keyed by 0-based
// DOCUMENT line, so folding never moves them.
type editorMarks struct {
	bookmarks   map[int]bool
	breakpoints map[int]bool
}

// toggle flips the mark on line and reports the new state.
func (m *editorMarks) toggle(set *map[int]bool, line int) bool {
	if *set == nil {
		*set = map[int]bool{}
	}
	if (*set)[line] {
		delete(*set, line)
		return false
	}
	(*set)[line] = true
	return true
}

// sortedLines returns the marked lines in ascending order.
func sortedLines(set map[int]bool) []int {
	out := make([]int, 0, len(set))
	for line := range set {
		out = append(out, line)
	}
	sort.Ints(out)
	return out
}

// WithBookmarkGutter adds IntelliJ's bookmark column to the gutter. Ctrl+F11
// toggles a bookmark on the caret's line, F11 / Shift+F11 walk them.
func WithBookmarkGutter() EditorOption {
	return func(e *Editor) {
		e.initBuffer()
		if e.gutterManager == nil {
			e.gutterManager = gutter.NewManager()
		}
		e.gutterManager.Register(providers.NewBookmarkProvider(
			func() map[int]bool { return e.marks.bookmarks },
			e.toggleBookmarkAt,
		))
	}
}

// WithBreakpointGutter adds IntelliJ's breakpoint column to the gutter. Ctrl+F8
// toggles a breakpoint on the caret's line.
func WithBreakpointGutter() EditorOption {
	return func(e *Editor) {
		e.initBuffer()
		if e.gutterManager == nil {
			e.gutterManager = gutter.NewManager()
		}
		e.gutterManager.Register(providers.NewBreakpointProvider(
			func() map[int]bool { return e.marks.breakpoints },
			e.toggleBreakpointAt,
		))
	}
}

// ----------------------------------------------------------------- bookmarks

// ToggleBookmark toggles the bookmark on the caret's line (Ctrl+F11) and
// reports the line and whether it is now bookmarked.
func (e *Editor) ToggleBookmark() (int, bool) {
	line := e.positionAt(e.caretOffset()).Line
	return line, e.toggleBookmarkAt(line)
}

func (e *Editor) toggleBookmarkAt(line int) bool {
	return e.marks.toggle(&e.marks.bookmarks, line)
}

// Bookmarks returns the bookmarked document lines in ascending order.
func (e *Editor) Bookmarks() []int { return sortedLines(e.marks.bookmarks) }

// ClearBookmarks drops every bookmark.
func (e *Editor) ClearBookmarks() { e.marks.bookmarks = nil }

// NextBookmark returns the first bookmarked line after line, wrapping around.
func (e *Editor) NextBookmark(line int) (int, bool) {
	lines := e.Bookmarks()
	if len(lines) == 0 {
		return 0, false
	}
	for _, l := range lines {
		if l > line {
			return l, true
		}
	}
	return lines[0], true
}

// PreviousBookmark is NextBookmark in the other direction.
func (e *Editor) PreviousBookmark(line int) (int, bool) {
	lines := e.Bookmarks()
	if len(lines) == 0 {
		return 0, false
	}
	for i := len(lines) - 1; i >= 0; i-- {
		if lines[i] < line {
			return lines[i], true
		}
	}
	return lines[len(lines)-1], true
}

// GoToNextBookmark moves the caret to the next bookmark (F11).
func (e *Editor) GoToNextBookmark() bool {
	line, ok := e.NextBookmark(e.positionAt(e.caretOffset()).Line)
	if !ok {
		return false
	}
	e.GoToPosition(line, 0)
	return true
}

// GoToPreviousBookmark moves the caret to the previous bookmark (Shift+F11).
func (e *Editor) GoToPreviousBookmark() bool {
	line, ok := e.PreviousBookmark(e.positionAt(e.caretOffset()).Line)
	if !ok {
		return false
	}
	e.GoToPosition(line, 0)
	return true
}

// -------------------------------------------------------------- breakpoints

// ToggleBreakpoint toggles the breakpoint on the caret's line (Ctrl+F8) and
// reports the line and whether it is now a breakpoint.
func (e *Editor) ToggleBreakpoint() (int, bool) {
	line := e.positionAt(e.caretOffset()).Line
	return line, e.toggleBreakpointAt(line)
}

func (e *Editor) toggleBreakpointAt(line int) bool {
	return e.marks.toggle(&e.marks.breakpoints, line)
}

// Breakpoints returns the breakpoint document lines in ascending order.
func (e *Editor) Breakpoints() []int { return sortedLines(e.marks.breakpoints) }

// ClearBreakpoints drops every breakpoint.
func (e *Editor) ClearBreakpoints() { e.marks.breakpoints = nil }

// HasBreakpoint reports whether line carries a breakpoint.
func (e *Editor) HasBreakpoint(line int) bool { return e.marks.breakpoints[line] }
