module github.com/oligo/gvcode

go 1.27

require (
	gioui.org v0.10.2
	github.com/andybalholm/stroke v0.0.0-20251027184313-5126dd7227a1
	github.com/go-text/typesetting v0.3.5
	github.com/rdleal/intervalst v1.5.0
	golang.org/x/exp v0.0.0-20260908205506-85c1c2202aba
	golang.org/x/image v0.46.0
)

require (
	gioui.org/shader v1.0.9 // indirect
	golang.org/x/exp/shiny v0.0.0-20250408133849-7e4ce0ab07d0 // indirect
	golang.org/x/net v0.48.0 // indirect
	golang.org/x/sys v0.48.0 // indirect
	golang.org/x/text v0.42.0 // indirect
)
