package gvcode

import (
	"image"
	"testing"

	"gioui.org/io/key"
	"gioui.org/unit"
)

// newEnterHarness builds a focused editor for the Enter/smart-key tests. Column
// mode is off: it has nothing to do with these paths and its carets would only add
// noise.
func newEnterHarness(t *testing.T, content string) (*columnEditHarness, *Editor) {
	t.Helper()
	h := newColumnEditHarness(t, content, image.Pt(600, 200), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	h.frame(true)
	return h, h.ed
}

// caretAt puts the caret at a rune offset and settles the frame.
func caretAt(h *columnEditHarness, e *Editor, off int) {
	h.t.Helper()
	e.SetCaret(off, off)
	h.frame(true)
}

// TestEnterAfterUnmatchedBraceInsertsTheCloser pins IntelliJ's
// EnterAfterUnmatchedBraceHandler: Enter right after a "{" that nothing closes yet
// puts the matching "}" on its own line and indents the caret between them, which
// is what GoLand produces for `func f() {` + Enter.
func TestEnterAfterUnmatchedBraceInsertsTheCloser(t *testing.T) {
	content := "package main\n\nfunc main() {"
	h, e := newEnterHarness(t, content)
	caretAt(h, e, e.Len())

	h.pressKey(key.NameEnter, 0)
	h.frame(true)

	want := "package main\n\nfunc main() {\n\t\n}"
	if got := e.Text(); got != want {
		t.Fatalf("after Enter:\n%q\nwant\n%q", got, want)
	}

	img := image.NewRGBA(image.Rect(0, 0, 600, 200))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-enter-brace-expansion", img)
}

// TestEnterInsideLineCommentSplitsIt pins EnterInLineCommentHandler: with text
// after the caret, Enter splits the line comment and the tail keeps a fresh "//".
func TestEnterInsideLineCommentSplitsIt(t *testing.T) {
	content := "package main\n\n// abcdef\n"
	h, e := newEnterHarness(t, content)
	// The caret sits between "abc" and "def".
	caretAt(h, e, runeOffsetOfDocumentLine(content, 2)+len("// abc"))

	h.pressKey(key.NameEnter, 0)
	h.frame(true)

	want := "package main\n\n// abc\n// def\n"
	if got := e.Text(); got != want {
		t.Fatalf("after Enter:\n%q\nwant\n%q", got, want)
	}
	// The caret follows the tail: right after the new comment's "// ".
	start, _ := e.Selection()
	wantCaret := runeOffsetOfDocumentLine(want, 3) + len("// ")
	if start != wantCaret {
		t.Fatalf("caret = %d, want %d (after the new \"// \")", start, wantCaret)
	}
}

// TestEnterAtEndOfLineCommentIsPlain pins the other half of
// EnterInLineCommentHandler: IntelliJ does NOT continue a line comment when the
// caret already sits at its end.
func TestEnterAtEndOfLineCommentIsPlain(t *testing.T) {
	content := "package main\n\n// abc\n"
	h, e := newEnterHarness(t, content)
	caretAt(h, e, runeOffsetOfDocumentLine(content, 2)+len("// abc"))

	h.pressKey(key.NameEnter, 0)
	h.frame(true)

	want := "package main\n\n// abc\n\n"
	if got := e.Text(); got != want {
		t.Fatalf("after Enter:\n%q\nwant\n%q", got, want)
	}
}

// TestEnterInBlockCommentClosesIt pins EnterInBlockCommentHandler with
// CLOSE_COMMENT_ON_ENTER: Enter inside an unterminated block comment closes it
// below, and the caret stays inside the comment body.
func TestEnterInBlockCommentClosesIt(t *testing.T) {
	content := "package main\n\n/* note"
	h, e := newEnterHarness(t, content)
	caretAt(h, e, e.Len())

	h.pressKey(key.NameEnter, 0)
	h.frame(true)

	want := "package main\n\n/* note\n\n */"
	if got := e.Text(); got != want {
		t.Fatalf("after Enter:\n%q\nwant\n%q", got, want)
	}
	// The caret is inside the comment: before the closing "*/".
	start, _ := e.Selection()
	if end := runeOffsetOfDocumentLine(want, 4); start >= end {
		t.Fatalf("caret = %d, want it inside the comment (before offset %d)", start, end)
	}
}

// TestEnterBetweenBracesExpandsTheBlock pins EnterBetweenBracesHandler: Enter
// between a pair that sits on one line opens the block and indents the caret.
func TestEnterBetweenBracesExpandsTheBlock(t *testing.T) {
	content := "package main\n\nfunc main() {}\n"
	h, e := newEnterHarness(t, content)
	caretAt(h, e, runeOffsetOfDocumentLine(content, 2)+len("func main() {"))

	h.pressKey(key.NameEnter, 0)
	h.frame(true)

	want := "package main\n\nfunc main() {\n\t\n}\n"
	if got := e.Text(); got != want {
		t.Fatalf("after Enter:\n%q\nwant\n%q", got, want)
	}
}

// TestTabJumpsOutsideAnEmptyPair pins the smart-key Tab: inside "()" it steps over
// the closing bracket instead of indenting.
func TestTabJumpsOutsideAnEmptyPair(t *testing.T) {
	content := "package main\n\nfoo()\n"
	h, e := newEnterHarness(t, content)
	open := runeOffsetOfDocumentLine(content, 2) + len("foo(")
	caretAt(h, e, open)

	h.pressKey(key.NameTab, 0)
	h.frame(true)

	if got := e.Text(); got != content {
		t.Fatalf("Tab changed the text: %q", got)
	}
	if start, _ := e.Selection(); start != open+1 {
		t.Fatalf("caret = %d, want %d (past the closing bracket)", start, open+1)
	}
}

// TestBackspaceDeletesAnEmptyPair pins smart backspace: deleting inside "()"
// removes both halves.
func TestBackspaceDeletesAnEmptyPair(t *testing.T) {
	content := "package main\n\nfoo()\n"
	h, e := newEnterHarness(t, content)
	open := runeOffsetOfDocumentLine(content, 2) + len("foo(")
	caretAt(h, e, open)

	h.pressKey(key.NameDeleteBackward, 0)
	h.frame(true)

	want := "package main\n\nfoo\n"
	if got := e.Text(); got != want {
		t.Fatalf("after Backspace:\n%q\nwant\n%q", got, want)
	}
}

// TestCompleteStatementClosesTheBrackets pins Ctrl+Shift+Enter
// (CompleteStatementAction): it closes what the caret still sits inside, and a
// missing "}" lands on its own line.
func TestCompleteStatementClosesTheBrackets(t *testing.T) {
	h, e := newEnterHarness(t, "package main\n\nfunc main(")
	caretAt(h, e, e.Len())

	h.pressKey(key.NameEnter, key.ModShift|key.ModShortcut)
	h.frame(true)

	want := "package main\n\nfunc main()"
	if got := e.Text(); got != want {
		t.Fatalf("after Ctrl+Shift+Enter:\n%q\nwant\n%q", got, want)
	}

	// A brace goes on its own line, the way IntelliJ completes a block.
	h2, e2 := newEnterHarness(t, "package main\n\nfunc main() {")
	caretAt(h2, e2, e2.Len())
	h2.pressKey(key.NameEnter, key.ModShift|key.ModShortcut)
	h2.frame(true)
	want2 := "package main\n\nfunc main() {\n}"
	if got := e2.Text(); got != want2 {
		t.Fatalf("after Ctrl+Shift+Enter on a brace:\n%q\nwant\n%q", got, want2)
	}

	img := image.NewRGBA(image.Rect(0, 0, 600, 200))
	if err := h2.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-enter-complete-statement", img)
}

// stopEnterDelegate takes over Enter without touching the document, which is what
// Result.Stop means in IntelliJ.
type stopEnterDelegate struct {
	called *int
}

func (d stopEnterDelegate) PreprocessEnter(e *Editor, ctx *EnterContext) EnterResult {
	*d.called++
	return EnterStop
}

// TestEnterHandlersRunBeforeTheDefault pins the delegate SPI: a registered
// delegate with Result.Stop prevents the default line break.
func TestEnterHandlersRunBeforeTheDefault(t *testing.T) {
	h, e := newEnterHarness(t, "package main\n\nfunc main() {")
	calls := 0
	e.WithOptions(WithEnterHandlers(stopEnterDelegate{called: &calls}))
	caretAt(h, e, e.Len())

	before := e.Text()
	h.pressKey(key.NameEnter, 0)
	h.frame(true)

	if calls != 1 {
		t.Fatalf("the delegate ran %d times, want 1", calls)
	}
	if got := e.Text(); got != before {
		t.Fatalf("EnterStop still changed the text: %q", got)
	}
}
