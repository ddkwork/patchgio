package gvcode

// Mode defines a mode for the editor. The editor can be switched
// back and forth bewteen different modes, depending on the context.
type EditorMode uint8

const (
	// ModeNormal is the default mode for the editor. Users can
	// insert or select text or anything else.
	ModeNormal EditorMode = iota

	// ModeReadOnly controls whether the contents of the editor can be
	// altered by user interaction. If set, the editor will allow selecting
	// text and copying it interactively, but not modifying it. Users can
	// enter or quit this mode via user commands.
	ModeReadOnly

	// ModeSnippet put the editor into the snippet mode required by LSP protocol.
	// The users can navigate bewteen the snippet locations/placeholders using
	// the tab/shift-tab keys. And clicking or pressing the ESC key switched the
	// editor to normal mode.
	//
	// See https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/#snippet_syntax.
	ModeSnippet

	// ModeColumnEdit enables column (vertical) selection mode, similar to
	// GoLand, VS Code, and other modern editors. Users can select a rectangular
	// block of text across multiple lines and edit them simultaneously.
	ModeColumnEdit
)

func (e *Editor) setMode(mode EditorMode) {
	switch mode {
	case ModeNormal, ModeReadOnly:
		if e.snippetCtx != nil {
			e.snippetCtx.Cancel()
			e.snippetCtx = nil
		}
		// Disable column editing when exiting column edit mode
		if e.mode == ModeColumnEdit && mode != ModeColumnEdit {
			e.clearColumnEdit()
		}
	}

	e.mode = mode
}

// SetColumnEditMode enables or disables column editing mode.
//
// Turning it ON with a linear selection CONVERTS that selection into a block, so a
// rough selection becomes the rectangle the user meant — GoLand's column-mode
// toggle does the same (ToggleColumnModeAction, ToggleColumnModeActionMultiCaretTest).
// With nothing selected the editor only switches mode.
//
// Turning it OFF converts the block back into a linear selection over the same
// text, which is also what GoLand restores.
func (e *Editor) SetColumnEditMode(enabled bool) {
	if enabled {
		e.mode = ModeColumnEdit
		e.columnEdit.enabled = true
		if e.columnBlockFromSelection() {
		}
	} else {
		e.columnToSelection()
		e.clearColumnEdit()
	}
}

// clearColumnEdit clears all column selections and disables column edit mode
func (e *Editor) clearColumnEdit() {
	e.columnEdit.enabled = false
	e.columnEdit.selections = nil
	e.columnEdit.levelValid = false
	if e.mode == ModeColumnEdit {
		e.mode = ModeNormal
	}
}

// ColumnEditEnabled returns whether column editing mode is active
func (e *Editor) ColumnEditEnabled() bool {
	return e.columnEdit.enabled || e.mode == ModeColumnEdit
}
