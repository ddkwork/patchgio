package gvcode

import (
	"image"
	"testing"

	"gioui.org/f32"
	"gioui.org/io/pointer"
	"gioui.org/unit"
)

// dragMoveContent has one line of two words, so a selection can be dragged
// within it and the result is easy to assert.
const dragMoveContent = "package main\n\nfunc main() {\n\talpha beta\n}\n"

// TestDragSelectionMovesTheText pins GoLand's "drag the selection to another
// position": pressing inside the selection and dragging past the slop threshold
// moves the text instead of extending the selection, and a plain click inside the
// selection still just places the caret.
func TestDragSelectionMovesTheText(t *testing.T) {
	h := newColumnEditHarness(t, dragMoveContent, image.Pt(560, 200), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	e := h.ed

	lineStart := runeOffsetOfDocumentLine(dragMoveContent, 3)
	// Select "alpha".
	e.SetCaret(lineStart+1, lineStart+6)
	h.frame(true)
	if start, end := e.Selection(); start != lineStart+1 || end != lineStart+6 {
		t.Fatalf("selection = %d..%d, want the word alpha", start, end)
	}

	lineHeight := e.text.GetLineHeight().Round()
	y := 3*lineHeight + lineHeight/2
	_, fromPt := e.ConvertPos(3, 3) // inside "alpha"
	_, toPt := e.ConvertPos(3, 10)  // end of the line, after "beta"
	from := image.Pt(int(fromPt.X), y)
	to := image.Pt(int(toPt.X)+8, y) // past the line end, so the drop clamps to it

	// Press: the selection must survive so the drag reads as picking it up.
	h.router.Queue(pointer.Event{
		Kind: pointer.Press, Buttons: pointer.ButtonPrimary, Source: pointer.Mouse,
		Position: f32.Pt(float32(from.X), float32(from.Y)),
	})
	h.frame(true)
	if e.textMove == (textMoveDrag{}) || !e.textMove.armed {
		t.Fatalf("the press inside the selection did not arm a move: %+v", e.textMove)
	}
	if start, end := e.Selection(); start != lineStart+1 || end != lineStart+6 {
		t.Fatalf("the press collapsed the selection early: %d..%d", start, end)
	}

	// First move crosses the slop threshold, the second reaches the drop target.
	h.router.Queue(pointer.Event{
		Kind: pointer.Move, Buttons: pointer.ButtonPrimary, Source: pointer.Mouse,
		Position: f32.Pt(float32(from.X+8), float32(from.Y)),
	})
	h.frame(true)
	h.router.Queue(pointer.Event{
		Kind: pointer.Move, Buttons: pointer.ButtonPrimary, Source: pointer.Mouse,
		Position: f32.Pt(float32(to.X), float32(to.Y)),
	})
	h.frame(true)
	if !e.textMove.active {
		t.Fatal("the drag never became a move")
	}
	if e.textMove.drop != lineStart+11 {
		t.Fatalf("drop offset = %d, want %d (the end of the line)", e.textMove.drop, lineStart+11)
	}

	img := image.NewRGBA(image.Rect(0, 0, 560, 200))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-drag-selection", img)

	h.router.Queue(pointer.Event{
		Kind: pointer.Release, Buttons: pointer.ButtonPrimary, Source: pointer.Mouse,
		Position: f32.Pt(float32(to.X), float32(to.Y)),
	})
	h.frame(true)
	h.frame(true)

	want := "package main\n\nfunc main() {\n\t betaalpha\n}\n"
	if got := e.Text(); got != want {
		t.Fatalf("after the drag:\n%q\nwant\n%q", got, want)
	}
	// The caret ends up after the moved text.
	start, _ := e.Selection()
	if wantCaret := lineStart + 11; start != wantCaret {
		t.Fatalf("caret = %d, want %d", start, wantCaret)
	}
}

// TestClickInsideSelectionKeepsTheNormalBehaviour guards the fallback: a press
// inside the selection without a drag must place the caret there, not move text.
func TestClickInsideSelectionKeepsTheNormalBehaviour(t *testing.T) {
	h := newColumnEditHarness(t, dragMoveContent, image.Pt(560, 200), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	e := h.ed

	lineStart := runeOffsetOfDocumentLine(dragMoveContent, 3)
	e.SetCaret(lineStart+1, lineStart+6)
	h.frame(true)

	lineHeight := e.text.GetLineHeight().Round()
	y := 3*lineHeight + lineHeight/2
	_, xPt := e.ConvertPos(3, 3)
	pos := image.Pt(int(xPt.X), y)

	h.router.Queue(pointer.Event{
		Kind: pointer.Press, Buttons: pointer.ButtonPrimary, Source: pointer.Mouse,
		Position: f32.Pt(float32(pos.X), float32(pos.Y)),
	})
	h.frame(true)
	h.router.Queue(pointer.Event{
		Kind: pointer.Release, Buttons: pointer.ButtonPrimary, Source: pointer.Mouse,
		Position: f32.Pt(float32(pos.X), float32(pos.Y)),
	})
	h.frame(true)
	h.frame(true)

	if got := e.Text(); got != dragMoveContent {
		t.Fatalf("a plain click inside the selection moved the text:\n%q", got)
	}
	if start, end := e.Selection(); start != end || start != lineStart+3 {
		t.Fatalf("caret = %d..%d, want the click position %d", start, end, lineStart+3)
	}
}
