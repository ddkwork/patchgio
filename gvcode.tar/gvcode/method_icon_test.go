package gvcode

import (
	"image"
	"image/color"
	"testing"

	"gioui.org/unit"

	"github.com/oligo/gvcode/gutter"
	"github.com/oligo/gvcode/gutter/providers"
	"github.com/oligo/gvcode/internal/folding"
)

// methodIconDocument is a file whose two methods are meant to carry inheritance
// markers: line 2 overrides a method, line 4 implements one.
const methodIconDocument = "package main\n" +
	"\n" +
	"func (b *base) run() {}\n" +
	"\n" +
	"func (i *impl) run() {}\n"

// IntelliJ's dark-theme marker colours, taken from
// platform/icons/src/expui/gutter/overridingMethod_dark.svg and
// implementingMethod_dark.svg: the "O" ring is blue and the "I" ring is green.
var (
	methodIconOverrideRing   = color.NRGBA{R: 0x54, G: 0x8A, B: 0xF7, A: 0xFF}
	methodIconImplementsRing = color.NRGBA{R: 0x57, G: 0x96, B: 0x5C, A: 0xFF}
)

// newMethodIconHarness builds an editor with the line-number gutter and the
// inheritance markers, and feeds it the two markers the tests expect.
func newMethodIconHarness(t *testing.T, size image.Point) (*columnEditHarness, *providers.MethodIconProvider) {
	t.Helper()
	h := newColumnEditHarness(t, methodIconDocument, size, unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	h.ed.WithOptions(WithDefaultGutters(), WithMethodIcons())
	h.ed.SetMethodIcons(map[int]gutter.MethodIconKind{
		2: gutter.MethodOverrides,
		4: gutter.MethodImplements,
	})
	for range 3 {
		h.frame(true)
	}
	provider, ok := h.ed.GutterManager().GetProvider(providers.MethodIconProviderID).(*providers.MethodIconProvider)
	if !ok {
		t.Fatal("the method icon provider was never registered")
	}
	return h, provider
}

// TestMethodIconRendersInheritanceMarkers pins the rendering: an override marker
// must be painted on its own document line in IntelliJ's blue, and an implements
// marker on its line in the green, with nothing on the lines in between.
func TestMethodIconRendersInheritanceMarkers(t *testing.T) {
	h, provider := newMethodIconHarness(t, image.Pt(460, 220))
	e := h.ed
	h.frame(true)

	img := image.NewRGBA(image.Rect(0, 0, 460, 220))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-method-icons", img)

	col, ok := e.GutterManager().ProviderBounds(providers.MethodIconProviderID)
	if !ok {
		t.Fatal("the method icon column was never laid out")
	}
	lineHeight := e.text.GetLineHeight().Round()
	band := func(line int, want color.NRGBA) int {
		return countColorIn(img, col.Min.X, col.Max.X, line*lineHeight, (line+1)*lineHeight, want)
	}

	if n := band(2, methodIconOverrideRing); n < 6 {
		t.Fatalf("no blue override marker on the overridden method's line (%d pixels)", n)
	}
	if n := band(4, methodIconImplementsRing); n < 6 {
		t.Fatalf("no green implements marker on the implemented method's line (%d pixels)", n)
	}

	// The markers must not bleed onto the blank lines or each other's lines.
	for _, line := range []int{0, 1, 3} {
		if n := band(line, methodIconOverrideRing); n != 0 {
			t.Fatalf("a blue marker appeared on line %d, which carries none (%d pixels)", line, n)
		}
		if n := band(line, methodIconImplementsRing); n != 0 {
			t.Fatalf("a green marker appeared on line %d, which carries none (%d pixels)", line, n)
		}
	}
	if n := band(4, methodIconOverrideRing); n != 0 {
		t.Fatalf("the implements line also painted an override marker (%d blue pixels)", n)
	}

	// Two markers were drawn, on the document lines that asked for them.
	rects := provider.MethodIconRects()
	if len(rects) != 2 {
		t.Fatalf("drew %d markers, want 2", len(rects))
	}
	if rects[0].Min.Y >= rects[1].Min.Y {
		t.Fatalf("the markers are not ordered top to bottom: %v", rects)
	}
}

// TestMethodIconClickEmitsEvent drives a real pointer click on the marker and
// checks the editor hands the application the clicked line and kind, exactly
// once so the marker is not wired up twice.
func TestMethodIconClickEmitsEvent(t *testing.T) {
	h, _ := newMethodIconHarness(t, image.Pt(460, 220))
	e := h.ed
	h.frame(true)

	col, ok := e.GutterManager().ProviderBounds(providers.MethodIconProviderID)
	if !ok {
		t.Fatal("the method icon column was never laid out")
	}
	lineHeight := e.text.GetLineHeight().Round()
	clickX := col.Min.X + col.Dx()/2
	clickY := 2*lineHeight + lineHeight/2
	events := h.clickGutter(clickX, clickY)

	img := image.NewRGBA(image.Rect(0, 0, 460, 220))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-method-icons-clicked", img)

	var clicks []gutter.MethodIconEvent
	for _, ev := range events {
		if wrapper, ok := ev.(MethodIconEventWrapper); ok {
			clicks = append(clicks, wrapper.Event)
		}
	}
	if len(clicks) != 1 {
		t.Fatalf("the marker emitted %d events, want exactly 1 (%+v)", len(clicks), clicks)
	}
	if clicks[0].Line != 2 || clicks[0].Kind != gutter.MethodOverrides {
		t.Fatalf("click event = %+v, want the override marker on line 2", clicks[0])
	}
}

// TestMethodIconLandsOnTheDocumentLineAfterFolding proves the markers are keyed
// by document line: collapsing a fold above a marked method must not move the
// marker onto whatever line now sits at that screen position.
func TestMethodIconLandsOnTheDocumentLineAfterFolding(t *testing.T) {
	content := "package main\n" +
		"\n" +
		"func helper() {\n" +
		"\tprintln(1)\n" +
		"\tprintln(2)\n" +
		"}\n" +
		"\n" +
		"func (b *base) run() {}\n"
	h := newColumnEditHarness(t, content, image.Pt(460, 240), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	folds := folding.NewManager()
	h.ed.WithOptions(WithDefaultGutters(), WithMethodIcons(), WithGutter(providers.NewFoldButtonProvider(folds)))
	h.ed.text.SetFoldManager(folds)
	h.ed.SetMethodIcons(map[int]gutter.MethodIconKind{7: gutter.MethodOverrides})
	for range 3 {
		h.frame(true)
	}

	col, ok := h.ed.GutterManager().ProviderBounds(providers.MethodIconProviderID)
	if !ok {
		t.Fatal("the method icon column was never laid out")
	}
	lineHeight := h.ed.text.GetLineHeight().Round()
	hasOverrideMarker := func(img *image.RGBA, line int) bool {
		return countColorIn(img, col.Min.X, col.Max.X, line*lineHeight, (line+1)*lineHeight, methodIconOverrideRing) >= 6
	}

	expanded := image.NewRGBA(image.Rect(0, 0, 460, 240))
	if err := h.win.Screenshot(expanded); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	if !hasOverrideMarker(expanded, 7) {
		t.Fatal("the marker is not on the method's own line before folding")
	}

	// Collapse the helper body, which hides lines 3 and 4 and shortens the
	// document above the marked method.
	if !folds.CollapseFold(2) {
		t.Fatal("the helper body was not detected as a fold")
	}
	for range 3 {
		h.frame(true)
	}
	img := image.NewRGBA(image.Rect(0, 0, 460, 240))
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-method-icons-folded", img)

	if folds.IsLineVisible(3) || folds.IsLineVisible(4) {
		t.Fatalf("the helper body was not collapsed: %+v", folds.GetFoldRanges())
	}
	// Two lines vanished above the method, so it moved from band 7 to band 5; a
	// visible-index lookup would have left the marker behind on band 7.
	if hasOverrideMarker(img, 7) {
		t.Fatal("the marker stayed on the old screen line after folding")
	}
	if !hasOverrideMarker(img, 5) {
		t.Fatal("the marker did not move with its document line after folding")
	}
}
