package gvcode

import (
	"fmt"
	"image"
	"image/color"
	"image/png"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"gioui.org/font/gofont"
	"gioui.org/font/opentype"
	"gioui.org/gpu/headless"
	"gioui.org/io/input"
	"gioui.org/io/key"
	"gioui.org/io/transfer"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/text"
	"gioui.org/unit"
	"golang.org/x/image/font/gofont/gomono"

	gvcolor "github.com/oligo/gvcode/color"
	"github.com/oligo/gvcode/textstyle/syntax"
)

// columnEditHarness borrows the flowui/uitest idea (gioui.org/gpu/headless +
// synthetic layout.Context) so column-edit caret math runs against a real,
// laid-out, FOCUSED Editor instead of mocks. Without a real input.Router the
// editor never satisfies gtx.Focused(e), showCaret is forced false every frame
// and NO caret is ever painted — which is exactly how a state-only test can
// pass while the rendered bug persists.
type columnEditHarness struct {
	t            *testing.T
	win          *headless.Window
	router       *input.Router
	shaper       *text.Shaper
	focusPending bool
	metric       unit.Metric
	gtx          layout.Context
	ed           *Editor
}

func newColumnEditHarness(t *testing.T, content string, size image.Point, metric unit.Metric) *columnEditHarness {
	t.Helper()
	win, err := headless.NewWindow(size.X, size.Y)
	if err != nil {
		t.Skipf("headless renderer unavailable: %v", err)
	}
	t.Cleanup(win.Release)

	ed := &Editor{}
	ed.initBuffer()
	ed.SetText(content)
	ed.text.TextSize = unit.Sp(14)
	ed.text.WrapLine = false
	// layout() panics without a color palette; use the same option the example uses.
	scheme := syntax.ColorScheme{
		Foreground: gvcolor.MakeColor(color.NRGBA{R: 0xd4, G: 0xd4, B: 0xd4, A: 0xff}),
		// Translucent select color like the example app (MulAlpha(0x60)): an
		// opaque rect paints OVER the glyphs and hides the selected text,
		// which makes rendered screenshots useless as evidence.
		SelectColor:     gvcolor.MakeColor(color.NRGBA{R: 0x26, G: 0x4f, B: 0x78, A: 0xff}).MulAlpha(0x60),
		Background:      gvcolor.MakeColor(color.NRGBA{R: 0x1e, G: 0x1e, B: 0x1e, A: 0xff}),
		LineColor:       gvcolor.MakeColor(color.NRGBA{R: 0x28, G: 0x28, B: 0x28, A: 0xff}),
		LineNumberColor: gvcolor.MakeColor(color.NRGBA{R: 0x85, G: 0x85, B: 0x85, A: 0xff})}
	WithColorScheme(scheme)(ed)
	// The user enters column editing with Alt+C (SetColumnEditMode). Without
	// it ColumnEditEnabled() is false and Layout never even calls
	// paintColumnCarets — the render test would silently verify nothing.
	ed.SetColumnEditMode(true)

	h := &columnEditHarness{
		t:            t,
		win:          win,
		router:       &input.Router{},
		shaper:       text.NewShaper(text.WithCollection(gofont.Collection())),
		focusPending: true,
		metric:       metric,
		ed:           ed,
	}
	// Frame 1 queues key.FocusCmd (processed by router.Frame at the end of the
	// frame); frame 2 lays out with the editor focused and consumes the
	// FocusEvent; frame 3 is fully deterministic. Two frames are not enough.
	h.frame(true)
	h.frame(true)
	h.frame(true)
	return h
}

// frame lays out and renders one frame. caretOn selects the caret blink phase
// deterministically: while focused and blinking (dt < 10s), showCaret is
// dt%timePerBlink < timePerBlink/2 with timePerBlink = 1s (blinksPerSecond=1).
// blinkStart 100ms ago => caret ON, 600ms ago => caret OFF.
func (h *columnEditHarness) frame(caretOn bool) {
	h.t.Helper()
	now := time.Now()
	if caretOn {
		h.ed.blinkStart = now.Add(-100 * time.Millisecond)
	} else {
		h.ed.blinkStart = now.Add(-600 * time.Millisecond)
	}
	h.gtx = layout.Context{
		Ops:         new(op.Ops),
		Source:      h.router.Source(),
		Metric:      h.metric,
		Constraints: layout.Constraints{Max: h.win.Size()},
		Now:         now,
	}
	if h.focusPending {
		h.gtx.Execute(key.FocusCmd{Tag: h.ed})
		h.focusPending = false
	}
	h.ed.Layout(h.gtx, h.shaper)
	h.router.Frame(h.gtx.Ops)
	if err := h.win.Frame(h.gtx.Ops); err != nil {
		h.t.Fatalf("headless frame: %v", err)
	}
}

// TestColumnEditRightArrowParksAtRightEdge reproduces the reported bug: in
// column edit mode, repeatedly pressing Right bounced the caret back to the
// left edge once it reached the middle of the selection rectangle.
//
// Root cause: the endX clamp loop in moveColumnCarets scanned testCol up to
// lineLength inclusive. ConvertPos(line, lineLength) resolves past the
// paragraph boundary to the NEXT line's first rune, whose X equals the line
// start and therefore always satisfies "X <= endX". bestCol jumped to
// end-of-line, and painting re-derived the caret X from that col, snapping
// the visible caret back to startX.
func TestColumnEditRightArrowParksAtRightEdge(t *testing.T) {
	content := "//go:build ignore\n" + // 17 runes, mirrors the reported repro
		"package main\n" +
		"import (\n" +
		"\t\"fmt\"\n" +
		"\t\"os\"\n" +
		")\n"
	h := newColumnEditHarness(t, content, image.Pt(600, 200), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed

	// Build a rectangle whose right edge sits between col 3 and col 4 of
	// the first line, like a short Alt+drag.
	_, x0 := e.ConvertPos(0, 0)
	_, x3 := e.ConvertPos(0, 3)
	_, x4 := e.ConvertPos(0, 4)
	startX := int(x0.X)
	endX := (int(x3.X) + int(x4.X)) / 2
	if !(int(x3.X) <= endX && endX < int(x4.X)) {
		t.Fatalf("bad rectangle metrics: x3=%d endX=%d x4=%d", int(x3.X), endX, int(x4.X))
	}

	lineHeight := e.text.GetLineHeight().Round()
	e.startColumnSelection(image.Pt(startX, 0))
	e.updateColumnSelection(h.gtx, image.Pt(endX, lineHeight*(e.text.Paragraphs()-1)))
	if len(e.columnEdit.selections) == 0 {
		t.Fatal("no column selections created")
	}

	line0Runes := e.text.ConvertPos(1, 0) - e.text.ConvertPos(0, 0)
	if line0Runes <= 4 {
		t.Fatalf("line 0 too short for the scenario: %d runes", line0Runes)
	}

	// Hold Right until NO caret moves any further. Convergence must be
	// global: with leader-lockstep movement an individual caret may pause
	// while the rest of the column catches up.
	last := make([]int, len(e.columnEdit.selections))
	final := -1
	converged := false
	for i := 0; i < line0Runes+40; i++ {
		for j := range e.columnEdit.selections {
			last[j] = e.columnEdit.selections[j].col
		}
		e.moveColumnCarets(1)
		final = e.columnEdit.selections[0].col
		moved := false
		for j := range e.columnEdit.selections {
			if e.columnEdit.selections[j].col != last[j] {
				moved = true
				break
			}
		}
		if !moved {
			converged = true
			break
		}
	}
	if !converged {
		t.Fatalf("caret never converged while holding Right (last col %d)", final)
	}

	// The bounce-back signature: col escaped to end-of-line, which makes the
	// painted caret jump back to the line start.
	if final >= line0Runes {
		t.Fatalf("caret ran to end-of-line col %d (line len %d): bounce-back repro", final, line0Runes)
	}
	// A left-to-right drag leaves the carets on the block's exclusive right edge
	// (col 4 here: the boundary just after the last selected rune), and holding
	// Right keeps them there because the block bounds plain movement.
	if final != 4 {
		t.Fatalf("caret should hold the block's right edge col 4, got %d", final)
	}

	// Extra Right presses must keep it parked at the right edge.
	e.moveColumnCarets(1)
	e.moveColumnCarets(1)
	if got := e.columnEdit.selections[0].col; got != final {
		t.Fatalf("caret bounced after extra Right presses: %d -> %d", final, got)
	}

	// Left still returns to the left edge of the rectangle and stays there.
	for i := 0; i < line0Runes+40; i++ {
		e.moveColumnCarets(-1)
	}
	if got := e.columnEdit.selections[0].col; got != 0 {
		t.Fatalf("Left should return to col 0, got %d", got)
	}
	e.moveColumnCarets(-1)
	if got := e.columnEdit.selections[0].col; got != 0 {
		t.Fatalf("caret moved before rectangle start on extra Left: got %d", got)
	}
}

// TestColumnEditRightArrowRealWorldScenario mirrors the user's exact repro:
// ~30 lines of import-like content, an Alt+drag from the RIGHT edge to the
// LEFT edge (anchor on the right), then holding Right. Each press dumps the
// reference cursor state so any bounce shows up in the trace.
func TestColumnEditRightArrowRealWorldScenario(t *testing.T) {
	var b strings.Builder
	b.WriteString("//go:build ignore\n// +build ignore\n\npackage main\n\nimport (\n")
	for _, imp := range []string{
		"\"fmt\"", "\"image\"", "\"image/color\"", "\"log\"",
		"_ \"net/http/pprof\" // This line registers the pprof handlers",
		"\"os\"", "\"regexp\"", "\"strings\"", "\"testing\"", "\"time\"",
		"\"unicode/utf8\"",
	} {
		b.WriteString("\t" + imp + "\n")
	}
	b.WriteString("\n\t\"gioui.org/app\"\n\t\"gioui.org/io/key\"\n\t\"gioui.org/layout\"\n" +
		"\t\"gioui.org/op\"\n\t\"gioui.org/text\"\n\t\"gioui.org/unit\"\n\t\"gioui.org/widget\"\n" +
		"\t\"gioui.org/widget/material\"\n\t\"github.com/oligo/gvcode\"\n" +
		"\t\"github.com/oligo/gvcode/addons/completion\"\n\t\"github.com/oligo/gvcode/addons/diff\"\n" +
		"\tgvcolor \"github.com/oligo/gvcode/color\"\n\t\"github.com/oligo/gvcode/gutter\"\n" +
		"\t\"github.com/oligo/gvcode/gutter/providers\"\n)\n")
	h := newColumnEditHarness(t, b.String(), image.Pt(1180, 880), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed

	lineHeight := e.text.GetLineHeight().Round()
	totalLines := e.text.Paragraphs()
	if totalLines < 28 {
		t.Fatalf("content should have >=28 lines, got %d", totalLines)
	}

	// Rect: from line start to ~col 12 of line 0, like the reported repro.
	_, x0 := e.ConvertPos(0, 0)
	_, x12 := e.ConvertPos(0, 12)
	startX := int(x0.X)
	endX := int(x12.X)
	t.Logf("metrics: lineHeight=%d totalLines=%d startX=%d endX=%d", lineHeight, totalLines, startX, endX)

	// Anchor on the RIGHT (user dragged right-to-left).
	e.startColumnSelection(image.Pt(endX, 0))
	e.updateColumnSelection(h.gtx, image.Pt(startX, lineHeight*(totalLines-1)))
	if len(e.columnEdit.selections) == 0 {
		t.Fatal("no selections created")
	}
	t.Logf("selections: %d, ref(line=%d col=%d startX=%d endX=%d)",
		len(e.columnEdit.selections), e.columnEdit.selections[0].line,
		e.columnEdit.selections[0].col, e.columnEdit.selections[0].startX, e.columnEdit.selections[0].endX)

	line0Runes := e.text.ConvertPos(1, 0) - e.text.ConvertPos(0, 0)
	ref := &e.columnEdit.selections[0]

	var trace strings.Builder
	last := make([]int, len(e.columnEdit.selections))
	convergedAt := -1
	for press := 1; press <= 200; press++ {
		for j := range e.columnEdit.selections {
			last[j] = e.columnEdit.selections[j].col
		}
		e.moveColumnCarets(1)
		_, pos := e.ConvertPos(ref.line, ref.col)
		fmt.Fprintf(&trace, "press %2d: ref col=%2d pixelX=%.1f (rect %d..%d)\n",
			press, ref.col, pos.X, ref.startX, ref.endX)
		moved := false
		for j := range e.columnEdit.selections {
			if e.columnEdit.selections[j].col != last[j] {
				moved = true
				break
			}
		}
		if !moved {
			convergedAt = press
			break
		}
	}
	t.Log("\n" + trace.String())

	if convergedAt < 0 {
		t.Fatalf("caret never converged; trace:\n%s", trace.String())
	}
	if ref.col >= line0Runes {
		t.Fatalf("caret escaped to end-of-line col %d (line len %d):\n%s", ref.col, line0Runes, trace.String())
	}
	if ref.col != 12 {
		t.Fatalf("caret should park at col 12 (right edge), got %d:\n%s", ref.col, trace.String())
	}

	// Keep pressing: must stay parked.
	for range 5 {
		e.moveColumnCarets(1)
	}
	if ref.col != 12 {
		t.Fatalf("caret bounced after extra presses: got %d", ref.col)
	}
}

// TestColumnEditRightArrowShortLineNoBounce covers the second bounce trigger
// found via instrumented logs: when the rectangle is wider than a selected
// line (short/empty/folded rows), col == lineLength has no pixel of its own —
// ConvertPos leaks to the next paragraph whose X (~line start) sits inside
// the rectangle, teleporting the painted caret back to the line start.
func TestColumnEditRightArrowShortLineNoBounce(t *testing.T) {
	content := "//go:build ignore\n" +
		"package main\n" +
		"\n" + // empty line inside the rectangle
		"ab\n" + // 2-rune line, way narrower than the rectangle
		"import (\n" +
		"\t\"fmt\"\n" +
		")\n"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed

	lineHeight := e.text.GetLineHeight().Round()
	totalLines := e.text.Paragraphs()

	// Rectangle much wider than most lines, anchored right-to-left.
	e.startColumnSelection(image.Pt(400, 0))
	e.updateColumnSelection(h.gtx, image.Pt(0, lineHeight*(totalLines-1)))
	if len(e.columnEdit.selections) == 0 {
		t.Fatal("no selections created")
	}

	ref := &e.columnEdit.selections[0]
	var prevX float32 = -1
	for press := 1; press <= 200; press++ {
		e.moveColumnCarets(1)
		lineLen := e.text.ConvertPos(ref.line+1, 0) - e.text.ConvertPos(ref.line, 0)
		if ref.col > lineLen {
			t.Fatalf("press %d: col %d escaped past line end (line len %d)", press, ref.col, lineLen)
		}
		// The painted pixel IS the shared caretX; it must never go
		// backwards (bounce).
		if pos := e.columnEdit.caretX; pos < prevX {
			t.Fatalf("press %d: caret X went backwards (%.1f -> %.1f) — bounce", press, prevX, pos)
		} else {
			prevX = pos
		}
	}

	// The caret holds the end-of-line position (one past the last rune) — a
	// legitimate insert position; painting clamps the pixel, not the state.
	lineLen := e.text.ConvertPos(ref.line+1, 0) - e.text.ConvertPos(ref.line, 0)
	if ref.col != lineLen {
		t.Fatalf("caret should park at end-of-line col %d, got %d", lineLen, ref.col)
	}
}

// --- rendered-frames verification -------------------------------------------
//
// The flowui uitest way: RENDER every frame headlessly, dump a PNG per Right
// press, and pixel-scan the caret column in the rendered image. State asserts
// alone missed two real bugs; pixels don't lie.

// screenshotDir keeps rendered frames next to the flowui screenshot output.
func screenshotDir(t *testing.T) string {
	t.Helper()
	dir := filepath.Join("..", "..", "bin", "screenshots")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Skipf("cannot create screenshot dir %s: %v", dir, err)
	}
	return dir
}

// dumpPNG writes one rendered frame (patchgio is exempt from testutil.DumpPNG;
// this module cannot import internal packages).
func dumpPNG(t *testing.T, dir, name string, img *image.RGBA) {
	t.Helper()
	f, err := os.Create(filepath.Join(dir, name+".png"))
	if err != nil {
		t.Fatalf("create png: %v", err)
	}
	defer f.Close()
	if err := png.Encode(f, img); err != nil {
		t.Fatalf("encode png: %v", err)
	}
}

// caretXByBlinkDiff finds the caret column by BLINK DIFF: render the same
// state with the caret blink phase ON and OFF; the only differing columns in
// the band are the caret. Glyph stems and the selection rectangle are static,
// so unlike a color heuristic this cannot misfire. Returns the RIGHTMOST
// differing column (a caret is 1-2px wide; adjacent diff columns are one
// caret) and whether any was found.
func (h *columnEditHarness) caretXByBlinkDiff(t *testing.T, top, bottom, xMin, xMax int) (int, bool) {
	t.Helper()
	h.frame(true)
	on := image.NewRGBA(image.Rect(0, 0, h.win.Size().X, h.win.Size().Y))
	if err := h.win.Screenshot(on); err != nil {
		t.Fatalf("screenshot on: %v", err)
	}
	h.frame(false)
	off := image.NewRGBA(image.Rect(0, 0, h.win.Size().X, h.win.Size().Y))
	if err := h.win.Screenshot(off); err != nil {
		t.Fatalf("screenshot off: %v", err)
	}

	for x := xMax; x >= xMin; x-- {
		diffRows := 0
		for y := top; y < bottom; y++ {
			po, pf := on.At(x, y), off.At(x, y)
			if po != pf {
				ro, go_, bo, _ := po.RGBA()
				rf, gf, bf, _ := pf.RGBA()
				// Tolerate the GPU's ±1/255 antialiasing jitter between
				// frames; only caret-class deltas (>16/255) count.
				const tol = 4096 // 16 in 8-bit scale
				if abs32(ro, rf) > tol || abs32(go_, gf) > tol || abs32(bo, bf) > tol {
					diffRows++
				}
			}
		}
		if diffRows >= (bottom-top)*85/100 {
			return x, true
		}
	}
	return -1, false
}

func abs32(a, b uint32) uint32 {
	if a > b {
		return a - b
	}
	return b - a
}

// runRenderedRightArrowTrajectory is the DPI-parametrized body of the
// rendered-frames test. scale is the device pixel ratio (1x and the 1.5x many
// laptops run are the interesting cases: px rounding must not break parking).
func runRenderedRightArrowTrajectory(t *testing.T, scale float32, pngSuffix string) {
	longLine := "// this is a fairly long leading comment used to reach the rectangle edge"
	content := longLine + "\npackage main\nab\nimport (\n\t\"fmt\"\n)\n"
	metric := unit.Metric{PxPerDp: scale, PxPerSp: scale}
	h := newColumnEditHarness(t, content, image.Pt(int(600*scale), int(300*scale)), metric)
	e := h.ed
	dir := screenshotDir(t)
	// GoLand's editor font is monospace, where every line's column boundaries sit
	// on the same pixel grid — the test asserts the caret column is one straight
	// line, so measure it on that grid.
	h.useMonospace(t)

	lineHeight := e.text.GetLineHeight().Round()
	totalLines := e.text.Paragraphs()

	// Rectangle from line start (col 0) to ~col 12 of line 0, anchored on the
	// RIGHT like the user's right-to-left Alt+drag.
	_, x0 := e.ConvertPos(0, 0)
	_, x12 := e.ConvertPos(0, 12)
	startX := int(x0.X)
	endX := int(x12.X)

	e.startColumnSelection(image.Pt(endX, 0))
	e.updateColumnSelection(h.gtx, image.Pt(startX, lineHeight*(totalLines-1)))
	if len(e.columnEdit.selections) == 0 {
		t.Fatal("no selections created")
	}

	// Park the MAIN caret at the buffer end so its static pixels stay outside
	// every scanned band; otherwise it pollutes the blink diff.
	e.text.MoveCaret(e.Len(), 0)

	ref := &e.columnEdit.selections[0]
	if ref.col != 0 {
		t.Fatalf("drag from right to left should start carets at col 0, got %d", ref.col)
	}

	bandTop := func(line int) int { return line*lineHeight + 2 }
	bandBot := func(line int) int { return (line+1)*lineHeight - 2 }

	// Hold Left to pin the caret at the rectangle's left edge (user step 1).
	for range 10 {
		e.moveColumnCarets(-1)
	}
	if ref.col != 0 {
		t.Fatalf("Left should pin the caret at col 0, got %d", ref.col)
	}

	presses := 0
	longPrev := -1
	for press := 1; press <= 60; press++ {
		e.moveColumnCarets(1)

		// Rendered "caret on" frame for the PNG sequence (the blink diff
		// renders its own ON/OFF pair afterwards).
		h.frame(true)
		img := image.NewRGBA(image.Rect(0, 0, int(600*scale), int(300*scale)))
		if err := h.win.Screenshot(img); err != nil {
			t.Fatalf("screenshot: %v", err)
		}
		dumpPNG(t, dir, "gvcode-column-right-press"+fmt.Sprintf("%02d", press)+pngSuffix, img)

		longX, ok := h.caretXByBlinkDiff(t, bandTop(0), bandBot(0), startX, endX+int(6*scale))
		if !ok {
			t.Fatalf("press %d: caret not found on the long line band", press)
		}
		if longPrev >= 0 && longX < longPrev-1 {
			t.Fatalf("press %d: long-line caret went backwards %d -> %d", press, longPrev, longX)
		}
		longPrev = longX

		// Short line "ab" parks at its end-of-line insert position long before
		// the rectangle's right edge, yet its caret must still paint at the
		// SHARED caretX: the whole point of column mode is a straight vertical
		// caret line, even when that line runs past a short line's text.
		// (Earlier semantics painted parked carets at the line's own EndX,
		// which left a ragged caret column — the "not a straight line" bug.)
		shortX, ok := h.caretXByBlinkDiff(t, bandTop(2), bandBot(2), startX, endX+int(6*scale))
		if !ok {
			t.Fatalf("press %d: caret not found on the short line band", press)
		}
		if d := shortX - longX; d > 1 || d < -1 {
			t.Fatalf("press %d: carets are not a straight line: long line x=%d vs short line x=%d (Δ=%d)",
				press, longX, shortX, d)
		}

		presses = press
		t.Logf("press %2d: state col=%d long-line caret x=%d (rect %d..%d)", press, ref.col, longX, startX, endX)
		// Converged at the rectangle's right edge?
		if longX >= endX-int(2*scale) {
			break
		}
	}

	if longPrev < endX-int(2*scale) {
		t.Fatalf("long-line caret never reached the right edge: got x=%d, endX=%d after %d presses", longPrev, endX, presses)
	}

	// Extra Right presses must hold the right edge — no bounce.
	for range 5 {
		e.moveColumnCarets(1)
	}
	heldX, ok := h.caretXByBlinkDiff(t, bandTop(0), bandBot(0), startX, endX+int(6*scale))
	if !ok || heldX < endX-int(2*scale) {
		t.Fatalf("caret bounced off the right edge on extra presses: held x=%d (endX=%d)", heldX, endX)
	}
}

// TestColumnEditRightArrowRenderedFrames1x verifies at 1x DPI.
func TestColumnEditRightArrowRenderedFrames1x(t *testing.T) {
	runRenderedRightArrowTrajectory(t, 1, "")
}

// TestColumnEditRightArrowRenderedFrames15x verifies at 1.5x DPI (px rounding
// must not keep the caret from parking at the rectangle's right edge).
func TestColumnEditRightArrowRenderedFrames15x(t *testing.T) {
	runRenderedRightArrowTrajectory(t, 1.5, "-15x")
}

// --- column delete / GoLand parity -------------------------------------------
//
// GoLand column mode semantics: every caret deletes the cluster(s) AFTER
// (Delete) or BEFORE (Backspace) itself ON ITS OWN LINE, a deletion never
// crosses the line boundary (lines can never merge), edge carets simply have
// nothing to delete, and the caret column stays a straight vertical line that
// tracks the deleted width.

// deleteLineRunes mirrors onColumnEditDelete's col convention: the editor
// counts col over paragraph runes, so a parked caret sits at len(runes)+1
// (one PAST the trailing newline) and a caret ON the newline sits at
// len(runes). Deletions never touch the newline itself.
func deleteLineRunes(line string, col, clusters int, backward bool) (string, int) {
	r := []rune(line)
	n := len(r)
	if !backward {
		// On the newline or parked past it: nothing after the caret.
		if col >= n {
			return line, 0
		}
		end := min(col+clusters, n)
		return string(r[:col]) + string(r[end:]), end - col
	}
	eff := min(col, n)
	if eff <= 0 {
		return line, 0
	}
	start := max(eff-clusters, 0)
	return string(r[:start]) + string(r[eff:]), eff - start
}

// selectAllLinesRect builds a column rectangle covering every line, from the
// line start to endX.
func selectAllLinesRect(t *testing.T, h *columnEditHarness, endX int) {
	t.Helper()
	lineHeight := h.ed.text.GetLineHeight().Round()
	h.ed.startColumnSelection(image.Pt(endX, 0))
	h.ed.updateColumnSelection(h.gtx, image.Pt(0, lineHeight*(h.ed.text.Paragraphs()-1)))
	if len(h.ed.columnEdit.selections) == 0 {
		t.Fatal("no column selections created")
	}
}

// deleteParityContent mixes plain, tab-indented, short and empty lines so the
// carets land on different logical columns after a pixel-lockstep march.
const deleteParityContent = "abcdefg\n\thij\nab\n\nklmnopqrst\n"

// TestColumnEditDeleteForwardGoLandParity: after moving the column right,
// Delete removes the char AFTER every mid-line caret, changes nothing on
// parked (end-of-line) or empty lines, and never merges lines.
func TestColumnEditDeleteForwardGoLandParity(t *testing.T) {
	h := newColumnEditHarness(t, deleteParityContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed

	_, x6 := e.ConvertPos(0, 6)
	selectAllLinesRect(t, h, int(x6.X))
	// A plain arrow with the block selected collapses it onto the edge it moves
	// towards (GoLand), so clear the selection first — the carets already sit on
	// the block's left edge, so this press does not move them.
	e.moveColumnCarets(-1)
	for range 4 {
		e.moveColumnCarets(1)
	}

	sels := make([]columnCursor, len(e.columnEdit.selections))
	copy(sels, e.columnEdit.selections)
	lines := strings.Split(deleteParityContent, "\n")
	wantLines := append([]string(nil), lines...)
	wantDeleted := 0
	for _, c := range sels {
		out, n := deleteLineRunes(lines[c.line], c.col, 1, false)
		wantLines[c.line] = out
		wantDeleted += n
	}

	deleted := e.Delete(1)

	if deleted != wantDeleted {
		t.Fatalf("deleted %d runes, want %d", deleted, wantDeleted)
	}
	if got := e.text.Paragraphs(); got != len(lines) {
		t.Fatalf("lines merged! paragraphs=%d, want %d", got, len(lines))
	}
	if got, want := e.Text(), strings.Join(wantLines, "\n"); got != want {
		t.Fatalf("forward delete scrambled the text:\n got  %q\n want %q", got, want)
	}
	// GoLand keeps every caret where it was on a forward delete.
	for i, c := range e.columnEdit.selections {
		if c.col != sels[i].col {
			t.Fatalf("forward delete moved caret %d (line %d): %d -> %d", i, c.line, sels[i].col, c.col)
		}
	}
}

// TestColumnEditDeleteBackwardGoLandParity: Backspace removes the char BEFORE
// every caret that has one, moves those carets left, and never eats the
// newline of the previous line (the bug that scrambled the text).
func TestColumnEditDeleteBackwardGoLandParity(t *testing.T) {
	h := newColumnEditHarness(t, deleteParityContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed

	_, x6 := e.ConvertPos(0, 6)
	selectAllLinesRect(t, h, int(x6.X))
	// Collapse the block first: a plain arrow with a block selected collapses it
	// onto the edge it moves towards, so the carets only start stepping after
	// that press. It does not move them here — they sit on the block's left edge.
	e.moveColumnCarets(-1)
	for range 4 {
		e.moveColumnCarets(1)
	}

	sels := make([]columnCursor, len(e.columnEdit.selections))
	copy(sels, e.columnEdit.selections)
	lines := strings.Split(deleteParityContent, "\n")
	wantLines := append([]string(nil), lines...)
	wantCols := make([]int, len(sels))
	wantDeleted := 0
	for k, c := range sels {
		out, n := deleteLineRunes(lines[c.line], c.col, 1, true)
		wantLines[c.line] = out
		wantCols[k] = c.col - n
		wantDeleted += n
	}

	deleted := e.Delete(-1)

	if deleted != wantDeleted {
		t.Fatalf("deleted %d runes, want %d", deleted, wantDeleted)
	}
	if got := e.text.Paragraphs(); got != len(lines) {
		t.Fatalf("lines merged! paragraphs=%d, want %d", got, len(lines))
	}
	if got, want := e.Text(), strings.Join(wantLines, "\n"); got != want {
		t.Fatalf("backward delete scrambled the text:\n got  %q\n want %q", got, want)
	}
	for k, c := range e.columnEdit.selections {
		if c.col != wantCols[k] {
			t.Fatalf("backward delete left caret %d (line %d) at col %d, want %d", k, c.line, c.col, wantCols[k])
		}
	}
}

// TestColumnEditDeleteAtLineEdges: carets parked at end-of-line delete
// nothing forward, delete their LAST char backward; carets at col 0 delete
// nothing backward. In no case does a line boundary get deleted.
func TestColumnEditDeleteAtLineEdges(t *testing.T) {
	h := newColumnEditHarness(t, deleteParityContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed

	// Rect wider than every line: holding Right can then park every caret at
	// its own line end (movement clamps to the rectangle edge, so a narrow
	// rect would stop the carets mid-line instead).
	selectAllLinesRect(t, h, 400)

	// Hold Right until every caret is parked.
	for range 60 {
		e.moveColumnCarets(1)
	}
	// A parked caret deletes nothing forward.
	if n := e.Delete(1); n != 0 {
		t.Fatalf("forward delete at end-of-line removed %d runes, want 0", n)
	}
	if got, want := e.Text(), deleteParityContent; got != want {
		t.Fatalf("parked forward delete changed the text: %q", got)
	}

	// Backward from the parked position removes each non-empty line's LAST
	// char (the empty line has no selection and nothing to delete).
	lines := strings.Split(deleteParityContent, "\n")
	wantDeleted := 0
	for _, c := range e.columnEdit.selections {
		out, n := deleteLineRunes(lines[c.line], c.col, 1, true)
		lines[c.line] = out
		wantDeleted += n
	}
	if n := e.Delete(-1); n != wantDeleted {
		t.Fatalf("backward delete at end-of-line removed %d runes, want %d", n, wantDeleted)
	}
	if wantDeleted == 0 {
		t.Fatal("scenario degenerated: nothing should be deletable at parked carets")
	}
	if got, want := e.Text(), strings.Join(lines, "\n"); got != want {
		t.Fatalf("parked backward delete scrambled the text:\n got  %q\n want %q", got, want)
	}
	if got := e.text.Paragraphs(); got != len(lines) {
		t.Fatalf("lines merged! paragraphs=%d, want %d", got, len(lines))
	}

	// Hold Left to col 0: backward deletes nothing, forward removes the
	// FIRST char of every non-empty line — still no line merge.
	for range 60 {
		e.moveColumnCarets(-1)
	}
	if n := e.Delete(-1); n != 0 {
		t.Fatalf("backward delete at col 0 removed %d runes, want 0", n)
	}
	wantDeleted = 0
	for _, c := range e.columnEdit.selections {
		out, n := deleteLineRunes(lines[c.line], c.col, 1, false)
		lines[c.line] = out
		wantDeleted += n
	}
	if n := e.Delete(1); n != wantDeleted {
		t.Fatalf("forward delete at col 0 removed %d runes, want %d", n, wantDeleted)
	}
	if got, want := e.Text(), strings.Join(lines, "\n"); got != want {
		t.Fatalf("col-0 forward delete scrambled the text:\n got  %q\n want %q", got, want)
	}
	if got := e.text.Paragraphs(); got != len(lines) {
		t.Fatalf("lines merged! paragraphs=%d, want %d", got, len(lines))
	}
}

// TestColumnEditDeleteRenderedFrames renders the whole delete flow headlessly
// (example: march the column right, Delete, Backspace) and verifies on PIXELS
// that (a) the text really changed, (b) lines never merged, and (c) the caret
// column is still one straight vertical line after every step.
func TestColumnEditDeleteRenderedFrames(t *testing.T) {
	h := newColumnEditHarness(t, deleteParityContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	dir := screenshotDir(t)

	// Park the main caret at the buffer end so its blink pixels stay out of
	// every scanned band.
	e.text.MoveCaret(e.Len(), 0)

	lineHeight := e.text.GetLineHeight().Round()
	_, x6 := e.ConvertPos(0, 6)
	endX := int(x6.X)
	e.startColumnSelection(image.Pt(endX, 0))
	e.updateColumnSelection(h.gtx, image.Pt(0, lineHeight*(e.text.Paragraphs()-1)))
	// Collapse the block first: a plain arrow with a block selected collapses it
	// onto the edge it moves towards, so the carets only start stepping after
	// that press. It does not move them here — they sit on the block's left edge.
	e.moveColumnCarets(-1)
	for range 4 {
		e.moveColumnCarets(1)
	}

	gutterW := e.gutterWidth
	bandTop := func(line int) int { return line*lineHeight + 2 }
	bandBot := func(line int) int { return (line+1)*lineHeight - 2 }
	caretOnLine := func(line int) (int, bool) {
		return h.caretXByBlinkDiff(t, bandTop(line), bandBot(line), gutterW, gutterW+endX+8)
	}
	// Every selected line paints its caret at the SAME shared caretX, so the
	// blink-diff X must match across the whole column. Empty lines may have no
	// selection (QueryPos skips them) — iterate the actual selections.
	straightLine := func(stage string) {
		ref := -1
		refLine := -1
		for _, c := range e.columnEdit.selections {
			x, ok := caretOnLine(c.line)
			if !ok {
				t.Fatalf("%s: caret missing on line %d", stage, c.line)
			}
			if ref < 0 {
				ref, refLine = x, c.line
			} else if d := x - ref; d > 2 || d < -2 {
				t.Fatalf("%s: carets are not a straight line: L%d x=%d vs L%d x=%d (Δ=%d)",
					stage, refLine, ref, c.line, x, d)
			}
		}
	}
	snapshot := func(dirName string) image.Image {
		h.frame(true)
		img := image.NewRGBA(image.Rect(0, 0, 600, 300))
		if err := h.win.Screenshot(img); err != nil {
			t.Fatalf("screenshot: %v", err)
		}
		dumpPNG(t, dir, dirName, img)
		return img
	}

	snapshot("gvcode-column-delete-before")
	straightLine("before delete")

	lines := strings.Split(deleteParityContent, "\n")

	// --- Delete: the char after every mid-line caret is gone ---------------
	wantLines := append([]string(nil), lines...)
	for _, c := range e.columnEdit.selections {
		out, _ := deleteLineRunes(lines[c.line], c.col, 1, false)
		wantLines[c.line] = out
	}
	if n := e.Delete(1); n == 0 {
		t.Fatal("forward deleted nothing")
	}
	if got := e.text.Paragraphs(); got != len(lines) {
		t.Fatalf("Delete merged lines! paragraphs=%d, want %d", got, len(lines))
	}
	if got, want := e.Text(), strings.Join(wantLines, "\n"); got != want {
		t.Fatalf("Delete scrambled the text:\n got  %q\n want %q", got, want)
	}
	snapshot("gvcode-column-delete-forward")
	straightLine("after Delete")

	// --- Backspace: the char before every caret is gone --------------------
	for _, c := range e.columnEdit.selections {
		out, _ := deleteLineRunes(wantLines[c.line], c.col, 1, true)
		wantLines[c.line] = out
	}
	if n := e.Delete(-1); n == 0 {
		t.Fatal("backward deleted nothing")
	}
	if got := e.text.Paragraphs(); got != len(lines) {
		t.Fatalf("Backspace merged lines! paragraphs=%d, want %d", got, len(lines))
	}
	if got, want := e.Text(), strings.Join(wantLines, "\n"); got != want {
		t.Fatalf("Backspace scrambled the text:\n got  %q\n want %q", got, want)
	}
	snapshot("gvcode-column-delete-backward")
	straightLine("after Backspace")
}

// pressKey injects a REAL key press+release through the input router so the
// builtin command table (Backspace → e.Delete(-1), Delete → e.Delete(1),
// Right → moveColumnCarets) runs exactly as it does for a human user. Tests
// that call e.Delete directly exercise only the delete implementation and
// cannot catch a broken key→command wiring — which is exactly the failure
// users see as "pressing Delete in column mode deletes the wrong text".
func (h *columnEditHarness) pressKey(name key.Name, mods key.Modifiers) {
	h.t.Helper()
	h.router.Queue(
		key.Event{Name: name, Modifiers: mods, State: key.Press},
		key.Event{Name: name, Modifiers: mods, State: key.Release},
	)
}

// keyDeleteContent is deliberately UNIFORM: four equal-length lines of plain
// runes. Every caret therefore sits mid-line with a character on BOTH sides, so
// a correct column delete must remove exactly one known character per line in
// each direction — the crisp case users expect and the exact case the old
// cross-line/merge bug got wrong. The trailing newline adds an empty paragraph
// (line 4) that the column rectangle deliberately excludes; it is where the
// main caret parks so its blink pixels stay out of every scanned band.
const keyDeleteContent = "abcdefghij\nabcdefghij\nabcdefghij\nabcdefghij\n"

// keyDeleteLines is the number of real text lines in keyDeleteContent.
const keyDeleteLines = 4

// TestColumnEditDeleteKeyDriven is the end-to-end GoLand parity proof: build a
// column rectangle, move the carets with REAL Right-arrow key events, then
// press the REAL Backspace and Delete keys — every one through the input
// router, none by calling editor methods — and verify on STATE (exact text,
// line count, caret columns) and on PIXELS (rendered frames + blink-diff
// straight caret column) that the deletion matched GoLand semantics: the char
// immediately BEFORE (Backspace) / AFTER (Delete) each caret on its OWN line.
func TestColumnEditDeleteKeyDriven(t *testing.T) {
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	dir := screenshotDir(t)

	// Park the main caret at the buffer end (the trailing empty paragraph, line
	// 4) so its blink pixels stay out of every scanned band.
	e.text.MoveCaret(e.Len(), 0)

	lineHeight := e.text.GetLineHeight().Round()
	// Rectangle from line start (col 0) to col 6 of line 0, anchored right and
	// covering ONLY the four real text lines (0..3), never the empty line 4.
	_, x0 := e.ConvertPos(0, 0)
	_, x6 := e.ConvertPos(0, 6)
	startX := int(x0.X)
	endX := int(x6.X)
	e.startColumnSelection(image.Pt(endX, 0))
	e.updateColumnSelection(h.gtx, image.Pt(startX, lineHeight*keyDeleteLines-lineHeight/2))
	if got := len(e.columnEdit.selections); got != keyDeleteLines {
		t.Fatalf("column rectangle covers %d lines, want %d", got, keyDeleteLines)
	}

	bandTop := func(line int) int { return line*lineHeight + 2 }
	bandBot := func(line int) int { return (line+1)*lineHeight - 2 }
	straightLine := func(stage string) {
		ref, refLine := -1, -1
		for _, c := range e.columnEdit.selections {
			x, ok := h.caretXByBlinkDiff(t, bandTop(c.line), bandBot(c.line), e.gutterWidth, e.gutterWidth+endX+8)
			if !ok {
				t.Fatalf("%s: caret missing on line %d", stage, c.line)
			}
			if ref < 0 {
				ref, refLine = x, c.line
			} else if d := x - ref; d > 2 || d < -2 {
				t.Fatalf("%s: carets are not a straight line: L%d x=%d vs L%d x=%d (Δ=%d)",
					stage, refLine, ref, c.line, x, d)
			}
		}
	}
	snapshot := func(dirName string) {
		h.frame(true)
		img := image.NewRGBA(image.Rect(0, 0, 600, 300))
		if err := h.win.Screenshot(img); err != nil {
			t.Fatalf("screenshot: %v", err)
		}
		dumpPNG(t, dir, dirName, img)
	}

	// --- move the carets with REAL Right-arrow key presses ------------------
	h.frame(true)
	snapshot("gvcode-column-key-delete-before")
	straightLine("before key presses")

	before := append([]columnCursor(nil), e.columnEdit.selections...)
	// One collapse press first: a plain arrow with a block selected collapses it
	// onto the edge it moves towards (GoLand), so the column only starts stepping
	// once nothing is selected. Left is the no-move choice here, the carets
	// already sitting on the block's left edge.
	h.pressKey(key.NameLeftArrow, 0)
	h.frame(true)
	for range 3 {
		h.pressKey(key.NameRightArrow, 0)
		h.frame(true)
	}
	// Every arrow press must reach the editor's column mover: uniform lines
	// advance in lockstep, so all carets end at the SAME col, 3.
	for i, c := range e.columnEdit.selections {
		if c.col != 3 {
			t.Fatalf("Right-arrow key events did not drive the column: caret %d (line %d) at col %d, want 3 (was %d before)",
				i, c.line, c.col, before[i].col)
		}
	}
	straightLine("after Right presses")

	lines := strings.Split(keyDeleteContent, "\n")
	wantLines := append([]string(nil), lines...)
	for _, c := range e.columnEdit.selections {
		out, n := deleteLineRunes(lines[c.line], c.col, 1, true)
		if n != 1 {
			t.Fatalf("scenario degenerated: caret on line %d (col %d) has no char before it", c.line, c.col)
		}
		// The caret sits at col 3, so Backspace must eat index 2, i.e. 'c'.
		if lines[c.line][c.col-1] != 'c' {
			t.Fatalf("scenario not as expected: line %d col %d precedes %q, want 'c'",
				c.line, c.col, lines[c.line][c.col-1])
		}
		wantLines[c.line] = out
	}

	// --- press the REAL Backspace key ---------------------------------------
	h.pressKey(key.NameDeleteBackward, 0)
	h.frame(true)

	if got := e.text.Paragraphs(); got != len(lines) {
		t.Fatalf("Backspace key merged lines! paragraphs=%d, want %d", got, len(lines))
	}
	if got, want := e.Text(), strings.Join(wantLines, "\n"); got != want {
		t.Fatalf("Backspace key deleted the wrong characters:\n got  %q\n want %q", got, want)
	}
	// Backspace shifts every caret one column left.
	for i, c := range e.columnEdit.selections {
		if c.col != 2 {
			t.Fatalf("Backspace key left caret %d (line %d) at col %d, want 2 (was 3)", i, c.line, c.col)
		}
		// The character to the LEFT of the new caret position is the one that
		// must have survived: "abcdefghij" -> "abdefghij" with caret after 'b'.
		if got := strings.Split(e.Text(), "\n")[c.line]; got[c.col-1] != 'b' {
			t.Fatalf("line %d became %q: char before the caret is not the expected 'b'", c.line, got)
		}
	}
	snapshot("gvcode-column-key-delete-backward")
	straightLine("after Backspace key")

	// --- press the REAL Delete key ------------------------------------------
	wantLines2 := append([]string(nil), wantLines...)
	for _, c := range e.columnEdit.selections {
		out, n := deleteLineRunes(wantLines[c.line], c.col, 1, false)
		if n != 1 {
			t.Fatalf("scenario degenerated: caret on line %d (col %d) has no char after it", c.line, c.col)
		}
		wantLines2[c.line] = out
	}

	h.pressKey(key.NameDeleteForward, 0)
	h.frame(true)

	if got := e.text.Paragraphs(); got != len(lines) {
		t.Fatalf("Delete key merged lines! paragraphs=%d, want %d", got, len(lines))
	}
	if got, want := e.Text(), strings.Join(wantLines2, "\n"); got != want {
		t.Fatalf("Delete key deleted the wrong characters:\n got  %q\n want %q", got, want)
	}
	// GoLand keeps every caret where it was on a forward delete ("abdefghij"
	// with the caret after 'b' loses 'd' -> "abefghij", caret still after 'b').
	for i, c := range e.columnEdit.selections {
		if c.col != 2 {
			t.Fatalf("Delete key moved caret %d (line %d): col %d, want 2", i, c.line, c.col)
		}
		if got := strings.Split(e.Text(), "\n")[c.line]; got[c.col-1] != 'b' || got[c.col] != 'e' {
			t.Fatalf("line %d became %q: Delete must remove the char AFTER the caret", c.line, got)
		}
	}
	snapshot("gvcode-column-key-delete-forward")
	straightLine("after Delete key")
}

// --- selection-bounded editing ----------------------------------------------
//
// The rectangle is the edit boundary: a column delete or insert may only touch
// characters INSIDE it. The caret may legally sit on the rectangle's LEFT edge
// (Backspace there has nothing selected before it) or on its exclusive RIGHT
// edge (Delete there has nothing selected after it), so both keys must refuse
// to reach the character just outside.

// pressText injects a REAL text-input event through the input router (gio hands
// key.EditEvent to the focused tag), which is exactly what the platform does
// when the user types a character.
func (h *columnEditHarness) pressText(s string) {
	h.t.Helper()
	h.router.Queue(key.EditEvent{Text: s})
}

// useMonospace swaps the harness to a Go-Mono shaper and re-lays out. Column mode
// measures its block in PIXELS, while GoLand measures it in the character cells of
// a MONOSPACE editor font — on a proportional font the two agree only by accident.
// Tests that assert exact columns or exact text use this.
func (h *columnEditHarness) useMonospace(t *testing.T) {
	t.Helper()
	monoFaces, err := opentype.ParseCollection(gomono.TTF)
	if err != nil {
		t.Fatalf("parse Go Mono: %v", err)
	}
	h.shaper = text.NewShaper(text.NoSystemFonts(), text.WithCollection(monoFaces))
	for range 3 {
		h.frame(true)
	}
}

// selectColumns builds a column rectangle spanning the column range
// [fromCol, toCol) of line 0 — anchored right-to-left like a user Alt+drag, so
// the carets start on the rectangle's LEFT edge — and covers exactly the
// keyDeleteLines real text lines.
func selectColumns(t *testing.T, h *columnEditHarness, fromCol, toCol int) {
	t.Helper()
	e := h.ed
	lineHeight := e.text.GetLineHeight().Round()
	_, xFrom := e.ConvertPos(0, fromCol)
	_, xTo := e.ConvertPos(0, toCol)
	startX := int(xFrom.X)
	endX := int(xTo.X)

	e.startColumnSelection(image.Pt(endX, 0))
	e.updateColumnSelection(h.gtx, image.Pt(startX, lineHeight*keyDeleteLines-lineHeight/2))

	if got := len(e.columnEdit.selections); got != keyDeleteLines {
		t.Fatalf("column rectangle covers %d lines, want %d", got, keyDeleteLines)
	}
	for _, c := range e.columnEdit.selections {
		if c.startX != startX || c.endX != endX {
			t.Fatalf("line %d rectangle = [%d,%d), want [%d,%d)", c.line, c.startX, c.endX, startX, endX)
		}
		if c.col != fromCol {
			t.Fatalf("line %d caret starts at col %d, want the rectangle's left edge col %d", c.line, c.col, fromCol)
		}
	}
}

// TestColumnEditDeleteRemovesBlockSelection: with the block still selected,
// Delete and Backspace remove the WHOLE selection on every line in one
// keystroke, the caret lands on the block's start, and the block is consumed —
// GoLand hands a caret that has a selection straight to the ordinary delete
// handler (DeleteInColumnModeHandler). No line is ever merged, and once the
// block is gone the keys fall back to one character per caret.
func TestColumnEditDeleteRemovesBlockSelection(t *testing.T) {
	// Both keys must behave identically for a selected block.
	for _, k := range []key.Name{key.NameDeleteForward, key.NameDeleteBackward} {
		name := "Delete"
		if k == key.NameDeleteBackward {
			name = "Backspace"
		}
		t.Run(name, func(t *testing.T) {
			h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
			e := h.ed
			dir := screenshotDir(t)
			e.text.MoveCaret(e.Len(), 0)
			selectColumns(t, h, 3, 6)

			h.frame(true)
			img := image.NewRGBA(image.Rect(0, 0, 600, 300))
			if err := h.win.Screenshot(img); err != nil {
				t.Fatalf("screenshot: %v", err)
			}
			dumpPNG(t, dir, "gvcode-column-blockdelete-before-"+name, img)

			h.pressKey(k, 0)
			h.frame(true)

			// Columns 3..5 ("def") are gone from EVERY line in one keystroke.
			want := strings.Repeat("abcghij\n", keyDeleteLines)
			if got := e.Text(); got != want {
				t.Fatalf("%s did not remove the whole block:\n got  %q\n want %q", name, got, want)
			}
			if got := e.text.Paragraphs(); got != keyDeleteLines+1 {
				t.Fatalf("%s merged lines: paragraphs=%d, want %d", name, got, keyDeleteLines+1)
			}
			for i, c := range e.columnEdit.selections {
				if c.col != 3 {
					t.Fatalf("%s left caret %d at col %d, want the block's start 3", name, i, c.col)
				}
				if c.selStart != c.selEnd {
					t.Fatalf("%s left a selection [%d,%d) behind on caret %d", name, c.selStart, c.selEnd, i)
				}
			}

			h.frame(true)
			img = image.NewRGBA(image.Rect(0, 0, 600, 300))
			if err := h.win.Screenshot(img); err != nil {
				t.Fatalf("screenshot: %v", err)
			}
			dumpPNG(t, dir, "gvcode-column-blockdelete-after-"+name, img)

			// The block is consumed, so the next press falls back to GoLand's
			// no-selection column delete: ONE character per caret, still clamped
			// to the rectangle. Delete takes 'g' after the caret; Backspace has
			// nothing before it INSIDE the rectangle, so the text is unchanged.
			h.pressKey(k, 0)
			h.frame(true)
			want = strings.Repeat("abchij\n", keyDeleteLines)
			if k == key.NameDeleteBackward {
				want = strings.Repeat("abcghij\n", keyDeleteLines)
			}
			if got := e.Text(); got != want {
				t.Fatalf("second %s did not fall back to the clamped one-char delete:\n got  %q\n want %q", name, got, want)
			}
		})
	}
}

// TestColumnEditDeleteClampsToSelection reproduces the reported bug: with the
// carets on the selection's LEFT edge, Backspace still deleted the character
// just before it — a column OUTSIDE the rectangle. Symmetrically, a caret
// parked on the rectangle's exclusive RIGHT edge must not let Delete reach the
// character just after it.
//
// This covers the NO-selection case, which is what the reported bug was about:
// one arrow press collapses the block (see
// TestColumnEditDeleteRemovesBlockSelection for the case where the block is
// still selected).
func TestColumnEditDeleteClampsToSelection(t *testing.T) {
	// --- left edge --------------------------------------------------------
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.MoveCaret(e.Len(), 0)
	selectColumns(t, h, 3, 6)

	// Collapse the block: the caret stays on the rectangle's left edge, but the
	// character before it is now outside anything that is selected.
	e.moveColumnCarets(-1)
	for i, c := range e.columnEdit.selections {
		if c.col != 3 || c.selStart != c.selEnd {
			t.Fatalf("caret %d = col %d sel [%d,%d), want a collapsed caret at col 3",
				i, c.col, c.selStart, c.selEnd)
		}
	}

	h.pressKey(key.NameDeleteBackward, 0)
	h.frame(true)

	if got := e.Text(); got != keyDeleteContent {
		t.Fatalf("Backspace on the selection's left edge deleted OUTSIDE it:\n got  %q\n want %q", got, keyDeleteContent)
	}
	for i, c := range e.columnEdit.selections {
		if c.col != 3 {
			t.Fatalf("caret %d moved to col %d on a refused Backspace", i, c.col)
		}
	}

	// Forward from the same edge must still work: col 3 ('d') is the FIRST
	// SELECTED column.
	h.pressKey(key.NameDeleteForward, 0)
	h.frame(true)
	if got, want := e.Text(), strings.Repeat("abcefghij\n", keyDeleteLines); got != want {
		t.Fatalf("Delete on the left edge must remove the first SELECTED char:\n got  %q\n want %q", got, want)
	}

	// --- right edge -------------------------------------------------------
	h2 := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e2 := h2.ed
	e2.text.MoveCaret(e2.Len(), 0)
	selectColumns(t, h2, 3, 6)

	// Hold Right until every caret parks on the rectangle's exclusive right edge
	// (col 6, whose left edge IS endX).
	for range 30 {
		e2.moveColumnCarets(1)
	}
	for i, c := range e2.columnEdit.selections {
		if c.col != 6 {
			t.Fatalf("caret %d parked at col %d, want the rectangle's right edge col 6", i, c.col)
		}
	}

	h2.pressKey(key.NameDeleteForward, 0)
	h2.frame(true)

	if got := e2.Text(); got != keyDeleteContent {
		t.Fatalf("Delete on the selection's right edge deleted OUTSIDE it:\n got  %q\n want %q", got, keyDeleteContent)
	}

	// Backward from the same edge must still work: col 5 ('f') is the LAST
	// SELECTED column.
	h2.pressKey(key.NameDeleteBackward, 0)
	h2.frame(true)
	if got, want := e2.Text(), strings.Repeat("abcdeghij\n", keyDeleteLines); got != want {
		t.Fatalf("Backspace on the right edge must remove the last SELECTED char:\n got  %q\n want %q", got, want)
	}
}

// TestColumnEditShiftArrowExtendsBlock reproduces the horizontal half of
// IntelliJ's EditorMultiCaretColumnModeTest.testSelectionWithKeyboard and
// testReverseBlockSelection: Shift+arrow moves the caret column while the
// selection keeps its FAR end (the anchor), so the block grows or shrinks, is
// empty the moment the carets reach that end, and reopens on the other side once
// they pass it.
func TestColumnEditShiftArrowExtendsBlock(t *testing.T) {
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.MoveCaret(e.Len(), 0)
	selectColumns(t, h, 3, 6)

	// The block is one column range shared by every caret, so every line must
	// agree — that is checked here as well as the values themselves.
	step := func(stage string, wantCol, wantSelStart, wantSelEnd int) {
		t.Helper()
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			if c.col != wantCol || c.selStart != wantSelStart || c.selEnd != wantSelEnd {
				t.Fatalf("%s: line %d = col %d sel [%d,%d), want col %d sel [%d,%d)",
					stage, c.line, c.col, c.selStart, c.selEnd, wantCol, wantSelStart, wantSelEnd)
			}
		}
	}
	shiftLeft := func() { h.pressKey(key.NameLeftArrow, key.ModShift); h.frame(true) }
	shiftRight := func() { h.pressKey(key.NameRightArrow, key.ModShift); h.frame(true) }
	plainRight := func() { h.pressKey(key.NameRightArrow, 0); h.frame(true) }

	step("after the drag", 3, 3, 6)

	// Shift+Left walks the caret column left and the block grows with it.
	shiftLeft()
	step("Shift+Left", 2, 2, 6)
	shiftLeft()
	step("Shift+Left again", 1, 1, 6)

	// Shift+Right walks back, shrinking the block from the left.
	shiftRight()
	step("Shift+Right", 2, 2, 6)
	shiftRight()
	step("Shift+Right again", 3, 3, 6)

	// Continue until the carets reach the block's far end: the selection is empty.
	for range 3 {
		shiftRight()
	}
	step("carets at the block's far end", 6, 6, 6)

	// One more press reopens the block on the OTHER side of the anchor, so the
	// carets now sit on the block's right edge — GoLand's reversed selection.
	shiftRight()
	step("Shift+Right past the anchor", 7, 6, 7)

	// A plain arrow collapses it. The block bounds plain movement, so the carets
	// stay on the block's far edge — they cannot walk out of the columns the user
	// dragged.
	plainRight()
	step("plain Right", 7, 7, 7)
}

// TestColumnEditShiftArrowNeverSelectsTheNewline: extending leftward past a
// short line must clamp that line's own selection to its text, so no block can
// ever cover a line break and column editing can never merge lines.
func TestColumnEditShiftArrowNeverSelectsTheNewline(t *testing.T) {
	content := "abcdefghij\nab\n"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)

	lineHeight := e.text.GetLineHeight().Round()
	// A block over columns 4..6 of the long line; the "ab" line has no rune
	// there, so its caret parks at its own end.
	_, xFrom := e.ConvertPos(0, 4)
	_, xTo := e.ConvertPos(0, 6)
	e.startColumnSelection(image.Pt(int(xTo.X), 0))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight))
	if got := len(e.columnEdit.selections); got != 2 {
		t.Fatalf("block covers %d lines, want 2", got)
	}

	// Extend leftward well past the short line's text.
	for range 8 {
		e.extendColumnCarets(-1)
	}

	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		textLen := len([]rune(strings.Split(content, "\n")[c.line]))
		if c.selEnd > textLen {
			t.Fatalf("line %d selects [%d,%d) but only has %d runes",
				c.line, c.selStart, c.selEnd, textLen)
		}
		if c.line == 1 && (c.selStart != 0 || c.selEnd != 2) {
			t.Fatalf("the short line selects [%d,%d), want its whole text [0,2) clamped to 2 runes",
				c.selStart, c.selEnd)
		}
	}
	if got := e.text.Paragraphs(); got != 3 {
		t.Fatalf("extending the block changed the line count: paragraphs=%d, want 3", got)
	}

	// Deleting the extended block must take the short line's whole text and
	// nothing else — in particular not its line break.
	h.pressKey(key.NameDeleteForward, 0)
	h.frame(true)
	if got, want := e.Text(), "ghij\n\n"; got != want {
		t.Fatalf("deleting the extended block:\n got  %q\n want %q", got, want)
	}
	if got := e.text.Paragraphs(); got != 3 {
		t.Fatalf("deleting the block merged lines: paragraphs=%d, want 3", got)
	}
}

// TestColumnEditShiftUpDownClonesLines reproduces IntelliJ's
// EditorMultiCaretColumnModeTest.testUpDown: in column mode a vertical
// Shift+arrow adds a line to the block, and the "clone level" bookkeeping makes
// the pair behave like a stack — the opposite key takes the last added line back
// until the block is back to its original height, and only then does it start
// adding lines on the far side. Presses at a document edge do nothing.
func TestColumnEditShiftUpDownClonesLines(t *testing.T) {
	content := "aaaa\nbbbb\ncccc\ndddd"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)
	h.useMonospace(t)

	lineHeight := e.text.GetLineHeight().Round()
	_, xFrom := e.ConvertPos(0, 1)
	_, xTo := e.ConvertPos(0, 3)
	// A block over lines 1..2 only.
	e.startColumnSelection(image.Pt(int(xTo.X), lineHeight))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight*2))

	// lines lists the block's line numbers, and the block's columns are checked
	// to be the same on every one of them.
	lines := func(stage string) []int {
		t.Helper()
		var out []int
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			out = append(out, c.line)
			if c.selStart != 1 || c.selEnd != 3 {
				t.Fatalf("%s: line %d selects [%d,%d), want [1,3)", stage, c.line, c.selStart, c.selEnd)
			}
		}
		return out
	}
	expect := func(stage string, want ...int) {
		t.Helper()
		got := lines(stage)
		if len(got) != len(want) {
			t.Fatalf("%s: block covers lines %v, want %v", stage, got, want)
		}
		for i := range want {
			if got[i] != want[i] {
				t.Fatalf("%s: block covers lines %v, want %v", stage, got, want)
			}
		}
	}
	shift := func(name key.Name) { h.pressKey(name, key.ModShift); h.frame(true) }
	down := func() { shift(key.NameDownArrow) }
	up := func() { shift(key.NameUpArrow) }

	expect("after the drag", 1, 2)

	// Shift+Down grows the block one line at a time, and the added lines carry
	// the SAME columns.
	down()
	expect("Shift+Down", 1, 2, 3)
	down()
	expect("Shift+Down again", 1, 2, 3)

	// Shift+Up takes back exactly what Shift+Down added...
	up()
	expect("Shift+Up", 1, 2)
	// ...and only once the block is back to its original height does it start
	// adding lines above it.
	up()
	expect("Shift+Up again", 0, 1, 2)
	up()
	expect("Shift+Up at the top edge", 0, 1, 2)

	// Shift+Down now takes the line above back, because that is what the last
	// sequence added.
	down()
	expect("Shift+Down", 1, 2)
}

// TestColumnEditVerticalCloneKeepsBlockColumns: the lines a vertical Shift+arrow
// adds must be edited exactly like the ones the drag covered — typing replaces
// the block's columns on them too.
func TestColumnEditVerticalCloneKeepsBlockColumns(t *testing.T) {
	content := "aaaa\nbbbb\ncccc\ndddd"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)
	h.useMonospace(t)

	lineHeight := e.text.GetLineHeight().Round()
	_, xFrom := e.ConvertPos(0, 1)
	_, xTo := e.ConvertPos(0, 3)
	e.startColumnSelection(image.Pt(int(xTo.X), lineHeight))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight*2))

	h.pressKey(key.NameDownArrow, key.ModShift)
	h.frame(true)
	if got := len(e.columnEdit.selections); got != 3 {
		t.Fatalf("block covers %d lines, want 3", got)
	}

	h.pressText("X")
	h.frame(true)

	// Columns 1..2 are replaced on lines 1..3, and line 0 is untouched.
	if got, want := e.Text(), "aaaa\nbXb\ncXc\ndXd"; got != want {
		t.Fatalf("typing after a vertical clone:\n got  %q\n want %q", got, want)
	}
	if got := e.text.Paragraphs(); got != 4 {
		t.Fatalf("typing changed the line count: paragraphs=%d, want 4", got)
	}
}

// TestColumnEditPlainArrowCollapsesBlock mirrors IntelliJ's
// EditorMultiCaretColumnModeTest.testMoveToSelectionStart / testMoveToSelectionEnd:
// a plain horizontal arrow pressed while a block is selected COLLAPSES it onto the
// edge it moves towards — ONE press, not one column. Only after the block is gone
// does a plain arrow step again, still bounded by the block.
func TestColumnEditPlainArrowCollapsesBlock(t *testing.T) {
	// The drag leaves the carets on the block's left edge (col 3) with columns
	// 3..5 selected.
	newBlock := func() (*columnEditHarness, *Editor) {
		h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
		h.ed.text.MoveCaret(h.ed.Len(), 0)
		selectColumns(t, h, 3, 6)
		return h, h.ed
	}
	state := func(t *testing.T, e *Editor, stage string, wantCol, wantSelStart, wantSelEnd int) {
		t.Helper()
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			if c.col != wantCol || c.selStart != wantSelStart || c.selEnd != wantSelEnd {
				t.Fatalf("%s: line %d = col %d sel [%d,%d), want col %d sel [%d,%d)",
					stage, c.line, c.col, c.selStart, c.selEnd, wantCol, wantSelStart, wantSelEnd)
			}
		}
	}

	// Right jumps the whole column to the block's right edge in one press.
	h, e := newBlock()
	h.pressKey(key.NameRightArrow, 0)
	h.frame(true)
	state(t, e, "Right", 6, 6, 6)
	// The block is gone now, so the next press only steps one column — and the
	// block still bounds movement, so there is nowhere left to go.
	h.pressKey(key.NameRightArrow, 0)
	h.frame(true)
	state(t, e, "Right again", 6, 6, 6)

	// Left finds the carets already on the block's left edge, so it only clears
	// the selection.
	h2, e2 := newBlock()
	h2.pressKey(key.NameLeftArrow, 0)
	h2.frame(true)
	state(t, e2, "Left", 3, 3, 3)

	// Neither press edited anything.
	if got := e.Text(); got != keyDeleteContent {
		t.Fatalf("the collapse presses changed the text: %q", got)
	}
	if got := e2.Text(); got != keyDeleteContent {
		t.Fatalf("the collapse press changed the text: %q", got)
	}
}

// TestColumnEditBlockCopyAndPaste covers the column clipboard: copying a block
// yields one line per covered line, padded out to the block's width so the
// columns survive (GoLand's testCopyPasteOfShortLines), and pasting a
// same-height text back puts each line on its own caret, replacing the selection
// there. A single-line clipboard goes to every caret, like typing it.
func TestColumnEditBlockCopyAndPaste(t *testing.T) {
	content := "aaaa\nbbbb\nc"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)
	h.useMonospace(t)

	lineHeight := e.text.GetLineHeight().Round()
	// Block over lines 1..2, columns 1..3. The "c" line is shorter than the
	// block, so its caret parks at its own end and it contributes no characters.
	_, xFrom := e.ConvertPos(0, 1)
	_, xTo := e.ConvertPos(0, 3)
	e.startColumnSelection(image.Pt(int(xTo.X), lineHeight))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight*2))
	if got := len(e.columnEdit.selections); got != 2 {
		t.Fatalf("block covers %d lines, want 2", got)
	}

	// Copy: one line per covered line, the short one padded to the block width.
	copied, ok := e.columnBlockText()
	if !ok {
		t.Fatal("a selected block must produce clipboard text")
	}
	if want := "bb\n  "; copied != want {
		t.Fatalf("copied block = %q, want %q", copied, want)
	}

	paste := func(text string) {
		t.Helper()
		e.onPasteEvent(transfer.DataEvent{
			Type: "application/text",
			Open: func() io.ReadCloser { return io.NopCloser(strings.NewReader(text)) },
		})
		h.frame(true)
	}

	// Paste a same-height block back: each line lands on its own caret.
	paste("XY\nZ")
	if got, want := e.Text(), "aaaa\nbXYb\ncZ"; got != want {
		t.Fatalf("pasting a block:\n got  %q\n want %q", got, want)
	}
	if got := e.text.Paragraphs(); got != 3 {
		t.Fatalf("pasting changed the line count: paragraphs=%d, want 3", got)
	}
	// The block is consumed, so the carets sit right after the pasted text.
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		if c.selStart != c.selEnd {
			t.Fatalf("caret %d kept a selection [%d,%d) after the paste", i, c.selStart, c.selEnd)
		}
	}
}

// TestColumnEditShiftPageDownClonesAPageOfLines: GoLand's Shift+PageDown runs the
// clone handler once per VISIBLE line (PageUpWithSelectionAction), so the block
// grows a whole page at a time, and Shift+PageUp takes that page back through the
// same clone levels.
func TestColumnEditShiftPageDownClonesAPageOfLines(t *testing.T) {
	var b strings.Builder
	for range 40 {
		b.WriteString("line\n")
	}
	content := strings.TrimSuffix(b.String(), "\n")

	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)

	lineHeight := e.text.GetLineHeight().Round()
	page := h.gtx.Constraints.Max.Y / lineHeight
	if page < 3 {
		t.Skipf("viewport too short for a meaningful page: %d lines", page)
	}

	// A block over lines 5..6.
	_, xFrom := e.ConvertPos(0, 0)
	_, xTo := e.ConvertPos(0, 7)
	e.startColumnSelection(image.Pt(int(xTo.X), lineHeight*5))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight*6))
	if got := len(e.columnEdit.selections); got != 2 {
		t.Fatalf("block covers %d lines, want 2", got)
	}

	h.pressKey(key.NamePageDown, key.ModShift)
	h.frame(true)
	first, last := e.columnLineBounds()
	if got := len(e.columnEdit.selections); got != 2+page {
		t.Fatalf("Shift+PageDown gave %d lines (%d..%d), want %d", got, first, last, 2+page)
	}
	if first != 5 || last != 6+page {
		t.Fatalf("Shift+PageDown covered lines %d..%d, want 5..%d", first, last, 6+page)
	}

	// Shift+PageUp pops exactly that page again.
	h.pressKey(key.NamePageUp, key.ModShift)
	h.frame(true)
	first, last = e.columnLineBounds()
	if got := len(e.columnEdit.selections); got != 2 || first != 5 || last != 6 {
		t.Fatalf("Shift+PageUp left %d lines (%d..%d), want 2 (5..6)", got, first, last)
	}
}

// TestColumnEditWordMovement: Alt+arrow moves the caret column a WHOLE word and
// Shift+Alt+arrow keeps the block, so a word-sized range gets selected — GoLand's
// word movement applied to the column.
func TestColumnEditWordMovement(t *testing.T) {
	content := "foo bar baz qux\nfoo bar baz qux"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)
	h.useMonospace(t)

	lineHeight := e.text.GetLineHeight().Round()
	// A block over lines 0..1, columns 0..8 ("foo bar"). The trailing word keeps
	// the steps away from the line end, where parking would kick in.
	_, xFrom := e.ConvertPos(0, 0)
	_, xTo := e.ConvertPos(0, 8)
	e.startColumnSelection(image.Pt(int(xTo.X), 0))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight))

	cols := func(stage string) []int {
		t.Helper()
		var out []int
		for i := range e.columnEdit.selections {
			out = append(out, e.columnEdit.selections[i].col)
		}
		return out
	}
	expectCol := func(stage string, want int) {
		t.Helper()
		for _, col := range cols(stage) {
			if col != want {
				t.Fatalf("%s: carets at %v, want all at col %d", stage, cols(stage), want)
			}
		}
	}
	expectSel := func(stage string, wantStart, wantEnd int) {
		t.Helper()
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			if c.selStart != wantStart || c.selEnd != wantEnd {
				t.Fatalf("%s: line %d selects [%d,%d), want [%d,%d)", stage, c.line, c.selStart, c.selEnd, wantStart, wantEnd)
			}
		}
	}

	// The first Alt+Right lands on the END of the first word, not one rune in.
	h.pressKey(key.NameRightArrow, key.ModShortcutAlt)
	h.frame(true)
	expectCol("Alt+Right", 3)

	// The next one skips the space and the second word.
	h.pressKey(key.NameRightArrow, key.ModShortcutAlt)
	h.frame(true)
	expectCol("Alt+Right again", 7)

	// The third runs past the block, so it parks on the block's right edge.
	h.pressKey(key.NameRightArrow, key.ModShortcutAlt)
	h.frame(true)
	expectCol("Alt+Right past the block", 8)

	// Alt+Left walks back a word at a time and collapses the block.
	h.pressKey(key.NameLeftArrow, key.ModShortcutAlt)
	h.frame(true)
	expectCol("Alt+Left", 4)
	h.pressKey(key.NameLeftArrow, key.ModShortcutAlt)
	h.frame(true)
	expectCol("Alt+Left again", 0)

	// Shift+Alt+Right keeps the block and selects a whole word.
	h.pressKey(key.NameRightArrow, key.ModShift|key.ModShortcutAlt)
	h.frame(true)
	expectCol("Shift+Alt+Right", 3)
	expectSel("Shift+Alt+Right", 0, 3)

	// A plain Alt+Left then takes it back, still inside the block.
	h.pressKey(key.NameLeftArrow, key.ModShortcutAlt)
	h.frame(true)
	expectCol("Alt+Left after extending", 0)
	expectSel("Alt+Left after extending", 0, 0)
}

// TestColumnEditHomeEndInColumnMode: the horizontal jumps act on the whole
// column. A plain Home/End parks the carets on the block's edges — the only
// pixels every line shares — while Shift grows or trims the block to the line
// start / to the end of its widest line, and the Ctrl variants also pull in every
// line up to the document edge, which is what GoLand's block selection to the
// document start/end does.
func TestColumnEditHomeEndInColumnMode(t *testing.T) {
	content := "foo bar\nfoo bar\nfoo bar"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)
	h.useMonospace(t)

	lineHeight := e.text.GetLineHeight().Round()
	// A block over lines 0..1, columns 4..7 ("bar").
	_, xFrom := e.ConvertPos(0, 4)
	_, xTo := e.ConvertPos(0, 7)
	e.startColumnSelection(image.Pt(int(xTo.X), 0))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight))
	if got := len(e.columnEdit.selections); got != 2 {
		t.Fatalf("block covers %d lines, want 2", got)
	}

	state := func(stage string, wantLines int, wantCol, wantSelStart, wantSelEnd int) {
		t.Helper()
		if got := len(e.columnEdit.selections); got != wantLines {
			t.Fatalf("%s: block covers %d lines, want %d", stage, got, wantLines)
		}
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			if c.col != wantCol || c.selStart != wantSelStart || c.selEnd != wantSelEnd {
				t.Fatalf("%s: line %d = col %d sel [%d,%d), want col %d sel [%d,%d)",
					stage, c.line, c.col, c.selStart, c.selEnd, wantCol, wantSelStart, wantSelEnd)
			}
		}
	}

	state("after the drag", 2, 4, 4, 7)

	// Plain End parks the carets on the block's right edge, plain Home back on
	// its left edge, and both collapse the block.
	h.pressKey(key.NameEnd, 0)
	h.frame(true)
	state("End", 2, 7, 7, 7)

	h.pressKey(key.NameHome, 0)
	h.frame(true)
	state("Home", 2, 4, 4, 4)

	// Shift+Home trims the block back to the line start.
	h.pressKey(key.NameHome, key.ModShift)
	h.frame(true)
	state("Shift+Home", 2, 0, 0, 4)

	// Shift+End grows it out to the end of its widest line.
	h.pressKey(key.NameEnd, key.ModShift)
	h.frame(true)
	state("Shift+End", 2, 0, 0, 7)

	// Shift+Ctrl+End also takes in every line below, up to the document end.
	h.pressKey(key.NameEnd, key.ModShift|key.ModShortcut)
	h.frame(true)
	state("Shift+Ctrl+End", 3, 0, 0, 7)

	// Shift+Ctrl+Home pulls in the lines above (none here) and homes the caret
	// column, which leaves nothing selected because the carets were already at
	// the line start.
	h.pressKey(key.NameHome, key.ModShift|key.ModShortcut)
	h.frame(true)
	state("Shift+Ctrl+Home", 3, 0, 0, 0)

	if got := e.text.Paragraphs(); got != 3 {
		t.Fatalf("the jumps changed the line count: paragraphs=%d, want 3", got)
	}
}

// TestColumnEditAltCConvertsSelection mirrors IntelliJ's
// ToggleColumnModeActionMultiCaretTest: toggling column mode ON with a linear
// selection CONVERTS that selection into a block over the same lines and the
// columns of its two endpoints, and toggling it OFF turns the block back into a
// linear selection over the same text. With nothing selected the toggle only
// switches the mode.
func TestColumnEditAltCConvertsSelection(t *testing.T) {
	const content = "line1\nline2\nline3"

	t.Run("no selection", func(t *testing.T) {
		h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
		e := h.ed
		e.SetColumnEditMode(false)

		h.pressKey("C", key.ModAlt)
		h.frame(true)
		if !e.ColumnEditEnabled() {
			t.Fatal("Alt+C did not enable column edit mode")
		}
		if got := len(e.columnEdit.selections); got != 0 {
			t.Fatalf("toggling with no selection made a block of %d lines", got)
		}

		h.pressKey("C", key.ModAlt)
		h.frame(true)
		if e.ColumnEditEnabled() {
			t.Fatal("the second Alt+C did not leave column edit mode")
		}
		if got := e.SelectedText(); got != "" {
			t.Fatalf("leaving column mode with no block selected %q", got)
		}
	})

	t.Run("converts a selection", func(t *testing.T) {
		h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
		e := h.ed
		h.useMonospace(t)
		e.SetColumnEditMode(false)

		// A linear selection from (0,1) to (1,4) — IntelliJ's
		// "l<selection>ine1 / line<caret></selection>2".
		e.SetCaret(1, 10)
		if got, want := e.SelectedText(), "ine1\nline"; got != want {
			t.Fatalf("selection = %q, want %q", got, want)
		}

		h.pressKey("C", key.ModAlt)
		h.frame(true)
		if !e.ColumnEditEnabled() {
			t.Fatal("Alt+C did not enable column edit mode")
		}
		if got := len(e.columnEdit.selections); got != 2 {
			t.Fatalf("the block covers %d lines, want 2", got)
		}
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			if c.line != i || c.col != 1 || c.selStart != 1 || c.selEnd != 4 {
				t.Fatalf("line %d = col %d sel [%d,%d), want col 1 sel [1,4)",
					c.line, c.col, c.selStart, c.selEnd)
			}
		}

		// A second Alt+C turns the block back into a linear selection over the
		// same text.
		h.pressKey("C", key.ModAlt)
		h.frame(true)
		if e.ColumnEditEnabled() {
			t.Fatal("the second Alt+C did not leave column edit mode")
		}
		if got, want := e.SelectedText(), "ine1\nline"; got != want {
			t.Fatalf("selection after toggling off = %q, want %q", got, want)
		}
	})
}

// TestColumnEditCtrlEndReplacesBlockColumns covers the "replace" half of GoLand's
// block-to-document-edge jump (TextEndWithSelectionAction sets a block selection
// from the lead to the document end): Shift+Ctrl+End puts the block's columns at
// [caret column, line end] and reaches the document's last line, so a block the
// caret sat at the RIGHT edge of is CUT BACK to the caret instead of merely
// growing.
func TestColumnEditCtrlEndReplacesBlockColumns(t *testing.T) {
	content := "abcdefghij\nabcdefghij\nabcdefghij"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)
	h.useMonospace(t)

	lineHeight := e.text.GetLineHeight().Round()
	// A LEFT-TO-RIGHT drag over lines 0..1, columns 3..6: the carets end up on the
	// block's right edge, because GoLand leaves them where the drag finished.
	_, xFrom := e.ConvertPos(0, 3)
	_, xTo := e.ConvertPos(0, 6)
	e.startColumnSelection(image.Pt(int(xFrom.X), 0))
	e.updateColumnSelection(h.gtx, image.Pt(int(xTo.X), lineHeight))
	if got := len(e.columnEdit.selections); got != 2 {
		t.Fatalf("block covers %d lines, want 2", got)
	}
	for i := range e.columnEdit.selections {
		if c := &e.columnEdit.selections[i]; c.col != 6 || c.selStart != 3 || c.selEnd != 6 {
			t.Fatalf("after the drag: line %d = col %d sel [%d,%d), want col 6 sel [3,6)",
				c.line, c.col, c.selStart, c.selEnd)
		}
	}

	h.pressKey(key.NameEnd, key.ModShift|key.ModShortcut)
	h.frame(true)

	// The block now reaches the document's last line, and its columns start at the
	// caret (col 6) — the part of the old block left of the caret is gone.
	if got := len(e.columnEdit.selections); got != 3 {
		t.Fatalf("block covers %d lines, want all 3", got)
	}
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		if c.col != 6 || c.selStart != 6 || c.selEnd != 10 {
			t.Fatalf("line %d = col %d sel [%d,%d), want col 6 sel [6,10)", c.line, c.col, c.selStart, c.selEnd)
		}
	}
}

// TestColumnEditBlockPasteOnFollowingLines mirrors IntelliJ's
// EditorMultiCaretColumnModeTest.testPasteOfBlockToASingleCaret: a clipboard with
// MORE lines than the block keeps writing on the following lines at the caret's
// column, instead of falling back to an ordinary paste at the single main caret.
func TestColumnEditBlockPasteOnFollowingLines(t *testing.T) {
	content := "aaaa\nbbbb\ncccc"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)
	h.useMonospace(t)

	// A single caret at (0,2) — GoLand's mouse().clickAt(0, 2).
	_, x := e.ConvertPos(0, 2)
	e.startColumnSelection(image.Pt(int(x.X), 0))
	if got := len(e.columnEdit.selections); got != 1 {
		t.Fatalf("a click must leave one caret, got %d", got)
	}

	e.onPasteEvent(transfer.DataEvent{
		Type: "application/text",
		Open: func() io.ReadCloser { return io.NopCloser(strings.NewReader("XY\nZ")) },
	})
	h.frame(true)

	// Line 0 takes the first clipboard line at column 2, and line 1 — which the
	// block does not cover — takes the second at the same column.
	if got, want := e.Text(), "aaXYaa\nbbZbb\ncccc"; got != want {
		t.Fatalf("pasting a taller block:\n got  %q\n want %q", got, want)
	}
	if got := e.text.Paragraphs(); got != 3 {
		t.Fatalf("pasting changed the line count: paragraphs=%d, want 3", got)
	}
}

// TestColumnEditInsertReplacesBlockSelection: the block is a real per-caret
// SELECTION, so typing replaces the characters it covers on every line — GoLand's
// block semantics — instead of inserting beside them, and the caret ends right
// after the replacement. The text must never land at the single main caret,
// which lives outside the rectangle.
func TestColumnEditInsertReplacesBlockSelection(t *testing.T) {
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	dir := screenshotDir(t)

	// Park the main caret at the very START of the buffer — outside the
	// rectangle, like in the real app. If the column branch were bypassed the
	// typed run would land there and this test would catch it.
	e.text.SetCaret(0, 0)
	selectColumns(t, h, 3, 6)

	h.frame(true)
	before := image.NewRGBA(image.Rect(0, 0, 600, 300))
	if err := h.win.Screenshot(before); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, dir, "gvcode-column-insert-before", before)

	h.pressText("X")
	h.frame(true)

	// Columns 3..5 ("def") are REPLACED by the single typed rune.
	want := strings.Repeat("abcXghij\n", keyDeleteLines)
	if got := e.Text(); got != want {
		t.Fatalf("typing did not replace the block selection:\n got  %q\n want %q", got, want)
	}
	if got := e.text.Paragraphs(); got != keyDeleteLines+1 {
		t.Fatalf("typing changed the line count: paragraphs=%d, want %d", got, keyDeleteLines+1)
	}
	for i, c := range e.columnEdit.selections {
		if c.col != 4 {
			t.Fatalf("caret %d sits at col %d after typing, want 4 (one past the replacement)", i, c.col)
		}
		// The selection is consumed, so the next keystroke inserts at the caret.
		if c.selStart != c.col || c.selEnd != c.col {
			t.Fatalf("caret %d still holds a selection [%d,%d) after the block was replaced",
				i, c.selStart, c.selEnd)
		}
	}

	h.frame(true)
	after := image.NewRGBA(image.Rect(0, 0, 600, 300))
	if err := h.win.Screenshot(after); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, dir, "gvcode-column-insert-mid", after)

	// A SECOND keystroke now inserts beside the caret — GoLand treats the block
	// as consumed once it has been replaced.
	h.pressText("Y")
	h.frame(true)
	if got, want := e.Text(), strings.Repeat("abcXYghij\n", keyDeleteLines); got != want {
		t.Fatalf("the block was not consumed by the first keystroke:\n got  %q\n want %q", got, want)
	}

	// Backspace then removes the two typed runes in turn. The block stays
	// consumed, so what remains is the line with the block's characters gone —
	// the same net result as replacing and then deleting the replacement.
	h.pressKey(key.NameDeleteBackward, 0)
	h.frame(true)
	h.pressKey(key.NameDeleteBackward, 0)
	h.frame(true)
	if got, want := e.Text(), strings.Repeat("abcghij\n", keyDeleteLines); got != want {
		t.Fatalf("Backspace did not remove the typed runs:\n got  %q\n want %q", got, want)
	}
}

// TestColumnEditInsertAtRightEdgeStaysSelected: typing while the carets sit on
// the rectangle's exclusive RIGHT edge must leave the new text INSIDE the
// selection. The rectangle grows with every insertion; without that, the run
// typed at the edge would start exactly at endX, fall outside the selection and
// become impossible to delete.
func TestColumnEditInsertAtRightEdgeStaysSelected(t *testing.T) {
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)
	selectColumns(t, h, 3, 6)

	for range 30 {
		e.moveColumnCarets(1)
	}
	for i, c := range e.columnEdit.selections {
		if c.col != 6 {
			t.Fatalf("caret %d parked at col %d, want 6", i, c.col)
		}
	}

	h.pressText("X")
	h.frame(true)

	want := strings.Repeat("abcdefXghij\n", keyDeleteLines)
	if got := e.Text(); got != want {
		t.Fatalf("typing at the right edge landed wrong:\n got  %q\n want %q", got, want)
	}

	// Round-trip: the run typed at the exclusive right edge is selectable, so
	// Backspace removes exactly it.
	h.pressKey(key.NameDeleteBackward, 0)
	h.frame(true)
	if got := e.Text(); got != keyDeleteContent {
		t.Fatalf("the run typed at the right edge is NOT inside the selection (Backspace could not remove it):\n got  %q\n want %q", got, keyDeleteContent)
	}
}

// --- mode lifecycle, geometry, undo, unicode --------------------------------
//
// The rest of column editing: entering/leaving the mode, how the rectangle is
// derived from a drag, the invariants movement must preserve, undo grouping,
// and multibyte columns.

// TestColumnEditModeLifecycle drives the mode through its REAL key bindings:
// ESC leaves column editing and drops the rectangle, Alt+C toggles it back on,
// and a second Alt+C leaves again — a stale rectangle surviving any of these
// would silently keep editing the wrong lines.
func TestColumnEditModeLifecycle(t *testing.T) {
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	if !e.ColumnEditEnabled() {
		t.Fatal("the harness should start in column edit mode")
	}

	// ESC exits column editing and clears the rectangle.
	selectColumns(t, h, 3, 6)
	h.pressKey(key.NameEscape, 0)
	h.frame(true)
	if e.ColumnEditEnabled() {
		t.Fatal("ESC did not leave column edit mode")
	}
	if n := len(e.columnEdit.selections); n != 0 {
		t.Fatalf("ESC left %d column selections behind", n)
	}

	// Alt+C toggles column editing back on.
	h.pressKey("C", key.ModAlt)
	h.frame(true)
	if !e.ColumnEditEnabled() {
		t.Fatal("Alt+C did not enable column edit mode")
	}

	// A second Alt+C toggles it off AND clears the rectangle.
	selectColumns(t, h, 3, 6)
	h.pressKey("C", key.ModAlt)
	h.frame(true)
	if e.ColumnEditEnabled() {
		t.Fatal("a second Alt+C did not disable column edit mode")
	}
	if n := len(e.columnEdit.selections); n != 0 {
		t.Fatalf("leaving column edit left %d column selections behind", n)
	}
}

// TestColumnEditRectangleIsDirectionIndependent: the anchor is only one corner, so
// dragging the other way must produce EXACTLY the same rectangle and the same
// selected runes. Only the caret's own end differs, and that is deliberate: GoLand
// leaves the caret where the drag finished, so a left-to-right drag parks the
// carets on the block's right edge.
func TestColumnEditRectangleIsDirectionIndependent(t *testing.T) {
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed

	lineHeight := e.text.GetLineHeight().Round()
	_, xFrom := e.ConvertPos(0, 3)
	_, xTo := e.ConvertPos(0, 6)
	startX, endX := int(xFrom.X), int(xTo.X)
	top, bottom := 0, lineHeight*(keyDeleteLines-1)

	// The rectangle and its selected runes, ignoring which end the carets are on.
	rect := func() string {
		var b strings.Builder
		for _, c := range e.columnEdit.selections {
			fmt.Fprintf(&b, "%d:%d:%d:%d:%d;", c.line, c.startX, c.endX, c.selStart, c.selEnd)
		}
		return b.String()
	}
	carets := func() []int {
		var out []int
		for _, c := range e.columnEdit.selections {
			out = append(out, c.col)
		}
		return out
	}

	// Anchor bottom-left, drag to top-right: the carets stay on the block's right
	// edge, where the drag ended.
	e.startColumnSelection(image.Pt(startX, bottom))
	e.updateColumnSelection(h.gtx, image.Pt(endX, top))
	downUp := rect()
	for _, col := range carets() {
		if col != 6 {
			t.Fatalf("a left-to-right drag must leave the carets on the block's right edge: col %d, want 6", col)
		}
	}

	// Anchor top-right, drag to bottom-left: the carets stay on the left edge.
	e.startColumnSelection(image.Pt(endX, top))
	e.updateColumnSelection(h.gtx, image.Pt(startX, bottom))
	upDown := rect()
	for _, col := range carets() {
		if col != 3 {
			t.Fatalf("a right-to-left drag must leave the carets on the block's left edge: col %d, want 3", col)
		}
	}

	if downUp == "" {
		t.Fatal("no column selections created")
	}
	if downUp != upDown {
		t.Fatalf("the rectangle depends on the drag direction:\n bottom-left->top-right: %s\n top-right->bottom-left: %s", downUp, upDown)
	}
	if got := len(e.columnEdit.selections); got != keyDeleteLines {
		t.Fatalf("rectangle covers %d lines, want %d", got, keyDeleteLines)
	}
	for _, c := range e.columnEdit.selections {
		if c.startX != startX || c.endX != endX {
			t.Fatalf("line %d rectangle = [%d,%d), want [%d,%d)", c.line, c.startX, c.endX, startX, endX)
		}
	}
}

// TestColumnEditMovementKeepsRectangle: arrow movement may only move each
// caret's col INSIDE the rectangle. The rectangle itself is fixed until the
// user drags again, so every col must stay within [leftEdge, rightEdge] and
// startX/endX must never change.
func TestColumnEditMovementKeepsRectangle(t *testing.T) {
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	selectColumns(t, h, 3, 6)

	// The cols the carets are allowed to occupy: the rectangle's left edge and
	// its exclusive right edge. startX/endX are the pinned pixel bounds.
	const minCol, maxCol = 3, 6
	startX := e.columnEdit.selections[0].startX
	endX := e.columnEdit.selections[0].endX

	check := func(stage string, wantCol int) {
		t.Helper()
		for i := range e.columnEdit.selections {
			c := &e.columnEdit.selections[i]
			if c.col != wantCol {
				t.Fatalf("%s: caret %d (line %d) at col %d, want %d", stage, i, c.line, c.col, wantCol)
			}
			if c.startX != startX || c.endX != endX {
				t.Fatalf("%s: movement changed the rectangle on line %d: [%d,%d), want [%d,%d)",
					stage, c.line, c.startX, c.endX, startX, endX)
			}
			if c.col < minCol || c.col > maxCol {
				t.Fatalf("%s: caret %d escaped the rectangle at col %d, want %d..%d", stage, i, c.col, minCol, maxCol)
			}
		}
	}

	// Hold Right well past the edge: every caret parks on the exclusive right
	// edge and the rectangle does not move.
	for range 30 {
		e.moveColumnCarets(1)
	}
	check("after holding Right", maxCol)

	// Hold Left well past the start: every caret returns to the left edge.
	for range 30 {
		e.moveColumnCarets(-1)
	}
	check("after holding Left", minCol)
}

// TestColumnEditWithoutRectangleFallsBackToSingleCaret: column editing on but no
// rectangle drawn must not change editing at all — the column branch is guarded
// by "a rectangle exists", so Delete still acts on the single caret instead of
// silently doing nothing.
func TestColumnEditWithoutRectangleFallsBackToSingleCaret(t *testing.T) {
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	if n := len(e.columnEdit.selections); n != 0 {
		t.Fatalf("harness unexpectedly has %d column selections", n)
	}
	e.SetCaret(1, 1) // caret between 'a' and 'b' of line 0

	h.pressKey(key.NameDeleteForward, 0)
	h.frame(true)

	want := "acdefghij\n" + strings.Repeat("abcdefghij\n", keyDeleteLines-1)
	if got := e.Text(); got != want {
		t.Fatalf("Delete without a rectangle must act on the single caret:\n got  %q\n want %q", got, want)
	}
}

// TestColumnEditDeleteUndoesAsOneStep: a column delete is a SINGLE undo step.
// GroupOp/UnGroupOp wrap the per-line deletions, so one Ctrl+Z restores every
// line at once instead of unwinding them one line at a time.
func TestColumnEditDeleteUndoesAsOneStep(t *testing.T) {
	h := newColumnEditHarness(t, keyDeleteContent, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.MoveCaret(e.Len(), 0)
	selectColumns(t, h, 3, 6)

	// The block is still selected, so one keystroke takes the whole of columns
	// 3..5 out of every line.
	h.pressKey(key.NameDeleteForward, 0)
	h.frame(true)
	if got, want := e.Text(), strings.Repeat("abcghij\n", keyDeleteLines); got != want {
		t.Fatalf("setup: forward delete gave %q, want %q", got, want)
	}

	h.pressKey("Z", key.ModShortcut)
	h.frame(true)
	if got := e.Text(); got != keyDeleteContent {
		t.Fatalf("one Ctrl+Z must restore the whole column delete:\n got  %q\n want %q", got, keyDeleteContent)
	}
	if got := e.text.Paragraphs(); got != keyDeleteLines+1 {
		t.Fatalf("undo changed the line count: paragraphs=%d, want %d", got, keyDeleteLines+1)
	}
}

// TestColumnEditMultibyteDelete: column positions are counted in RUNES, not
// bytes, so deleting one cluster per caret must remove exactly one CJK rune
// (3 bytes each) per line and leave the rest of the line intact.
func TestColumnEditMultibyteDelete(t *testing.T) {
	const cjk = "一二三四五六" // 6 runes, 18 bytes
	content := cjk + "\n" + cjk + "\n"

	// Forward: the block [2,4) is still selected, so Delete removes 三 and 四 —
	// two RUNES, not two bytes — in one keystroke.
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.MoveCaret(e.Len(), 0)
	lineHeight := e.text.GetLineHeight().Round()
	_, xFrom := e.ConvertPos(0, 2)
	_, xTo := e.ConvertPos(0, 4)
	e.startColumnSelection(image.Pt(int(xTo.X), 0))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight))
	if got := len(e.columnEdit.selections); got != 2 {
		t.Fatalf("rectangle covers %d lines, want 2", got)
	}
	for _, c := range e.columnEdit.selections {
		if c.col != 2 {
			t.Fatalf("caret on line %d at col %d, want 2 (the rune index, not the byte offset)", c.line, c.col)
		}
		if c.selStart != 2 || c.selEnd != 4 {
			t.Fatalf("line %d selects [%d,%d), want [2,4) in RUNES", c.line, c.selStart, c.selEnd)
		}
	}

	h.pressKey(key.NameDeleteForward, 0)
	h.frame(true)
	if got, want := e.Text(), strings.Repeat("一二五六\n", 2); got != want {
		t.Fatalf("multibyte forward delete:\n got  %q\n want  %q", got, want)
	}
	if got := e.text.Paragraphs(); got != 3 {
		t.Fatalf("multibyte delete merged lines: paragraphs=%d, want 3", got)
	}

	// Backward: march one step right first, which collapses the block, so
	// Backspace takes a single rune before the caret.
	h2 := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e2 := h2.ed
	e2.text.MoveCaret(e2.Len(), 0)
	e2.startColumnSelection(image.Pt(int(xTo.X), 0))
	e2.updateColumnSelection(h2.gtx, image.Pt(int(xFrom.X), lineHeight))
	for range 20 {
		e2.moveColumnCarets(1)
	}
	for _, c := range e2.columnEdit.selections {
		if c.col != 4 {
			t.Fatalf("caret on line %d at col %d after marching right, want 4", c.line, c.col)
		}
	}

	h2.pressKey(key.NameDeleteBackward, 0)
	h2.frame(true)
	// 一[二]三... with the caret at col 4 (after 四): Backspace removes 四.
	if got, want := e2.Text(), strings.Repeat("一二三五六\n", 2); got != want {
		t.Fatalf("multibyte backward delete:\n got  %q\n want  %q", got, want)
	}
}

// TestColumnEditInsertOnMixedLengthLines: typing must land on EVERY line of the
// block at the SAME pixel column, including a line shorter than the rectangle —
// IntelliJ keeps the block's desired column for the whole line range, so that
// line's caret parks at its own end and the typed run is padded out with spaces.
// The check is deliberately expressed in PIXELS so it does not depend on how
// wide the font makes a space.
func TestColumnEditInsertOnMixedLengthLines(t *testing.T) {
	content := "abcdefghij\nabcdefg\nabc\nabcdefghij\n"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)

	lineHeight := e.text.GetLineHeight().Round()
	_, xFrom := e.ConvertPos(0, 6)
	_, xTo := e.ConvertPos(0, 9)
	e.startColumnSelection(image.Pt(int(xTo.X), 0))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight*3))

	// Every line in the range belongs to the block. The 3-rune line ends left of
	// the block's left edge, so its caret parks at its own end (col 3).
	if got := len(e.columnEdit.selections); got != 4 {
		t.Fatalf("block covers %d lines, want all 4", got)
	}
	for _, c := range e.columnEdit.selections {
		want := 6
		if c.line == 2 {
			want = 3
		}
		if c.col != want {
			t.Fatalf("caret on line %d at col %d, want %d", c.line, c.col, want)
		}
	}

	h.pressText("X")
	h.frame(true)

	lines := strings.Split(e.Text(), "\n")
	if got := e.text.Paragraphs(); got != 5 {
		t.Fatalf("typing changed the line count: paragraphs=%d, want 5", got)
	}

	refX, refLine := -1, -1
	for i := range e.columnEdit.selections {
		c := &e.columnEdit.selections[i]
		// The typed rune sits immediately before the caret.
		if c.col <= 0 || lines[c.line][c.col-1] != 'X' {
			t.Fatalf("line %d (%q) did not receive the typed rune at the caret", c.line, lines[c.line])
		}
		_, pos := e.ConvertPos(c.line, c.col-1)
		x := int(pos.X)
		if refX < 0 {
			refX, refLine = x, c.line
		} else if d := x - refX; d > 2 || d < -2 {
			t.Fatalf("typed runes are not in one column: L%d x=%d vs L%d x=%d (Δ=%d)",
				refLine, refX, c.line, x, d)
		}
	}

	// The short line was padded, so it grew by MORE than the single typed rune.
	if got, was := len(lines[2]), len("abc"); got <= was+1 {
		t.Fatalf("the short line was not padded to the block column: %q", lines[2])
	}
}

// TestColumnEditInsertPadsShortLineToBlockColumn reproduces IntelliJ's
// EditorMultiCaretColumnModeTest.testTyping exactly: a block over
// "a\nbbb\nccccc" that starts at column 2, typed with a rune, must give
//
//	a S<caret>
//	bbS<caret>
//	ccS<caret>cc
//
// — the longer lines have the block's character REPLACED, and the one-rune line
// is padded out to the block's column with a space so the typed rune lands in
// the block column on EVERY line.
func TestColumnEditInsertPadsShortLineToBlockColumn(t *testing.T) {
	content := "a\nbbb\nccccc\n"
	h := newColumnEditHarness(t, content, image.Pt(600, 300), unit.Metric{PxPerDp: 1, PxPerSp: 1})
	e := h.ed
	e.text.SetCaret(0, 0)
	h.useMonospace(t)

	lineHeight := e.text.GetLineHeight().Round()
	// Measure the block's columns on the LONGEST line: the one-rune line has no
	// pixel for column 2 at all, so ConvertPos there would leak to the next
	// paragraph's start.
	_, xFrom := e.ConvertPos(2, 2)
	_, xTo := e.ConvertPos(2, 3)
	e.startColumnSelection(image.Pt(int(xTo.X), 0))
	e.updateColumnSelection(h.gtx, image.Pt(int(xFrom.X), lineHeight*2))

	if got := len(e.columnEdit.selections); got != 3 {
		t.Fatalf("block covers %d lines, want 3", got)
	}
	// The one-rune line parks at its own end and is NOT dropped from the block;
	// the longer lines select the single character the block covers.
	if c := e.columnEdit.selections[0]; c.line != 0 || c.col != 1 || c.selStart != 1 || c.selEnd != 1 {
		t.Fatalf("short line cursor = (line %d, col %d, sel [%d,%d)), want (0, 1, [1,1))",
			c.line, c.col, c.selStart, c.selEnd)
	}
	if c := e.columnEdit.selections[1]; c.line != 1 || c.col != 2 || c.selStart != 2 || c.selEnd != 3 {
		t.Fatalf("second line cursor = (line %d, col %d, sel [%d,%d)), want (1, 2, [2,3))",
			c.line, c.col, c.selStart, c.selEnd)
	}

	h.pressText("S")
	h.frame(true)

	// Exactly GoLand's result: padding on the short line, replacement elsewhere.
	if got, want := e.Text(), "a S\nbbS\nccScc\n"; got != want {
		t.Fatalf("column typing:\n got  %q\n want %q", got, want)
	}
	if got := e.text.Paragraphs(); got != 4 {
		t.Fatalf("typing changed the line count: paragraphs=%d, want 4", got)
	}
	// The caret ends right after the typed rune on every line, which is what
	// makes the three lines read "a S|", "bbS|" and "ccS|cc".
	for i, c := range e.columnEdit.selections {
		if c.col != 3 {
			t.Fatalf("caret %d sits at col %d, want 3 (just after the typed rune)", i, c.col)
		}
	}
}
