package gvcode

import (
	"image"
	"image/color"
	"strings"
	"testing"

	"gioui.org/f32"
	"gioui.org/io/key"
	"gioui.org/io/pointer"
	"gioui.org/unit"

	"github.com/oligo/gvcode/lsp"
	"github.com/oligo/gvcode/textstyle/syntax"
)

// navSample drives the navigation tests: an interface, two implementing types
// and a usage of both the interface and one of its methods.
const navSample = "package store\n" +
	"\n" +
	"// Reader reads records.\n" +
	"type Reader interface {\n" +
	"\tRead(id int) (string, error)\n" +
	"}\n" +
	"\n" +
	"type memory struct{}\n" +
	"\n" +
	"func (m *memory) Read(id int) (string, error) {\n" +
	"\treturn \"\", nil\n" +
	"}\n" +
	"\n" +
	"type disker struct{}\n" +
	"\n" +
	"func (d *disker) Read(id int) (string, error) {\n" +
	"\treturn \"\", nil\n" +
	"}\n" +
	"\n" +
	"func use(r Reader) {\n" +
	"\t_, _ = r.Read(1)\n" +
	"}\n"

// newNavHarness is newLanguageHarness with an explicit window size, so a test can
// reach lines that fall outside the default 220px window.
func newNavHarness(t *testing.T, content string, size image.Point) *columnEditHarness {
	t.Helper()
	h := newColumnEditHarness(t, content, size, unit.Metric{PxPerDp: 1, PxPerSp: 1})
	h.ed.SetColumnEditMode(false)
	h.ed.WithOptions(WithLanguageServer(lsp.NewMockServer()))
	for range 2 {
		h.frame(true)
	}
	return h
}

// caretOnNeedle parks the caret on the first occurrence of needle.
func caretOnNeedle(t *testing.T, e *Editor, needle string) {
	t.Helper()
	off := strings.Index(e.Text(), needle)
	if off < 0 {
		t.Fatalf("the document does not contain %q", needle)
	}
	e.SetCaret(off, off)
}

func screenshot(t *testing.T, h *columnEditHarness) *image.RGBA {
	t.Helper()
	img := image.NewRGBA(image.Rectangle{Max: h.win.Size()})
	if err := h.win.Screenshot(img); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	return img
}

// ---------------------------------------------------------------- navigation

func TestShowUsagesCollectsTheOccurrences(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	caretOnNeedle(t, e, "Reader interface")
	h.frame(true)

	event, ok := e.ShowUsages()
	if !ok {
		t.Fatal("ShowUsages found nothing on the interface name")
	}
	nav, isNav := event.(NavigationEvent)
	if !isNav || nav.Kind != NavigationUsages {
		t.Fatalf("event = %#v, want a NavigationEvent of kind usages", event)
	}
	// Reader 出现在接口声明和 use 的参数上（注释里的不算）。
	if len(nav.Items) != 2 {
		t.Fatalf("usages = %d rows, want 2 (%+v)", len(nav.Items), nav.Items)
	}
	for _, item := range nav.Items {
		if item.Name != "Reader" {
			t.Fatalf("row %+v does not name the symbol", item)
		}
	}
}

func TestShowImplementationsFindsTheImplementingTypes(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	caretOnNeedle(t, e, "Reader interface")
	h.frame(true)

	event, ok := e.ShowImplementations()
	if !ok {
		t.Fatal("ShowImplementations found nothing on the interface name")
	}
	nav := event.(NavigationEvent)
	if len(nav.Items) != 2 {
		t.Fatalf("implementations = %d rows, want memory and disker (%+v)", len(nav.Items), nav.Items)
	}
	var names []string
	for _, item := range nav.Items {
		names = append(names, item.Detail)
	}
	joined := strings.Join(names, "\n")
	if !strings.Contains(joined, "type memory struct") || !strings.Contains(joined, "type disker struct") {
		t.Fatalf("implementations = %q, want both implementing types", joined)
	}
}

func TestShowTypeHierarchyWalksTheInterface(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	caretOnNeedle(t, e, "Reader interface")
	h.frame(true)

	event, ok := e.ShowTypeHierarchy()
	if !ok {
		t.Fatal("ShowTypeHierarchy found nothing on the interface name")
	}
	nav := event.(NavigationEvent)
	if nav.Kind != NavigationHierarchy || nav.Hierarchy == nil {
		t.Fatalf("event = %+v, want a hierarchy", nav)
	}
	if nav.Hierarchy.Name != "Reader" || len(nav.Hierarchy.Subs) != 2 {
		t.Fatalf("hierarchy = %+v, want Reader with two subtypes", nav.Hierarchy)
	}
}

func TestImplementationsAtAndReferencesAtExposeTheRawLocations(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	caretOnNeedle(t, e, "Read(id int) (string, error)")
	h.frame(true)

	if got := e.ImplementationsAt(); len(got) != 2 {
		t.Fatalf("ImplementationsAt = %d, want the two Read methods", len(got))
	}
	if got := e.ReferencesAt(); len(got) != 4 {
		// 接口里的签名 + 两个实现 + 调用点。
		t.Fatalf("ReferencesAt = %d, want 4", len(got))
	}
}

func TestRenameSymbolRewritesEveryReference(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	caretOnNeedle(t, e, "memory struct")
	h.frame(true)

	if !e.RenameSymbol("mem") {
		t.Fatal("RenameSymbol reported no change")
	}
	text := e.Text()
	if strings.Contains(text, "memory") {
		t.Fatalf("the old name survived the rename:\n%s", text)
	}
	if !strings.Contains(text, "func (m *mem) Read") {
		t.Fatalf("the receiver was not renamed:\n%s", text)
	}
}

func TestRenameSymbolRejectsAnEmptyName(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	caretOnNeedle(t, e, "memory struct")
	h.frame(true)
	if e.RenameSymbol("") {
		t.Fatal("RenameSymbol accepted an empty name")
	}
}

func TestFormatDocumentExpandsTabs(t *testing.T) {
	h := newLanguageHarness(t, "package main\n\nfunc main() {\n\tx := 1   \n\t_ = x\n}\n")
	e := h.ed
	h.frame(true)

	if !e.FormatDocument() {
		t.Fatal("FormatDocument reported no change")
	}
	if strings.Contains(e.Text(), "\t") {
		t.Fatalf("tabs survived the reformat: %q", e.Text())
	}
	if strings.Contains(e.Text(), "1   \n") {
		t.Fatalf("trailing whitespace survived the reformat: %q", e.Text())
	}
}

// ------------------------------------------------------------------ code lens

func TestCodeLensesAreReportedAndPainted(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	e.WithOptions(WithCodeLens())
	h.frame(true)
	h.frame(true)

	var titles []string
	for _, lens := range e.CodeLenses() {
		titles = append(titles, lens.Title)
	}
	joined := strings.Join(titles, "|")
	if !strings.Contains(joined, "2 implementations") {
		t.Fatalf("lenses = %q, want the interface implementation count", joined)
	}

	img := screenshot(t, h)
	dumpPNG(t, screenshotDir(t), "gvcode-navigation-code-lens", img)

	lineHeight := e.text.GetLineHeight().Round()
	// The interface lens sits on document line 3, right-aligned.
	if n := countColorIn(img, e.gutterWidth, h.win.Size().X, 3*lineHeight, 4*lineHeight, codeLensColor); n < 8 {
		t.Fatalf("no code lens painted on the interface (%d pixels)", n)
	}
}

// -------------------------------------------------------- usage highlighting

func TestUsageHighlightingMarksTheOtherOccurrences(t *testing.T) {
	h := newNavHarness(t, navSample, image.Pt(560, 420))
	e := h.ed
	e.WithOptions(WithUsageHighlighting())

	// Caret nowhere near a symbol: nothing is highlighted.
	e.SetCaret(0, 0)
	h.frame(true)
	h.frame(true)
	if got := e.UsageHighlights(); len(got) != 0 {
		t.Fatalf("UsageHighlights = %+v, want none at the start of the file", got)
	}

	// Caret on the interface name: the usage on line 19 lights up instead. The
	// declaration itself is not a usage, which is what separates this from the
	// syntactic word highlighter.
	caretOnNeedle(t, e, "Reader interface")
	h.frame(true)
	h.frame(true)
	got := e.UsageHighlights()
	if len(got) != 1 {
		t.Fatalf("UsageHighlights = %+v, want just the usage on line 19", got)
	}
	if line := got[0].Range.Start.Line; line != 19 {
		t.Fatalf("the usage landed on line %d, want 19", line)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-navigation-usage-highlight", screenshot(t, h))

	// Moving the caret onto a keyword clears the highlight again.
	e.SetCaret(0, 0)
	h.frame(true)
	h.frame(true)
	if got := e.UsageHighlights(); len(got) != 0 {
		t.Fatalf("UsageHighlights = %+v, want none after the caret left the symbol", got)
	}
}

// ---------------------------------------------------------------------- marks

func TestBookmarksToggleAndNavigate(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	e.WithOptions(WithBookmarkGutter())

	e.GoToPosition(3, 0)
	line, on := e.ToggleBookmark()
	if line != 3 || !on {
		t.Fatalf("ToggleBookmark = (%d, %v), want (3, true)", line, on)
	}
	e.GoToPosition(12, 0)
	if line, on := e.ToggleBookmark(); line != 12 || !on {
		t.Fatalf("ToggleBookmark = (%d, %v), want (12, true)", line, on)
	}
	if got := e.Bookmarks(); len(got) != 2 || got[0] != 3 || got[1] != 12 {
		t.Fatalf("Bookmarks = %v, want [3 12]", got)
	}

	// F11 from the top walks forward and wraps; Shift+F11 walks back.
	e.GoToPosition(0, 0)
	if !e.GoToNextBookmark() {
		t.Fatal("GoToNextBookmark found nothing")
	}
	if start, _ := e.Selection(); start != lineStartOffset(e, 3) {
		t.Fatalf("the caret is at %d, want the bookmark on line 3", start)
	}
	if !e.GoToNextBookmark() {
		t.Fatal("GoToNextBookmark found nothing on the second step")
	}
	if start, _ := e.Selection(); start != lineStartOffset(e, 12) {
		t.Fatalf("the caret is at %d, want the bookmark on line 12", start)
	}

	e.GoToPosition(3, 0)
	if line, on := e.ToggleBookmark(); line != 3 || on {
		t.Fatalf("ToggleBookmark = (%d, %v), want the bookmark removed", line, on)
	}
	if got := e.Bookmarks(); len(got) != 1 || got[0] != 12 {
		t.Fatalf("Bookmarks = %v, want just line 12", got)
	}
}

// lineStartOffset returns the rune offset that starts a document line.
func lineStartOffset(e *Editor, line int) int {
	return e.offsetAt(lsp.Position{Line: line})
}

func TestBookmarkGutterPaintsARibbon(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	e.WithOptions(WithBookmarkGutter())
	e.GoToPosition(3, 0)
	e.ToggleBookmark()
	h.frame(true)
	h.frame(true)

	img := screenshot(t, h)
	dumpPNG(t, screenshotDir(t), "gvcode-navigation-bookmark-gutter", img)

	lineHeight := e.text.GetLineHeight().Round()
	// Both mark columns live inside the gutter, so scanning the gutter band is
	// enough to prove the ribbon was painted.
	band := image.Rect(0, 3*lineHeight, e.gutterWidth, 4*lineHeight)
	if n := countColorIn(img, band.Min.X, band.Max.X, band.Min.Y, band.Max.Y, bookmarkColor()); n < 4 {
		t.Fatalf("no bookmark ribbon painted (%d pixels)", n)
	}
}

func TestBreakpointGutterPaintsADot(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	e.WithOptions(WithBreakpointGutter())
	e.GoToPosition(10, 0)
	line, on := e.ToggleBreakpoint()
	if line != 10 || !on {
		t.Fatalf("ToggleBreakpoint = (%d, %v), want (10, true)", line, on)
	}
	if !e.HasBreakpoint(10) {
		t.Fatal("HasBreakpoint(10) is false after toggling")
	}
	h.frame(true)
	h.frame(true)

	img := screenshot(t, h)
	dumpPNG(t, screenshotDir(t), "gvcode-navigation-breakpoint-gutter", img)

	lineHeight := e.text.GetLineHeight().Round()
	band := image.Rect(0, 10*lineHeight, e.gutterWidth, 11*lineHeight)
	if n := countColorIn(img, band.Min.X, band.Max.X, band.Min.Y, band.Max.Y, breakpointColor()); n < 4 {
		t.Fatalf("no breakpoint dot painted (%d pixels)", n)
	}
}

// bookmarkColor / breakpointColor mirror the provider's palette.
func bookmarkColor() color.NRGBA { return color.NRGBA{R: 0x6E, G: 0x9A, B: 0xCF, A: 0xFF} }
func breakpointColor() color.NRGBA {
	return color.NRGBA{R: 0xE0, G: 0x55, B: 0x55, A: 0xFF}
}

// --------------------------------------------------- semantic token merging

func TestMergeSemanticTokensRefinesTheLexerTokens(t *testing.T) {
	// lineStarts maps an LSP position onto a rune offset, the way the editor does;
	// the document is "package main\n\nfunc greet() {}\n".
	lineStarts := []int{0, 13, 14}
	offsetAt := func(p lsp.Position) int { return lineStarts[p.Line] + p.Character }

	base := []syntax.Token{
		{Start: 0, End: 7, Scope: "Keyword"},   // package
		{Start: 8, End: 12, Scope: "Name"},     // main
		{Start: 14, End: 18, Scope: "Keyword"}, // func
		{Start: 19, End: 24, Scope: "Name"},    // greet
	}
	// The server classifies greet as a function, which the lexer cannot know.
	semantic := []lsp.SemanticToken{{
		Type:  lsp.SemanticFunction,
		Range: lsp.Range{Start: lsp.Position{Line: 2, Character: 5}, End: lsp.Position{Line: 2, Character: 10}},
	}}
	merged := MergeSemanticTokens(base, semantic, offsetAt)

	scopeAt := func(off int) syntax.StyleScope {
		for _, token := range merged {
			if off >= token.Start && off < token.End {
				return token.Scope
			}
		}
		return ""
	}
	if got := scopeAt(20); got != "NameFunction" {
		t.Fatalf("greet scope = %q, want NameFunction", got)
	}
	if got := scopeAt(2); got != "Keyword" {
		t.Fatalf("package scope = %q, want the lexer's Keyword", got)
	}
	if got := scopeAt(15); got != "Keyword" {
		t.Fatalf("func scope = %q, want the lexer's Keyword", got)
	}
	if got := scopeAt(9); got != "Name" {
		t.Fatalf("main scope = %q, want the lexer's Name", got)
	}
}

func TestMergeSemanticTokensWithoutSemanticsIsANoOp(t *testing.T) {
	base := []syntax.Token{{Start: 0, End: 3, Scope: "Keyword"}}
	if got := MergeSemanticTokens(base, nil, func(lsp.Position) int { return 0 }); len(got) != 1 || got[0] != base[0] {
		t.Fatalf("MergeSemanticTokens = %+v, want the input unchanged", got)
	}
}

func TestSemanticScopeCoversEveryType(t *testing.T) {
	for _, kind := range []lsp.SemanticTokenType{
		lsp.SemanticKeyword, lsp.SemanticString, lsp.SemanticNumber, lsp.SemanticComment,
		lsp.SemanticFunction, lsp.SemanticMethod, lsp.SemanticType, lsp.SemanticStruct,
		lsp.SemanticInterface, lsp.SemanticNamespace, lsp.SemanticProperty,
		lsp.SemanticVariable, lsp.SemanticParameter, lsp.SemanticOperator,
	} {
		if SemanticScope(kind) == "" {
			t.Fatalf("semantic type %q has no scope", kind)
		}
	}
}

// ---------------------------------------------------- column selection mode

// drag queues a real press, a move and a release.
func (h *columnEditHarness) drag(from, to image.Point, mods key.Modifiers) {
	h.t.Helper()
	pump := func() {
		for {
			if _, ok := h.ed.Update(h.gtx); !ok {
				break
			}
		}
	}
	h.router.Queue(pointer.Event{
		Kind: pointer.Press, Buttons: pointer.ButtonPrimary, Source: pointer.Mouse,
		Position: f32.Pt(float32(from.X), float32(from.Y)), Modifiers: mods,
	})
	h.frame(true)
	pump()
	h.router.Queue(pointer.Event{
		Kind: pointer.Move, Source: pointer.Mouse,
		Position: f32.Pt(float32(to.X), float32(to.Y)), Modifiers: mods,
	})
	h.frame(true)
	pump()
	h.router.Queue(pointer.Event{
		Kind: pointer.Release, Buttons: pointer.ButtonPrimary, Source: pointer.Mouse,
		Position: f32.Pt(float32(to.X), float32(to.Y)), Modifiers: mods,
	})
	h.frame(true)
	pump()
}

// TestColumnSelectionModeSelectsABlockOnAPlainDrag is the whole point of
// Alt+Shift+Insert: with the mode on, an unmodified drag selects a rectangle.
func TestColumnSelectionModeSelectsABlockOnAPlainDrag(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	e.SetColumnEditMode(false)
	e.SetColumnSelectionMode(true)

	lineHeight := e.text.GetLineHeight().Round()
	left := e.gutterWidth + 4
	h.drag(image.Pt(left, 3*lineHeight+lineHeight/2), image.Pt(left+60, 6*lineHeight+lineHeight/2), 0)

	if !e.ColumnEditEnabled() {
		t.Fatal("a plain drag did not start a column selection with the mode on")
	}
}

// TestAColumnDragWithoutTheModeStaysATextSelection guards the default.
func TestAColumnDragWithoutTheModeStaysATextSelection(t *testing.T) {
	h := newLanguageHarness(t, navSample)
	e := h.ed
	e.SetColumnEditMode(false)
	e.SetColumnSelectionMode(false)

	lineHeight := e.text.GetLineHeight().Round()
	left := e.gutterWidth + 4
	h.drag(image.Pt(left, 3*lineHeight+lineHeight/2), image.Pt(left+60, 6*lineHeight+lineHeight/2), 0)

	if e.ColumnEditEnabled() {
		t.Fatal("a plain drag entered column edit mode without Alt or the mode")
	}
}
