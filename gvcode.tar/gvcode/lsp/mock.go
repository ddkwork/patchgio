package lsp

import (
	"fmt"
	"sort"
	"strings"
	"unicode"
)

var _ Server = (*MockServer)(nil)

// MockServer is a self-contained stand-in for a language server. It scans the
// document with a small Go tokenizer and derives diagnostics, completions,
// hover, signature help, inlay hints, semantic tokens, code actions and the
// outline from it, so the editor's language features can be built and tested
// before a real LSP client exists.
//
// The analysis is deliberately syntactic: there is no type system. Every method
// takes the document it should analyse, so swapping in a real server only means
// implementing this interface.
type MockServer struct {
	// cached is the analysis of the last text handed in; the editor analyses
	// once per document change.
	cachedText string
	cached     *analysis
}

// NewMockServer creates a mock language server.
func NewMockServer() *MockServer {
	return &MockServer{}
}

// ---------------------------------------------------------------- tokenizing

type tokenKind int

const (
	tkIdent tokenKind = iota
	tkKeyword
	tkNumber
	tkString
	tkRune
	tkComment
	tkPunct
)

type token struct {
	kind       tokenKind
	text       string
	start, end int // rune offsets, half-open
}

// file is a tokenized document.
type file struct {
	text   string
	runes  []rune
	starts []int // rune offset of the first rune of each line
	tokens []token
}

var goKeywords = map[string]bool{
	"break": true, "case": true, "chan": true, "const": true, "continue": true,
	"default": true, "defer": true, "else": true, "fallthrough": true, "for": true,
	"func": true, "go": true, "goto": true, "if": true, "import": true,
	"interface": true, "map": true, "package": true, "range": true, "return": true,
	"select": true, "struct": true, "switch": true, "type": true, "var": true,
}

func newFile(text string) *file {
	f := &file{text: text, runes: []rune(text)}
	f.starts = append(f.starts, 0)
	for i, r := range f.runes {
		if r == '\n' {
			f.starts = append(f.starts, i+1)
		}
	}
	f.tokenize()
	return f
}

func (f *file) tokenize() {
	src := f.runes
	for i := 0; i < len(src); {
		r := src[i]
		switch {
		case r == '\n' || r == ' ' || r == '\t' || r == '\r':
			i++
		case r == '/' && i+1 < len(src) && src[i+1] == '/':
			j := i
			for j < len(src) && src[j] != '\n' {
				j++
			}
			f.tokens = append(f.tokens, token{tkComment, string(src[i:j]), i, j})
			i = j
		case r == '/' && i+1 < len(src) && src[i+1] == '*':
			j := i + 2
			for j+1 < len(src) && !(src[j] == '*' && src[j+1] == '/') {
				j++
			}
			if j+1 < len(src) {
				j += 2
			} else {
				j = len(src)
			}
			f.tokens = append(f.tokens, token{tkComment, string(src[i:j]), i, j})
			i = j
		case r == '"':
			j := i + 1
			for j < len(src) && src[j] != '"' {
				if src[j] == '\\' {
					j++
				}
				j++
			}
			if j < len(src) {
				j++
			}
			f.tokens = append(f.tokens, token{tkString, string(src[i:j]), i, j})
			i = j
		case r == '`':
			j := i + 1
			for j < len(src) && src[j] != '`' {
				j++
			}
			if j < len(src) {
				j++
			}
			f.tokens = append(f.tokens, token{tkString, string(src[i:j]), i, j})
			i = j
		case r == '\'':
			j := i + 1
			for j < len(src) && src[j] != '\'' {
				if src[j] == '\\' {
					j++
				}
				j++
			}
			if j < len(src) {
				j++
			}
			f.tokens = append(f.tokens, token{tkRune, string(src[i:j]), i, j})
			i = j
		case unicode.IsDigit(r):
			j := i
			for j < len(src) && (unicode.IsDigit(src[j]) || unicode.IsLetter(src[j]) || src[j] == '.') {
				j++
			}
			f.tokens = append(f.tokens, token{tkNumber, string(src[i:j]), i, j})
			i = j
		case r == '_' || unicode.IsLetter(r):
			j := i
			for j < len(src) && (src[j] == '_' || unicode.IsLetter(src[j]) || unicode.IsDigit(src[j])) {
				j++
			}
			text := string(src[i:j])
			kind := tkIdent
			if goKeywords[text] {
				kind = tkKeyword
			}
			f.tokens = append(f.tokens, token{kind, text, i, j})
			i = j
		default:
			f.tokens = append(f.tokens, token{tkPunct, string(r), i, i + 1})
			i++
		}
	}
}

// pos converts a rune offset into a line/character position.
func (f *file) pos(off int) Position {
	line := sort.Search(len(f.starts), func(i int) bool { return f.starts[i] > off }) - 1
	if line < 0 {
		line = 0
	}
	return Position{Line: line, Character: off - f.starts[line]}
}

// offset converts a line/character position into a rune offset, clamped.
func (f *file) offset(p Position) int {
	if p.Line < 0 {
		return 0
	}
	if p.Line >= len(f.starts) {
		return len(f.runes)
	}
	off := f.starts[p.Line] + p.Character
	if off > len(f.runes) {
		off = len(f.runes)
	}
	return off
}

// rangeOf returns the LSP range covering [start, end) rune offsets.
func (f *file) rangeOf(start, end int) Range {
	return Range{Start: f.pos(start), End: f.pos(end)}
}

// lineText returns the text of a line without its line feed.
func (f *file) lineText(line int) string {
	if line < 0 || line >= len(f.starts) {
		return ""
	}
	start := f.starts[line]
	end := len(f.runes)
	if line+1 < len(f.starts) {
		end = f.starts[line+1] - 1
	}
	if end > 0 && end <= len(f.runes) && end > start && f.runes[end-1] == '\r' {
		end--
	}
	return string(f.runes[start:end])
}

// tokenAt returns the token containing off, or nil.
func (f *file) tokenAt(off int) *token {
	for i := range f.tokens {
		if f.tokens[i].start <= off && off < f.tokens[i].end {
			return &f.tokens[i]
		}
	}
	return nil
}

// ------------------------------------------------------------------ analysis

// decl is one declaration found in the document.
type decl struct {
	name      string
	kind      SymbolKind
	keyword   string // func / type / var / const / ":="
	line      int
	nameStart int // rune offset of the name
	startLine int // first line of the declaration
	endLine   int // last line of the declaration (inclusive)
	signature string
	doc       string
	params    []string
	// assigned is the rune offset just past the "=" of a short declaration, so
	// "unused" and "convert to var" can point at the statement.
	assignEnd int
	// colonStart/End is the ":" of a short declaration, which the convert-to-var
	// intention removes.
	colonStart int
	colonEnd   int
	local      bool
	// receiver is a method's receiver type name ("Server" for
	// "func (s *Server) ListenAndServe"), empty for a plain function.
	receiver string
	// ifaceMethods holds the method names of an interface type declaration and
	// ifaceEmbeds the interfaces it embeds, so "implements"/"hierarchy" have a
	// method set to compare against.
	ifaceMethods []string
	ifaceEmbeds  []string
	// bodyStart/bodyEnd bracket an interface's "{...}", so a method signature
	// inside it can be told apart from a declaration.
	bodyStart int
	bodyEnd   int
}

type analysis struct {
	file        *file
	decls       []*decl
	byName      map[string]*decl
	diagnostics []Diagnostic
	comments    []token
}

func (m *MockServer) analyse(doc Document) *analysis {
	if m.cached != nil && m.cachedText == doc.Text {
		return m.cached
	}
	a := buildAnalysis(doc.Text)
	m.cachedText = doc.Text
	m.cached = a
	return a
}

func buildAnalysis(text string) *analysis {
	f := newFile(text)
	a := &analysis{file: f, byName: map[string]*decl{}}

	for i := 0; i < len(f.tokens); i++ {
		tok := &f.tokens[i]
		switch {
		case tok.kind == tkComment:
			a.comments = append(a.comments, *tok)
		case tok.kind == tkKeyword && (tok.text == "func" || tok.text == "type" ||
			tok.text == "var" || tok.text == "const"):
			if d := a.buildDecl(i); d != nil {
				a.decls = append(a.decls, d)
				if _, exists := a.byName[d.name]; !exists {
					a.byName[d.name] = d
				}
			}
		case tok.kind == tkIdent && i+1 < len(f.tokens) &&
			f.tokens[i+1].kind == tkPunct && f.tokens[i+1].text == ":" &&
			i+2 < len(f.tokens) && f.tokens[i+2].kind == tkPunct && f.tokens[i+2].text == "=" &&
			a.isStatementStart(i):
			d := &decl{
				name:       tok.text,
				kind:       SymbolKindVariable,
				keyword:    ":=",
				line:       f.pos(tok.start).Line,
				nameStart:  tok.start,
				startLine:  f.pos(tok.start).Line,
				endLine:    f.pos(f.tokens[i+2].end).Line,
				assignEnd:  f.tokens[i+2].end,
				colonStart: f.tokens[i+1].start,
				colonEnd:   f.tokens[i+1].end,
				local:      true,
			}
			a.decls = append(a.decls, d)
			if _, exists := a.byName[d.name]; !exists {
				a.byName[d.name] = d
			}
		}
	}

	a.collectDiagnostics()
	return a
}

// isStatementStart reports whether the token at idx opens a statement, so a
// "x :=" inside an expression (a map literal key, for instance) is not mistaken
// for a short variable declaration.
func (a *analysis) isStatementStart(idx int) bool {
	if idx == 0 {
		return true
	}
	prev := &a.file.tokens[idx-1]
	if prev.kind == tkComment {
		return true
	}
	return prev.kind == tkPunct && (prev.text == "{" || prev.text == ";" || prev.text == "(")
}

// buildDecl builds the declaration that starts at the keyword token index.
func (a *analysis) buildDecl(keywordIdx int) *decl {
	f := a.file
	kw := &f.tokens[keywordIdx]
	d := &decl{keyword: kw.text, startLine: f.pos(kw.start).Line, line: f.pos(kw.start).Line}

	switch kw.text {
	case "func":
		i := keywordIdx + 1
		// Skip a method receiver: func (r T) Name, remembering the receiver type
		// so methods can be grouped into a per-type method set.
		if i < len(f.tokens) && f.tokens[i].kind == tkPunct && f.tokens[i].text == "(" {
			close := a.matching(f.tokens, i, "(", ")")
			if close > i {
				for j := i + 1; j < close; j++ {
					if f.tokens[j].kind == tkIdent && !isBuiltinType(f.tokens[j].text) {
						d.receiver = f.tokens[j].text
					}
				}
			}
			i = close + 1
		}
		if i >= len(f.tokens) || f.tokens[i].kind != tkIdent {
			return nil
		}
		d.name = f.tokens[i].text
		d.nameStart = f.tokens[i].start
		d.kind = SymbolKindFunction
		if p := a.findNext(f.tokens, i, "("); p >= 0 {
			close := a.matching(f.tokens, p, "(", ")")
			if close > p {
				d.params = a.paramNames(f.tokens, p, close)
			}
			d.signature = strings.TrimSpace(f.lineText(f.pos(f.tokens[i].start).Line))
			d.signature = strings.TrimSuffix(d.signature, "{")
			d.signature = strings.TrimSpace(d.signature)
		}
		if body := a.findNext(f.tokens, i, "{"); body >= 0 {
			if end := a.matching(f.tokens, body, "{", "}"); end > body {
				d.endLine = f.pos(f.tokens[end].end).Line
			}
		}
		d.doc = a.docBefore(kw.start)
		return d
	case "type":
		i := keywordIdx + 1
		if i >= len(f.tokens) || f.tokens[i].kind != tkIdent {
			return nil
		}
		d.name = f.tokens[i].text
		d.nameStart = f.tokens[i].start
		d.kind = SymbolKindType
		if j := i + 1; j < len(f.tokens) && f.tokens[j].kind == tkKeyword {
			switch f.tokens[j].text {
			case "struct":
				d.kind = SymbolKindStruct
			case "interface":
				d.kind = SymbolKindInterface
				a.parseInterface(d, j)
			}
		}
		d.signature = "type " + d.name
		d.doc = a.docBefore(kw.start)
		return d
	case "var", "const":
		i := keywordIdx + 1
		if i >= len(f.tokens) || f.tokens[i].kind != tkIdent {
			return nil
		}
		d.name = f.tokens[i].text
		d.nameStart = f.tokens[i].start
		if kw.text == "var" {
			d.kind = SymbolKindVariable
		} else {
			d.kind = SymbolKindConstant
		}
		d.signature = kw.text + " " + d.name
		d.doc = a.docBefore(kw.start)
		// An indented "var"/"const" is a function-local declaration, which is
		// where an unused name is an error.
		d.local = strings.HasPrefix(f.lineText(d.line), " ") || strings.HasPrefix(f.lineText(d.line), "\t")
		if eq := a.findNext(f.tokens, i, "="); eq >= 0 {
			d.assignEnd = f.tokens[eq].end
		}
		return d
	}
	return nil
}

// paramNames extracts the parameter names of a signature between the paren
// indexes. A group whose only token is a type has no name and is skipped.
func (a *analysis) paramNames(tokens []token, open, close int) []string {
	var names []string
	depth := 0
	groupStart := open + 1
	flush := func(end int) {
		var idents []*token
		for i := groupStart; i < end; i++ {
			if tokens[i].kind == tkIdent {
				idents = append(idents, &tokens[i])
			}
		}
		if len(idents) >= 2 {
			names = append(names, idents[0].text)
		} else if len(idents) == 1 && !isBuiltinType(idents[0].text) && !isExported(idents[0].text) {
			names = append(names, idents[0].text)
		} else {
			names = append(names, "")
		}
	}
	for i := open + 1; i < close; i++ {
		switch {
		case tokens[i].kind == tkPunct && (tokens[i].text == "(" || tokens[i].text == "[" || tokens[i].text == "{"):
			depth++
		case tokens[i].kind == tkPunct && (tokens[i].text == ")" || tokens[i].text == "]" || tokens[i].text == "}"):
			depth--
		case tokens[i].kind == tkPunct && tokens[i].text == "," && depth == 0:
			flush(i)
			groupStart = i + 1
		}
	}
	if groupStart < close {
		flush(close)
	}
	return names
}

func isBuiltinType(name string) bool {
	switch name {
	case "int", "int8", "int16", "int32", "int64", "uint", "uint8", "uint16",
		"uint32", "uint64", "float32", "float64", "string", "bool", "byte",
		"rune", "error", "any":
		return true
	}
	return false
}

func isExported(name string) bool {
	if name == "" {
		return false
	}
	return unicode.IsUpper([]rune(name)[0])
}

// matching returns the index of the token closing the group that opens at
// openIdx, or -1.
func (a *analysis) matching(tokens []token, openIdx int, open, close string) int {
	depth := 0
	for i := openIdx; i < len(tokens); i++ {
		if tokens[i].kind != tkPunct {
			continue
		}
		switch tokens[i].text {
		case open:
			depth++
		case close:
			depth--
			if depth == 0 {
				return i
			}
		}
	}
	return -1
}

// findNext returns the index of the next token with the given text, or -1.
func (a *analysis) findNext(tokens []token, from int, text string) int {
	for i := from; i < len(tokens); i++ {
		if tokens[i].text == text {
			return i
		}
	}
	return -1
}

// docBefore collects the "//" comment block directly above a declaration.
func (a *analysis) docBefore(off int) string {
	line := a.file.pos(off).Line
	var lines []string
	for l := line - 1; l >= 0; l-- {
		text := strings.TrimSpace(a.file.lineText(l))
		if !strings.HasPrefix(text, "//") {
			break
		}
		lines = append([]string{strings.TrimSpace(strings.TrimPrefix(text, "//"))}, lines...)
	}
	return strings.Join(lines, "\n")
}

// ------------------------------------------------------------- diagnostics

func (a *analysis) collectDiagnostics() {
	f := a.file
	// Bracket balance over the whole document.
	type open struct {
		text string
		idx  int
	}
	var stack []open
	pairs := map[string]string{"(": ")", "[": "]", "{": "}"}
	for i := range f.tokens {
		tok := &f.tokens[i]
		if tok.kind != tkPunct {
			continue
		}
		if _, ok := pairs[tok.text]; ok {
			stack = append(stack, open{tok.text, i})
			continue
		}
		if tok.text == ")" || tok.text == "]" || tok.text == "}" {
			if n := len(stack); n > 0 && pairs[stack[n-1].text] == tok.text {
				stack = stack[:n-1]
				continue
			}
			a.diagnostics = append(a.diagnostics, Diagnostic{
				Range:    f.rangeOf(tok.start, tok.end),
				Severity: SeverityError,
				Code:     "unmatched-bracket",
				Source:   "mock",
				Message:  fmt.Sprintf("Unexpected %q", tok.text),
			})
		}
	}
	for _, o := range stack {
		a.diagnostics = append(a.diagnostics, Diagnostic{
			Range:    f.rangeOf(f.tokens[o.idx].start, f.tokens[o.idx].end),
			Severity: SeverityError,
			Code:     "unmatched-bracket",
			Source:   "mock",
			Message:  fmt.Sprintf("Missing closing %q", pairs[o.text]),
		})
	}

	// Unused local variables: a short declaration or "var" whose name never
	// appears again is an error in Go.
	counts := map[string]int{}
	for i := range f.tokens {
		if f.tokens[i].kind == tkIdent {
			counts[f.tokens[i].text]++
		}
	}
	for _, d := range a.decls {
		if !d.local {
			continue
		}
		if d.name == "_" || counts[d.name] > 1 {
			continue
		}
		a.diagnostics = append(a.diagnostics, Diagnostic{
			Range:    f.rangeOf(d.nameStart, d.nameStart+len([]rune(d.name))),
			Severity: SeverityWarning,
			Code:     "unused-variable",
			Source:   "mock",
			Message:  fmt.Sprintf("`%s` declared and not used", d.name),
		})
	}

	// TODO comments, the way an IDE surfaces them.
	for _, c := range a.comments {
		upper := strings.ToUpper(c.text)
		if !strings.Contains(upper, "TODO") && !strings.Contains(upper, "FIXME") {
			continue
		}
		a.diagnostics = append(a.diagnostics, Diagnostic{
			Range:    f.rangeOf(c.start, c.end),
			Severity: SeverityInformation,
			Code:     "todo",
			Source:   "mock",
			Message:  strings.TrimSpace(c.text),
		})
	}

	sort.SliceStable(a.diagnostics, func(i, j int) bool {
		return a.diagnostics[i].Range.Start.Line < a.diagnostics[j].Range.Start.Line
	})
}

// ------------------------------------------------------------------ Server

// Diagnostics implements Server.
func (m *MockServer) Diagnostics(doc Document) []Diagnostic {
	return m.analyse(doc).diagnostics
}

// DocumentSymbols implements Server.
func (m *MockServer) DocumentSymbols(doc Document) []DocumentSymbol {
	a := m.analyse(doc)
	var out []DocumentSymbol
	for _, d := range a.decls {
		if d.local || d.kind == SymbolKindVariable || d.kind == SymbolKindConstant {
			continue
		}
		out = append(out, DocumentSymbol{
			Name:           d.name,
			Detail:         d.signature,
			Kind:           d.kind,
			Range:          a.file.rangeOf(a.lineStart(d.startLine), a.lineStart(d.endLine+1)),
			SelectionRange: a.file.rangeOf(d.nameStart, d.nameStart+len([]rune(d.name))),
		})
	}
	return out
}

func (a *analysis) lineStart(line int) int {
	if line <= 0 {
		return 0
	}
	if line >= len(a.file.starts) {
		return len(a.file.runes)
	}
	return a.file.starts[line]
}

// Hover implements Server.
func (m *MockServer) Hover(doc Document, pos Position) *Hover {
	a := m.analyse(doc)
	tok := a.file.tokenAt(a.file.offset(pos))
	if tok == nil || tok.kind != tkIdent {
		return nil
	}
	rng := a.file.rangeOf(tok.start, tok.end)
	if d := a.byName[tok.text]; d != nil && d.signature != "" {
		contents := "```go\n" + d.signature + "\n```"
		if d.doc != "" {
			contents += "\n\n" + d.doc
		}
		return &Hover{Contents: contents, Range: &rng}
	}
	if goKeywords[tok.text] {
		return &Hover{Contents: fmt.Sprintf("`%s` — Go keyword", tok.text), Range: &rng}
	}
	return nil
}

// Completions implements Server.
func (m *MockServer) Completions(doc Document, pos Position) []CompletionItem {
	a := m.analyse(doc)
	var items []CompletionItem
	seen := map[string]bool{}
	for _, d := range a.decls {
		if seen[d.name] {
			continue
		}
		seen[d.name] = true
		kind := CompletionFunction
		switch d.kind {
		case SymbolKindVariable, SymbolKindConstant:
			kind = CompletionVariable
		case SymbolKindStruct, SymbolKindType:
			kind = CompletionStruct
		case SymbolKindInterface:
			kind = CompletionInterface
		}
		items = append(items, CompletionItem{
			Label: d.name, Kind: kind, Detail: d.signature,
			Documentation: d.doc, InsertText: d.name, SortText: "0" + d.name,
		})
	}
	for kw := range goKeywords {
		if seen[kw] {
			continue
		}
		seen[kw] = true
		items = append(items, CompletionItem{
			Label: kw, Kind: CompletionKeyword, InsertText: kw, SortText: "1" + kw,
		})
	}
	for _, b := range []string{"append", "cap", "close", "copy", "delete", "len", "make", "new", "panic", "print", "println", "recover"} {
		if seen[b] {
			continue
		}
		seen[b] = true
		items = append(items, CompletionItem{
			Label: b, Kind: CompletionFunction, InsertText: b, SortText: "2" + b,
		})
	}
	return items
}

// SignatureHelp implements Server.
func (m *MockServer) SignatureHelp(doc Document, pos Position) *SignatureHelp {
	a := m.analyse(doc)
	off := a.file.offset(pos)
	callee, openIdx := a.enclosingCall(off)
	if callee == nil {
		return nil
	}
	d := a.byName[callee.text]
	if d == nil || d.kind != SymbolKindFunction {
		return nil
	}
	params := make([]ParameterInformation, 0, len(d.params))
	for i, p := range d.params {
		label := p
		if label == "" {
			label = fmt.Sprintf("arg%d", i+1)
		}
		params = append(params, ParameterInformation{Label: label})
	}
	active := a.activeParameter(a.file.tokens, openIdx, off)
	return &SignatureHelp{
		Signatures: []SignatureInformation{{
			Label: d.signature, Documentation: d.doc, Parameters: params,
		}},
		ActiveSignature: 0,
		ActiveParameter: active,
	}
}

// enclosingCall finds the innermost call whose "(" is still open at off.
func (a *analysis) enclosingCall(off int) (callee *token, openIdx int) {
	tokens := a.file.tokens
	for i := len(tokens) - 1; i >= 0; i-- {
		tok := &tokens[i]
		if tok.start >= off {
			continue
		}
		if tok.kind != tkPunct {
			continue
		}
		if tok.text == ")" || tok.text == "]" || tok.text == "}" {
			continue
		}
		if tok.text != "(" {
			continue
		}
		if close := a.matching(tokens, i, "(", ")"); close >= 0 && tokens[close].start < off {
			continue // the call closed before the caret: not the one we are in
		}
		if i == 0 || tokens[i-1].kind != tkIdent {
			return nil, -1
		}
		return &tokens[i-1], i
	}
	return nil, -1
}

// activeParameter counts the top-level commas between the call's "(" and off.
func (a *analysis) activeParameter(tokens []token, openIdx, off int) int {
	depth := 0
	active := 0
	for i := openIdx + 1; i < len(tokens) && tokens[i].start < off; i++ {
		if tokens[i].kind != tkPunct {
			continue
		}
		switch tokens[i].text {
		case "(", "[", "{":
			depth++
		case ")", "]", "}":
			depth--
		case ",":
			if depth == 0 {
				active++
			}
		}
	}
	return active
}

// InlayHints implements Server. The mock reports parameter-name hints for calls
// to functions declared in the same document, which is the inlay hint GoLand
// shows by default.
func (m *MockServer) InlayHints(doc Document, rng Range) []InlayHint {
	a := m.analyse(doc)
	tokens := a.file.tokens
	var hints []InlayHint
	for i := 0; i < len(tokens); i++ {
		if tokens[i].kind != tkIdent {
			continue
		}
		d := a.byName[tokens[i].text]
		if d == nil || d.kind != SymbolKindFunction || len(d.params) == 0 {
			continue
		}
		if i+1 >= len(tokens) || tokens[i+1].text != "(" {
			continue
		}
		openIdx := i + 1
		closeIdx := a.matching(tokens, openIdx, "(", ")")
		if closeIdx < 0 {
			continue
		}
		argIdx := 0
		depth := 0
		argStartIdx := -1
		flush := func() {
			if argStartIdx < 0 || argIdx >= len(d.params) || d.params[argIdx] == "" {
				argIdx++
				argStartIdx = -1
				return
			}
			// An argument that already reads like the parameter adds nothing.
			if tokens[argStartIdx].kind == tkIdent && tokens[argStartIdx].text == d.params[argIdx] {
				argIdx++
				argStartIdx = -1
				return
			}
			pos := a.file.pos(tokens[argStartIdx].start)
			if inRange(pos, rng) {
				hints = append(hints, InlayHint{
					Position: pos, Label: d.params[argIdx] + ":", Kind: InlayParameter,
				})
			}
			argIdx++
			argStartIdx = -1
		}
		for j := openIdx + 1; j < closeIdx; j++ {
			switch {
			case tokens[j].kind == tkPunct && (tokens[j].text == "(" || tokens[j].text == "[" || tokens[j].text == "{"):
				depth++
			case tokens[j].kind == tkPunct && (tokens[j].text == ")" || tokens[j].text == "]" || tokens[j].text == "}"):
				depth--
			case tokens[j].kind == tkPunct && tokens[j].text == "," && depth == 0:
				flush()
			default:
				if argStartIdx < 0 && tokens[j].kind != tkComment {
					argStartIdx = j
				}
			}
		}
		if argStartIdx >= 0 {
			flush()
		}
	}
	return hints
}

func inRange(p Position, rng Range) bool {
	if p.Line < rng.Start.Line || p.Line > rng.End.Line {
		return false
	}
	if p.Line == rng.Start.Line && p.Character < rng.Start.Character {
		return false
	}
	if p.Line == rng.End.Line && p.Character > rng.End.Character {
		return false
	}
	return true
}

// intersectsRange reports whether a and b overlap. An empty b is the caret range
// of an intention request, so it counts as overlapping when it sits inside a.
func intersectsRange(a, b Range) bool {
	if b.Start == b.End {
		return inRange(b.Start, a)
	}
	// Half-open ranges overlap when each starts before the other ends.
	return positionLess(a.Start, b.End) && positionLess(b.Start, a.End)
}

func positionLess(a, b Position) bool {
	if a.Line != b.Line {
		return a.Line < b.Line
	}
	return a.Character < b.Character
}

// SemanticTokens implements Server.
func (m *MockServer) SemanticTokens(doc Document) *SemanticTokens {
	a := m.analyse(doc)
	out := &SemanticTokens{}
	for i := range a.file.tokens {
		tok := &a.file.tokens[i]
		var kind SemanticTokenType
		var modifiers []string
		switch tok.kind {
		case tkKeyword:
			kind = SemanticKeyword
		case tkString, tkRune:
			kind = SemanticString
		case tkNumber:
			kind = SemanticNumber
		case tkComment:
			kind = SemanticComment
		case tkIdent:
			if d := a.byName[tok.text]; d != nil && d.nameStart == tok.start {
				switch d.kind {
				case SymbolKindFunction:
					kind = SemanticFunction
				case SymbolKindType, SymbolKindStruct:
					kind = SemanticType
				case SymbolKindInterface:
					kind = SemanticInterface
				default:
					kind = SemanticVariable
				}
				modifiers = []string{"declaration"}
			} else if d := a.byName[tok.text]; d != nil {
				switch d.kind {
				case SymbolKindFunction:
					kind = SemanticFunction
				case SymbolKindType, SymbolKindStruct:
					kind = SemanticType
				case SymbolKindInterface:
					kind = SemanticInterface
				default:
					kind = SemanticVariable
				}
			}
		}
		if kind == "" {
			continue
		}
		out.Data = append(out.Data, SemanticToken{
			Range: a.file.rangeOf(tok.start, tok.end), Type: kind, Modifiers: modifiers,
		})
	}
	return out
}

// CodeActions implements Server: a quick fix for every diagnostic in rng plus
// the intentions available at rng.Start.
func (m *MockServer) CodeActions(doc Document, rng Range, diags []Diagnostic) []CodeAction {
	a := m.analyse(doc)
	var actions []CodeAction

	for _, diag := range diags {
		if !intersectsRange(diag.Range, rng) {
			continue
		}
		switch diag.Code {
		case "unused-variable":
			line := diag.Range.Start.Line
			start, end := a.lineStart(line), a.lineStart(line+1)
			if diagnosticsText(a, diag) == "" {
				continue
			}
			actions = append(actions, CodeAction{
				Title:       fmt.Sprintf("Remove unused variable %s", diagnosticsText(a, diag)),
				Kind:        QuickFixKind,
				IsPreferred: true,
				Diagnostics: []Diagnostic{diag},
				Edits:       []TextEdit{{Range: a.file.rangeOf(start, end), NewText: ""}},
			})
		case "unmatched-bracket":
			if !strings.HasPrefix(diag.Message, "Missing closing") {
				continue
			}
			closer := strings.Trim(diag.Message[strings.Index(diag.Message, "\""):], "\"")
			end := len(a.file.runes)
			actions = append(actions, CodeAction{
				Title:       fmt.Sprintf("Insert missing %q", closer),
				Kind:        QuickFixKind,
				IsPreferred: true,
				Diagnostics: []Diagnostic{diag},
				Edits:       []TextEdit{{Range: a.file.rangeOf(end, end), NewText: "\n" + closer}},
			})
		}
	}

	// The "convert to var" intention: the caret sits on a short declaration.
	off := a.file.offset(rng.Start)
	for _, d := range a.decls {
		if d.keyword != ":=" || d.line != rng.Start.Line {
			continue
		}
		if off < d.nameStart || off > d.assignEnd {
			continue
		}
		actions = append(actions, CodeAction{
			Title: fmt.Sprintf("Convert `%s := ...` to `var %s = ...`", d.name, d.name),
			Kind:  RefactorKind,
			Edits: []TextEdit{
				{Range: a.file.rangeOf(d.nameStart, d.nameStart), NewText: "var "},
				// Drop only the ":" so the "=" and its spacing stay put.
				{Range: a.file.rangeOf(d.colonStart, d.colonEnd), NewText: ""},
			},
		})
	}
	return actions
}

// diagnosticsText extracts the quoted identifier from a diagnostic message.
func diagnosticsText(a *analysis, diag Diagnostic) string {
	start := strings.Index(diag.Message, "`")
	end := strings.LastIndex(diag.Message, "`")
	if start < 0 || end <= start {
		return ""
	}
	return diag.Message[start : end+1]
}

// ------------------------------------------------- navigation and refactoring

// parseInterface fills in an interface declaration's method set and embedded
// interfaces. It backs "go to implementation" and the type hierarchy, both of
// which compare a type's method set against the interface's.
func (a *analysis) parseInterface(d *decl, interfaceKeyword int) {
	f := a.file
	body := a.findNext(f.tokens, interfaceKeyword, "{")
	if body < 0 {
		return
	}
	close := a.matching(f.tokens, body, "{", "}")
	if close < 0 {
		return
	}
	d.bodyStart = f.tokens[body].start
	d.bodyEnd = f.tokens[close].end
	sameLine := func(x, y int) bool {
		return f.pos(f.tokens[x].start).Line == f.pos(f.tokens[y].start).Line
	}
	for i := body + 1; i < close; i++ {
		tok := &f.tokens[i]
		if tok.kind != tkIdent {
			continue
		}
		// A method signature is Name(...). The result list that follows belongs to
		// the same element, so it is skipped rather than mistaken for an embed.
		if i+1 < close && f.tokens[i+1].kind == tkPunct && f.tokens[i+1].text == "(" {
			d.ifaceMethods = append(d.ifaceMethods, tok.text)
			if end := a.matching(f.tokens, i+1, "(", ")"); end > i+1 {
				i = end
			}
			for i+1 < close && sameLine(i+1, i) {
				i++
			}
			continue
		}
		// Only the beginning of an element can be an embedded interface.
		if prev := &f.tokens[i-1]; prev.text != "{" && sameLine(i-1, i) {
			continue
		}
		// A qualified embed such as io.Reader keeps its type name.
		if i+2 < close && f.tokens[i+1].text == "." && f.tokens[i+2].kind == tkIdent {
			d.ifaceEmbeds = append(d.ifaceEmbeds, f.tokens[i+2].text)
			i += 2
			continue
		}
		if i+1 < close && f.tokens[i+1].text == "." {
			continue
		}
		d.ifaceEmbeds = append(d.ifaceEmbeds, tok.text)
	}
}

// inInterfaceBody reports whether off lies inside an interface's braces, where a
// method signature is not a declaration of its own.
func (a *analysis) inInterfaceBody(off int) bool {
	for _, d := range a.decls {
		if d.kind != SymbolKindInterface || d.bodyEnd == 0 {
			continue
		}
		if off > d.bodyStart && off < d.bodyEnd {
			return true
		}
	}
	return false
}

// symbolAt returns the identifier token at pos, plus the declaration it names
// when there is one.
func (a *analysis) symbolAt(pos Position) (*token, *decl) {
	tok := a.file.tokenAt(a.file.offset(pos))
	if tok == nil || tok.kind != tkIdent {
		return nil, nil
	}
	return tok, a.byName[tok.text]
}

// nameRange is the range of a declaration's name.
func (a *analysis) nameRange(d *decl) Range {
	return a.file.rangeOf(d.nameStart, d.nameStart+len([]rune(d.name)))
}

// typeDecl finds the type/struct/interface declaration with the given name.
func (a *analysis) typeDecl(name string) *decl {
	for _, d := range a.decls {
		switch d.kind {
		case SymbolKindType, SymbolKindStruct, SymbolKindInterface:
			if d.name == name {
				return d
			}
		}
	}
	return nil
}

// methodsOf returns the method set of a receiver type, expanding the embedded
// interfaces of the types it satisfies so a type that only implements an
// embedded contract still counts.
func (a *analysis) methodsOf(typeName string) map[string]bool {
	set := map[string]bool{}
	for _, d := range a.decls {
		if d.kind == SymbolKindFunction && d.receiver == typeName {
			set[d.name] = true
		}
	}
	return set
}

// ifaceMethodSet returns an interface's method set, including the methods of the
// interfaces it embeds (one level deep, which is what the mock needs).
func (a *analysis) ifaceMethodSet(d *decl) []string {
	methods := append([]string(nil), d.ifaceMethods...)
	for _, embed := range d.ifaceEmbeds {
		if ed := a.typeDecl(embed); ed != nil && ed.kind == SymbolKindInterface {
			methods = append(methods, ed.ifaceMethods...)
		}
	}
	return methods
}

// implements reports whether a receiver type satisfies an interface.
func (a *analysis) implements(typeName string, iface *decl) bool {
	methods := a.ifaceMethodSet(iface)
	if len(methods) == 0 {
		return false
	}
	set := a.methodsOf(typeName)
	for _, m := range methods {
		if !set[m] {
			return false
		}
	}
	return true
}

// receiverTypes returns every type that declares at least one method, in
// declaration order.
func (a *analysis) receiverTypes() []string {
	var out []string
	seen := map[string]bool{}
	for _, d := range a.decls {
		if d.kind != SymbolKindFunction || d.receiver == "" || seen[d.receiver] {
			continue
		}
		seen[d.receiver] = true
		out = append(out, d.receiver)
	}
	return out
}

// interfaceDeclaring reports the name of the interface whose method set contains
// the method name, so navigation works from a method signature inside an
// interface body (which is not a declaration of its own).
func (a *analysis) interfaceDeclaring(method string) string {
	for _, d := range a.decls {
		if d.kind != SymbolKindInterface {
			continue
		}
		for _, m := range a.ifaceMethodSet(d) {
			if m == method {
				return d.name
			}
		}
	}
	return ""
}

// Implementations implements Server.
func (m *MockServer) Implementations(doc Document, pos Position) []Location {
	a := m.analyse(doc)
	tok, decl := a.symbolAt(pos)
	if tok == nil {
		return nil
	}
	// A method signature inside an interface body is not a declaration of its own,
	// so byName cannot resolve it: every same-named method implements it.
	if a.inInterfaceBody(a.file.offset(pos)) {
		return a.methodLocations(doc, tok.text, nil)
	}
	if decl == nil {
		return nil
	}
	switch decl.kind {
	case SymbolKindInterface:
		var out []Location
		for _, typeName := range a.receiverTypes() {
			if !a.implements(typeName, decl) {
				continue
			}
			if td := a.typeDecl(typeName); td != nil {
				out = append(out, Location{URI: doc.URI, Range: a.nameRange(td)})
			}
		}
		return out
	case SymbolKindFunction:
		if decl.receiver == "" {
			return nil
		}
		// A method: the other implementations of the same interface method.
		return a.methodLocations(doc, decl.name, decl)
	}
	return nil
}

// methodLocations returns the locations of every method named name, optionally
// skipping one declaration (the method the navigation started from).
func (a *analysis) methodLocations(doc Document, name string, skip *decl) []Location {
	var out []Location
	for _, d := range a.decls {
		if d == skip || d.kind != SymbolKindFunction || d.name != name || d.receiver == "" {
			continue
		}
		out = append(out, Location{URI: doc.URI, Range: a.nameRange(d)})
	}
	return out
}

// References implements Server.
func (m *MockServer) References(doc Document, pos Position, includeDeclaration bool) []Location {
	a := m.analyse(doc)
	tok, decl := a.symbolAt(pos)
	if tok == nil {
		return nil
	}
	var out []Location
	for i := range a.file.tokens {
		t := &a.file.tokens[i]
		if t.kind != tkIdent || t.text != tok.text {
			continue
		}
		if !includeDeclaration && decl != nil && t.start == decl.nameStart {
			continue
		}
		out = append(out, Location{URI: doc.URI, Range: a.file.rangeOf(t.start, t.end)})
	}
	return out
}

// TypeHierarchy implements Server.
func (m *MockServer) TypeHierarchy(doc Document, pos Position) *HierarchyNode {
	a := m.analyse(doc)
	tok, decl := a.symbolAt(pos)
	if tok == nil {
		return nil
	}
	if decl == nil && !a.inInterfaceBody(a.file.offset(pos)) {
		return nil
	}
	// A method signature inside an interface body: the interface is the supertype
	// and the same-named methods are the subtypes.
	if a.inInterfaceBody(a.file.offset(pos)) {
		if iface := a.interfaceDeclaring(tok.text); iface != "" {
			if id := a.typeDecl(iface); id != nil {
				root := a.typeNode(doc, id)
				root.Subs = a.methodNodes(doc, tok.text, nil)
				return &root
			}
		}
		return nil
	}
	switch decl.kind {
	case SymbolKindInterface:
		root := a.typeNode(doc, decl)
		for _, embed := range decl.ifaceEmbeds {
			if ed := a.typeDecl(embed); ed != nil && ed.kind == SymbolKindInterface {
				root.Supers = append(root.Supers, a.typeNode(doc, ed))
			}
		}
		for _, typeName := range a.receiverTypes() {
			if a.implements(typeName, decl) {
				if td := a.typeDecl(typeName); td != nil {
					root.Subs = append(root.Subs, a.typeNode(doc, td))
				}
			}
		}
		return &root
	case SymbolKindFunction:
		if decl.receiver == "" {
			return nil
		}
		root := a.methodNode(doc, decl)
		for _, d := range a.decls {
			if d.kind == SymbolKindInterface {
				for _, m := range a.ifaceMethodSet(d) {
					if m == decl.name {
						root.Supers = append(root.Supers, a.typeNode(doc, d))
					}
				}
			}
		}
		root.Subs = a.methodNodes(doc, decl.name, decl)
		return &root
	default:
		// A struct: the interfaces it implements are its supertypes.
		root := a.typeNode(doc, decl)
		for _, d := range a.decls {
			if d.kind == SymbolKindInterface && a.implements(decl.name, d) {
				root.Supers = append(root.Supers, a.typeNode(doc, d))
			}
		}
		return &root
	}
}

func (a *analysis) typeNode(doc Document, d *decl) HierarchyNode {
	return HierarchyNode{
		Name: d.name, Detail: d.signature, Kind: d.kind,
		Location: Location{URI: doc.URI, Range: a.nameRange(d)},
	}
}

func (a *analysis) methodNode(doc Document, d *decl) HierarchyNode {
	detail := d.signature
	if detail == "" {
		detail = fmt.Sprintf("func (%s) %s", d.receiver, d.name)
	}
	return HierarchyNode{
		Name: d.name, Detail: detail, Kind: SymbolKindMethod,
		Location: Location{URI: doc.URI, Range: a.nameRange(d)},
	}
}

func (a *analysis) methodNodes(doc Document, name string, skip *decl) []HierarchyNode {
	var out []HierarchyNode
	for _, d := range a.decls {
		if d == skip || d.kind != SymbolKindFunction || d.name != name {
			continue
		}
		out = append(out, a.methodNode(doc, d))
	}
	return out
}

// CodeLenses implements Server: a usage count on every function and an
// implementation count on every interface, the two lenses IntelliJ's Go plugin
// shows by default.
func (m *MockServer) CodeLenses(doc Document) []CodeLens {
	a := m.analyse(doc)
	var out []CodeLens
	for _, d := range a.decls {
		if d.local || d.name == "" {
			continue
		}
		switch d.kind {
		case SymbolKindFunction:
			if n := a.usageCount(d.name); n > 0 {
				out = append(out, CodeLens{Range: a.nameRange(d), Title: pluralCount(n, "usage"), Command: "find-usages"})
			}
		case SymbolKindInterface:
			n := 0
			for _, typeName := range a.receiverTypes() {
				if a.implements(typeName, d) {
					n++
				}
			}
			if n > 0 {
				out = append(out, CodeLens{Range: a.nameRange(d), Title: pluralCount(n, "implementation"), Command: "goto-implementation"})
			}
		}
	}
	return out
}

// usageCount counts the identifier occurrences of name minus its declaration.
func (a *analysis) usageCount(name string) int {
	n := 0
	for i := range a.file.tokens {
		if a.file.tokens[i].kind == tkIdent && a.file.tokens[i].text == name {
			n++
		}
	}
	if n > 0 {
		n--
	}
	return n
}

func pluralCount(n int, noun string) string {
	if n == 1 {
		return fmt.Sprintf("1 %s", noun)
	}
	return fmt.Sprintf("%d %ss", n, noun)
}

// Rename implements Server: every reference of the symbol at pos is rewritten.
func (m *MockServer) Rename(doc Document, pos Position, newName string) []TextEdit {
	locs := m.References(doc, pos, true)
	if len(locs) == 0 || newName == "" {
		return nil
	}
	edits := make([]TextEdit, 0, len(locs))
	for _, l := range locs {
		edits = append(edits, TextEdit{Range: l.Range, NewText: newName})
	}
	return edits
}

// Formatting implements Server. The mock reformats conservatively: leading tabs
// become tab-stop-sized spaces and trailing whitespace is dropped, which is a
// deterministic subset of what IntelliJ's Reformat Code does.
func (m *MockServer) Formatting(doc Document) []TextEdit {
	a := m.analyse(doc)
	var edits []TextEdit
	for line := 0; line < len(a.file.starts); line++ {
		text := a.file.lineText(line)
		if text == "" {
			continue
		}
		fixed := formatLine(text, 4)
		if fixed == text {
			continue
		}
		start := a.file.starts[line]
		edits = append(edits, TextEdit{
			Range:   a.file.rangeOf(start, start+len([]rune(text))),
			NewText: fixed,
		})
	}
	return edits
}

// formatLine expands leading tabs and trims trailing blanks.
func formatLine(line string, tabWidth int) string {
	lead := 0
	for lead < len(line) && (line[lead] == '\t' || line[lead] == ' ') {
		lead++
	}
	indent := strings.ReplaceAll(line[:lead], "\t", strings.Repeat(" ", tabWidth))
	return indent + strings.TrimRight(line[lead:], " \t")
}
