package lsp

import (
	"strings"
	"testing"
)

const sample = `package main

import "fmt"

// greet says hello.
func greet(name string, times int) string {
	msg := "hello " + name
	return msg
}

func main() {
	unused := 1
	fmt.Println(greet("world", 3))
	// TODO: handle errors
}
`

func analyse(t *testing.T, text string) (*MockServer, Document) {
	t.Helper()
	return NewMockServer(), Document{URI: "file:///main.go", LanguageID: "go", Text: text}
}

// navDoc 是导航用例的固定输入：一个接口 + 两个实现类型 + 一处接口方法调用。
const navDoc = `package store

// Reader reads records.
type Reader interface {
	Read(id int) (string, error)
	Close() error
}

type memory struct{}

func (m *memory) Read(id int) (string, error) { return "", nil }
func (m *memory) Close() error                { return nil }

type disker struct{}

func (d *disker) Read(id int) (string, error) { return "", nil }
func (d *disker) Close() error                { return nil }

// Open exercises the interface.
func Open(r Reader) {
	_, _ = r.Read(1)
}

// Boot calls Open so the usage lens has something to count.
func Boot(r Reader) {
	Open(r)
}
`

// posOf returns the position of the first occurrence of needle in text.
func posOf(t *testing.T, text, needle string) Position {
	t.Helper()
	idx := strings.Index(text, needle)
	if idx < 0 {
		t.Fatalf("fixture does not contain %q", needle)
	}
	before := text[:idx]
	line := strings.Count(before, "\n")
	col := idx - (strings.LastIndex(before, "\n") + 1)
	return Position{Line: line, Character: col}
}

// linesOf collects the start lines of a location list.
func linesOf(locations []Location) []int {
	out := make([]int, 0, len(locations))
	for _, l := range locations {
		out = append(out, l.Range.Start.Line)
	}
	return out
}

func containsLine(lines []int, want int) bool {
	for _, l := range lines {
		if l == want {
			return true
		}
	}
	return false
}

func TestImplementationsFindTheTypesSatisfyingAnInterface(t *testing.T) {
	srv, doc := analyse(t, navDoc)
	got := srv.Implementations(doc, posOf(t, navDoc, "Reader interface"))
	if len(got) != 2 {
		t.Fatalf("implementations = %v, want the two implementing types", linesOf(got))
	}
	memoryLine := posOf(t, navDoc, "type memory struct").Line
	diskerLine := posOf(t, navDoc, "type disker struct").Line
	if lines := linesOf(got); !containsLine(lines, memoryLine) || !containsLine(lines, diskerLine) {
		t.Fatalf("implementations land on lines %v, want %d and %d", lines, memoryLine, diskerLine)
	}
}

func TestImplementationsFromAnInterfaceMethodFindTheMethods(t *testing.T) {
	srv, doc := analyse(t, navDoc)
	got := srv.Implementations(doc, posOf(t, navDoc, "Read(id int) (string, error)"))
	if len(got) != 2 {
		t.Fatalf("implementations = %v, want the two Read methods", linesOf(got))
	}
	memoryRead := posOf(t, navDoc, ") Read(id int) (string, error)").Line
	if !containsLine(linesOf(got), memoryRead) {
		t.Fatalf("implementations = %v, want the memory Read at line %d", linesOf(got), memoryRead)
	}
}

func TestImplementationsOfAPlainFunctionAreEmpty(t *testing.T) {
	srv, doc := analyse(t, navDoc)
	if got := srv.Implementations(doc, posOf(t, navDoc, "func Open(")); len(got) != 0 {
		t.Fatalf("a plain function has no implementations, got %v", linesOf(got))
	}
}

func TestReferencesExcludeTheDeclarationOnDemand(t *testing.T) {
	srv, doc := analyse(t, navDoc)
	refPos := posOf(t, navDoc, "Read(1)")
	withDecl := srv.References(doc, refPos, true)
	without := srv.References(doc, refPos, false)
	if len(without) != len(withDecl)-1 {
		t.Fatalf("References(includeDeclaration=false) = %d, want one fewer than %d",
			len(without), len(withDecl))
	}
	// Read appears in the interface, on both methods and at the call site.
	if len(withDecl) != 4 {
		t.Fatalf("References(includeDeclaration=true) = %d, want 4 (%v)", len(withDecl), linesOf(withDecl))
	}
}

func TestTypeHierarchyWalksBothDirections(t *testing.T) {
	srv, doc := analyse(t, navDoc)
	iface := srv.TypeHierarchy(doc, posOf(t, navDoc, "Reader interface"))
	if iface == nil || iface.Name != "Reader" {
		t.Fatalf("hierarchy root = %+v, want Reader", iface)
	}
	if len(iface.Subs) != 2 {
		t.Fatalf("Reader subtypes = %d, want memory and disker", len(iface.Subs))
	}

	impl := srv.TypeHierarchy(doc, posOf(t, navDoc, "memory struct"))
	if impl == nil || impl.Name != "memory" {
		t.Fatalf("hierarchy root = %+v, want memory", impl)
	}
	if len(impl.Supers) != 1 || impl.Supers[0].Name != "Reader" {
		t.Fatalf("memory supertypes = %+v, want Reader", impl.Supers)
	}
}

func TestTypeHierarchyOfAMethodShowsTheInterface(t *testing.T) {
	srv, doc := analyse(t, navDoc)
	node := srv.TypeHierarchy(doc, posOf(t, navDoc, "Read(id int) (string, error) { return"))
	if node == nil || node.Name != "Read" {
		t.Fatalf("hierarchy root = %+v, want the Read method", node)
	}
	if len(node.Supers) != 1 || node.Supers[0].Name != "Reader" {
		t.Fatalf("Read supertypes = %+v, want Reader", node.Supers)
	}
	if len(node.Subs) != 1 {
		t.Fatalf("Read subtypes = %d, want the disker implementation", len(node.Subs))
	}
}

func TestRenameRewritesEveryReference(t *testing.T) {
	srv, doc := analyse(t, navDoc)
	edits := srv.Rename(doc, posOf(t, navDoc, "memory struct"), "mem")
	if len(edits) == 0 {
		t.Fatal("Rename produced no edits")
	}
	for _, e := range edits {
		if e.NewText != "mem" {
			t.Fatalf("edit %+v does not use the new name", e)
		}
	}
	// memory 出现 3 次：类型声明 + 两个方法接收者。
	if len(edits) != 3 {
		t.Fatalf("edits = %d, want 3", len(edits))
	}
}

func TestRenameWithAnEmptyNameIsANoOp(t *testing.T) {
	srv, doc := analyse(t, navDoc)
	if edits := srv.Rename(doc, posOf(t, navDoc, "memory struct"), ""); edits != nil {
		t.Fatalf("Rename with an empty name returned %d edits", len(edits))
	}
}

func TestCodeLensesCountImplementationsAndUsages(t *testing.T) {
	srv, doc := analyse(t, navDoc)
	lenses := srv.CodeLenses(doc)
	var ifaceLens, funcLens *CodeLens
	for i := range lenses {
		switch lenses[i].Range.Start.Line {
		case posOf(t, navDoc, "Reader interface").Line:
			ifaceLens = &lenses[i]
		case posOf(t, navDoc, "func Open(").Line:
			funcLens = &lenses[i]
		}
	}
	if ifaceLens == nil || ifaceLens.Title != "2 implementations" {
		t.Fatalf("interface lens = %+v, want \"2 implementations\"", ifaceLens)
	}
	if funcLens == nil || funcLens.Title != "1 usage" {
		t.Fatalf("function lens = %+v, want \"1 usage\"", funcLens)
	}
}

func TestFormattingExpandsTabsAndTrimsTrailingSpace(t *testing.T) {
	srv, doc := analyse(t, "package main\n\nfunc main() {\n\tx := 1   \n\t_ = x\n}\n")
	edits := srv.Formatting(doc)
	if len(edits) != 2 {
		t.Fatalf("edits = %d, want the two indented lines", len(edits))
	}
	for _, e := range edits {
		if e.NewText != "    "+strings.TrimSpace(e.NewText) {
			t.Fatalf("edit %q was not expanded to spaces", e.NewText)
		}
		if strings.HasSuffix(e.NewText, " ") {
			t.Fatalf("edit %q kept trailing whitespace", e.NewText)
		}
	}
}

func TestDocumentSymbolsOutlineTheDeclarations(t *testing.T) {
	srv, doc := analyse(t, sample)
	symbols := srv.DocumentSymbols(doc)
	names := map[string]SymbolKind{}
	for _, s := range symbols {
		names[s.Name] = s.Kind
	}
	if names["greet"] != SymbolKindFunction {
		t.Fatalf("greet missing from the outline: %+v", symbols)
	}
	if names["main"] != SymbolKindFunction {
		t.Fatalf("main missing from the outline: %+v", symbols)
	}
	if len(symbols) != 2 {
		t.Fatalf("outline = %d symbols, want the two functions (%+v)", len(symbols), symbols)
	}
}

func TestDiagnosticsFindUnusedVariableAndTodo(t *testing.T) {
	srv, doc := analyse(t, sample)
	diags := srv.Diagnostics(doc)

	var unused, todo *Diagnostic
	for i := range diags {
		switch diags[i].Code {
		case "unused-variable":
			unused = &diags[i]
		case "todo":
			todo = &diags[i]
		}
	}
	if unused == nil {
		t.Fatalf("no unused-variable diagnostic: %+v", diags)
	}
	if unused.Range.Start.Line != 11 {
		t.Fatalf("unused diagnostic on line %d, want 11", unused.Range.Start.Line)
	}
	if !strings.Contains(unused.Message, "unused") {
		t.Fatalf("unused message = %q", unused.Message)
	}
	if todo == nil {
		t.Fatalf("no TODO diagnostic: %+v", diags)
	}
	if todo.Severity != SeverityInformation {
		t.Fatalf("TODO severity = %v, want information", todo.Severity)
	}
	// "msg" is read again, so it must not be flagged.
	for _, d := range diags {
		if strings.Contains(d.Message, "`msg`") {
			t.Fatalf("msg wrongly flagged as unused: %+v", d)
		}
	}
}

func TestDiagnosticsReportUnmatchedBracket(t *testing.T) {
	srv, doc := analyse(t, "package main\n\nfunc f() {\n")
	diags := srv.Diagnostics(doc)
	found := false
	for _, d := range diags {
		if d.Code == "unmatched-bracket" && strings.Contains(d.Message, `Missing closing "}"`) {
			found = true
		}
	}
	if !found {
		t.Fatalf("no missing-brace diagnostic: %+v", diags)
	}
}

func TestHoverShowsSignatureAndDoc(t *testing.T) {
	srv, doc := analyse(t, sample)
	hover := srv.Hover(doc, Position{Line: 5, Character: 6})
	if hover == nil {
		t.Fatal("no hover for the greet declaration")
	}
	if !strings.Contains(hover.Contents, "func greet(name string, times int) string") {
		t.Fatalf("hover contents = %q", hover.Contents)
	}
	if !strings.Contains(hover.Contents, "greet says hello.") {
		t.Fatalf("hover lost the doc comment: %q", hover.Contents)
	}
	if srv.Hover(doc, Position{Line: 1, Character: 0}) != nil {
		t.Fatal("hover appeared on a blank line")
	}
}

func TestSignatureHelpTracksTheActiveParameter(t *testing.T) {
	srv, doc := analyse(t, sample)
	// Inside greet("world", |3).
	help := srv.SignatureHelp(doc, Position{Line: 12, Character: 28})
	if help == nil {
		t.Fatal("no signature help inside the call")
	}
	if len(help.Signatures) != 1 || len(help.Signatures[0].Parameters) != 2 {
		t.Fatalf("signature = %+v", help.Signatures)
	}
	if help.ActiveParameter != 1 {
		t.Fatalf("active parameter = %d, want 1", help.ActiveParameter)
	}
	// Inside greet(|"world", 3).
	first := srv.SignatureHelp(doc, Position{Line: 12, Character: 20})
	if first == nil || first.ActiveParameter != 0 {
		t.Fatalf("first parameter help = %+v", first)
	}
	if help.Signatures[0].Parameters[0].Label != "name" {
		t.Fatalf("parameter labels = %+v", help.Signatures[0].Parameters)
	}
}

func TestInlayHintsNameTheCallArguments(t *testing.T) {
	srv, doc := analyse(t, sample)
	hints := srv.InlayHints(doc, Range{
		Start: Position{Line: 0, Character: 0},
		End:   Position{Line: 20, Character: 0},
	})
	labels := map[string]Position{}
	for _, h := range hints {
		labels[h.Label] = h.Position
	}
	if _, ok := labels["name:"]; !ok {
		t.Fatalf("no parameter hint for name: %+v", hints)
	}
	if _, ok := labels["times:"]; !ok {
		t.Fatalf("no parameter hint for times: %+v", hints)
	}
	if p := labels["name:"]; p.Line != 12 || p.Character != 19 {
		t.Fatalf("name: hint at %+v, want the first argument on line 12", p)
	}
	// A call outside the requested range is not reported.
	outside := srv.InlayHints(doc, Range{Start: Position{Line: 0}, End: Position{Line: 2, Character: 0}})
	for _, h := range outside {
		t.Fatalf("hint %+v leaked outside the requested range", h)
	}
}

func TestCompletionsMixSymbolsAndKeywords(t *testing.T) {
	srv, doc := analyse(t, sample)
	items := srv.Completions(doc, Position{Line: 12, Character: 13})
	byLabel := map[string]CompletionItem{}
	for _, it := range items {
		byLabel[it.Label] = it
	}
	if it, ok := byLabel["greet"]; !ok || it.Kind != CompletionFunction {
		t.Fatalf("greet completion = %+v", it)
	}
	if it, ok := byLabel["func"]; !ok || it.Kind != CompletionKeyword {
		t.Fatalf("keyword completion = %+v", it)
	}
	if it, ok := byLabel["msg"]; !ok || it.Kind != CompletionVariable {
		t.Fatalf("local variable completion = %+v", it)
	}
}

func TestSemanticTokensClassifyDeclarations(t *testing.T) {
	srv, doc := analyse(t, sample)
	tokens := srv.SemanticTokens(doc)
	var declFunc, keyword bool
	for _, tok := range tokens.Data {
		if tok.Type == SemanticFunction && tok.Range.Start.Line == 5 && len(tok.Modifiers) == 1 {
			declFunc = true
		}
		if tok.Type == SemanticKeyword && tok.Range.Start.Line == 5 {
			keyword = true
		}
	}
	if !declFunc {
		t.Fatalf("no function declaration token: %+v", tokens.Data)
	}
	if !keyword {
		t.Fatalf("no keyword token for func: %+v", tokens.Data)
	}
}

func TestCodeActionsOfferTheUnusedRemoval(t *testing.T) {
	srv, doc := analyse(t, sample)
	all := srv.Diagnostics(doc)
	var unused []Diagnostic
	for _, d := range all {
		if d.Code == "unused-variable" {
			unused = append(unused, d)
		}
	}
	if len(unused) == 0 {
		t.Fatal("no unused diagnostic to fix")
	}
	actions := srv.CodeActions(doc, unused[0].Range, unused)
	if len(actions) == 0 {
		t.Fatal("no quick fix offered")
	}
	action := actions[0]
	if action.Kind != QuickFixKind || !action.IsPreferred {
		t.Fatalf("action = %+v", action)
	}
	if !strings.Contains(action.Title, "unused") {
		t.Fatalf("action title = %q", action.Title)
	}
	if len(action.Edits) != 1 {
		t.Fatalf("edits = %+v", action.Edits)
	}
	edit := action.Edits[0]
	if edit.Range.Start.Line != 11 || edit.NewText != "" {
		t.Fatalf("unused edit = %+v", edit)
	}
}

func TestCodeActionsOfferConvertToVar(t *testing.T) {
	srv, doc := analyse(t, sample)
	pos := Position{Line: 11, Character: 3} // on "unused"
	actions := srv.CodeActions(doc, Range{Start: pos, End: pos}, nil)
	var found *CodeAction
	for i := range actions {
		if actions[i].Kind == RefactorKind {
			found = &actions[i]
		}
	}
	if found == nil {
		t.Fatalf("no convert-to-var intention: %+v", actions)
	}
	if len(found.Edits) != 2 {
		t.Fatalf("intention edits = %+v", found.Edits)
	}
	if found.Edits[0].NewText != "var " || found.Edits[1].NewText != "" {
		t.Fatalf("intention edits = %+v", found.Edits)
	}
	// The second edit removes only the ":", so "\tunused := 1" keeps its "=".
	if found.Edits[1].Range.Start.Character != 8 || found.Edits[1].Range.End.Character != 9 {
		t.Fatalf("the colon edit = %+v", found.Edits[1].Range)
	}
}
