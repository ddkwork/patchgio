// Package lsp defines the language-service boundary the editor talks to, plus a
// self-contained mock implementation.
//
// The types and method shapes mirror the Language Server Protocol closely enough
// that a real LSP client can be dropped in later: replace MockServer with a
// client that forwards to a language server process and nothing above this
// package has to change. All positions and ranges are 0-based line/character
// pairs, and all ranges are half-open, exactly like LSP.
package lsp

// Position is a 0-based line/character coordinate.
type Position struct {
	Line      int
	Character int
}

// Range is a half-open span between two positions.
type Range struct {
	Start Position
	End   Position
}

// Severity is the LSP DiagnosticSeverity.
type Severity int

const (
	SeverityError Severity = iota + 1
	SeverityWarning
	SeverityInformation
	SeverityHint
)

// Diagnostic is one problem reported for a document.
type Diagnostic struct {
	Range    Range
	Severity Severity
	Code     string
	Source   string
	Message  string
}

// CompletionItemKind is the LSP CompletionItemKind subset the editor renders.
type CompletionItemKind int

const (
	CompletionText CompletionItemKind = iota + 1
	CompletionMethod
	CompletionFunction
	CompletionConstructor
	CompletionField
	CompletionVariable
	CompletionClass
	CompletionInterface
	CompletionModule
	CompletionProperty
	CompletionKeyword
	CompletionSnippet
	CompletionStruct
	CompletionTypeParameter
)

// InsertTextFormat selects how InsertText is interpreted.
type InsertTextFormat int

const (
	// PlainText inserts InsertText verbatim.
	PlainText InsertTextFormat = iota + 1
	// SnippetFormat interprets InsertText as an LSP snippet.
	SnippetFormat
)

// TextEdit replaces Range with NewText.
type TextEdit struct {
	Range   Range
	NewText string
}

// CompletionItem is one completion candidate.
type CompletionItem struct {
	Label            string
	Kind             CompletionItemKind
	Detail           string
	Documentation    string
	SortText         string
	FilterText       string
	InsertText       string
	InsertTextFormat InsertTextFormat
	// TextEdit, when set, wins over InsertText/InsertTextFormat.
	TextEdit *TextEdit
}

// Hover is the documentation shown for the symbol under the caret.
type Hover struct {
	Contents string
	Range    *Range
}

// ParameterInformation describes one parameter of a signature.
type ParameterInformation struct {
	Label         string
	Documentation string
}

// SignatureInformation is one overload of a callable.
type SignatureInformation struct {
	Label         string
	Documentation string
	Parameters    []ParameterInformation
}

// SignatureHelp is the parameter info popup state.
type SignatureHelp struct {
	Signatures      []SignatureInformation
	ActiveSignature int
	ActiveParameter int
}

// InlayHintKind is the LSP InlayHintKind.
type InlayHintKind int

const (
	InlayType InlayHintKind = iota + 1
	InlayParameter
)

// InlayHint is a virtual annotation rendered next to the text without being
// part of the document.
type InlayHint struct {
	Position Position
	Label    string
	Kind     InlayHintKind
}

// SemanticTokenType is the LSP SemanticTokenTypes subset used here.
type SemanticTokenType string

const (
	SemanticNamespace SemanticTokenType = "namespace"
	SemanticType      SemanticTokenType = "type"
	SemanticStruct    SemanticTokenType = "struct"
	SemanticInterface SemanticTokenType = "interface"
	SemanticFunction  SemanticTokenType = "function"
	SemanticMethod    SemanticTokenType = "method"
	SemanticParameter SemanticTokenType = "parameter"
	SemanticVariable  SemanticTokenType = "variable"
	SemanticProperty  SemanticTokenType = "property"
	SemanticKeyword   SemanticTokenType = "keyword"
	SemanticComment   SemanticTokenType = "comment"
	SemanticString    SemanticTokenType = "string"
	SemanticNumber    SemanticTokenType = "number"
	SemanticOperator  SemanticTokenType = "operator"
)

// SemanticToken marks a range of the document with a semantic type.
type SemanticToken struct {
	Range Range
	Type  SemanticTokenType
	// Modifiers currently carries "declaration" and "definition".
	Modifiers []string
}

// SemanticTokens is the full token list of a document.
type SemanticTokens struct {
	Data []SemanticToken
}

// CodeActionKind is the LSP CodeActionKind subset used here.
type CodeActionKind string

const (
	// QuickFixKind marks diagnostic-driven fixes.
	QuickFixKind CodeActionKind = "quickfix"
	// RefactorKind marks context-driven intentions (IntelliJ's "intention").
	RefactorKind CodeActionKind = "refactor"
)

// CodeAction is a quick fix or an intention the user can invoke.
type CodeAction struct {
	Title       string
	Kind        CodeActionKind
	IsPreferred bool
	Diagnostics []Diagnostic
	Edits       []TextEdit
}

// SymbolKind is the LSP SymbolKind subset used here.
type SymbolKind int

const (
	SymbolKindFile SymbolKind = iota + 1
	SymbolKindModule
	SymbolKindNamespace
	SymbolKindPackage
	SymbolKindClass
	SymbolKindType
	SymbolKindMethod
	SymbolKindProperty
	SymbolKindField
	SymbolKindConstructor
	SymbolKindEnum
	SymbolKindInterface
	SymbolKindFunction
	SymbolKindVariable
	SymbolKindConstant
	SymbolKindStruct
	SymbolKindTypeParameter
)

// DocumentSymbol is one entry of the document's outline. Children nest, which
// is what a breadcrumb trail and a structure view walk.
type DocumentSymbol struct {
	Name           string
	Detail         string
	Kind           SymbolKind
	Range          Range
	SelectionRange Range
	Children       []DocumentSymbol
}

// Document is the snapshot an analysis runs against. Version mirrors LSP's
// document version so a real server can reject stale requests.
type Document struct {
	URI        string
	LanguageID string
	Version    int
	Text       string
}

// Location is a range inside a document. It is what every navigation result
// (usages, implementations) is made of, exactly like LSP's Location.
type Location struct {
	URI   string
	Range Range
}

// HierarchyNode is one entry of a type hierarchy: LSP's TypeHierarchyItem plus
// the two directions IntelliJ's hierarchy popup walks. Supers are the types (or
// methods) this one overrides/implements, Subs the ones that override/implement
// it.
type HierarchyNode struct {
	Name     string
	Detail   string
	Kind     SymbolKind
	Location Location
	Supers   []HierarchyNode
	Subs     []HierarchyNode
}

// CodeLens is the small actionable annotation IntelliJ shows next to a
// declaration ("1 implementation", "3 usages"). The editor paints Title and the
// application runs Command.
type CodeLens struct {
	Range   Range
	Title   string
	Command string
}

// Server is the language-service boundary. A real LSP client implements the same
// methods by forwarding to the language server; the editor only ever sees this
// interface.
type Server interface {
	// Diagnostics reports the problems of the whole document.
	Diagnostics(doc Document) []Diagnostic
	// Completions reports the candidates at pos.
	Completions(doc Document, pos Position) []CompletionItem
	// Hover reports the documentation of the symbol at pos, or nil.
	Hover(doc Document, pos Position) *Hover
	// SignatureHelp reports the parameter info for a call the caret sits in, or nil.
	SignatureHelp(doc Document, pos Position) *SignatureHelp
	// InlayHints reports the hints inside rng.
	InlayHints(doc Document, rng Range) []InlayHint
	// SemanticTokens reports the semantic classification of the document.
	SemanticTokens(doc Document) *SemanticTokens
	// CodeActions reports the fixes for diags and the intentions available in rng.
	CodeActions(doc Document, rng Range, diags []Diagnostic) []CodeAction
	// DocumentSymbols reports the document outline.
	DocumentSymbols(doc Document) []DocumentSymbol
	// Implementations reports the declarations implementing the interface (or
	// overriding the method) at pos. It backs Go to Implementation(s).
	Implementations(doc Document, pos Position) []Location
	// References reports every usage of the symbol at pos. includeDeclaration
	// keeps the declaration itself in the result, the way Find Usages does.
	References(doc Document, pos Position, includeDeclaration bool) []Location
	// TypeHierarchy reports the super- and subtypes of the type (or method) at
	// pos, or nil when there is no hierarchy to show.
	TypeHierarchy(doc Document, pos Position) *HierarchyNode
	// CodeLenses reports the annotations painted next to declarations.
	CodeLenses(doc Document) []CodeLens
	// Rename reports the edits that rename the symbol at pos to newName.
	Rename(doc Document, pos Position, newName string) []TextEdit
	// Formatting reports the edits that reformat the whole document.
	Formatting(doc Document) []TextEdit
}
