package gvcode

import (
	"fmt"
	"sort"
	"strings"
	"unicode"

	"gioui.org/layout"
	"gioui.org/text"
	stdColor "image/color"

	gvcolor "github.com/oligo/gvcode/color"
	"github.com/oligo/gvcode/lsp"
	"github.com/oligo/gvcode/textstyle/decoration"
)

// usageSource is the decoration source the automatic usage highlight uses.
const usageSource = "_usages"

// WithUsageHighlighting turns on IntelliJ's automatic "highlight usages of the
// symbol under the caret": every other occurrence of the identifier the caret
// sits on gets a subtle background, without any explicit Find Usages.
func WithUsageHighlighting() EditorOption {
	return func(e *Editor) { e.usageHighlighting = true }
}

// WithCodeLens paints IntelliJ's code lenses — the dimmed "N usages" /
// "N implementations" annotations next to declarations — using the language
// server's CodeLenses.
func WithCodeLens() EditorOption {
	return func(e *Editor) { e.codeLens = true }
}

// WithColumnSelectionMode turns IntelliJ's Column Selection Mode on. While on, a
// plain mouse drag selects a rectangular block instead of a text range, which is
// what Edit > Column Selection Mode (Alt+Shift+Insert) toggles.
func WithColumnSelectionMode(enabled bool) EditorOption {
	return func(e *Editor) { e.columnSelectionMode = enabled }
}

// ColumnSelectionMode reports whether Column Selection Mode is on.
func (e *Editor) ColumnSelectionMode() bool { return e.columnSelectionMode }

// SetColumnSelectionMode toggles Column Selection Mode at runtime.
func (e *Editor) SetColumnSelectionMode(enabled bool) {
	e.columnSelectionMode = enabled
	if !enabled {
		e.SetColumnEditMode(false)
	}
}

// NavigationKind is the IntelliJ navigation a result came from.
type NavigationKind uint8

const (
	// NavigationUsages is Find Usages (Alt+F7).
	NavigationUsages NavigationKind = iota
	// NavigationImplementations is Go to Implementation(s) (Ctrl+Alt+B).
	NavigationImplementations
	// NavigationHierarchy is the type or method hierarchy (Ctrl+H / Ctrl+Alt+H).
	NavigationHierarchy
)

// NavigationItem is one row of a navigation result.
type NavigationItem struct {
	// Name is the symbol the row lands on.
	Name string
	// Detail is the source line of the occurrence, trimmed.
	Detail string
	// Path is the document URI.
	Path string
	// Line and Column are the 0-based target position.
	Line, Column int
}

// NavigationEvent carries a navigation result to the host. The application
// renders the rows (a popup or a tool window) and calls GoToPosition when one is
// picked, which is exactly how IntelliJ's Find Usages / hierarchy views work.
type NavigationEvent struct {
	Kind      NavigationKind
	Title     string
	Items     []NavigationItem
	Hierarchy *lsp.HierarchyNode
}

func (NavigationEvent) isEditorEvent() {}

// RenameEvent is Shift+F6: the editor cannot ask for a new name itself, so it
// hands the host the symbol under the caret. The host shows its input and calls
// RenameSymbol with the result.
type RenameEvent struct {
	Symbol string
	Line   int
}

func (RenameEvent) isEditorEvent() {}

// ColumnSelectionModeEvent reports the new state of Column Selection Mode after
// Alt+Shift+Insert, so the host can keep its own menu checkbox in sync.
type ColumnSelectionModeEvent struct{ Enabled bool }

func (ColumnSelectionModeEvent) isEditorEvent() {}

// --------------------------------------------------------------- public API

// SymbolAtCaret returns the identifier under the caret, or "".
func (e *Editor) SymbolAtCaret() string {
	runes := e.runes()
	off := e.caretOffset()
	if off < 0 || off > len(runes) {
		return ""
	}
	isIdent := func(r rune) bool {
		return r == '_' || unicode.IsLetter(r) || unicode.IsDigit(r)
	}
	start, end := off, off
	for start > 0 && isIdent(runes[start-1]) {
		start--
	}
	for end < len(runes) && isIdent(runes[end]) {
		end++
	}
	if start == end {
		return ""
	}
	return string(runes[start:end])
}

// GoToPosition moves the caret to a 0-based line/column (Go to Declaration,
// clicking a Find Usages row).
func (e *Editor) GoToPosition(line, column int) {
	off := e.offsetAt(lsp.Position{Line: line, Character: column})
	e.text.SetCaret(off, off)
	e.scrollCaret = true
}

// ImplementationsAt returns the implementations of the symbol at the caret.
func (e *Editor) ImplementationsAt() []lsp.Location {
	svc := e.language
	if svc == nil || svc.server == nil {
		return nil
	}
	return svc.server.Implementations(e.document(), e.positionAt(e.caretOffset()))
}

// ReferencesAt returns every usage of the symbol at the caret, the declaration
// included.
func (e *Editor) ReferencesAt() []lsp.Location {
	svc := e.language
	if svc == nil || svc.server == nil {
		return nil
	}
	return svc.server.References(e.document(), e.positionAt(e.caretOffset()), true)
}

// TypeHierarchyAt returns the type (or method) hierarchy of the symbol at the
// caret, or nil.
func (e *Editor) TypeHierarchyAt() *lsp.HierarchyNode {
	svc := e.language
	if svc == nil || svc.server == nil {
		return nil
	}
	return svc.server.TypeHierarchy(e.document(), e.positionAt(e.caretOffset()))
}

// CodeLenses returns the lenses the language server reported.
func (e *Editor) CodeLenses() []lsp.CodeLens {
	if e.language == nil {
		return nil
	}
	return e.language.lenses
}

// ShowUsages is Find Usages (Alt+F7): it builds the navigation result the host
// renders. It returns false when the caret is not on a resolvable symbol.
func (e *Editor) ShowUsages() (EditorEvent, bool) {
	items := e.navigationItems(e.ReferencesAt())
	if len(items) == 0 {
		return nil, false
	}
	return NavigationEvent{
		Kind:  NavigationUsages,
		Title: fmt.Sprintf("Find Usages: %s (%d)", e.SymbolAtCaret(), len(items)),
		Items: items,
	}, true
}

// ShowImplementations is Go to Implementation(s) (Ctrl+Alt+B).
func (e *Editor) ShowImplementations() (EditorEvent, bool) {
	items := e.navigationItems(e.ImplementationsAt())
	if len(items) == 0 {
		return nil, false
	}
	return NavigationEvent{
		Kind:  NavigationImplementations,
		Title: fmt.Sprintf("Implementations of %s (%d)", e.SymbolAtCaret(), len(items)),
		Items: items,
	}, true
}

// ShowTypeHierarchy is the Ctrl+H / Ctrl+Alt+H hierarchy view.
func (e *Editor) ShowTypeHierarchy() (EditorEvent, bool) {
	node := e.TypeHierarchyAt()
	if node == nil {
		return nil, false
	}
	return NavigationEvent{
		Kind:      NavigationHierarchy,
		Title:     "Hierarchy of " + node.Name,
		Items:     e.navigationItems(e.hierarchyLocations(node)),
		Hierarchy: node,
	}, true
}

// hierarchyLocations flattens a hierarchy node into locations, supers first.
func (e *Editor) hierarchyLocations(node *lsp.HierarchyNode) []lsp.Location {
	var out []lsp.Location
	for _, super := range node.Supers {
		out = append(out, super.Location)
	}
	out = append(out, node.Location)
	for _, sub := range node.Subs {
		out = append(out, sub.Location)
	}
	return out
}

// RenameSymbol applies IntelliJ's Rename (Shift+F6) to the symbol at the caret.
func (e *Editor) RenameSymbol(newName string) bool {
	svc := e.language
	if svc == nil || svc.server == nil || newName == "" {
		return false
	}
	edits := svc.server.Rename(e.document(), e.positionAt(e.caretOffset()), newName)
	if !e.applyTextEdits(edits) {
		return false
	}
	svc.rev = 0 // force a re-analysis on the next frame
	return true
}

// FormatDocument applies IntelliJ's Reformat Code (Ctrl+Alt+L) using the
// language server's edits.
func (e *Editor) FormatDocument() bool {
	svc := e.language
	if svc == nil || svc.server == nil {
		return false
	}
	if !e.applyTextEdits(svc.server.Formatting(e.document())) {
		return false
	}
	svc.rev = 0
	return true
}

// navigationItems turns locations into host-renderable rows.
func (e *Editor) navigationItems(locations []lsp.Location) []NavigationItem {
	lines := strings.Split(e.Text(), "\n")
	runes := e.runes()
	items := make([]NavigationItem, 0, len(locations))
	for _, l := range locations {
		line := l.Range.Start.Line
		detail := ""
		if line >= 0 && line < len(lines) {
			detail = strings.TrimSpace(lines[line])
		}
		name := ""
		start, end := e.offsetAt(l.Range.Start), e.offsetAt(l.Range.End)
		if start >= 0 && start < end && end <= len(runes) {
			name = string(runes[start:end])
		}
		items = append(items, NavigationItem{
			Name:   name,
			Detail: detail,
			Path:   l.URI,
			Line:   line,
			Column: l.Range.Start.Character,
		})
	}
	return items
}

// applyTextEdits applies LSP edits from the end of the document backwards so the
// earlier offsets stay valid, and leaves the caret after the last one. It is the
// single path every edit-producing language feature shares.
func (e *Editor) applyTextEdits(edits []lsp.TextEdit) bool {
	if len(edits) == 0 {
		return false
	}
	type runeEdit struct {
		start, end int
		text       string
	}
	converted := make([]runeEdit, 0, len(edits))
	for _, edit := range edits {
		converted = append(converted, runeEdit{
			start: e.offsetAt(edit.Range.Start),
			end:   e.offsetAt(edit.Range.End),
			text:  edit.NewText,
		})
	}
	sort.SliceStable(converted, func(i, j int) bool { return converted[i].start > converted[j].start })
	caret := converted[0].start
	for _, edit := range converted {
		e.text.Replace(edit.start, edit.end, edit.text)
		caret = edit.start + len([]rune(edit.text))
	}
	e.text.SetCaret(caret, caret)
	e.scrollCaret = true
	return true
}

// ------------------------------------------------------- usage highlighting

// syncUsageHighlighting repaints the usage highlight when the caret moved onto a
// different identifier. IntelliJ runs this scan continuously; keying it on the
// caret keeps it out of the typing path.
func (e *Editor) syncUsageHighlighting() {
	svc := e.language
	if svc == nil || svc.server == nil || !e.usageHighlighting {
		return
	}
	pos := e.positionAt(e.caretOffset())
	start, end := e.Selection()
	if svc.usageReady && svc.usagePos == pos && svc.usageSelection == (start != end) {
		return
	}
	svc.usageReady = true
	svc.usagePos = pos
	svc.usageSelection = start != end

	e.ClearDecorations(usageSource)
	// The built-in word highlighter is the syntactic version of the same feature
	// and is skipped while this is on; clear anything it left behind.
	e.ClearDecorations(wordHighlightSource)
	svc.usage = nil
	// A selection already marks the text; IntelliJ drops the usage highlight then.
	if start != end {
		return
	}
	locs := svc.server.References(e.document(), pos, false)
	var decorations []decoration.Decoration
	for _, l := range locs {
		from, to := e.offsetAt(l.Range.Start), e.offsetAt(l.Range.End)
		if from >= to {
			continue
		}
		decorations = append(decorations, decoration.Decoration{
			Source: usageSource, Start: from, End: to,
			Background: &decoration.Background{Color: gvcolor.MakeColor(usageHighlightColor)},
		})
	}
	if len(decorations) > 0 {
		_ = e.AddDecorations(decorations...)
		svc.usage = locs
	}
}

// UsageHighlights returns the ranges currently marked as usages of the symbol at
// the caret. It is empty while usage highlighting is off or the caret is not on
// a resolvable symbol.
func (e *Editor) UsageHighlights() []lsp.Location {
	if e.language == nil {
		return nil
	}
	return e.language.usage
}

// paintCodeLenses draws the language server's lenses right-aligned on their
// declaration's line, which is where IntelliJ puts its inlay lenses.
func (e *Editor) paintCodeLenses(gtx layout.Context, shaper *text.Shaper) {
	svc := e.language
	if svc == nil || !e.codeLens || len(svc.lenses) == 0 || shaper == nil {
		return
	}
	viewport := e.text.Viewport()
	params := e.text.Params()
	params.MinWidth = 0
	params.MaxLines = 1
	lineHeight := int(e.text.GetLineHeight().Ceil())

	for _, lens := range svc.lenses {
		if lens.Title == "" {
			continue
		}
		line := lens.Range.Start.Line
		if line*lineHeight > viewport.Max.Y || (line+1)*lineHeight < viewport.Min.Y {
			continue
		}
		coords := e.text.RuneCoords(e.offsetAt(lens.Range.Start))
		width := measureString(shaper, params, lens.Title)
		x := float32(viewport.Max.X - width - gtx.Dp(8))
		if x < float32(coords.X) {
			continue // the line is long: do not overlap the code
		}
		e.paintTextAtBaseline(gtx, shaper, params, lens.Title, x, float32(coords.Y), codeLensColor)
	}
}

var (
	usageHighlightColor = stdColor.NRGBA{R: 0x35, G: 0x4A, B: 0x6B, A: 0xA0}
	codeLensColor       = stdColor.NRGBA{R: 0x8C, G: 0x8C, B: 0x8C, A: 0xFF}
)
