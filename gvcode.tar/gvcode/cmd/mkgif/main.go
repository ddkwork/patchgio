// mkgif assembles the rendered column-edit frames into an animated GIF so the
// caret trajectory can be reviewed visually. One-off helper; not part of the
// library.
package main

import (
	"image"
	"image/color"
	"image/gif"
	"image/png"
	"os"
	"path/filepath"
	"sort"
	"time"
)

func main() {
	if len(os.Args) < 3 {
		println("usage: mkgif <pattern> <out.gif>")
		os.Exit(2)
	}
	pattern, out := os.Args[1], os.Args[2]

	paths, err := filepath.Glob(pattern)
	if err != nil || len(paths) == 0 {
		println("no frames found:", pattern)
		os.Exit(1)
	}
	sort.Strings(paths)

	g := &gif.GIF{LoopCount: 0}
	for _, p := range paths {
		f, err := os.Open(p)
		if err != nil {
			panic(err)
		}
		img, err := png.Decode(f)
		f.Close()
		if err != nil {
			panic(err)
		}
		// GIF needs a paletted image; quantize by drawing into a palette image.
		pal := image.NewPaletted(img.Bounds(), color.Palette(palette))
		for y := img.Bounds().Min.Y; y < img.Bounds().Max.Y; y++ {
			for x := img.Bounds().Min.X; x < img.Bounds().Max.X; x++ {
				pal.Set(x, y, img.At(x, y))
			}
		}
		g.Image = append(g.Image, pal)
		g.Delay = append(g.Delay, 35) // ~350ms per frame
	}

	f, err := os.Create(out)
	if err != nil {
		panic(err)
	}
	defer f.Close()
	if err := gif.EncodeAll(f, g); err != nil {
		panic(err)
	}
	println("wrote", out, "frames:", len(g.Image), time.Now().Format(time.Kitchen))
}

// 256-entry palette: 6x6x6 web cube + 40-step grayscale, good enough for
// editor screenshots.
var palette = func() []color.Color {
	c := make([]color.Color, 0, 256)
	for r := range 6 {
		for g := range 6 {
			for b := range 6 {
				c = append(c, color.NRGBA{uint8(r * 51), uint8(g * 51), uint8(b * 51), 0xff})
			}
		}
	}
	for i := 0; len(c) < 256; i++ {
		v := uint8(i * (256 / 40))
		c = append(c, color.NRGBA{v, v, v, 0xff})
	}
	return c
}()
