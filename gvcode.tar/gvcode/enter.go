package gvcode

import (
	"strings"
)

// bracketPairs maps an opening bracket or quote to the character that closes it.
// It mirrors textview's builtin pairs, which are not exported.
var bracketPairs = map[rune]rune{
	'(': ')',
	'[': ']',
	'{': '}',
	'"': '"',
	'\'': '\'',
	'`':  '`',
}

// closingPair returns the character that closes r, or 0 when r opens nothing.
func closingPair(r rune) rune {
	return bracketPairs[r]
}

// tabOutOfBracket reports whether Tab should jump the caret past the closing
// bracket or quote right after it rather than indent the line. IntelliJ only
// jumps when the caret really is inside the pair: either it is empty (the rune
// before the caret opens it) or the pair was auto-inserted.
func (e *Editor) tabOutOfBracket() bool {
	start, end := e.Selection()
	if start != end {
		return false
	}
	next, err := e.text.ReadRuneAt(start)
	if err != nil {
		return false
	}
	if _, isClosing := closingRunes[next]; !isClosing {
		return false
	}

	emptyPair := false
	if start > 0 {
		if prev, err := e.text.ReadRuneAt(start - 1); err == nil && closingPair(prev) == next {
			emptyPair = true
		}
	}
	if !emptyPair {
		if _, auto := e.autoInsertions[start]; !auto {
			return false
		}
	}
	e.text.MoveCaret(1, 1)
	return true
}

// closingRunes is the set of characters that close a pair.
var closingRunes = map[rune]struct{}{
	')': {}, ']': {}, '}': {}, '"': {}, '\'': {}, '`': {},
}

// EnterResult mirrors IntelliJ's EnterHandlerDelegate.Result
// (platform/lang-impl/.../enter/EnterHandlerDelegate.java): a delegate can take
// over Enter, adjust the caret and the indentation, or let the chain continue.
type EnterResult int

const (
	// EnterContinue lets the next delegate run, then the default Enter logic.
	EnterContinue EnterResult = iota
	// EnterDefault runs the default Enter logic without calling further delegates.
	EnterDefault
	// EnterDefaultForceIndent is EnterDefault plus forced indentation, even when
	// the editor's smart indent setting is off.
	EnterDefaultForceIndent
	// EnterDefaultSkipIndent is EnterDefault without any indentation work.
	EnterDefaultSkipIndent
	// EnterStop aborts Enter handling entirely; the delegate did the work.
	EnterStop
)

// EnterContext is the Go counterpart of the Ref parameters IntelliJ passes to
// preprocessEnter: the offset the line break goes to, and how far the caret moves
// forward on the new line afterwards.
type EnterContext struct {
	// CaretOffset is where the line break is inserted. A delegate may move it.
	CaretOffset int
	// CaretAdvance is the number of runes the caret is pushed past the indent.
	CaretAdvance int
}

// EnterHandlerDelegate is the Go counterpart of
// com.intellij.codeInsight.editorActions.enter.EnterHandlerDelegate.
type EnterHandlerDelegate interface {
	PreprocessEnter(e *Editor, ctx *EnterContext) EnterResult
}

// WithEnterHandlers registers Enter delegates. They run in registration order, the
// way IntelliJ orders its com.intellij.enterHandlerDelegate extensions, and the
// built-in ones are consulted after them.
func WithEnterHandlers(handlers ...EnterHandlerDelegate) EditorOption {
	return func(e *Editor) {
		e.enterHandlers = append(e.enterHandlers, handlers...)
	}
}

// Go's comment tokens, the values GoLand's commenter reports for the three cases
// the platform Enter delegates handle.
const (
	lineCommentPrefix = "//"
	blockCommentOpen  = "/*"
	blockCommentEnd   = "*/"
)

// builtinEnterHandlers returns the platform delegates IntelliJ registers by
// default, in its registration order
// (platform/lang-impl/resources/intellij.platform.lang.impl.xml):
// EnterInStringLiteralHandler, EnterInLineCommentHandler,
// EnterAfterUnmatchedBraceHandler, EnterBetweenBracesHandler,
// EnterInBlockCommentHandler (order="last").
func builtinEnterHandlers() []EnterHandlerDelegate {
	return []EnterHandlerDelegate{
		enterInLineCommentHandler{},
		enterAfterUnmatchedBraceHandler{},
		enterBetweenBracesHandler{},
		enterInBlockCommentHandler{},
	}
}

// currentLine returns the caret's line text, its first rune offset and the offset
// just past its last rune (the line feed is not part of the returned text).
func (e *Editor) currentLine() (line string, lineStart, contentEnd int) {
	var buf []byte
	buf, lineStart, _ = e.text.SelectedLineText(e.scratch)
	e.scratch = buf
	s := strings.TrimRight(string(buf), "\r\n")
	return s, lineStart, lineStart + len([]rune(s))
}

// runEnterHandlers feeds each delegate in order and reports what the default Enter
// logic should do, following IntelliJ's Result contract exactly.
func (e *Editor) runEnterHandlers(gtxCtx int) (ctx EnterContext, forceIndent, skipIndent bool, stop bool) {
	ctx = EnterContext{CaretOffset: gtxCtx}

	for _, h := range e.enterHandlers {
		switch res := h.PreprocessEnter(e, &ctx); res {
		case EnterStop:
			return ctx, false, false, true
		case EnterContinue:
			continue
		case EnterDefaultForceIndent:
			return ctx, true, false, false
		case EnterDefaultSkipIndent:
			return ctx, false, true, false
		default:
			return ctx, false, false, false
		}
	}

	for _, h := range builtinEnterHandlers() {
		switch res := h.PreprocessEnter(e, &ctx); res {
		case EnterStop:
			return ctx, false, false, true
		case EnterContinue:
			continue
		case EnterDefaultForceIndent:
			return ctx, true, false, false
		case EnterDefaultSkipIndent:
			return ctx, false, true, false
		default:
			return ctx, false, false, false
		}
	}

	return ctx, false, false, false
}

// enterInLineCommentHandler mirrors EnterInLineCommentHandler: pressing Enter with
// real text after the caret inside a line comment SPLITS the comment, so the tail
// keeps its own "//". IntelliJ deliberately does not continue the comment when the
// caret already sits at its end, and neither do we.
type enterInLineCommentHandler struct{}

func (enterInLineCommentHandler) PreprocessEnter(e *Editor, ctx *EnterContext) EnterResult {
	line, lineStart, contentEnd := e.currentLine()
	caret := ctx.CaretOffset
	if caret < lineStart || caret > contentEnd {
		return EnterContinue
	}

	commentAt := strings.Index(line, lineCommentPrefix)
	if commentAt < 0 || strings.TrimSpace(line[:commentAt]) != "" {
		return EnterContinue
	}
	prefixEnd := commentAt + len(lineCommentPrefix)
	if caret < lineStart+prefixEnd {
		return EnterContinue // the caret is inside the "//" itself
	}
	// Only a split is handled: there has to be text left on the line.
	if strings.TrimSpace(line[caret-lineStart:]) == "" {
		return EnterContinue
	}

	// The new comment line reuses the spacing the original "//" was followed by,
	// exactly like the platform handler does.
	spacing := ""
	for i := prefixEnd; i < len(line) && (line[i] == ' ' || line[i] == '\t'); i++ {
		spacing += string(line[i])
	}
	if spacing == "" {
		spacing = " "
	}

	// Drop the blanks the caret sat on, then start the tail on a fresh line that
	// carries the same indent and prefix.
	tail := line[caret-lineStart:]
	tail = strings.TrimLeft(tail, " \t")
	indent := line[:commentAt]
	insert := "\n" + indent + lineCommentPrefix + spacing
	e.text.Replace(caret, contentEnd, tail)
	e.text.Replace(caret, caret, insert)
	end := caret + len([]rune(insert))
	e.text.SetCaret(end, end)
	return EnterStop
}

// enterAfterUnmatchedBraceHandler mirrors EnterAfterUnmatchedBraceHandler: with the
// caret right after a "{", the matching "}" is inserted on the next line
// (CodeInsightSettings.INSERT_BRACE_ON_ENTER).
type enterAfterUnmatchedBraceHandler struct{}

func (enterAfterUnmatchedBraceHandler) PreprocessEnter(e *Editor, ctx *EnterContext) EnterResult {
	caret := ctx.CaretOffset
	if caret <= 0 {
		return EnterContinue
	}
	prev, err := e.text.ReadRuneAt(caret - 1)
	if err != nil || prev != '{' {
		return EnterContinue
	}
	// Only an unmatched brace opens a block: a "{" the trailing "}" already closes
	// must not grow another one.
	text := e.runes()
	if unmatchedLBraces(text, caret) <= 0 {
		return EnterContinue
	}

	line, lineStart, contentEnd := e.currentLine()
	caretInLine := caret - lineStart
	if caretInLine < 0 || caretInLine > len(line) {
		return EnterContinue
	}
	// The closer goes after the line's trailing blanks, the way the platform
	// handler shifts forward before inserting.
	insertAt := contentEnd
	for i := caretInLine; i < len(line) && (line[i] == ' ' || line[i] == '\t'); i++ {
		insertAt = lineStart + i + 1
	}
	e.text.Replace(insertAt, insertAt, "\n}")
	// The insertion carried the caret along; the line break has to land at the
	// original position, between the braces.
	e.text.SetCaret(caret, caret)
	return EnterDefaultForceIndent
}

// enterBetweenBracesHandler mirrors EnterBetweenBracesHandler for the case the
// default indent logic cannot see: the caret between a pair that sits on the same
// line. It only asks for a forced indent, the actual expansion being the default
// Enter logic's job (see TextView.IndentOnBreak).
type enterBetweenBracesHandler struct{}

func (enterBetweenBracesHandler) PreprocessEnter(e *Editor, ctx *EnterContext) EnterResult {
	caret := ctx.CaretOffset
	if caret <= 0 || caret >= e.text.Len() {
		return EnterContinue
	}
	prev, errPrev := e.text.ReadRuneAt(caret - 1)
	next, errNext := e.text.ReadRuneAt(caret)
	if errPrev != nil || errNext != nil {
		return EnterContinue
	}
	if _, ok := bracketPairs[prev]; !ok || bracketPairs[prev] != next {
		return EnterContinue
	}
	return EnterDefaultForceIndent
}

// enterInBlockCommentHandler mirrors EnterInBlockCommentHandler: Enter inside a
// block comment that is not closed yet inserts the closing "*/" on its own line
// (CodeInsightSettings.CLOSE_COMMENT_ON_ENTER).
type enterInBlockCommentHandler struct{}

func (enterInBlockCommentHandler) PreprocessEnter(e *Editor, ctx *EnterContext) EnterResult {
	caret := ctx.CaretOffset
	text := e.runes()
	if caret <= 0 || caret > len(text) {
		return EnterContinue
	}
	// Unterminated block comment: the last "/*" before the caret has no "*/" after
	// it yet.
	open := lastIndexRunes(text[:caret], blockCommentOpen)
	if open < 0 || lastIndexRunes(text[:caret], blockCommentEnd) > open {
		return EnterContinue
	}

	line, lineStart, _ := e.currentLine()
	caretInLine := caret - lineStart
	if caretInLine < 0 || caretInLine > len(line) {
		return EnterContinue
	}
	indent := line[:len(line)-len(strings.TrimLeft(line, " \t"))]
	// The suffix lands at the end of the line, so the caret keeps its place and the
	// default Enter opens the comment's body.
	e.text.Replace(lineStart+len(line), lineStart+len(line), "\n"+indent+" "+blockCommentEnd)
	// The insertion carried the caret to the end of the appended text; the line
	// break has to stay where the user was typing.
	e.text.SetCaret(caret, caret)
	return EnterDefault
}

// unmatchedLBraces mirrors EnterAfterUnmatchedBraceHandler
// .getUnmatchedLBracesNumberBefore. It walks the WHOLE file, because a "}" after
// the caret closes the "{" the caret sits behind — and then Enter must not insert
// another one. Braces inside comments and strings do not count.
func unmatchedLBraces(text []rune, offset int) int {
	lBracesBefore, rBracesAfter := 0, 0
	for i := 0; i < len(text); i++ {
		switch text[i] {
		case '"', '\'':
			i = skipQuoted(text, i)
		case '`':
			i = skipRawString(text, i)
		case '/':
			if i+1 < len(text) && text[i+1] == '/' {
				i = skipLineComment(text, i)
			} else if i+1 < len(text) && text[i+1] == '*' {
				i = skipBlockComment(text, i)
			}
		case '{':
			if i < offset {
				lBracesBefore++
			} else {
				rBracesAfter--
			}
		case '}':
			if i < offset {
				if lBracesBefore > 0 {
					lBracesBefore--
				}
			} else {
				rBracesAfter++
				if rBracesAfter == lBracesBefore {
					// Every scope before the caret is closed again.
					return 0
				}
			}
		}
	}
	return lBracesBefore - rBracesAfter
}

// runes returns the document as runes. Enter handling runs once per key press, so
// the copy is not on a hot path.
func (e *Editor) runes() []rune {
	return []rune(e.Text())
}

func skipQuoted(text []rune, i int) int {
	for i++; i < len(text); i++ {
		if text[i] == '\\' {
			i++
			continue
		}
		if text[i] == '"' || text[i] == '\'' {
			return i
		}
		if text[i] == '\n' {
			return i
		}
	}
	return len(text) - 1
}

func skipRawString(text []rune, i int) int {
	for i++; i < len(text); i++ {
		if text[i] == '`' {
			return i
		}
	}
	return len(text) - 1
}

func skipLineComment(text []rune, i int) int {
	for ; i < len(text); i++ {
		if text[i] == '\n' {
			return i
		}
	}
	return len(text) - 1
}

func skipBlockComment(text []rune, i int) int {
	for i += 2; i < len(text)-1; i++ {
		if text[i] == '*' && text[i+1] == '/' {
			return i + 1
		}
	}
	return len(text) - 1
}

// lastIndexRunes reports the last index of needle in text, or -1.
func lastIndexRunes(text []rune, needle string) int {
	target := []rune(needle)
	for i := len(text) - len(target); i >= 0; i-- {
		if string(text[i:i+len(target)]) == string(target) {
			return i
		}
	}
	return -1
}

// completeStatement mirrors IntelliJ's CompleteStatementAction (Ctrl+Shift+Enter,
// BaseSmartEnterProcessor): it closes every bracket the caret still sits inside. A
// missing "}" or "]" goes on its own line, a missing ")" right after the caret.
func (e *Editor) completeStatement() (EditorEvent, bool) {
	start, end := e.Selection()
	if start != end {
		e.text.SetCaret(start, start)
		start, _ = e.Selection()
	}

	missing := e.unclosedBrackets(start)
	if missing == "" {
		return nil, false
	}

	indent := ""
	if line, lineStart, _ := e.currentLine(); start >= lineStart {
		indent = line[:len(line)-len(strings.TrimLeft(line, " \t"))]
	}

	insert := missing
	if strings.HasPrefix(missing, "}") || strings.HasPrefix(missing, "]") {
		insert = "\n" + indent + missing
	}
	e.text.Replace(start, start, insert)
	caret := start + len([]rune(insert))
	e.text.SetCaret(caret, caret)
	e.scrollCaret = true
	return ChangeEvent{}, true
}

// unclosedBrackets returns the closers for the brackets still open at offset, in
// the order they have to be inserted.
func (e *Editor) unclosedBrackets(offset int) string {
	text := e.runes()
	if offset > len(text) {
		offset = len(text)
	}
	stack := make([]rune, 0, 4)
	for i := 0; i < offset; i++ {
		switch text[i] {
		case '"', '\'':
			i = skipQuoted(text, i)
		case '`':
			i = skipRawString(text, i)
		case '/':
			if i+1 < offset && text[i+1] == '/' {
				i = skipLineComment(text, i)
			} else if i+1 < offset && text[i+1] == '*' {
				i = skipBlockComment(text, i)
			}
		case '(', '[', '{':
			stack = append(stack, text[i])
		case ')', ']', '}':
			if n := len(stack); n > 0 && bracketPairs[stack[n-1]] == text[i] {
				stack = stack[:n-1]
			}
		}
	}

	var b strings.Builder
	for i := len(stack) - 1; i >= 0; i-- {
		b.WriteRune(bracketPairs[stack[i]])
	}
	return b.String()
}
