package gvcode

import (
	"sort"
	"strings"
)

// CommentSyntax describes how a language comments code out, the data IntelliJ's
// com.intellij.lang.Commenter exposes: a line-comment prefix and/or a block pair.
type CommentSyntax struct {
	// Line is the line-comment prefix: "//" for Go, "#" for shell, "REM" for
	// batch, "--" for SQL. Empty when the language has no line comment.
	Line string
	// BlockStart/BlockEnd wrap a block comment: "/*" and "*/" for C-like
	// languages, "<!--" and "-->" for markup.
	BlockStart string
	BlockEnd   string
}

// HasLine reports whether the syntax supports line comments.
func (s CommentSyntax) HasLine() bool { return s.Line != "" }

// HasBlock reports whether the syntax supports block comments.
func (s CommentSyntax) HasBlock() bool { return s.BlockStart != "" && s.BlockEnd != "" }

// commentSyntaxes maps a language id OR a file extension (both lower-cased, no
// leading dot) to its comment syntax. Keeping extensions in the same table means
// a caller can resolve either "bat" (a language id) or "build.bat" (a path).
var commentSyntaxes = map[string]CommentSyntax{
	// C family: // and /* */.
	"c": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "h": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"cpp": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "c++": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"cc": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "cxx": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"hpp": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "hh": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"m": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "mm": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"cu": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "cuh": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"java": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"js":   {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "javascript": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"jsx": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "mjs": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"ts": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "typescript": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"tsx": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"cs":  {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "csharp": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"kt": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "kotlin": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"kts":   {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"scala": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "sc": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"groovy": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "gradle": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"swift": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "dart": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"rs": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "rust": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"zig": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"d":   {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"go":  {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "golang": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"proto": {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "protobuf": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"thrift": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"glsl":   {Line: "//", BlockStart: "/*", BlockEnd: "*/"}, "hlsl": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"php":  {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"scss": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"less": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	// JSON proper has no comments; JSONC/JSON5 do.
	"jsonc": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"json5": {Line: "//", BlockStart: "/*", BlockEnd: "*/"},
	"json":  {},

	// Hash family.
	"py": {Line: "#"}, "python": {Line: "#"}, "pyi": {Line: "#"},
	"rb": {Line: "#"}, "ruby": {Line: "#"},
	"pl": {Line: "#"}, "pm": {Line: "#"}, "perl": {Line: "#"}, "raku": {Line: "#"},
	"sh": {Line: "#"}, "bash": {Line: "#"}, "zsh": {Line: "#"}, "ksh": {Line: "#"}, "fish": {Line: "#"},
	"shell": {Line: "#"}, "shellscript": {Line: "#"},
	"ps1":        {Line: "#", BlockStart: "<#", BlockEnd: "#>"},
	"psm1":       {Line: "#", BlockStart: "<#", BlockEnd: "#>"},
	"powershell": {Line: "#", BlockStart: "<#", BlockEnd: "#>"},
	"yaml":       {Line: "#"}, "yml": {Line: "#"},
	"toml": {Line: "#"}, "ini": {Line: "#"}, "cfg": {Line: "#"}, "conf": {Line: "#"},
	"properties": {Line: "#"},
	"r":          {Line: "#"}, "julia": {Line: "#"}, "jl": {Line: "#"}, "nim": {Line: "#"},
	"cr": {Line: "#"}, "crystal": {Line: "#"},
	"ex": {Line: "#"}, "exs": {Line: "#"}, "elixir": {Line: "#"},
	"tf": {Line: "#"}, "hcl": {Line: "#"}, "terraform": {Line: "#"},
	"dockerfile": {Line: "#"}, "makefile": {Line: "#"}, "mk": {Line: "#"}, "cmake": {Line: "#"},
	"tcl": {Line: "#"}, "awk": {Line: "#"}, "sed": {Line: "#"},
	"graphviz": {Line: "#"}, "dot": {Line: "#"}, "gnuplot": {Line: "#"}, "gd": {Line: "#"},
	"gitignore": {Line: "#"}, "gitconfig": {Line: "#"}, "gitattributes": {Line: "#"}, "editorconfig": {Line: "#"},
	"env": {Line: "#"}, "desktop": {Line: "#"}, "service": {Line: "#"}, "nix": {Line: "#"},

	// Windows script family. Batch uses REM; "::" also works but REM is the
	// canonical commenter prefix.
	"bat": {Line: "REM"}, "cmd": {Line: "REM"}, "batch": {Line: "REM"}, "dosbatch": {Line: "REM"},
	"vbs": {Line: "'"}, "vbscript": {Line: "'"},
	"vb": {Line: "'"}, "basic": {Line: "'"}, "bas": {Line: "'"},

	// SQL / Ada / Haskell family.
	"sql": {Line: "--", BlockStart: "/*", BlockEnd: "*/"},
	"lua": {Line: "--", BlockStart: "--[[", BlockEnd: "]]"},
	"hs":  {Line: "--", BlockStart: "{-", BlockEnd: "-}"}, "haskell": {Line: "--", BlockStart: "{-", BlockEnd: "-}"},
	"elm": {Line: "--", BlockStart: "{-", BlockEnd: "-}"},
	"ada": {Line: "--"}, "adb": {Line: "--"}, "ads": {Line: "--"},
	"vhd": {Line: "--"}, "vhdl": {Line: "--"},
	"applescript": {Line: "--"},
	"hcl2":        {Line: "#"},

	// Semicolon family.
	"lisp": {Line: ";"}, "clj": {Line: ";"}, "cljs": {Line: ";"}, "clojure": {Line: ";"},
	"scm": {Line: ";"}, "scheme": {Line: ";"}, "rkt": {Line: ";"}, "racket": {Line: ";"},
	"el": {Line: ";"}, "asm": {Line: ";"}, "s": {Line: ";"}, "nasm": {Line: ";"},

	// Percent family.
	"tex": {Line: "%"}, "latex": {Line: "%"}, "bib": {Line: "%"},
	"erl": {Line: "%"}, "erlang": {Line: "%"},
	"matlab": {Line: "%", BlockStart: "%{", BlockEnd: "%}"},
	"octave": {Line: "%", BlockStart: "%{", BlockEnd: "%}"},

	// Bang family.
	"f": {Line: "!"}, "f90": {Line: "!"}, "f95": {Line: "!"}, "for": {Line: "!"}, "fortran": {Line: "!"},

	// Markup: block comments only.
	"html":     {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"htm":      {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"xml":      {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"xsl":      {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"xsd":      {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"svg":      {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"vue":      {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"svelte":   {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"md":       {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"markdown": {Line: "", BlockStart: "<!--", BlockEnd: "-->"},
	"css":      {BlockStart: "/*", BlockEnd: "*/"},

	// Pascal/Delphi.
	"pas": {Line: "//", BlockStart: "{", BlockEnd: "}"}, "pascal": {Line: "//", BlockStart: "{", BlockEnd: "}"},
	"dpr": {Line: "//", BlockStart: "{", BlockEnd: "}"},

	// Plain text and data formats have no comment syntax at all.
	"txt": {}, "text": {}, "plaintext": {}, "log": {}, "csv": {}, "tsv": {}, "diff": {}, "patch": {},
	"png": {}, "jpg": {}, "jpeg": {}, "gif": {}, "zip": {}, "tar": {}, "gz": {}, "pdf": {}, "exe": {}, "dll": {},
}

// normalizeLanguage lower-cases a language id or extension and drops a leading dot.
func normalizeLanguage(lang string) string {
	return strings.TrimPrefix(strings.ToLower(strings.TrimSpace(lang)), ".")
}

// CommentSyntaxForLanguage resolves a language id ("go", "bat") or an extension
// ("go", "bat") to its comment syntax.
func CommentSyntaxForLanguage(lang string) (CommentSyntax, bool) {
	syntax, ok := commentSyntaxes[normalizeLanguage(lang)]
	return syntax, ok
}

// CommentSyntaxForPath resolves a file path by its base name, so extension-less
// files (Makefile, Dockerfile) resolve too.
func CommentSyntaxForPath(path string) (CommentSyntax, bool) {
	base := path
	if i := strings.LastIndexAny(base, `/\`); i >= 0 {
		base = base[i+1:]
	}
	base = strings.ToLower(base)
	if syntax, ok := commentSyntaxes[base]; ok {
		return syntax, true
	}
	if i := strings.LastIndexByte(base, '.'); i >= 0 && i+1 < len(base) {
		if syntax, ok := commentSyntaxes[base[i+1:]]; ok {
			return syntax, true
		}
	}
	return CommentSyntax{}, false
}

// WithCommentLanguage selects the comment syntax for a language id from the
// built-in table, so Ctrl+/ comments in that language's own syntax. An unknown
// language disables the comment commands.
func WithCommentLanguage(lang string) EditorOption {
	return func(e *Editor) {
		if syntax, ok := CommentSyntaxForLanguage(lang); ok {
			e.commentSyntax = syntax
			return
		}
		e.commentSyntax = CommentSyntax{}
	}
}

// SetCommentSyntax overrides the comment syntax directly.
func (e *Editor) SetCommentSyntax(syntax CommentSyntax) {
	e.commentSyntax = syntax
}

// CommentSyntax returns the syntax the comment commands use.
func (e *Editor) CommentSyntax() CommentSyntax {
	return e.commentSyntax
}

// commentLineStarts returns the rune offset of every line's first rune.
func commentLineStarts(runes []rune) []int {
	starts := make([]int, 1, len(runes)/24+1)
	starts[0] = 0
	for i, r := range runes {
		if r == '\n' {
			starts = append(starts, i+1)
		}
	}
	return starts
}

// commentLineIndex returns the index of the line containing off.
func commentLineIndex(starts []int, off int) int {
	if off < 0 {
		return 0
	}
	index := sort.Search(len(starts), func(i int) bool { return starts[i] > off }) - 1
	if index < 0 {
		return 0
	}
	return index
}

// commentLineEnd returns the offset just past a line's last rune (the line feed is
// not part of the line).
func commentLineEnd(runes []rune, starts []int, line int) int {
	if line+1 < len(starts) {
		end := starts[line+1] - 1
		if end > starts[line] && runes[end-1] == '\r' {
			end--
		}
		return end
	}
	return len(runes)
}

// commentFirstNonSpace returns the offset of the line's first non-blank rune, or
// the line's end when it is blank. Comment markers go there so indentation is
// preserved, which is what GoLand does for Go and what keeps scripts valid.
func commentFirstNonSpace(runes []rune, starts []int, line int) int {
	end := commentLineEnd(runes, starts, line)
	at := starts[line]
	for at < end && (runes[at] == ' ' || runes[at] == '\t') {
		at++
	}
	return at
}

// commentMarkerAt reports whether the marker starts at off and reads as a comment
// marker rather than the inside of a longer token.
func commentMarkerAt(runes []rune, off int, marker []rune) bool {
	if off < 0 || off+len(marker) > len(runes) {
		return false
	}
	for i, r := range marker {
		if runes[off+i] != r {
			return false
		}
	}
	// A marker that ends in a letter (REM, "#" does not) must be followed by a
	// separator, so "REMOVE" is not mistaken for a commented "OVE".
	if last := marker[len(marker)-1]; isIdentifierRune(last) {
		if off+len(marker) < len(runes) {
			next := runes[off+len(marker)]
			if isIdentifierRune(next) {
				return false
			}
		}
	}
	return true
}

func isIdentifierRune(r rune) bool {
	return r == '_' ||
		(r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9')
}

// isBlankRune reports whether r is a space, a tab or a line feed.
func isBlankRune(r rune) bool {
	return r == ' ' || r == '\t' || r == '\n' || r == '\r'
}

// ToggleLineComment comments or uncomments every line the selection touches,
// following IntelliJ's CommentByLineCommentAction: when any affected line is not
// commented yet all of them are commented, otherwise they are all uncommented.
// The marker is inserted after the indentation, which keeps the code valid.
func (e *Editor) ToggleLineComment() (EditorEvent, bool) {
	marker := []rune(e.commentSyntax.Line)
	if len(marker) == 0 {
		return nil, false
	}

	start, end := e.Selection()
	if start > end {
		start, end = end, start
	}
	collapsed := start == end

	runes := e.runes()
	starts := commentLineStarts(runes)
	first := commentLineIndex(starts, start)
	last := commentLineIndex(starts, end)
	// A selection that stops exactly at a line start does not include that line.
	if last > first && end == starts[last] {
		last--
	}

	type target struct{ at int }
	targets := make([]target, 0, last-first+1)
	allCommented := true
	for line := first; line <= last; line++ {
		at := commentFirstNonSpace(runes, starts, line)
		targets = append(targets, target{at: at})
		if !commentMarkerAt(runes, at, marker) {
			allCommented = false
		}
	}

	type edit struct {
		from, to int
		text     string
	}
	edits := make([]edit, 0, len(targets))
	if allCommented {
		for _, t := range targets {
			to := t.at + len(marker)
			// Drop the single separating space too, so "// x" becomes "x".
			if to < len(runes) && (runes[to] == ' ' || runes[to] == '\t') {
				to++
			}
			edits = append(edits, edit{from: t.at, to: to, text: ""})
		}
	} else {
		blank := func(at int) bool { return at >= len(runes) || isBlankRune(runes[at]) }
		for _, t := range targets {
			text := string(marker)
			if !blank(t.at) {
				text += " "
			}
			edits = append(edits, edit{from: t.at, to: t.at, text: text})
		}
	}

	// Apply from the end of the document backwards so the earlier offsets stay
	// valid, and track the offset shift for the caret. An insertion at the caret
	// pushes it past the marker; a removal at the caret leaves it in place.
	sort.SliceStable(edits, func(i, j int) bool { return edits[i].from > edits[j].from })
	adjust := func(off int) int {
		delta := 0
		for _, edit := range edits {
			switch {
			case edit.from < off:
				delta += len([]rune(edit.text)) - (edit.to - edit.from)
			case edit.from == off && edit.text != "":
				delta += len([]rune(edit.text))
			}
		}
		return off + delta
	}
	for _, edit := range edits {
		e.text.Replace(edit.from, edit.to, edit.text)
	}

	// Recompose the selection over the affected lines, the way IntelliJ leaves
	// the commented block selected.
	newRunes := e.runes()
	newStarts := commentLineStarts(newRunes)
	if first < len(newStarts) {
		from := newStarts[first]
		to := commentLineEnd(newRunes, newStarts, min(last, len(newStarts)-1))
		if collapsed {
			from, to = adjust(start), adjust(start)
		}
		e.text.SetCaret(from, to)
	}
	e.scrollCaret = true
	return ChangeEvent{}, true
}

// ToggleBlockComment wraps the selection in the language's block comment or
// removes the wrapping when the selection already has it, mirroring IntelliJ's
// CommentByBlockCommentAction. It reports false when the language has no block
// comment syntax.
func (e *Editor) ToggleBlockComment() (EditorEvent, bool) {
	syntax := e.commentSyntax
	if !syntax.HasBlock() {
		return nil, false
	}
	open, close := []rune(syntax.BlockStart), []rune(syntax.BlockEnd)

	start, end := e.Selection()
	if start > end {
		start, end = end, start
	}
	runes := e.runes()

	// Already wrapped: the text right before and right after the selection is the
	// pair.
	if start >= len(open) && end+len(close) <= len(runes) &&
		string(runes[start-len(open):start]) == syntax.BlockStart &&
		string(runes[end:end+len(close)]) == syntax.BlockEnd {
		e.text.Replace(end, end+len(close), "")
		e.text.Replace(start-len(open), start, "")
		e.text.SetCaret(start-len(open), end-len(open))
		e.scrollCaret = true
		return ChangeEvent{}, true
	}

	e.text.Replace(end, end, syntax.BlockEnd)
	e.text.Replace(start, start, syntax.BlockStart)
	e.text.SetCaret(start+len(open), end+len(open))
	e.scrollCaret = true
	return ChangeEvent{}, true
}
