package gvcode

import (
	"image"
	"testing"

	"gioui.org/io/key"
)

// multiCaretFixture repeats a word so occurrence actions have something to find.
const multiCaretFixture = "package main\n\nfoo()\nfoo()\nfoo()\n"

// selectAllFoo places the caret inside the first foo and runs
// Ctrl+Alt+Shift+J, leaving one caret per occurrence.
func selectAllFoo(t *testing.T, h *columnEditHarness, e *Editor) {
	t.Helper()
	caretAt(h, e, runeOffsetOfDocumentLine(multiCaretFixture, 2))
	h.pressKey("J", key.ModShortcut|key.ModAlt|key.ModShift)
	h.frame(true)
}

// TestMultiCaretSelectAllOccurrences pins IntelliJ's SelectAllOccurrencesAction
// (Ctrl+Alt+Shift+J): one caret per occurrence of the word at the primary caret.
func TestMultiCaretSelectAllOccurrences(t *testing.T) {
	h, e := newEnterHarness(t, multiCaretFixture)
	selectAllFoo(t, h, e)

	carets := e.allCarets()
	if len(carets) != 3 {
		t.Fatalf("got %d carets, want 3 (one per occurrence): %+v", len(carets), carets)
	}
	for i, c := range carets {
		line := runeOffsetOfDocumentLine(multiCaretFixture, 2+i)
		if c.start != line || c.end != line+3 {
			t.Fatalf("caret %d = %+v, want the \"foo\" on line %d (%d..%d)", i, c, 2+i, line, line+3)
		}
	}
}

// TestMultiCaretAltJWalksTheOccurrences pins SelectNextOccurrenceAction (Alt+J):
// each press selects the next occurrence, and once the file runs out nothing more
// happens.
func TestMultiCaretAltJWalksTheOccurrences(t *testing.T) {
	h, e := newEnterHarness(t, multiCaretFixture)
	caretAt(h, e, runeOffsetOfDocumentLine(multiCaretFixture, 2)+1)

	// The first press selects the word under the caret.
	h.pressKey("J", key.ModAlt)
	h.frame(true)
	if got := e.allCarets(); len(got) != 1 {
		t.Fatalf("after the first Alt+J there are %d carets, want only the primary", len(got))
	}
	start, end := e.Selection()
	if end-start != 3 {
		t.Fatalf("the first Alt+J selected %d..%d, want the whole word \"foo\"", start, end)
	}

	h.pressKey("J", key.ModAlt)
	h.frame(true)
	if got := e.allCarets(); len(got) != 2 {
		t.Fatalf("after the second Alt+J there are %d carets, want 2", len(got))
	}
	h.pressKey("J", key.ModAlt)
	h.frame(true)
	if got := e.allCarets(); len(got) != 3 {
		t.Fatalf("after the third Alt+J there are %d carets, want 3", len(got))
	}

	// No occurrence left: the caret count stays put.
	h.pressKey("J", key.ModAlt)
	h.frame(true)
	if got := e.allCarets(); len(got) != 3 {
		t.Fatalf("Alt+J invented a %dth caret past the last occurrence", len(got))
	}
}

// TestMultiCaretTypingReplacesEveryOccurrence pins the point of multi-caret
// editing: typed text replaces the selection of every caret.
func TestMultiCaretTypingReplacesEveryOccurrence(t *testing.T) {
	h, e := newEnterHarness(t, multiCaretFixture)
	selectAllFoo(t, h, e)

	h.pressText("bar")
	h.frame(true)

	want := "package main\n\nbar()\nbar()\nbar()\n"
	if got := e.Text(); got != want {
		t.Fatalf("after typing:\n%q\nwant\n%q", got, want)
	}
}

// TestMultiCaretBackspaceDeletesEverySelection pins Backspace with several carets:
// every selection goes at once.
func TestMultiCaretBackspaceDeletesEverySelection(t *testing.T) {
	h, e := newEnterHarness(t, multiCaretFixture)
	selectAllFoo(t, h, e)

	h.pressKey(key.NameDeleteBackward, 0)
	h.frame(true)

	want := "package main\n\n()\n()\n()\n"
	if got := e.Text(); got != want {
		t.Fatalf("after Backspace:\n%q\nwant\n%q", got, want)
	}
}

// TestMultiCaretEscapeCollapses pins Esc: the extra carets go away and the primary
// one keeps its place.
func TestMultiCaretEscapeCollapses(t *testing.T) {
	h, e := newEnterHarness(t, multiCaretFixture)
	selectAllFoo(t, h, e)
	if !e.MultiCaretEnabled() {
		t.Fatal("no extra carets to collapse")
	}

	h.pressKey(key.NameEscape, 0)
	h.frame(true)

	if e.MultiCaretEnabled() {
		t.Fatalf("Esc left %d extra carets behind", len(e.extraCarets()))
	}
}

// TestMultiCaretCtrlClickAddsACaret pins Ctrl+Click: it adds a caret without
// moving the primary one.
func TestMultiCaretCtrlClickAddsACaret(t *testing.T) {
	h, e := newEnterHarness(t, multiCaretFixture)
	caretAt(h, e, runeOffsetOfDocumentLine(multiCaretFixture, 2))

	lineHeight := e.text.GetLineHeight().Round()
	// Ctrl+Click after the third column of the fourth line ("foo()").
	_, column := e.ConvertPos(4, 3)
	h.clickAt(e.gutterWidth+int(column.X), 4*lineHeight+lineHeight/2, key.ModShortcut)
	h.frame(true)

	if got := len(e.allCarets()); got != 2 {
		t.Fatalf("Ctrl+Click left %d carets, want 2", got)
	}
	primary, _ := e.Selection()
	if primary != runeOffsetOfDocumentLine(multiCaretFixture, 2) {
		t.Fatalf("Ctrl+Click moved the primary caret to %d", primary)
	}

	h.pressText("x")
	h.frame(true)
	want := "package main\n\nxfoo()\nfoo()\nfoox()\n"
	if got := e.Text(); got != want {
		t.Fatalf("after typing at two carets:\n%q\nwant\n%q", got, want)
	}
}

// TestMultiCaretPaintsEveryCaret pins the rendering: every caret of the session is
// drawn, and it stops being drawn once the session is collapsed.
func TestMultiCaretPaintsEveryCaret(t *testing.T) {
	h, e := newEnterHarness(t, multiCaretFixture)
	selectAllFoo(t, h, e)

	rects := e.multiCaretCaretRects()
	if len(rects) != 2 {
		t.Fatalf("got %d extra caret rectangles, want 2", len(rects))
	}

	withCarets := image.NewRGBA(image.Rect(0, 0, 600, 200))
	if err := h.win.Screenshot(withCarets); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	dumpPNG(t, screenshotDir(t), "gvcode-multicaret-carets", withCarets)

	// Collapse the session and render again: the two frames are identical apart
	// from the extra carets, so any pixel that changed inside a caret rectangle
	// proves the caret was painted there.
	h.pressKey(key.NameEscape, 0)
	h.frame(true)
	single := image.NewRGBA(image.Rect(0, 0, 600, 200))
	if err := h.win.Screenshot(single); err != nil {
		t.Fatalf("screenshot: %v", err)
	}
	for _, r := range rects {
		if n := countPixelDiff(withCarets, single, r); n == 0 {
			t.Fatalf("no caret painted at %v", r)
		}
	}
}

// countPixelDiff counts the pixels that differ between two frames inside a
// rectangle.
func countPixelDiff(a, b *image.RGBA, rect image.Rectangle) int {
	bounds := a.Bounds().Intersect(b.Bounds())
	n := 0
	for y := rect.Min.Y - 2; y < rect.Max.Y+2; y++ {
		for x := rect.Min.X - 2; x < rect.Max.X+2; x++ {
			if !(image.Point{X: x, Y: y}).In(bounds) {
				continue
			}
			ar, ag, ab, _ := a.At(x, y).RGBA()
			br, bg, bb, _ := b.At(x, y).RGBA()
			if ar != br || ag != bg || ab != bb {
				n++
			}
		}
	}
	return n
}
